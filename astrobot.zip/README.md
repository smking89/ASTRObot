# AstroBot

A Discord.js v14 server-management and gaming bot for Rust Console communities: economy, casino
mini-games, WebRCON telemetry, killfeeds, zone/raid protection alerts, teams, LFG, tickets,
licensing and a developer console — all driven by slash commands, panels and message components.

> Server configuration lives in one panel layer; every parent command opens its panel, and every
> subcommand jumps straight into the matching control screen.

---

## Requirements

- Node.js **22+** (tested on 22.23.4). The project uses the built-in `node:sqlite` module, so the
  npm scripts pass `--experimental-sqlite`.
- A Discord application with a bot token.
- Privileged intents enabled in the Developer Portal: **Server Members** and **Message Content**
  (the latter is required by the Frank FAQ keyword listener).
- Network access from the bot host to your Rust servers' WebRCON ports.

## Quick start

```bash
cp .env.example .env        # fill in DISCORD_TOKEN, DISCORD_CLIENT_ID, DEVELOPER_IDS
npm install
npm run migrate             # create ./data/astrobot.db and apply schema.sql
npm run deploy              # register slash commands (dev guild if set, else global)
npm start
```

For development use `npm run dev` (Node `--watch`). If `DISCORD_DEV_GUILD_ID` is set, `npm run deploy`
registers commands to that guild instantly; otherwise global registration can take up to an hour.

## Environment

| Variable | Required | Purpose |
| --- | --- | --- |
| `DISCORD_TOKEN` | yes | Bot token |
| `DISCORD_CLIENT_ID` | yes | Application ID used for command registration |
| `DISCORD_DEV_GUILD_ID` | no | Fast command registration to one test guild |
| `DASHBOARD_PASSWORD` | no | Enables dashboard login sessions + CSRF. Required before binding `DASHBOARD_HOST` off loopback |
| `DEVELOPER_IDS` | recommended | Comma-separated user IDs with the `developer` tier (`/dev`) |
| `OFFICIAL_GUILD_ID` | no | Enables `/leaderboards official` and cross-server hubs |
| `DEVELOPER_LOG_CHANNEL_ID` | recommended | Receives stack traces, RCON failures, task errors |
| `DATABASE_PATH` | no | SQLite file (default `./data/astrobot.db`) |
| `BOT_ENCRYPTION_KEY` | recommended | 32+ chars; AES-256-GCM key for RCON passwords at rest |
| `LOG_LEVEL` | no | `debug` / `info` / `warn` / `error` |
| `COMMAND_TIMEOUT_MS` | no | Interaction budget (default 15 min) |
| `ENABLE_BACKGROUND_JOBS` | no | Toggles RCON, scheduler, playtime and webhook loops |
| `ENFORCE_GUILD_APPROVAL` | no | Require `/dev guild approve` before a guild can use the bot |
| `TIP4SERV_API_KEY` / `TIP4SERV_WEBHOOK_SECRET` | no | Storefront integration + HMAC verification |
| `TIP4SERV_WEBHOOK_PORT` / `TIP4SERV_WEBHOOK_PATH` | no | Local webhook listener (default `8080`, `/tip4serv/webhook`) |
| `RCON_DEFAULT_HOST` / `RCON_DEFAULT_PORT` | no | Defaults for new server records |
| `RCON_RECONNECT_MS` | no | Reconnect backoff |
| `PLAYTIME_COIN_*`, `NITRO_BOOSTER_MULTIPLIER`, `DEATH_PENALTY_PERCENT` | no | Economy defaults (guild settings override) |
| `WEB_BASE_URL` | no | Dashboard origin linked from `/game-forge` and `/dev directory setup` |
| `BRAND_LOGO_URL` | no | Public https image used as the embed footer icon (fallback: bot avatar) |
| `BRAND_COPYRIGHT` | no | Footer copyright line (default `© <year> AstroBot. All rights reserved.`) |

Without `BOT_ENCRYPTION_KEY`, RCON passwords are stored with a `plain:` prefix and a warning is
logged at boot. Set the key before connecting real servers.

## Branding

Every embed built by `src/ui/embeds.js` gets a footer with the copyright line, so panels, feeds,
alerts and error reports stay consistent. The upper-right thumbnail and upper-left author area are
left empty unless a feature supplies its own artwork or author. The footer icon is `BRAND_LOGO_URL`
when set; otherwise it falls back to the bot's avatar (resolved on ready). Discord renders that icon
at a fixed ~20px, so a tightly cropped square logo reads much better than a wide padded image.

The same builder normalises text everywhere: slash commands such as `/link` become inline code and
known `#channel-name` references become clickable channel mentions. The channel lookup is installed
on client ready from the channel cache; unknown names are left exactly as typed.

Discord only accepts http(s) URLs for footer icons, so a local file path cannot be used. To brand
the bot, either upload the logo as the application icon in the Developer Portal, or host it and set
`BRAND_LOGO_URL=https://.../logo.png`. Override `BRAND_COPYRIGHT` to change the copyright text.

## Layout

```
src/
  index.js                 boot: env -> db -> loader -> client -> jobs
  config/                  env, constants, default guild settings, settings schema
  core/                    loader, registry, router, context, permissions, rate limits,
                           panel-kit, reporter, logger, errors, client, runtime
  commands/                one folder per parent command, one file per subcommand
  components/              button/select/modal handlers, id = "ab:<handler>:<args>"
  panels/                  embed + component builders, one file per panel
  db/                      schema.sql, connection, repositories/
  services/                economy, progression, playtime, scheduler, backup, kits,
                           Tip4Serv, moderation helpers
    games/                 blackjack, uno, dice, slots, wheel, tower, mines, crash, plinko, roulette,
                           lootbox, defuse, minefield, recycler, range, scratch, challenge
    rcon/                  client, parser, manager, killfeed, protection, telemetry
  ui/                      embed/component builders, settings view, game views
  events/                  ready, guildCreate, messageCreate (Frank FAQ)
  utils/                   object, format, parse, random, crypto, async
scripts/                   deploy-commands, check, smoke, migrate
```

## Command architecture

The loader is strictly file based — there is no central command switch:

- `src/commands/<name>/index.js` — parent command metadata (`name`, `label`, `description`,
  `access`, `panel`). The parent is what owns the category panel.
- `src/commands/<name>/<sub>.js` — one subcommand per file (`name`, `description`, optional
  `configure`, `execute`).
- `src/commands/<name>/<group>/<sub>.js` — nested subcommand group; `_group.js` supplies its
  description.
- `src/commands/<name>.js` — standalone top-level command exporting a `SlashCommandBuilder` as
  `data` plus `execute`.
- `src/panels/<id>.js` — exports `{ id, public?, render({ ctx, params }) }`.
- `src/components/<id>.js` — exports `{ id, access, execute(ctx) }`.

Because Discord refuses to invoke a parent that has subcommands, the loader appends a synthetic
`panel` subcommand to every parent that declares a panel (except where a real `panel` subcommand
already exists, e.g. `/staff panel`). The router also still handles a bare parent interaction if
one arrives from an API client.

### Dual-route behaviour

| Interaction | Result |
| --- | --- |
| `/config panel` (or bare parent via API) | Main Server Configuration Panel |
| `/config shop` | Opens that section directly, bypassing the root menu |
| `/play` | Games Panel |
| `/team` | Team panel or the no-team view |

### Adding a command

```js
// src/commands/config/example.js
import { SlashCommandSubcommandBuilder } from 'discord.js';

export default {
  name: 'example',
  description: 'Example configuration section.',
  configure: (sub) => sub.addStringOption((o) => o.setName('value').setDescription('New value')),
  async execute(ctx) {
    await ctx.panel('config', { section: 'misc', notice: 'Example saved.' });
  },
};
```

No registration step is needed: the loader discovers the file, validates names/descriptions, and
attaches it to the parent's payload.

## Command dictionary

### Parent commands (13)

| Command | Access | Subcommands |
| --- | --- | --- |
| `/config` | restricted | `battle-pass`, `shop`, `economy`, `events`, `misc`, `staff`, `killfeed`, `rules`, `features`, `messages`, `frank`, `clan`, `backup`, `template`, `panel` |
| `/partner` | admin | `request`, `status` |
| `/set` | restricted | `pricing`, `channel`, `message`, `style`, `roles`, `lfg`, `panel` |
| `/server` | admin | `manage`, `backup`, `template`, `panel` |
| `/team` | player | `create`, `manage`, `invite`, `leave`, `config`, `war`, `orp`, `panel` |
| `/lfg` | player | `create`, `browse`, `manage`, `close`, `panel` |
| `/coins` | player | `balance`, `send`, `panel` |
| `/referral` | player | `create`, `redeem`, `leaderboard`, `panel` |
| `/leaderboards` | player (official sub: `official`) | `referrals`, `official`, `panel` |
| `/staff` | restricted | `panel`, `recruit` |
| `/mod` | staff | panel only |
| `/dev` | developer | `ads`, `guild approve`, `guild revoke`, `guild list`, `directory setup`, `membership grant`, `membership revoke`, `license list`, `license revoke`, `panel` |
| `/license` | player | `activate`, `manage`, `transfer`, `panel` |

### Standalone commands (20)

Players: `/battle-pass`, `/bounty`, `/card-style`, `/challenge`, `/claim`, `/features`, `/freeroles`,
`/link`, `/unlink`, `/market`, `/play`, `/progression`, `/shop`, `/support`.

Administrators: `/give`, `/giveaway`, `/kit-panel`, `/market-panel`, `/onboarding`, `/player-panel`,
`/poll`, `/giveaway-portal`, `/reaction-roles`, `/shop-mint`, `/shop-panel`, `/game-forge`.

Superadmin: `/white-label` (developer only; backs up the database before rebranding).

`/link` and `/unlink` are intentionally not subcommands: linking verifies the gamertag against the
live `playerlist` of a connected server before storing it. `/create-lfg` no longer exists — use
`/lfg create`.

## Permissions

Tiers, lowest to highest: `player` → `team` → `staff` → `admin` → `restricted` → `developer`.
`official` is a separate guild-scoped tier. Guild owner and `DEVELOPER_IDS` hold every tier;
members with the Discord **Administrator** permission pass `restricted` (unless
`access.strictRestricted` is enabled).

Checks are enforced in three places:

1. **Router** — every slash command and subcommand entry declares `access`; the router rejects the
   interaction before dispatch.
2. **Subcommand / handler** — handlers can add Discord permission bits (`permissions`) and
   domain checks (e.g. team ownership).
3. **Components** — button, select and modal handlers re-resolve grants from the member on every
   click (`ab:<handler>:<args>`); custom IDs never carry authority.

Panels also declare an `access` tier through their owning command; panel-scoped buttons route back
through the same component permission pass.

## Economy

- Wallet vs Safe Bank: cash can be lost on death, bank cannot. `/coins balance`, `/coins send`,
  deposits and withdrawals live in the Currency Panel.
- Currency scope: **Local** keeps the wallet in one server, **Global** shares it across every
  AstroBot server, and **Partner** shares it with servers linked through an accepted partnership.
  Set the scope in `/config` → **Shop**, or accept a partnership to switch both servers to the
  shared partner network automatically. Accepted partnerships can post a public announcement in both servers from `/config` → **Partnerships**. Switching from local to global/partner carries the server's existing local wallet balances into the shared bucket; switching back to local does not split shared balances apart.
- Minted currency: enable **Minted currency** in `/config` → **Feature switches** or **Shop**.
  Once enabled, only the configured game/event/daily/kill/playtime/shop sources can create coins;
  `/give` and `/shop-mint` reject manual grants, including from the server owner.
- Supply controls: wallet caps, minting and burning from `/shop-mint`; all movements write a
  `transactions` row.
- Shop catalog: `/shop` supports text search and previews the selected product image. Quick setup
  hides Tier 3 items and explosives by default; both can be included with the two toggles. Products
  can be deleted individually, or the whole shop can be cleared and disabled from `/shop-panel` or
  the web dashboard. The dashboard **Currency** page shows the active scope, minted mode, mint
  sources, supply and top wallets.
- Playtime coins: background loop (default every 10 minutes) with Nitro Booster multiplier,
  configured per guild.
- Kill rewards differentiate player and scientist victims; death penalties subtract a percentage
  of wallet only.
- Bounties, daily streaks, referrals, battle pass and progression all feed the same account row.
- Tip4Serv webhook verifies `HMAC-SHA256(raw body)` with `TIP4SERV_WEBHOOK_SECRET`, deduplicates
  transaction IDs, then delivers coins, kits, roles or the premium battle pass.
- The premium battle pass is a real-money product. Set **Premium checkout URL** to the server
  owner's store page (or Tip4Serv product page) and **Tip4Serv premium product ID** to the product
  the webhook should treat as premium. `/battle-pass` then links buyers straight to checkout; they
  enter their Discord ID and the signed webhook sets `battle_pass.premium` automatically. Premium
  costs no coins by default — the legacy coin path only appears when **Allow coin purchase** is
  explicitly enabled with a coin price.

`/rules` (staff) posts the configured rules embed: bold rules text, `{support}` resolved to the
configured **Rules support channel** (falling back to the ticket channel), the embed timestamp, and
a footer carrying the configured copyright and brand icon. Edit the title, text, copyright, support
channel and default channel with `/config rules` (or under `/config` → **Server Rules**).

## LFG, partnerships and feature switches

- `/lfg` is either **local** (one server) or **global** (every server that has LFG enabled and has
  chosen the global scope). Global listings show their origin server; `/set lfg` and `/config` →
  **Looking for Group** control the scope, channel and party limits.
- `/partner request` opens a modal for brand name, duration, value proposition and a target guild
  ID, invite link or channel. The bot records the source server's live member count when the form
  is submitted, then posts an Accept/Decline card in the target's partnership inbox (or DMs its
  owner). Accepting links both economies into one partner network; declining notifies the requester.
  `/partner status` lists the server's requests. Configure the inbox and minimum member gate under
  `/config` → **Partnerships**.
- `/config features` opens a single dropdown of the major systems. Selecting a switch toggles it
  immediately; every change is applied and audited, so owners can turn off a feature without
  editing JSON.

## Player Marketplace

`/market` is a player-to-player marketplace for inventory items, kits and Discord roles. The server
owner turns it on and chooses the currency label, fee, delivery-lock minutes, listing types and VIP
role from `/config` → **Player Marketplace**. Balances use the existing economy wallet, so a minted
currency can be reused as the marketplace currency.

- Sellers list an owned asset as **Buy now**, **Auction** or **On sale**. Auctions accept bids and
  settle through the background job; a failed settlement is marked expired without charging the
  bidder.
- The bot blocks self-purchases and any trade where the buyer and seller share a team or clan. That
  check runs when a listing is bought and again when an auction settles.
- Purchased kits and roles receive a delivery lock (default **1 minute**, configurable, or `0` to
  disable). The seller's lock is cleared when the sale completes and the buyer's fresh lock is
  recorded; locked assets cannot be relisted. Roles are granted at purchase time, so the lock
  prevents immediate resale rather than delaying the role grant.
- The configured fee is deducted from the sale and credited to the server treasury account. The
  treasury balance is visible in `/market-panel`.
- VIP members get the VIP price (or the automatic VIP discount) and the VIP fee. Configure the VIP
  role, currency label, fee and discount in `/config` → **Player Marketplace**. `/market-panel`
  shows volume, fees, active listings, recent sales and top sellers; use **Marketplace settings** to
  change the fee, lock, currency or listing modes.

## Onboarding suite

`/onboarding` is the staff overview for the community suite. All features are configured from
`/config` → **Onboarding & Welcome**, **Onboarding Leaver & Channels** and **Onboarding Roles &
Events**.

- **Welcomer** posts a configurable embed to the welcome channel and can also send a DM. Tokens:
  `{user}`, `{username}`, `{server}`, `{memberCount}`; an optional image URL or the server banner is
  used for artwork.
- **AutoRoles** grants configured roles on join, with an optional delay.
- **Borderwall** posts a button challenge and grants the verified role when completed. Unverified
  members can be kicked after the configured timeout.
- **FreeRoles** (`/freeroles`) lets members self-assign configured roles up to a maximum.
- **Reaction/Button Roles** posts a persistent role menu from `/reaction-roles`; choices are
  configured as `{roleId, label, emoji}` entries and members toggle them from the message.
- **Giveaways** are created from `/giveaway` with a prize, winner count and duration. Entries use a
  button and winners are drawn automatically when the timer expires.
- **Polls** (`/poll`) create durable button polls with 2–10 answers, a configurable duration and
  stored ballots. Open `/poll` with no question for the admin panel: basic analytics show totals,
  and advanced analytics show each voter's Xbox Gamertag / PSN ID, rival score, clan tag, team tag
  and clan rank.
- **Astro Pro giveaway portal** (`/giveaway-portal`) gives subscribers a branded public giveaway
  page using the Astro cyan/magenta/lime palette. The builder stores copy, prize, tasks, countdown
  and section choices in SQLite; access requires an active membership, the configured Pro role or a
  Pro server plan. Set `DASHBOARD_PUBLIC_URL` to the public dashboard origin. The official guild
  template also creates `#✨・astro-features` and posts the feature guide there.
- **Managed giveaway pages** live in the dashboard's Giveaways panel: create, edit and delete
  giveaways, choose a username for `<username>.giveaway.astro.com`, publish a Linktree-style
  `/links` page, set per-giveaway colours, and track views, entries, conversion and link clicks.
  Public entries collect an email plus gamertag, PSN ID or Steam username and a region, and are included in the automatic draw alongside Discord entries,
  and each giveaway can define its own public bonus tasks that add persisted tickets. Managers
  can export public and Discord entrants as one CSV and manually check or automatically monitor
  DNS/TLS/Host health from the giveaway row, with saved check history, acknowledgeable dashboard
  alerts, and per-task claim/ticket analytics. Set `GIVEAWAY_ALERT_WEBHOOK_URL` to also post
  failure/recovery notices to a Discord webhook. See
  [Giveaway subdomain setup](docs/giveaway-domains.md) for wildcard DNS and TLS. Use `/features`
  for the full feature catalogue.

- `/white-label` is a developer-only command that snapshots the SQLite database first, then
  changes the global brand name, favicon, wordmark image and colour scheme used by the bot and
  dashboard. Run it again with `reset:true` to return to AstroBot defaults. The same controls are
  available at `/white-label` in the dashboard, with a live preview and transparent PNG/SVG favicon
  and wordmark uploads; every screen save also creates a backup before writing.
- **Leaver** posts a farewell when a member leaves; **Rules on join** can send the configured rules
  embed to a channel or by DM.
- **TempChannels** creates a voice channel when a member joins the configured hub and deletes it
  when it becomes empty.
- **TimeRoles** grants configured roles after members have stayed the configured number of minutes.
- **Server analytics** in `/onboarding` shows joins, leaves and a 14-day growth strip; the existing
  `/analytics` panel continues to show RCON session retention.

## Games & wagers

`/play` opens the Games Panel: Blackjack, UNO, Dice, Spin Wheel, Treasure Slots, Tower Climb,
Mines, Astro Crash, Plinko, Roulette, Lootbox, The Defuse Wire, The Grid Minefield, The Ticket
Jackpot, The Recycler Roulette, The Target Range and four scratch cards: Radiation Rush, High-Voltage
Grid, The Royal Vault and The Scrap Pile. Scratch cards pre-generate a 3x3 grid with exactly three
target symbols; every scratch reveals one cell and the round ends when the third target appears. The
payout ladder is highest when the card completes in three scratches and tapers to a partial return on
the ninth. Sessions live in the runtime registry; wagers are debited
up front and payouts credited once (`settled` guard). Crash is advanced by a background loop so its
multiplier climbs in the message; its 30-second round settles automatically or when the player cashes
out. Slots, Wheel and Crash feed the persistent per-guild progressive jackpot, which is funded by a
small rake and resets after a win. The pool widget shows tuned per-game odds and a durable winner
history. Administrators can tune the jackpot seed, minimum payout, rake, per-game odds and milestone
threshold from `/play` → **Configure** → **Jackpot**. Set the milestone alert channel under
`/config` → **Games**; the bot announces once whenever the pool crosses the threshold. The dashboard
shows the pool and recent winners read-only and does not host playable games. `/challenge` escrows
both wagers and posts an accept/decline card;
expired challenges are refunded by the background sweeper. `/card-style` selects the deck/card back
stored in player preferences.

UNO and Blackjack render real card art from `assets/cards/`: the UNO sprite sheet supplies number,
action, wild and draw-four faces plus the standard back, while Blackjack uses the individual
52-card PNG set. `/card-style` offers the three shipped card backs (Classic Red, Astro Blue and
Nebula Green) with a live preview of the selected art; each deck also chooses its matching table
artwork, and UNO uses the chosen back for the house hand unless an admin uploads `uno_back`.
UNO exposes a playable-card selector; selecting a wild card opens Red, Yellow,
Green and Blue color controls before the card is committed. Administrators can upload custom game
artwork with `/game-asset`: choose a game and a `cover`, `win` or `lose` slot, and attach a
PNG/JPEG/WebP up to 4 MB. UNO also accepts `uno_back` for the house hand card back and `uno_table`
for the table background. Run `/game-asset` without an image to list the server's uploads, or add
`remove:true` to delete a slot.

The Jackpot panel also runs a separate three-place raffle. Administrators configure **Prizes &
tickets** from the panel: choose fixed prizes for 1st/2nd/3rd or shares of the raffle pool, and define
custom ticket tiers with a cost and entry weight. Bronze, Silver and Gold tiers are included by
default. Tickets are paid in the guild currency, each tier adds its configured entries, and the pool
is funded by ticket sales. The panel's **Alert channel** shortcut opens a native channel picker for
jackpot milestone announcements without leaving the games flow. A draw pays the configured places and
requires at least three different ticket holders.

Every solo game and 1v1 game can also have an optional random **game prize pool**. Pools are disabled
by default; when enabled, a win credits one amount chosen at random from that game's configured list.
Open `/play` → **Configure** → **Prize pools** and edit the JSON map, for example
`{"blackjack":{"enabled":true,"prizes":[100,250,500]}}`. The base game payout and progressive
jackpot are unchanged; the pool prize is a separate `game_prize_pool` transaction.

## RCON, telemetry and protection

- Add servers with `/server manage` (label, host, port, password). Passwords are encrypted with
  `BOT_ENCRYPTION_KEY`; credentials are never exported by backups.
- The manager keeps one WebRCON connection per enabled server, reconnects with backoff, and fans
  frames out to the parser.
- The live `global-players-queue` and per-server `players-queue` lines are backed by SQLite. Every
  `serverinfo` poll updates `server_live_stats`, and the five-second publisher reads the aggregate
  from the database, ignores snapshots older than two minutes, and persists each channel message id
  in `stats_channel_messages` so restarts edit the existing line instead of posting a duplicate.
- Killfeed layout is a template with `{killer}`, `{victim}`, `{weapon}`, `{distance}`, `{grid}`,
  `{killer_clan}`, `{victim_clan}`, `{killer_id}`, `{victim_id}`, `{server}`, `{time}`. Clan tokens
  accept `{clan}`, `[clan]` and `[{clan}]`; empty clans never leave `[]`.
- Helios-style live placeholders work in the local and global killfeed layouts:
  `{KillerPlayerName}`, `{VictimPlayerName}`, `{KillerKills}`, `{KillerDeaths}`,
  `{KillerCurrentStreak}`, `{KillerBestStreak}`, `{KillerKD}`, `{KillerStreak}`,
  `{VictimKills}`, `{VictimDeaths}`, `{VictimCurrentStreak}`, `{VictimBestStreak}`, `{VictimKD}`,
  `{VictimStreak}`, `{KillerWallet}`, `{VictimWallet}`, `{KillerXP}`, `{VictimXP}`, `{KillerLevel}`,
  `{VictimLevel}`, `{KillerRank}`, `{VictimRank}`, `{KillerRivalPoints}`, `{VictimRivalPoints}`,
  `{KillerClanTag}`, `{VictimClanTag}`, `{KillerTeamTag}`, `{VictimTeamTag}`, `{KillerTeamName}`,
  `{VictimTeamName}`, `{Currency}`, `{Stolen}` and `{Distance}`. Rank tokens give the name only, which
  is all in-game text can carry; enable **Post killfeed as embeds** and the killer's real rank badge PNG
  is attached as the embed thumbnail.
  PvP tokens are `{KillerPvPKills}`, `{KillerPvPDeaths}`, `{KillerPvPKD}` plus the victim trio; PvE
  tokens are `{KillerPvEKills}`, `{KillerPvEDeaths}`, `{KillerPvEKD}` plus the victim trio. Both K/D
  ratios round to two decimals and use their own kill/death groups. `{Distance}` is killer-to-victim
  metres when a position is tracked, otherwise `Mystery Box`. `{Stolen}` is the wallet amount taken
  from the victim by that kill. Unknown tokens are left untouched so template typos stay visible.
- Telemetry routes joins, leaves, kills, suicides, chat, structure damage and server status to the
  configured channels, awards kill coins/XP, and pushes RaidLink alerts to a team's private channel.
- ZORP reduces damage for offline teams inside their registered zone; SRP blocks raiding outside
  configured UTC windows. Both are evaluated per damage event.
- The scheduler runs stored tasks (console commands, restarts, broadcasts, wipe notices) and the
  night-skip vote tracker.

> RaidLink attribution depends on the server's damage log naming the structure owner ("owned by X").
> Without an owner in the log line, damage is still forwarded to the defending team channel but
> cannot be attributed to a specific clan.

## Scripts

| Command | Purpose |
| --- | --- |
| `npm start` | Run the bot |
| `npm run dev` | Run with `--watch` |
| `npm run migrate` | Apply `schema.sql`, list tables |
| `npm run deploy` | Register slash commands |
| `npm run check` | Load every module and validate the command tree (no Discord connection) |
| `npm run smoke` | In-memory runtime test: economy, XP, parser, killfeed, protection, all game engines, every panel render, a settings edit |
| `npm run package` | Rebuild `astrobot.zip` without secrets, runtime data or dependencies |
| `npm run package -- --check` | Validate the existing `astrobot.zip` without rebuilding it |
| `npm run audit-panels` | Audit every registered panel and deploy missing entry panels (`-- --deploy`) |
| `npm run deploy:global-killfeed` | Create/configure the global killfeed channel for the selected guild |

`check` and `smoke` run without a token and are safe in CI.

## Data model

SQLite (WAL) through `node:sqlite`, repositories in `src/db/repositories/`. Tables: `guilds`,
`guild_settings`, `settings_audit`, `players`, `player_links`, `player_prefs`, `transactions`,
`inventory`, `teams`, `team_members`, `team_invites`, `team_wars`, `lfg_posts`, `referrals`,
`referral_claims`, `licenses`, `bounties`, `battle_pass`, `servers`, `scheduled_tasks`,
`telemetry_events`, `mod_cases`, `memberships`, `tickets`. Settings are JSON documents with an
audit trail; every mutation goes through `patchGuildSetting`.

`schema.sql` is applied idempotently with `CREATE TABLE IF NOT EXISTS`. Versioned migrations in
`src/db/migrations/` run once each, inside a transaction, and are recorded in `schema_migrations`;
add a numbered `.sql` file there for any column or table added to an existing deployment.

## Plans and billing

AstroBot is sold per guild. Basic is free forever, Pro is **$12/month or $120/year**, and Max is
**$29/month or $290/year**. Yearly billing includes two months free. A guild may start the
**14-day Pro trial once**; the trial is recorded in `plan_trials` and cannot be reset by leaving and
re-installing the bot.

| Feature | Basic — Free | Pro — $12/mo | Max — $29/mo |
| --- | --- | --- | --- |
| Discord servers | 1 | 1 (+$6/mo each) | 5 (+$6/mo each) |
| Rust/RCON servers | 1 | 3 | 10 |
| Core bot | Included | Included | Included |
| Games | Core set | Full suite + jackpot/raffle | Full suite + network events |
| RCON/killfeed | Basic live stats | Full telemetry + filters | Network-wide telemetry |
| Discord giveaways | 1 active | 5 active | 15 active |
| Hosted giveaway pages | — | 1 page · 5k entrants | 5 pages · 25k entrants |
| Branding | AstroBot | Logo, colours & FAQ | Full white-label |
| Analytics | 14 days | 90 days + CSV | 365 days + network |
| Scheduled tasks | 3 | 25 | 100 |
| Server templates | 1 | All templates | All + custom |

Support is identical on every plan. There is no paid priority queue and no faster-response tier.

Limits are enforced where the resource is created: adding an RCON server, scheduling a task, saving a
template, creating a Discord giveaway, creating or reactivating a hosted giveaway page, accepting
page entries, opening the jackpot/raffle, and exporting CSV. The dashboard reports the guild's plan
and analytics window, and the hosted-page routes return 403 once a guild no longer has Pro or Max.

Each Pro/Max membership carries Discord-server seats: Pro starts with 1 and Max with 5. An extra
server is **$6/month or $60/year** on either plan, delivered as one additional seat. The server owner
attaches a server with `/plan` on that server, releases a seat from the same panel, and moves the
subscription from another server with `/transfer` (or `/plan` → **Move a seat here**). The billing
owner is recorded on `guilds.plan_owner_id`; the seat count lives on `memberships.server_limit`.

Assign a paid plan manually with `/dev plan assign guild:<id> plan:<pro|max> owner:@buyer days:<n>`.
The owner is required for Pro/Max so the Discord-server seat allowance is enforced. Tip4Serv
purchases apply the plan to the guild in the signed payload and record the buyer as the owner. Grant
a free trial to a player with:

```
/dev plan grant user:@player plan:<pro|max> duration:<lifetime|14|30|custom> servers:<n> [days:<n>]
```

`servers` defaults to the plan's included seat count. The grant also updates any servers already
attached to that player, releasing extras beyond the new seat count. Dashboard branding remains
installation-wide, so full per-tenant white-label is limited to hosted giveaway pages until the
network branding layer ships.

## Known limitations

- **Bare parent commands cannot be sent by Discord** when the command has subcommands. This is a
  Discord platform rule; AstroBot mitigates it with the generated `panel` subcommand and router
  fallback.
- Backups export settings plus informational structure metadata and restore **settings only**; they
  do not recreate channels or roles.
- The web dashboard, case-battle lobby, node/entity spawn tool, prison and granular wipe controller
  are represented by data/services but do not yet have shipped panels. `/game-forge` links to the
  website builder.
- The marketplace reuses the server economy wallet for all listings; the `marketplace.currency` and
  `marketplace.vip.currency` values are labels for that same balance, not separate currency ledgers.
- Card decks ship as presets; custom canvas upload is not rendered server-side.
- Global command propagation can take up to an hour after `npm run deploy`.

## Scheduled announcements, checkout and portal entries

- `/announcements` (also in the Staff, Admin and Owner hubs) schedules a message for a calendar date
  and clock time, delivered to a Discord channel, the game console through RCON, or both. `once`,
  `daily` and `weekly` repeat modes are supported; paused announcements can be resumed or sent
  immediately, and the Discord channel can be changed from the panel.
- `/checkout` shows Basic, Pro and Max, the guild's current plan and trial state. Set the four plan
  checkout URLs plus the extra-server monthly/yearly URLs and all six Tip4Serv product ids in
  `/config` → **Checkout**; the signed webhook applies plans and grants one extra-server seat per
  Tip4Serv subscription. Renewal webhooks reuse that subscription and do not stack another seat.
- `/plan` is the self-serve seat manager: attach this server, release it, or move a seat here. `/transfer`
  does the same move from a source-server picker and is restricted to the server owner.
- Licenses belong to the Discord account, not a server. `/license activate` turns a key into the
  account's Pro or Max membership, `/plan` attaches its seats to servers the account owns, and
  `/license transfer` moves the plan and seats to another account. Legacy `standard` licenses map to Pro;
  `enterprise` licenses map to Max.
- `/giveaway-entry` issues a personal portal link. Opening it on the public giveaway page records an
  entry against the same giveaway the Discord button feeds. Winner announcements go to the channel
  configured in `/config` → **Onboarding Roles & Events** and can also be sent in game.
- Polls close automatically when their timer expires: the message is refreshed with final results and
  a results embed is posted in the poll channel.
