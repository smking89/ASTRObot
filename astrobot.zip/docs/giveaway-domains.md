# Giveaway subdomain setup

Dashboard-managed giveaways can use `https://<username>.giveaway.astro.com` as well as the
local fallback `/g/<username>`. The app already resolves the subdomain from the `Host` header;
only DNS, TLS and the reverse proxy live outside this repository.

## 1. Point wildcard DNS at the dashboard host

Create a wildcard DNS record for the giveaway domain:

| Type | Name | Value |
| --- | --- | --- |
| `A` | `*.giveaway` | the dashboard server's public IPv4 address |
| `AAAA` | `*.giveaway` | the dashboard server's public IPv6 address, if used |

If DNS is managed by Cloudflare, use a proxied wildcard record (`*.giveaway` → dashboard
origin). Do not create a separate record for every username; new giveaways must work without
waiting for DNS propagation.

## 2. Terminate TLS for the wildcard

The reverse proxy needs a certificate that covers `*.giveaway.astro.com` plus the base domain.
Let's Encrypt supports wildcard certificates through a DNS-01 challenge. Configure your ACME
client (Caddy, certbot DNS plugin, Traefik or the hosting provider) to renew it automatically.

Caddy example:

```caddyfile
giveaway.astro.com, *.giveaway.astro.com {
  reverse_proxy 127.0.0.1:4173
}
```

Nginx example:

```nginx
server {
  listen 443 ssl http2;
  server_name giveaway.astro.com *.giveaway.astro.com;

  ssl_certificate     /etc/letsencrypt/live/giveaway.astro.com/fullchain.pem;
  ssl_certificate_key /etc/letsencrypt/live/giveaway.astro.com/privkey.pem;

  location / {
    proxy_pass http://127.0.0.1:4173;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
  }
}
```

The dashboard must bind to a reachable interface when it is behind a proxy. Keep the dashboard
password set whenever it is not loopback-only:

```env
DASHBOARD_HOST=0.0.0.0
DASHBOARD_PASSWORD=<strong-password>
GIVEAWAY_ROOT_DOMAIN=giveaway.astro.com
GIVEAWAY_PUBLIC_PROTOCOL=https
```

## 3. Verify routing before announcing a giveaway

With the server running, replace `astrotest` with the username shown in the admin panel:

```bash
curl -I -H 'Host: astrotest.giveaway.astro.com' http://127.0.0.1:4173/
curl -I -H 'Host: astrotest.giveaway.astro.com' http://127.0.0.1:4173/links
curl -I -H 'Host: astrotest.giveaway.astro.com' http://127.0.0.1:4173/go/0
```

Expected results: `200` for `/` and `/links`, and `302` for `/go/0` when that link exists. Through
the public proxy, also check:

```bash
curl -I https://astrotest.giveaway.astro.com/
curl -I https://astrotest.giveaway.astro.com/links
```

The app uses `Host` to find the giveaway, so the proxy must preserve the original host
(`proxy_set_header Host $host` in Nginx, which Caddy does by default).

The admin **Domain check** button runs the same DNS lookup, a local Host-routing probe, and a
public HTTPS request for the selected giveaway. Results are saved as a health snapshot. Active
giveaways are also rechecked every 15 minutes in the background (override with
`GIVEAWAY_DOMAIN_MONITOR_MS`), and the latest status appears beside each giveaway.

Each giveaway keeps its recent check history, and active domains with a failing status appear in
the manager alert banner. Acknowledge an alert to suppress it until the domain recovers. Set
`GIVEAWAY_ALERT_WEBHOOK_URL` to a Discord webhook to receive notices when a domain starts failing or
recovers; alerts only fire on a status change. DNS and public HTTPS
will fail until the wildcard record and certificate are live; Host routing should pass as soon as
the app is running.

## Troubleshooting

- **The base domain works but every username returns 404:** the proxy is forwarding to the
  dashboard but not preserving the subdomain, or the wildcard DNS/TLS record is missing.
- **Browser shows a certificate warning:** the certificate does not cover the wildcard. Reissue it
  with a DNS-01 challenge.
- **`/g/<username>` works but the subdomain does not:** DNS or the proxy has not been updated; the
  app-side routing is already working and is the fallback during setup.
- **The giveaway was renamed:** update the public URL and any links you shared. Usernames are
  unique case-insensitively, but old subdomains do not redirect.

Local development does not need any of this: use `http://127.0.0.1:4173/g/<username>`.