# AstroBot Console — Tactical Dashboard & Daily Run Blueprint

Technical specification and file roadmap for the player dashboard rebuild. This
document describes structure and intent; it deliberately contains no source.

## 1. Brand system

- Canvas and every card, panel, metric and workspace box are pure white. The
  card header strips are white as well; no tinted panel sits behind them.
- Every structural surface and primary action carries a 2px solid black outline
  with square corners. Border radius is zero across the interface; only the
  round milestone checkpoints, status dots and toggle knobs stay circular.
- All text is jet black. Crimson is the only accent and appears on active
  navigation edges, the available capsule frame, the GRAB LOOT action, the
  progress fill, the JACKPOT label and the bank vault marker. Navigation group
  markers are black rather than multi-hued.
- Platform identifiers and technical metadata sit in solid black monospace
  pills with white text: the player's Discord ID at the top of the identity
  card is one, undisturbed IDs elsewhere are the same treatment.

## 2. Sidebar branding

- The anchor block is transparent: no container fill, no shadow, no mask behind
  it, on the white sidebar layer.
- A flat black D-pad mark sits to the left of a two-line wordmark. Line one is
  ASTROBOT in extra-bold uppercase with wide tracking. Line two is NETWORK
  CONSOLE in an ultra-small bold uppercase monospace.
- A single 1px black rule separates branding from the navigation tree and runs
  the full width of the column. The sidebar frame itself is 2px black.
- The active navigation tab is outlined in crimson, with a crimson inset anchor
  down its left edge.

## 3. Daily Run capsule matrix

### Header

One unified row only: Daily Run on the left, a right-aligned black monospace
label on the right reading the live streak and cycle. No duplicate sub-header
repeats the component name, and the label is a solid black pill with white text.

### Capsule geometry

- Seven vertical capsules of 104 by 168 pixels, each with a 2px black frame.
- Each capsule carries an aspect-locked 56 by 56 pixel art well, with the asset
  contained inside so nothing stretches. The weekly jackpot uses the same 56px
  well rather than a larger override.
- Top to bottom inside a capsule: day label, art well, reward name, then the
  state marker or action anchored to the bottom.
- The wrapper is a single horizontal overflow track. On desktop the capsules
  distribute across the full card width; below 760px the track becomes a
  snap-scrolling swipe deck with the next day peeking past the right margin.

### Run states

- Claimed: light grey wash with the day label, reward name and art held at 50%
  strength while the green SECURED marker stays crisp above the mask.
- Active: a 3px crimson frame around the capsule and a solid crimson GRAB LOOT
  button with bold white text, outlined in 2px black.
- Locked: 40% opacity across the day label, reward name and art, with a crisp
  flat black padlock centred in the art well.
- Weekly jackpot: dashed black outline, master chest at the standard 56px well,
  and a bold crimson JACKPOT sub-label.

## 4. Career milestone pipeline

- A lifetime progress pipe sits directly under the deck, introduced by Career
  Drops Secured on the left and the lifetime claim total on the right.
- The pipe is 14px tall with a 2px solid black frame, white interior and a
  crimson fill sized to lifetime claims.
- Round star checkpoints at 10, 25 and 50 are centred on the pipe itself. Earned
  checkpoints are solid crimson with a white check; unearned ones dim their star
  and pin a small lock.
- A footer line reports the claims remaining to the gilded checkpoint. The
  100-claim elite vault remains part of the reward engine and voucher flow but
  is not drawn as a fourth node.

## 5. Layout consequences

- The Daily Run card spans the full content column so seven capsules fit without
  compression; the paired hub grid auto-fits so lone cards stretch.
- Identity carries the ID pill, level, XP bar and a four-cell stat strip.
- Wallet and bank vaults split evenly, each with a 2px frame and a 3px top
  marker: black for the wallet, crimson for the bank.
- Arcade tiles and clan panels stay square, white and black-framed with the
  crimson focus applied only on hover and active state.

## 6. File roadmap

- `dashboard/public/style.css` — tokens, sidebar and brand anchor, black pill
  identifiers, white card headers, crimson active tabs, base card and button
  geometry.
- `dashboard/public/hubs.css` — capsule matrix, run-state masks, padlock
  overlay, milestone pipe and pins, vault, arcade and the final tactical frame
  pass that raises structural borders to 2px and forces square corners.
- `dashboard/public/app.js` — capsule and pipeline markup, header label,
  identity ID pill, claim wiring.
- `dashboard/public/index.html` — sidebar structure and the SVG D-pad mark.
- `src/services/economy-service.js` — unchanged reward ladder and thresholds
  that drive the visual states.

## 7. Acceptance checks

- Every asset well is square at 56px and no reward or badge image distorts.
- Cards, panels and primary buttons read as 2px black frames; corners are 0px.
- Claimed, active, locked and jackpot states are visibly distinct at their
  specified opacities and strokes.
- Pipe fill tracks lifetime percentage and all three pins sit on the pipe axis.
- Desktop shows the full capsule row; mobile scrolls with snap and a peek.
- Identifiers render as black monospace pills, and crimson remains the only
  accent hue in the dashboard.
