(() => {
  const links = () => document.querySelectorAll('link[rel~="icon"], link[rel="apple-touch-icon"]');

  fetch('/api/branding', { cache: 'no-store', credentials: 'same-origin' })
    .then((response) => (response.ok ? response.json() : null))
    .then((branding) => {
      if (!branding?.faviconUrl) return;
      links().forEach((link) => {
        link.href = branding.faviconUrl;
      });
    })
    .catch(() => {
      // The static Astro favicon remains in place when branding cannot load.
    });
})();
