let state = null;
let view = 'overview';
let guildId = '';
let search = '';
let toastTimer = null;

const TITLES = {
  overview: 'Overview',
  servers: 'Servers',
  players: 'Players',
  sessions: 'Sessions',
  shop: 'Shop & Economy',
  currency: 'Currency Dashboard',
  wipes: 'Wipe Scripts',
  templates: 'Templates',
  teams: 'Teams & Clans',
  clans: 'Badges & Ranks',
  bounties: 'Bounties',
  battlepass: 'Battle Pass',
  tasks: 'Scheduled Tasks',
  lfg: 'LFG Posts',
  tickets: 'Tickets',
  moderation: 'Moderation',
  audit: 'Audit Log',
  retention: 'Retention',
  status: 'Status & Uptime',
  settings: 'Settings',
  hubPlayer: 'Player Dashboard',
  hubMod: 'Moderator Dashboard',
  hubAdmin: 'Administrator Dashboard',
  hubOwner: 'Owner Dashboard',
};

const PRIORITIES = ['low', 'normal', 'high', 'urgent'];
const APPEALS = ['none', 'pending', 'approved', 'denied'];

const esc = (value) =>
  String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');

const num = (value) => Number(value ?? 0).toLocaleString();
const time = (ms) => (ms ? new Date(Number(ms)).toLocaleString() : '—');
const ago = (ms) => {
  if (!ms) return '—';
  const delta = Math.max(0, Date.now() - Number(ms));
  const hours = Math.floor(delta / 3_600_000);
  if (hours < 1) return `${Math.max(1, Math.floor(delta / 60_000))}m`;
  if (hours < 48) return `${hours}h`;
  return `${Math.floor(hours / 24)}d`;
};
const dateLocal = (ms) => {
  if (!ms) return '';
  const date = new Date(Number(ms));
  return new Date(date.getTime() - date.getTimezoneOffset() * 60_000).toISOString().slice(0, 16);
};
const fromLocal = (value) => (value ? new Date(value).getTime() : null);

function getPath(object, path) {
  return String(path).split('.').reduce((value, key) => (value == null ? undefined : value[key]), object);
}
function setPath(object, path, value) {
  const parts = String(path).split('.');
  let cursor = object;
  for (let index = 0; index < parts.length - 1; index += 1) {
    if (cursor[parts[index]] == null || typeof cursor[parts[index]] !== 'object') cursor[parts[index]] = {};
    cursor = cursor[parts[index]];
  }
  cursor[parts[parts.length - 1]] = value;
  return object;
}
function matches(...fields) {
  if (!search) return true;
  const needle = search.toLowerCase();
  return fields.some((field) => String(field ?? '').toLowerCase().includes(needle));
}
function toneFor(value, good = 'green', bad = 'red') {
  return Number(value) ? bad : good;
}

function metric(label, value, tone = '') {
  return `<div class="metric ${tone}"><span>${esc(label)}</span><strong>${esc(value)}</strong></div>`;
}
function card(title, badge, tone, body, footer = '') {
  return `<section class="card ${tone}">
    <header><strong>${esc(title)}</strong><span class="badge">${esc(badge)}</span></header>
    <div class="body">${body}</div>
    ${footer ? `<div class="card-foot">${footer}</div>` : ''}
  </section>`;
}
function table(headers, rows, empty = 'No records yet.') {
  const head = headers.map((header) => `<th>${esc(header)}</th>`).join('');
  const body = rows.length
    ? rows.map((row) => `<tr>${row.map((cell) => `<td>${cell}</td>`).join('')}</tr>`).join('')
    : `<tr><td colspan="${headers.length}" class="empty">${esc(empty)}</td></tr>`;
  return `<div class="table-wrap"><table class="table"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
}
function switchRow(action, id, checked, label = 'Enabled') {
  return `<label class="switch-row"><span>${esc(label)}</span><span class="switch">
    <input type="checkbox" data-toggle="${esc(action)}" data-id="${esc(id)}" ${checked ? 'checked' : ''} />
    <i></i>
  </span></label>`;
}
function empty(message) {
  return `<div class="empty">${esc(message)}</div>`;
}
function tag(text, tone = '') {
  return `<span class="tag ${tone}">${esc(text)}</span>`;
}

function renderOverview() {
  const o = state.overview;
  const feed = [
    ...state.moderation.cases.slice(0, 6).map((entry) => ({
      at: entry.created_at,
      tone: 'red',
      text: `${entry.action} · ${entry.target_id} by ${entry.moderator_id}`,
    })),
    ...state.tickets.open.slice(0, 5).map((entry) => ({
      at: entry.created_at,
      tone: 'orange',
      text: `Ticket “${entry.subject}” opened by ${entry.owner_id}`,
    })),
    ...state.shop.purchases.slice(0, 5).map((entry) => ({
      at: entry.created_at,
      tone: 'teal',
      text: `${entry.user_id} bought ${entry.quantity}× ${entry.product_id} for ${num(entry.price)}`,
    })),
    ...state.audit.slice(0, 6).map((entry) => ({
      at: entry.created_at,
      tone: 'purple',
      text: `Settings · ${entry.key} changed by ${entry.actor_id}`,
    })),
  ]
    .sort((a, b) => Number(b.at) - Number(a.at))
    .slice(0, 12);

  const serverRows = state.servers
    .map(
      (server) => `<div class="status-row">
        <div class="name"><strong>${esc(server.label)}</strong><span>${esc(server.host)}:${esc(server.port)}</span></div>
        <div>${tag(server.current, server.current === 'online' ? 'online' : 'offline')}</div>
        <div>${num(server.players)} online</div>
        <div><div class="uptime"><i style="width:${Math.max(0, Math.min(100, server.uptimePercent))}%"></i></div></div>
      </div>`,
    )
    .join('');

  return `<div class="metrics">
      ${metric('Players tracked', num(o.players), 'purple')}
      ${metric('Open tickets', num(o.openTickets), toneFor(o.openTickets))}
      ${metric('Active cases', num(o.activeCases), toneFor(o.activeCases, 'green', 'orange'))}
      ${metric('Servers online', `${o.onlineServers}/${o.servers}`, 'blue')}
      ${metric('Wallet in circulation', num(o.wallet), 'gold')}
      ${metric('Jackpot pool', num(state.jackpot?.balance ?? 0), 'gold')}
      ${metric('Shop revenue · 7d', num(o.revenue7d), 'teal')}
      ${metric('Teams', num(o.teams), 'pink')}
      ${metric('Unique players · 28d', num(o.uniquePlayers28d), 'green')}
    </div>
    ${card('Server status', `${state.servers.length} connected`, 'teal', serverRows || empty('No servers connected. Go to Server Management to add an RCON bridge.'))}
    <div class="grid-2">
      ${card('Recent activity', `${feed.length} events`, 'purple', `<div class="feed">${feed
        .map((item) => `<div class="feed-item"><span class="dot ${item.tone}"></span><div><div>${esc(item.text)}</div><small>${ago(item.at)} ago</small></div></div>`)
        .join('') || empty('No activity recorded yet.')}</div>`)}
      ${card('Next wipe', o.nextWipeAt ? time(o.nextWipeAt) : 'Not scheduled', 'gold', `
        <div class="mini-list">
          <div><span>Next wipe</span><strong>${o.nextWipeAt ? time(o.nextWipeAt) : '—'}</strong></div>
          <div><span>Sessions today</span><strong>${num(o.sessionsToday)}</strong></div>
          <div><span>Purchases · 7d</span><strong>${num(o.purchases7d)}</strong></div>
          <div><span>Bank deposits</span><strong>${num(o.bank)}</strong></div>
        </div>`)}
    </div>`;
}

function renderServers() {
  const rows = state.servers.filter((server) => matches(server.label, server.host, server.id));
  const cards = rows
    .map(
      (server) => `<div class="entity" data-server="${esc(server.id)}">
        <div class="entity-head">
          <div><strong>${esc(server.label)}</strong><div class="meta">${esc(server.id)} · ${server.hasPassword ? 'password stored' : 'no password'} · ${num(server.players)}${server.maxPlayers ? `/${num(server.maxPlayers)}` : ''} online · ${num(server.queue)} in queue</div></div>
          <div class="entity-tags">${tag(server.current, server.current === 'online' ? 'online' : 'offline')}${tag(`${server.uptimePercent}% · 7d`, 'high')}</div>
        </div>
        <div class="entity-grid">
          <label class="field"><span>Label</span><input data-field="label" value="${esc(server.label)}" maxlength="80" /></label>
          <label class="field"><span>Host</span><input data-field="host" value="${esc(server.host)}" maxlength="120" /></label>
          <label class="field"><span>RCON port</span><input data-field="port" type="number" min="1" max="65535" value="${esc(server.port)}" /></label>
          <label class="field"><span>Password</span><input value="${server.hasPassword ? '••••••••' : 'not set'}" disabled /></label>
        </div>
        <div class="entity-foot">
          ${switchRow('server.toggle', server.id, server.enabled, 'Connection enabled')}
          <button class="primary small" data-server-save="${esc(server.id)}">Save server</button>
        </div>
      </div>`,
    )
    .join('');
  return `<div class="metrics">
      ${metric('Servers', state.servers.length, 'blue')}
      ${metric('Online', state.servers.filter((s) => s.current === 'online').length, 'green')}
      ${metric('Players in game', state.servers.reduce((total, s) => total + Number(s.players ?? 0), 0), 'teal')}
      ${metric('In queue', state.servers.reduce((total, s) => total + Number(s.queue ?? 0), 0), 'purple')}
      ${metric('RCON incidents · 7d', state.servers.reduce((total, s) => total + Number(s.incidents ?? 0), 0), 'orange')}
    </div>
    ${card('Connected servers', `${rows.length} shown`, 'blue', `<div class="entity-list">${cards || empty('No servers connected. Go to Server Management to add an RCON bridge.')}</div>`)}`;
}

function renderPlayers() {
  const rows = state.players.filter((player) => matches(player.user_id, player.link?.gamertag, player.link?.platform));
  return `<div class="metrics">
      ${metric('Accounts', state.players.length, 'purple')}
      ${metric('Wallet', num(state.overview.wallet), 'gold')}
      ${metric('Bank', num(state.overview.bank), 'blue')}
      ${metric('Linked gamertags', state.links.length, 'teal')}
    </div>
    ${card('Player accounts', `${rows.length} shown`, 'purple', table(
      ['User', 'Gamertag', 'Wallet', 'Bank', 'Level', 'Astro score', 'K / D', 'Playtime'],
      rows.map((player) => [
        `<code>${esc(player.user_id)}</code>`,
        player.link ? `${esc(player.link.gamertag)} ${tag(player.link.platform)}` : '<span class="muted">not linked</span>',
        num(player.wallet),
        num(player.bank),
        `${esc(player.level)}${Number(player.prestige) ? ` · P${esc(player.prestige)}` : ''}`,
        num(player.astro_score),
        `${num(player.kills)} / ${num(player.deaths)}`,
        `${Math.round(Number(player.playtime_seconds ?? 0) / 3600)}h`,
      ]),
      'No player accounts recorded yet.',
    ))}`;
}

function renderSessions() {
  const rows = state.sessions.filter((session) => matches(session.gamertag, session.server_id, session.user_id));
  const serverName = (id) => state.servers.find((server) => server.id === id)?.label ?? id;
  return `${card('Recent sessions', `${rows.length} shown`, 'teal', table(
    ['Gamertag', 'Server', 'Started', 'Duration', 'Ended'],
    rows.map((session) => [
      esc(session.gamertag),
      esc(serverName(session.server_id)),
      time(session.started_at),
      session.duration_seconds ? `${Math.round(Number(session.duration_seconds) / 60)}m` : '<span class="muted">live</span>',
      session.ended_at ? time(session.ended_at) : '—',
    ]),
    'No sessions recorded yet. They fill as RCON join/leave telemetry arrives.',
  ))}`;
}

function renderCurrency() {
  const currency = state.currency ?? {};
  const scope =
    currency.scope === 'partner'
      ? `Partner network${currency.partnerNetworkId ? ` · ${currency.partnerNetworkId}` : ''}`
      : currency.scope === 'global'
        ? 'Global · all servers'
        : 'Local · this server';
  const sources = Object.entries(currency.mintSources ?? {});
  const top = (currency.topWallets ?? []).filter((row) => matches(row.userId, row.wallet, row.bank));
  const transactions = (currency.transactions ?? []).filter((row) => matches(row.kind, row.user_id, row.amount, row.guild_id));

  const supply = table(
    ['Ledger', 'Wallet', 'Bank', 'Total'],
    [
      ['Current scope', num(currency.wallet), num(currency.bank), num(currency.total)],
      ['Bot-wide tracked accounts', num(state.overview?.wallet ?? 0), num(state.overview?.bank ?? 0), num((state.overview?.wallet ?? 0) + (state.overview?.bank ?? 0))],
    ],
    'No currency rows yet.',
  );

  const sourceTable = table(
    ['Mint source', 'Allowed'],
    sources.map(([name, allowed]) => [esc(name), tag(allowed ? 'allowed' : 'blocked', allowed ? 'online' : 'mute')]),
    'No mint sources configured.',
  );

  const walletTable = table(
    ['Player', 'Wallet', 'Bank', 'Total'],
    top.map((row) => [`<code>${esc(row.userId)}</code>`, num(row.wallet), num(row.bank), num(row.total)]),
    'No wallets in this scope yet.',
  );

  const ledgerTable = table(
    ['When', 'Player', 'Kind', 'Amount'],
    transactions.slice(0, 40).map((row) => [time(row.created_at), `<code>${esc(row.user_id)}</code>`, esc(row.kind), num(row.amount)]),
    'No ledger entries recorded.',
  );

  return `<div class="metrics">
      ${metric('Currency', currency.currency ?? 'coins', 'gold')}
      ${metric('Scope', scope, 'blue')}
      ${metric('Minted mode', currency.minted ? 'On' : 'Off', currency.minted ? 'orange' : 'green')}
      ${metric('Circulation', num(currency.total), 'teal')}
    </div>
    <div class="grid-2">
      ${card('Supply by ledger', scope, 'gold', supply)}
      ${card('Mint sources', `${sources.filter(([, allowed]) => allowed).length}/${sources.length} allowed`, 'purple', sourceTable)}
    </div>
    ${card('Top wallets', `${top.length} shown · ${scope}`, 'teal', walletTable)}
    ${card('Recent ledger activity', `${transactions.length} shown`, 'blue', ledgerTable)}`;
}

const SHOP_PAGE_SIZE = 24;
let shopCategory = 'All';
let shopPage = 0;

function productCard(product) {
  const art = product.image
    ? `<img src="${esc(product.image)}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer" />`
    : `<span class="product-fallback" aria-hidden="true">${esc((product.name ?? '?').slice(0, 1))}</span>`;
  return `<div class="entity" data-product="${esc(product.id)}">
    <div class="entity-head">
      <div class="product-id">
        <span class="product-thumb">${art}</span>
        <div><strong>${esc(product.name)}</strong><div class="meta">${esc(product.shortname ?? product.id)} · ${esc(product.category)}</div></div>
      </div>
      <div class="entity-tags">${tag(product.stock === null ? 'unlimited' : `${product.stock} in stock`, product.stock === 0 ? 'overdue' : 'online')}${product.alertMuted ? tag('alerts muted') : ''}</div>
    </div>
    <div class="entity-grid">
      <label class="field"><span>Price</span><input data-pfield="price" type="number" min="0" value="${esc(product.price)}" /></label>
      <label class="field"><span>Stock</span><input data-pfield="stock" type="number" min="0" placeholder="unlimited" value="${product.stock ?? ''}" /></label>
      <label class="field"><span>Quantity per sale</span><input data-pfield="quantity" type="number" min="1" value="${esc(product.quantity)}" /></label>
      <label class="field"><span>Low-stock alerts</span><span class="switch-row"><span>Mute</span><span class="switch"><input type="checkbox" data-pfield="alertMuted" ${product.alertMuted ? 'checked' : ''} /><i></i></span></span></label>
    </div>
    <div class="entity-foot"><span class="muted">${esc(product.requiredRoleId ? `Requires role ${product.requiredRoleId}` : 'Open to everyone')}</span><span><button class="ghost small" data-product-delete="${esc(product.id)}">Delete</button> <button class="primary small" data-product-save="${esc(product.id)}">Save product</button></span></div>
  </div>`;
}

function renderShop() {
  const all = state.shop.products;
  const categories = [...new Set(all.map((product) => product.category).filter(Boolean))].sort();
  if (shopCategory !== 'All' && !categories.includes(shopCategory)) shopCategory = 'All';

  const products = all.filter(
    (product) =>
      (shopCategory === 'All' || product.category === shopCategory) &&
      matches(product.name, product.shortname, product.category, product.id),
  );
  const pageCount = Math.max(1, Math.ceil(products.length / SHOP_PAGE_SIZE));
  if (shopPage > pageCount - 1) shopPage = pageCount - 1;
  const pageProducts = products.slice(shopPage * SHOP_PAGE_SIZE, (shopPage + 1) * SHOP_PAGE_SIZE);
  const purchases = state.shop.purchases.filter((purchase) => matches(purchase.user_id, purchase.product_id));

  const categoryOptions = ['All', ...categories]
    .map((category) => {
      const count = category === 'All' ? all.length : all.filter((product) => product.category === category).length;
      return `<option value="${esc(category)}" ${category === shopCategory ? 'selected' : ''}>${esc(category)} (${count})</option>`;
    })
    .join('');

  const toolbar = `<div class="shop-tools">
      <label class="field"><span>Category</span><select data-shop-cat>${categoryOptions}</select></label>
      <button class="ghost small" data-shop-clear ${all.length === 0 ? 'disabled' : ''}>Delete shop</button>
      <div class="pager">
        <button class="small" data-shop-page="prev" ${shopPage === 0 ? 'disabled' : ''}>Prev</button>
        <span>Page ${shopPage + 1} / ${pageCount}</span>
        <button class="small" data-shop-page="next" ${shopPage >= pageCount - 1 ? 'disabled' : ''}>Next</button>
      </div>
    </div>`;

  return `<div class="metrics">
      ${metric('Shop', state.shop.enabled ? 'Open' : 'Closed', state.shop.enabled ? 'green' : 'red')}
      ${metric('Products', num(all.length), 'purple')}
      ${metric('Revenue · 7d', num(state.shop.sales.revenue), 'teal')}
      ${metric('Purchases · 7d', num(state.shop.sales.purchases), 'blue')}
    </div>
    ${card('Products', `${products.length} shown · ${shopCategory}`, 'teal', `${toolbar}<div class="entity-list">${pageProducts.map(productCard).join('') || empty('No products match this filter.')}</div>`)}
    <div class="grid-2">
      ${card('Recent purchases', `${purchases.length} shown`, 'gold', table(
        ['Buyer', 'Product', 'Qty', 'Price', 'When'],
        purchases.map((purchase) => [
          `<code>${esc(purchase.user_id)}</code>`,
          esc(purchase.product_id),
          num(purchase.quantity),
          num(purchase.price),
          ago(purchase.created_at) + ' ago',
        ]),
        'No purchases recorded.',
      ))}
      ${card('Top sellers · 30d', `${state.shop.topSellers.length} products`, 'purple', table(
        ['Product', 'Units', 'Revenue'],
        state.shop.topSellers.map((entry) => [esc(entry.product_id), num(entry.units), num(entry.revenue)]),
        'No sales yet.',
      ))}
    </div>`;
}

function renderWipes() {
  const profiles = state.wipes.filter((profile) => matches(profile.name, profile.serverLabel, profile.id));
  const cards = profiles
    .map(
      (profile) => `<div class="entity" data-wipe="${esc(profile.id)}">
        <div class="entity-head">
          <div><strong>${esc(profile.name)}</strong><div class="meta">${esc(profile.serverLabel ?? profile.server_id)} · ${esc(profile.wipe_type)} · every ${esc(profile.interval_hours)}h</div></div>
          <div class="entity-tags">${tag(profile.auto_restart ? 'auto restart' : 'manual', profile.auto_restart ? 'online' : '')}</div>
        </div>
        <div class="entity-grid">
          <label class="field"><span>Next wipe</span><input data-wfield="next_wipe_at" type="datetime-local" value="${dateLocal(profile.next_wipe_at)}" /></label>
          <label class="field"><span>Interval (hours)</span><input data-wfield="interval_hours" type="number" min="1" max="8760" value="${esc(profile.interval_hours)}" /></label>
          <label class="field"><span>Countdowns</span><input value="${esc(profile.countdowns ?? '')}" disabled /></label>
          <label class="field"><span>Restart command</span><input value="${esc(profile.restart_command ?? '')}" disabled /></label>
        </div>
        <div class="entity-foot">
          ${switchRow('wipe.auto', profile.id, Boolean(profile.auto_restart), 'Auto restart after wipe')}
          <button class="primary small" data-wipe-save="${esc(profile.id)}">Save wipe</button>
        </div>
      </div>`,
    )
    .join('');
  return `${card('Wipe profiles', `${profiles.length} scheduled`, 'gold', `<div class="entity-list">${cards || empty('No wipe profiles. Create one with /server wipe in Discord.')}</div>`)}`;
}

function renderTemplates() {
  const rows = state.templates.filter((template) => matches(template.name, template.description));
  return `${card('Server templates', `${rows.length} saved`, 'orange', table(
    ['Template', 'Roles', 'Categories', 'Channels', 'Created'],
    rows.map((template) => [
      `<strong>${esc(template.name)}</strong>${template.description ? `<div class="meta">${esc(template.description)}</div>` : ''}`,
      num(template.roles),
      num(template.categories),
      num(template.channels),
      time(template.created_at),
    ]),
    'No saved templates yet. Save the current server with /templates in Discord.',
  ))}`;
}

function renderTeams() {
  const teams = state.teams.filter((team) => matches(team.name, team.tag, team.owner_id, team.id));
  const cards = teams
    .map(
      (team) => `<div class="entity" data-team="${esc(team.id)}">
        <div class="entity-head">
          <div><strong>${esc(team.name)} <span class="muted">[${esc(team.tag)}]</span></strong><div class="meta">Owner ${esc(team.owner_id)} · ${esc(team.members)} members</div></div>
          <div class="entity-tags">${team.role_id ? tag('role linked') : ''}${team.raid_channel_id ? tag('raid channel') : ''}</div>
        </div>
        <div class="entity-grid">
          <label class="field"><span>Tag</span><input data-tfield="tag" value="${esc(team.tag)}" maxlength="8" /></label>
          <label class="field"><span>Color</span><input data-tfield="color" value="${esc(team.color ?? '')}" placeholder="#8b5cf6" /></label>
        </div>
        <details><summary>${team.memberList.length} member(s)</summary><div class="member-list">${team.memberList
          .map((member) => `<div><code>${esc(member.user_id)}</code> ${tag(member.rank)} <span class="muted">joined ${ago(member.joined_at)} ago</span></div>`)
          .join('') || '<div class="empty">No members.</div>'}</div></details>
        <div class="entity-foot"><span class="muted">Created ${time(team.created_at)}</span><button class="primary small" data-team-save="${esc(team.id)}">Save team</button></div>
      </div>`,
    )
    .join('');
  return `<div class="metrics">
      ${metric('Teams', state.teams.length, 'pink')}
      ${metric('Players in teams', state.teams.reduce((total, team) => total + Number(team.members), 0), 'purple')}
      ${metric('Active wars', state.wars.filter((war) => war.status === 'active').length, 'red')}
      ${metric('Wars logged', state.wars.length, 'blue')}
    </div>
    ${card('Teams', `${teams.length} shown`, 'pink', `<div class="entity-list">${cards || empty('No teams created yet.')}</div>`)}
    ${card('Team wars', `${state.wars.length} recent`, 'orange', table(
      ['Team', 'Opponent', 'Status', 'Score', 'Started'],
      state.wars.map((war) => [esc(war.team_name), esc(war.opponent_name ?? '—'), tag(war.status, war.status === 'active' ? 'red' : ''), esc(war.score), time(war.started_at)]),
      'No wars recorded.',
    ))}`;
}

function renderClans() {
  const badges = state.clans.catalogue ?? state.clans.badges ?? [];
  const awards = Number(state.clans.awards ?? badges.reduce((total, badge) => total + Number(badge.awarded ?? 0), 0));
  const uploads = badges.filter((badge) => badge.requirement === 'Clan badge').length;

  return `<div class="metrics">
      ${metric('Badges available', badges.length, 'pink')}
      ${metric('Badges awarded', awards, 'gold')}
      ${metric('Clan uploads', uploads, 'blue')}
      ${metric('Clan ranks', state.clans.ranks.length, 'purple')}
    </div>
    <div class="grid-2">
      ${card('Badge catalogue', `${badges.length} badges`, 'pink', table(
        ['Badge', 'Requirement', 'Awarded', 'ID'],
        badges.map((badge) => [
          `<img class="badge-art" src="${esc(badge.art)}" alt="" loading="lazy" /> <strong>${esc(badge.label)}</strong>`,
          esc(badge.requirement ?? '—'),
          num(badge.awarded),
          `<code>${esc(badge.id)}</code>`,
        ]),
        'No badges available. Award one with /badge give.',
      ))}
      ${card('Clan ranks', `${state.clans.ranks.length} ranks`, 'gold', table(
        ['Key', 'Label', 'Position'],
        state.clans.ranks.map((rank) => [`<code>${esc(rank.key)}</code>`, esc(rank.label), num(rank.position)]),
        'No clan ranks configured.',
      ))}
    </div>`;
}

function renderBounties() {
  const rows = state.bounties.filter((bounty) => matches(bounty.target_id, bounty.placed_by, bounty.status));
  return `${card('Bounties', `${rows.length} shown`, 'gold', table(
    ['Target', 'Placed by', 'Amount', 'Status', 'Created', 'Claimed by'],
    rows.map((bounty) => [
      `<code>${esc(bounty.target_id)}</code>`,
      `<code>${esc(bounty.placed_by)}</code>`,
      num(bounty.amount),
      tag(bounty.status, bounty.status === 'claimed' ? 'online' : 'mute'),
      time(bounty.created_at),
      bounty.claimed_by ? `<code>${esc(bounty.claimed_by)}</code>` : '—',
    ]),
    'No bounties placed.',
  ))}`;
}

function renderBattlePass() {
  const rows = state.battlePass.filter((entry) => matches(entry.user_id, entry.tier, entry.premium));
  return `${card('Battle pass progress', `${rows.length} entries`, 'purple', table(
    ['Player', 'Tier', 'XP', 'Premium', 'Claimed', 'Updated'],
    rows.map((entry) => [
      `<code>${esc(entry.user_id)}</code>`,
      num(entry.tier),
      num(entry.xp),
      entry.premium ? tag('premium', 'online') : '—',
      entry.claimed ? 'yes' : 'no',
      time(entry.updated_at),
    ]),
    'No battle pass progress recorded.',
  ))}`;
}

function renderTasks() {
  const rows = state.tasks.filter((task) => matches(task.name, task.kind, task.command));
  return `${card('Scheduled tasks', `${rows.length} tasks`, 'blue', table(
    ['Name', 'Kind', 'Interval', 'Command', 'Next run', 'Enabled'],
    rows.map((task) => [
      `<strong>${esc(task.name)}</strong>`,
      tag(task.kind),
      `${Math.round(Number(task.interval_seconds) / 60)}m`,
      task.command ? `<code>${esc(task.command)}</code>` : '—',
      task.next_run_at ? time(task.next_run_at) : '—',
      switchRow('task.toggle', task.id, Boolean(task.enabled), ''),
    ]),
    'No scheduled tasks configured.',
  ))}`;
}

function renderLfg() {
  const rows = state.lfg.filter((post) => matches(post.title, post.owner_id, post.platform, post.region, post.status));
  return `${card('LFG posts', `${rows.length} posts`, 'teal', table(
    ['Title', 'Owner', 'Platform', 'Players', 'Status', 'Created', ''],
    rows.map((post) => [
      `<strong>${esc(post.title)}</strong><div class="meta">${esc(post.description ?? '')}</div>`,
      `<code>${esc(post.owner_id)}</code>`,
      esc(post.platform ?? '—'),
      `${num(post.joined)}/${num(post.players_needed)}`,
      tag(post.status, post.status === 'open' ? 'online' : ''),
      ago(post.created_at) + ' ago',
      post.status === 'open' ? `<button class="ghost small" data-lfg-close="${esc(post.id)}">Close</button>` : '—',
    ]),
    'No LFG posts yet.',
  ))}`;
}

function renderTickets() {
  const open = state.tickets.open.filter((ticket) => matches(ticket.subject, ticket.owner_id, ticket.category, ticket.priority));
  const cards = open
    .map((ticket) => `<div class="entity" data-ticket="${esc(ticket.id)}">
      <div class="entity-head">
        <div><strong>${esc(ticket.subject)}</strong><div class="meta">${esc(ticket.id)} · ${esc(ticket.category ?? 'general')} · ${esc(ticket.owner_id)} · opened ${ago(ticket.created_at)} ago</div></div>
        <div class="entity-tags">${tag(ticket.priority ?? 'normal', ticket.priority === 'high' || ticket.priority === 'urgent' ? 'high' : '')}${ticket.sla_due_at && ticket.sla_due_at < Date.now() ? tag('SLA overdue', 'overdue') : ''}</div>
      </div>
      <div class="entity-grid">
        <label class="field"><span>Priority</span><select data-tfield="priority">${PRIORITIES.map((priority) => `<option ${priority === (ticket.priority ?? 'normal') ? 'selected' : ''}>${priority}</option>`).join('')}</select></label>
        <label class="field"><span>Assigned to</span><input data-tfield="assigned_to" value="${esc(ticket.assigned_to ?? '')}" placeholder="Discord user ID" /></label>
      </div>
      <div class="entity-foot"><span class="muted">SLA ${ticket.sla_due_at ? time(ticket.sla_due_at) : 'not set'}</span><button class="primary small" data-ticket-save="${esc(ticket.id)}">Save ticket</button></div>
    </div>`,
    )
    .join('');

  return `<div class="metrics">
      ${metric('Open tickets', state.tickets.open.length, toneFor(state.tickets.open.length))}
      ${metric('Overdue SLA', state.tickets.overdue, toneFor(state.tickets.overdue, 'green', 'orange'))}
      ${metric('Unassigned', state.tickets.unassigned, 'gold')}
      ${metric('Average rating', state.tickets.averageRating ?? '—', 'teal')}
    </div>
    ${card('Support queue', `${open.length} shown`, 'orange', `<div class="entity-list">${cards || empty('Queue is clear.')}</div>`)}
    ${card('Closed tickets', `${state.tickets.closed.length} recent`, 'green', table(
      ['Subject', 'Owner', 'Priority', 'Rating', 'Closed by', 'Closed'],
      state.tickets.closed.map((ticket) => [
        esc(ticket.subject),
        `<code>${esc(ticket.owner_id)}</code>`,
        tag(ticket.priority ?? 'normal'),
        ticket.rating ? `${ticket.rating}/5` : '—',
        ticket.closed_by ? `<code>${esc(ticket.closed_by)}</code>` : '—',
        time(ticket.closed_at),
      ]),
      'No closed tickets yet.',
    ))}`;
}

function renderModeration() {
  const cases = state.moderation.cases.filter((entry) =>
    matches(entry.id, entry.target_id, entry.moderator_id, entry.action, entry.reason, entry.appeal_status),
  );
  const rows = cases.map((entry) => [
    `<code>${esc(entry.id)}</code>`,
    tag(entry.action, entry.action === 'ban' ? 'ban' : entry.action === 'mute' ? 'mute' : ''),
    `<code>${esc(entry.target_id)}</code>`,
    `<code>${esc(entry.moderator_id)}</code>`,
    `${esc(entry.scope ?? 'guild')}${entry.server_id ? ` · ${esc(entry.server_id)}` : ''}`,
    esc(entry.reason ?? '—'),
    `<select data-afield="appeal_status" data-id="${esc(entry.id)}">${APPEALS.map((appeal) => `<option ${appeal === (entry.appeal_status ?? 'none') ? 'selected' : ''}>${appeal}</option>`).join('')}</select>`,
    `<button class="ghost small" data-appeal-save="${esc(entry.id)}">Save</button>`,
    ago(entry.created_at) + ' ago',
  ]);

  const staff = state.moderation.staff
    .map(
      (entry) => `<div class="item"><div><strong>${esc(entry.moderator_id)}</strong><div class="meta">${num(entry.bans)} bans · ${num(entry.total)} total</div></div><span class="badge">${num(entry.total)}</span></div>`,
    )
    .join('');

  return `<div class="metrics">
      ${metric('Cases', state.moderation.cases.length, 'red')}
      ${metric('Pending appeals', state.moderation.appeals.length, toneFor(state.moderation.appeals.length, 'green', 'orange'))}
      ${metric('Staff active · 30d', state.moderation.staff.length, 'purple')}
      ${metric('Network scoped', state.moderation.cases.filter((entry) => entry.scope === 'network').length, 'blue')}
    </div>
    ${card('Case log', `${cases.length} shown`, 'red', table(
      ['Case', 'Action', 'Target', 'Moderator', 'Scope', 'Reason', 'Appeal', '', 'When'],
      rows,
      'No moderation cases yet.',
    ))}
    <div class="grid-2">
      ${card('Staff activity · 30 days', `${state.moderation.staff.length} staff`, 'teal', `<div class="stack">${staff || empty('No staff cases.')}</div>`)}
      ${card('Appeal queue', `${state.moderation.appeals.length} pending`, 'gold', `<div class="stack">${state.moderation.appeals
        .map((entry) => `<div class="item"><div><strong>${esc(entry.target_id)}</strong><div class="meta">${esc(entry.action)} · ${esc(entry.reason ?? 'no reason')}</div></div>${tag('pending', 'high')}</div>`)
        .join('') || empty('No pending appeals.')}</div>`)}
    </div>`;
}

function pretty(value) {
  if (value === null || value === undefined) return '—';
  const text = String(value);
  return text.length > 90 ? `${text.slice(0, 90)}…` : text;
}

function renderAudit() {
  const rows = state.audit.filter((entry) => matches(entry.key, entry.actor_id, entry.old_value, entry.new_value));
  return `${card('Audit log', `${rows.length} entries`, 'blue', table(
    ['When', 'Actor', 'Key', 'Old value', 'New value'],
    rows.map((entry) => [time(entry.created_at), `<code>${esc(entry.actor_id)}</code>`, `<code>${esc(entry.key)}</code>`, esc(pretty(entry.old_value)), esc(pretty(entry.new_value))]),
    'No configuration changes recorded yet.',
  ))}`;
}

function renderRetention() {
  const r = state.retention;
  const peak = r.daily.reduce((best, entry) => (entry.sessions > best.sessions ? entry : best), { sessions: 0, day: '—' });
  const max = Math.max(1, ...r.daily.slice(-14).map((entry) => entry.sessions));
  const bars = r.daily
    .slice(-14)
    .map((entry) => `<div class="bar"><div class="fill" style="height:${Math.round((entry.sessions / max) * 100)}%"></div><span>${entry.day.slice(5)}</span></div>`)
    .join('');
  const weekMax = Math.max(1, ...r.heatmap.flat());
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const heat = r.heatmap
    .map(
      (row, index) =>
        `<span class="label">${days[index]}</span>${row
          .map((count) => `<div class="cell" title="${days[index]} ${count} sessions" style="background:rgba(230,33,39,${(0.06 + (count / weekMax) * 0.85).toFixed(3)})"></div>`)
          .join('')}`,
    )
    .join('');

  return `<div class="metrics">
      ${metric('Players this week', r.currentWeekPlayers, 'purple')}
      ${metric('Week-over-week retention', `${r.retentionPercent}%`, 'green')}
      ${metric('New / returning', `${r.newPlayers} / ${r.returningPlayers}`, 'blue')}
      ${metric('Avg session', `${Math.round(r.averageDurationSeconds / 60)}m`, 'teal')}
    </div>
    ${card('Sessions · last 14 days', `peak ${peak.sessions} on ${peak.day.slice(5)}`, 'purple', `<div class="bars">${bars || empty('No sessions yet.')}</div>`)}
    ${card('Activity heatmap · UTC', 'day × hour', 'teal', `<div class="heat">${heat}</div>`)}
    ${card('Retention detail', `${r.totalSessions} sessions · 28d`, 'green', table(
      ['Metric', 'Value'],
      [
        ['Unique players', r.uniquePlayers],
        ['Previous week players', r.previousWeekPlayers],
        ['Returning players', r.returningPlayers],
        ['New players', r.newPlayers],
      ].map(([label, value]) => [label, num(value)]),
    ))}`;
}

function renderStatus() {
  const rows = state.status.servers.filter((server) => matches(server.label, server.host, server.id));
  const cards = rows
    .map(
      (server) => `<div class="status-card">
        <div class="entity-head"><div><strong>${esc(server.label)}</strong><div class="meta">${esc(server.host)}:${esc(server.port)}</div></div>${tag(server.current, server.current === 'online' ? 'online' : 'offline')}</div>
        <div class="uptime"><i style="width:${Math.max(0, Math.min(100, server.uptimePercent))}%"></i></div>
        <div class="meta">${server.uptimePercent}% uptime · ${num(server.incidents)} incident(s) · ${num(server.players)} online · ${num(server.queue)} in queue</div>
      </div>`,
    )
    .join('');
  return `<div class="metrics">
      ${metric('Servers', state.status.servers.length, 'blue')}
      ${metric('Online now', state.status.servers.filter((server) => server.current === 'online').length, 'green')}
      ${metric('In queue', state.status.servers.reduce((total, server) => total + Number(server.queue ?? 0), 0), 'purple')}
      ${metric('Incidents · 7d', state.status.servers.reduce((total, server) => total + Number(server.incidents), 0), 'orange')}
      ${metric('Average uptime', `${state.status.servers.length ? Math.round((state.status.servers.reduce((total, server) => total + Number(server.uptimePercent), 0) / state.status.servers.length) * 10) / 10 : 0}%`, 'teal')}
    </div>
    ${card('Uptime by server', 'rolling 7 days', 'blue', `<div class="status-grid">${cards || empty('No servers connected.')}</div>`)}
    ${card('RCON status events', `${state.status.events.length} recent`, 'teal', table(
      ['When', 'Server', 'Status', 'Players'],
      state.status.events.slice(-40).reverse().map((event) => [
        time(event.created_at),
        esc(state.servers.find((server) => server.id === event.server_id)?.label ?? event.server_id),
        tag(event.status, event.status === 'online' ? 'online' : 'offline'),
        num(event.players),
      ]),
      'No status events yet.',
    ))}`;
}

function settingField(field) {
  const value = getPath(state.settings, field.path);
  const path = `data-path="${esc(field.path)}"`;
  const wide = field.type === 'text' || field.type === 'role' ? 'wide' : '';
  let control = '';
  if (field.type === 'boolean') {
    control = `<span class="switch"><input type="checkbox" ${path} ${value ? 'checked' : ''} /><i></i></span>`;
  } else if (field.type === 'number') {
    control = `<input type="number" ${path} value="${esc(value ?? '')}" ${field.min !== undefined ? `min="${field.min}"` : ''} ${field.max !== undefined ? `max="${field.max}"` : ''} />`;
  } else if (field.type === 'color') {
    control = `<input type="color" ${path} value="${esc(value ?? '#8b5cf6')}" />`;
  } else if (field.type === 'channel') {
    control = Array.isArray(value)
      ? `<input ${path} data-list="1" value="${esc(value.join(', '))}" placeholder="Channel IDs, comma separated" />`
      : `<input ${path} value="${esc(value ?? '')}" placeholder="Channel ID" />`;
  } else if (field.type === 'role') {
    control = `<input ${path} value="${esc(Array.isArray(value) ? value.join(', ') : value ?? '')}" placeholder="Role IDs, comma separated" />`;
  } else if (typeof value === 'object' && value !== null) {
    control = `<textarea ${path} data-json="1" rows="4">${esc(JSON.stringify(value, null, 2))}</textarea>`;
  } else {
    control = `<input ${path} value="${esc(value ?? '')}" />`;
  }
  return `<label class="field ${wide}"><span>${esc(field.label)}</span>${control}${field.help ? `<small>${esc(field.help)}</small>` : ''}</label>`;
}

function renderSettings() {
  const sections = state.configSections
    .map(
      (section) => `<div data-section="${esc(section.id)}">
        ${card(
          `${section.emoji ?? ''} ${section.label}`,
          'settings',
          'blue',
          `<p class="section-desc">${esc(section.description ?? '')}</p><div class="form-grid">${section.fields.map(settingField).join('')}</div>`,
          `<span class="muted">Saves to ${section.id} settings</span><button class="primary small" data-settings-save="${esc(section.id)}">Save ${esc(section.label)}</button>`,
        )}
      </div>`,
    )
    .join('');
  return `<p class="page-desc">Every card writes straight to the same settings the Discord panels use. The bot reloads them within 30 seconds.</p>${sections}`;
}

const RENDERERS = {
  overview: renderOverview,
  servers: renderServers,
  players: renderPlayers,
  sessions: renderSessions,
  shop: renderShop,
  currency: renderCurrency,
  wipes: renderWipes,
  templates: renderTemplates,
  teams: renderTeams,
  clans: renderClans,
  bounties: renderBounties,
  battlepass: renderBattlePass,
  tasks: renderTasks,
  lfg: renderLfg,
  tickets: renderTickets,
  moderation: renderModeration,
  audit: renderAudit,
  retention: renderRetention,
  status: renderStatus,
  settings: renderSettings,
  hubPlayer: renderPlayerHub,
  hubMod: renderModeratorHub,
  hubAdmin: renderAdministratorHub,
  hubOwner: renderOwnerHub,
};

function renderCounts() {
  const counts = {
    servers: state.servers.length,
    players: state.overview.players,
    tickets: state.tickets.open.length,
    cases: state.overview.activeCases,
  };
  document.querySelectorAll('[data-count]').forEach((element) => {
    const value = counts[element.dataset.count];
    element.textContent = value ? String(value) : '';
    element.hidden = !value;
  });
}

function render() {
  if (!state) return;
  document.querySelector('main').dataset.section = view;
  document.getElementById('view-title').textContent = TITLES[view] ?? 'Overview';
  document.getElementById('generated').textContent = `updated ${new Date(state.generatedAt).toLocaleTimeString()}`;
  const renderer = RENDERERS[view] ?? renderOverview;
  document.getElementById('app').innerHTML = renderer();
  renderCounts();
}

function renderGuilds() {
  const select = document.getElementById('guild');
  const current = state.guildId ?? '';
  select.innerHTML =
    (state.guilds ?? [])
      .map((guild) => `<option value="${esc(guild.id)}" ${guild.id === current ? 'selected' : ''}>${esc(guild.name ?? guild.id)}</option>`)
      .join('') || '<option>No guilds</option>';
  guildId = current;
}

function toast(message, tone = 'ok') {
  const element = document.getElementById('toast');
  element.textContent = message;
  element.className = `toast ${tone}`;
  element.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    element.hidden = true;
  }, 3200);
}

function csrfToken() {
  const part = document.cookie.split('; ').find((entry) => entry.startsWith('astro_csrf='));
  return part ? decodeURIComponent(part.slice('astro_csrf='.length)) : '';
}

async function post(action, payload = {}) {
  const response = await fetch('/api/action', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', 'X-Dashboard': '1', 'X-CSRF-Token': csrfToken() },
    body: JSON.stringify({ action, guildId, ...payload }),
  });
  if (response.status === 401) {
    location.href = '/login';
    throw new Error('Sign in required.');
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error ?? 'Request failed.');
  return data;
}

async function saveAndReload(action, payload) {
  try {
    await post(action, payload);
    await load();
    toast('Saved.');
  } catch (error) {
    toast(error.message, 'error');
  }
}

function setView(next) {
  if (!(next in TITLES)) return;
  view = next;
  document.querySelectorAll('nav button').forEach((entry) => entry.classList.toggle('active', entry.dataset.view === view));
  if (location.hash !== `#${view}`) history.replaceState(null, '', `#${view}`);
  render();
}

async function load() {
  const query = guildId ? `?guild=${encodeURIComponent(guildId)}` : '';
  if (!state) document.getElementById('app').innerHTML = '<div class="loading">Loading dashboard…</div>';
  const response = await fetch(`/api/summary${query}`, { credentials: 'same-origin' });
  if (response.status === 401) {
    location.href = '/login';
    return;
  }
  state = await response.json();
  renderGuilds();
  render();
}

document.querySelectorAll('nav button').forEach((entry) => entry.classList.toggle('active', entry.dataset.view === view));

document.body.addEventListener('click', (event) => {
  const nav = event.target.closest('button[data-view]');
  if (nav) {
    setView(nav.dataset.view);
    return;
  }

  const serverSave = event.target.closest('[data-server-save]');
  if (serverSave) {
    const cardEl = serverSave.closest('[data-server]');
    saveAndReload('server.update', {
      id: serverSave.dataset.serverSave,
      label: cardEl.querySelector('[data-field="label"]').value,
      host: cardEl.querySelector('[data-field="host"]').value,
      port: Number(cardEl.querySelector('[data-field="port"]').value),
    });
    return;
  }

  const productDelete = event.target.closest('[data-product-delete]');
  if (productDelete) {
    if (!window.confirm('Delete this product? This cannot be undone.')) return;
    post('product.delete', { id: productDelete.dataset.productDelete })
      .then(load)
      .then(() => toast('Product deleted.'))
      .catch((error) => toast(error.message, 'error'));
    return;
  }

  const shopClear = event.target.closest('[data-shop-clear]');
  if (shopClear) {
    if (!window.confirm('Delete every product and disable the shop? This cannot be undone.')) return;
    post('shop.clear')
      .then(load)
      .then(() => toast('Shop deleted.'))
      .catch((error) => toast(error.message, 'error'));
    return;
  }

  const productSave = event.target.closest('[data-product-save]');
  if (productSave) {
    const cardEl = productSave.closest('[data-product]');
    const stockValue = cardEl.querySelector('[data-pfield="stock"]').value.trim();
    saveAndReload('product.update', {
      id: productSave.dataset.productSave,
      price: Number(cardEl.querySelector('[data-pfield="price"]').value),
      quantity: Number(cardEl.querySelector('[data-pfield="quantity"]').value),
      stock: stockValue === '' ? null : Number(stockValue),
      alertMuted: cardEl.querySelector('[data-pfield="alertMuted"]').checked,
    });
    return;
  }

  const wipeSave = event.target.closest('[data-wipe-save]');
  if (wipeSave) {
    const cardEl = wipeSave.closest('[data-wipe]');
    saveAndReload('wipe.update', {
      id: wipeSave.dataset.wipeSave,
      interval_hours: Number(cardEl.querySelector('[data-wfield="interval_hours"]').value),
      next_wipe_at: fromLocal(cardEl.querySelector('[data-wfield="next_wipe_at"]').value),
    });
    return;
  }

  const teamSave = event.target.closest('[data-team-save]');
  if (teamSave) {
    const cardEl = teamSave.closest('[data-team]');
    saveAndReload('team.update', {
      id: teamSave.dataset.teamSave,
      tag: cardEl.querySelector('[data-tfield="tag"]').value,
      color: cardEl.querySelector('[data-tfield="color"]').value,
    });
    return;
  }

  const ticketSave = event.target.closest('[data-ticket-save]');
  if (ticketSave) {
    const cardEl = ticketSave.closest('[data-ticket]');
    saveAndReload('ticket.update', {
      id: ticketSave.dataset.ticketSave,
      priority: cardEl.querySelector('[data-tfield="priority"]').value,
      assigned_to: cardEl.querySelector('[data-tfield="assigned_to"]').value.trim() || null,
    });
    return;
  }

  const appealSave = event.target.closest('[data-appeal-save]');
  if (appealSave) {
    const id = appealSave.dataset.appealSave;
    const select = document.querySelector(`select[data-afield="appeal_status"][data-id="${CSS.escape(id)}"]`);
    saveAndReload('case.appeal', { id, appeal_status: select.value });
    return;
  }

  const lfgClose = event.target.closest('[data-lfg-close]');
  if (lfgClose) {
    saveAndReload('lfg.close', { id: lfgClose.dataset.lfgClose });
    return;
  }

  const settingsSave = event.target.closest('[data-settings-save]');
  if (settingsSave) {
    const sectionId = settingsSave.dataset.settingsSave;
    const section = state.configSections.find((entry) => entry.id === sectionId);
    const cardEl = document.querySelector(`[data-section="${CSS.escape(sectionId)}"]`);
    const groups = {};
    try {
      for (const field of section.fields) {
        const input = cardEl.querySelector(`[data-path="${CSS.escape(field.path)}"]`);
        if (!input) continue;
        const root = field.path.split('.')[0];
        if (!groups[root]) groups[root] = JSON.parse(JSON.stringify(state.settings[root] ?? {}));
        let value;
        if (field.type === 'boolean') value = input.checked;
        else if (field.type === 'number') value = Number(input.value);
        else if (field.type === 'channel') {
          value = input.dataset.list === '1'
            ? input.value.split(/[,\s]+/).filter(Boolean)
            : input.value.trim() || null;
        }
        else if (field.type === 'role') value = input.value.split(/[,\s]+/).filter(Boolean);
        else if (input.dataset.json === '1') value = JSON.parse(input.value || 'null');
        else value = input.value;
        setPath(groups[root], field.path.slice(root.length + 1), value);
      }
    } catch (error) {
      toast(`Invalid JSON: ${error.message}`, 'error');
      return;
    }
    saveAndReload('settings.saveMany', { groups });
  }
});

document.body.addEventListener('change', (event) => {
  const toggle = event.target.closest('[data-toggle]');
  if (!toggle) return;
  const action = toggle.dataset.toggle;
  if (action === 'wipe.auto') {
    const cardEl = toggle.closest('[data-wipe]');
    saveAndReload('wipe.update', {
      id: toggle.dataset.id,
      auto_restart: toggle.checked,
      interval_hours: Number(cardEl.querySelector('[data-wfield="interval_hours"]').value),
      next_wipe_at: fromLocal(cardEl.querySelector('[data-wfield="next_wipe_at"]').value),
    });
    return;
  }
  saveAndReload(action, { id: toggle.dataset.id, enabled: toggle.checked });
});

document.getElementById('guild').addEventListener('change', (event) => {
  guildId = event.target.value;
  load();
});

document.getElementById('search').addEventListener('input', (event) => {
  search = event.target.value.trim();
  render();
});

document.body.addEventListener('change', (event) => {
  const select = event.target.closest('[data-shop-cat]');
  if (!select) return;
  shopCategory = select.value;
  shopPage = 0;
  render();
});

document.body.addEventListener('click', (event) => {
  const pager = event.target.closest('[data-shop-page]');
  if (!pager) return;
  shopPage = Math.max(0, shopPage + (pager.dataset.shopPage === 'next' ? 1 : -1));
  render();
});

document.getElementById('refresh').addEventListener('click', load);

window.addEventListener('hashchange', () => {
  const next = location.hash.replace('#', '');
  if (next in TITLES) {
    view = next;
    document.querySelectorAll('nav button').forEach((entry) => entry.classList.toggle('active', entry.dataset.view === view));
    render();
  }
});

const initialView = location.hash.replace('#', '');
if (initialView in TITLES) view = initialView;
document.querySelectorAll('nav button').forEach((entry) => entry.classList.toggle('active', entry.dataset.view === view));

setInterval(() => {
  if (document.visibilityState === 'visible') load();
}, 60_000);

load();

// Flow rail → day capsule: clicking a node scrolls the matching reward tile
// into view inside the capsule deck and flashes it briefly.
document.addEventListener('click', (event) => {
  const node = event.target.closest?.('[data-flow-day]');
  if (!node) return;
  const capsule = document.querySelector(`.day-capsule[data-day="${node.dataset.flowDay}"]`);
  if (!capsule) return;
  capsule.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
  capsule.classList.remove('is-target');
  // Force a restart so rapid clicks re-flash the tile.
  void capsule.offsetWidth;
  capsule.classList.add('is-target');
  clearTimeout(capsule._targetTimer);
  capsule._targetTimer = setTimeout(() => capsule.classList.remove('is-target'), 1500);
});

/* ═══════════════════════════════════════════════════════════
   Role hubs: player, moderator, administrator, owner
   ═══════════════════════════════════════════════════════════ */

const DAY_MS = 86_400_000;
let hubUser = '';

const rewardArt = (name) => `/rewards/${name}.png`;
const serverLabel = (id) => state?.servers?.find((server) => server.id === id)?.label ?? id;

const STREAK_TRACK = [
  { day: 1, label: 'Coins drop', art: 'mobile_currency_sun_coin_08', note: 'Straight to the wallet' },
  { day: 2, label: 'Wager token', art: 'mobile_currency_prism_gem_02', note: '+10% on your next challenge win' },
  { day: 3, label: 'Tower pass', art: 'mobile_chest_crystal_04', note: 'Refunds a collapsed climb' },
  { day: 4, label: 'Playtime x2', art: 'mobile_login_tile_double_reward_07', note: 'Two hours of double coin drops' },
  { day: 5, label: 'Bounty shield', art: 'mobile_milestone_gem_07', note: 'Absorbs a bounty, then 24h safe' },
  { day: 6, label: 'Lucky key', art: 'mobile_currency_star_token_01', note: 'One extra loot crate' },
  { day: 7, label: 'Master chest', art: 'mobile_chest_milestone_12', note: 'Weekly jackpot box' },
];

const CLAIM_MILESTONES = [
  { at: 10, label: 'Bronze crate', art: 'mobile_chest_wooden_supply_01' },
  { at: 25, label: 'Iron crate', art: 'mobile_chest_silver_02' },
  { at: 50, label: 'Gilded chest', art: 'mobile_chest_gold_03' },
  { at: 100, label: 'Elite vault', art: 'mobile_chest_epic_vault_09' },
];

function fmtDuration(ms) {
  if (!Number.isFinite(ms) || ms <= 0) return 'now';
  const total = Math.floor(ms / 1000);
  const days = Math.floor(total / 86_400);
  const hours = Math.floor((total % 86_400) / 3_600);
  const minutes = Math.floor((total % 3_600) / 60);
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m ${total % 60}s`;
}

function hubPlayers() {
  return (state?.players ?? []).filter((entry) => entry.user_id);
}
function hubSelected() {
  const list = hubPlayers();
  return list.find((entry) => entry.user_id === hubUser) ?? list[0] ?? null;
}
function hubReward(userId) {
  return (
    state?.rewards?.[userId] ?? {
      streak: 0, claimedToday: false, nextAt: null, cycle: 0, claimableDay: 1, lifetime: 0, milestones: [], vouchers: [],
    }
  );
}

function renderPlayerHub() {
  const list = hubPlayers();
  if (!list.length) {
    return card('Player dashboard', '0 accounts', 'pink', empty('No player accounts yet — they appear after the first /coins balance or an RCON join.'));
  }

  const account = hubSelected();
  const reward = hubReward(account.user_id);
  const link = account.link ?? (state.links ?? []).find((entry) => entry.user_id === account.user_id) ?? null;
  const team = (state.teams ?? []).find((entry) => (entry.memberList ?? []).some((member) => member.user_id === account.user_id)) ?? null;
  const membership = team ? team.memberList.find((member) => member.user_id === account.user_id) : null;
  const activeWars = team ? (state.wars ?? []).filter((war) => war.team_id === team.id && war.status === 'active') : [];
  const wipe = (state.wipes ?? []).filter((entry) => entry.next_wipe_at).sort((a, b) => Number(a.next_wipe_at) - Number(b.next_wipe_at))[0] ?? null;
  const xpPerTier = Number(state.settings?.battlePass?.xpPerTier ?? 1000) || 1000;
  const levelProgress = Math.min(100, Math.round(((Number(account.xp ?? 0) % xpPerTier) / xpPerTier) * 100));
  const gamertag = link?.gamertag ?? `Player ${account.user_id.slice(-4)}`;
  const initials = gamertag.replace(/[^A-Za-z0-9]/g, '').slice(0, 2).toUpperCase() || 'AB';

  const head = `<div class="hub-head">
    <div><h2>Player dashboard</h2><p>Identity, vaults, streak track, jackpot and clan status.</p></div>
    <label class="hub-select"><span>Player</span><select data-hub-player>
      ${list
        .map((entry) => {
          const name = entry.link?.gamertag ?? entry.user_id;
          return `<option value="${esc(entry.user_id)}" ${entry.user_id === account.user_id ? 'selected' : ''}>${esc(name)}${entry.link ? ` · ${esc(entry.link.platform)}` : ''}</option>`;
        })
        .join('')}
    </select></label>
  </div>`;

  const identity = `<div class="identity">
      <div class="identity-mark">${esc(initials)}</div>
      <div class="identity-main">
        <div class="identity-line">
          <strong>${esc(gamertag)}</strong>
          ${link ? tag(link.platform) : tag('not linked')}
          ${Number(account.prestige) ? tag(`prestige ${account.prestige}`, 'high') : ''}
        </div>
        <div class="meta"><code>${esc(account.user_id)}</code> · level ${num(account.level)} · ${num(account.xp)} xp</div>
        <div class="xpbar"><i style="width:${levelProgress}%"></i></div>
        <div class="identity-stats">
          <div><span>Astro score</span><strong>${num(account.astro_score)}</strong></div>
          <div><span>Kills</span><strong>${num(account.kills)}</strong></div>
          <div><span>Deaths</span><strong>${num(account.deaths)}</strong></div>
          <div><span>Playtime</span><strong>${Math.round(Number(account.playtime_seconds ?? 0) / 3600)}h</strong></div>
        </div>
        <div class="identity-badges">
          <span class="identity-rank" title="${esc(account.rankBadge?.label ?? 'Stone')} rank">
            <img src="/badges/${esc(account.rankBadge?.key ?? 'stone')}.png" alt="" loading="lazy" />
            <span>${esc(account.rankBadge?.label ?? 'Stone')}</span>
          </span>
          ${(account.badges ?? [])
            .map(
              (badge) =>
                `<span class="identity-badge" title="${esc(badge.label)}"><img src="${esc(badge.art)}" alt="${esc(badge.label)}" loading="lazy" /></span>`,
            )
            .join('')}
          ${(account.badges ?? []).length === 0 ? '<span class="identity-badge-empty">No achievement badges yet</span>' : ''}
        </div>
      </div>
    </div>`;

  const completed = reward.claimedToday ? ((Number(reward.streak) - 1) % 7) + 1 : Number(reward.streak) % 7;
  const activeDay = reward.claimableDay;
  const tileState = (day) => (day <= completed ? 'claimed' : day === activeDay ? 'available' : 'locked');
  // Uniform aspect-locked capsules: no stretched cells, no per-tile header text.
  const tiles = STREAK_TRACK.map((entry) => {
    const tone = tileState(entry.day);
    const jackpot = entry.day === STREAK_TRACK.length;
    const lock = '<span class="cap-lock" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="5" y="10" width="14" height="10" /><path d="M8.5 10V7.5a3.5 3.5 0 0 1 7 0V10" /></svg></span>';
    return `<article class="day-capsule ${tone}${jackpot ? ' jackpot' : ''}" data-day="${entry.day}"${tone === 'locked' ? ` title="Locked until day ${entry.day}"` : ''}>
      <span class="cap-day">Day ${entry.day}</span>
      <span class="cap-art">${tone === 'locked' ? lock : ''}<img src="${rewardArt(entry.art)}" alt="" loading="lazy" /></span>
      <strong class="cap-label">${esc(entry.label)}</strong>
      ${jackpot ? '<span class="cap-jackpot">Jackpot</span>' : ''}
      ${tone === 'claimed' ? '<span class="cap-state secured">✓ Secured</span>' : ''}
      ${tone === 'available' ? `<button class="cap-claim" data-claim="${esc(account.user_id)}">Grab loot</button>` : ''}
    </article>`;
  }).join('');

  const lifetime = Number(reward.lifetime ?? 0);
  const STAR_NODE = 'mobile_currency_star_token_01';
  const nodes = CLAIM_MILESTONES.filter((entry) => entry.at <= 50).map((entry) => {
    const reached = lifetime >= entry.at;
    // Ends are inset slightly so a pin never clips against the card edge.
    const position = Math.max(6, Math.min(94, entry.at));
    return `<div class="ms-node ${reached ? 'completed' : 'locked'}" style="left:${position}%">
      <span class="ms-pin">${reached ? '<b>✓</b>' : `<img src="${rewardArt(STAR_NODE)}" alt="" loading="lazy" /><span class="ms-lock" aria-hidden="true">🔒</span>`}</span>
      <strong>${entry.at}</strong>
      <span class="ms-node-label">${esc(entry.label)}</span>
    </div>`;
  }).join('');

  // Day-by-day flow strip: the same rail the Discord claim panel shows, so a
  // player can read the whole cycle without opening seven art tiles.
  const flow = STREAK_TRACK.map((entry, index) => {
    const tone = tileState(entry.day);
    const icon = tone === 'claimed' ? '✓' : tone === 'available' ? '🎁' : entry.day === STREAK_TRACK.length ? '★' : '🔒';
    const link = index < STREAK_TRACK.length - 1 ? `<i class="flow-link ${tone === 'claimed' ? 'done' : ''}" aria-hidden="true"></i>` : '';
    return `<button type="button" class="flow-node ${tone}${entry.day === STREAK_TRACK.length ? ' jackpot' : ''}" data-flow-day="${entry.day}" aria-label="Day ${entry.day} — ${esc(entry.label)}" title="Show day ${entry.day}">
      <span class="flow-dot" aria-hidden="true">${icon}</span>
      <span class="flow-day">Day ${entry.day}</span>
      <span class="flow-label">${esc(entry.label)}</span>
    </button>${link}`;
  }).join('');

  const basePayout = Number(state.settings?.economy?.dailyStreakBase ?? 100) || 100;
  const todayEntry = STREAK_TRACK[Math.max(1, Number(reward.claimableDay ?? 1)) - 1];
  const nextClaim =
    reward.claimedToday && Number(reward.nextAt)
      ? `<div class="streak-next">Next claim in <span data-countdown="${Number(reward.nextAt)}"></span></div>`
      : `<div class="streak-next">Today: <strong>${esc(todayEntry?.label ?? 'Coins drop')}</strong> · ${num(basePayout + Number(reward.streak ?? 0) * 25)} coins · +${50 * (Number(reward.streak ?? 0) + 1)} XP</div>`;

  const streak = `<div class="flow-track">${flow}</div>
    ${nextClaim}
    <div class="streak-rail">${tiles}</div>
    <div class="milestones">
      <div class="ms-label"><span>Career drops secured</span><span>${num(lifetime)} total</span></div>
      <div class="ms-track">
        <div class="ms-base"><i class="ms-fill" style="width:${Math.min(100, lifetime)}%"></i></div>
        ${nodes}
      </div>
      <div class="ms-foot">${num(Math.max(0, 50 - lifetime))} claims to the gilded checkpoint</div>
    </div>`;

  const CRATE_KEYS = new Set(['streak_lucky_key', 'streak_weekly_chest', 'milestone_10', 'milestone_25', 'milestone_50', 'milestone_100']);
  const VOUCHER_META = {
    streak_wager_token: { label: 'Wager token', note: 'Auto · +10% on your next challenge win' },
    streak_arcade_insurance: { label: 'Tower insurance', note: 'Auto · refunds a collapsed Tower Climb stake' },
    streak_playtime_boost: { label: 'Playtime boost', note: 'Auto · doubles playtime coins for 2 hours' },
    streak_bounty_shield: { label: 'Bounty shield', note: 'Auto · absorbs one bounty, then 24h safe' },
    streak_lucky_key: { label: 'Lucky key', note: 'Open for one crate roll' },
    streak_weekly_chest: { label: 'Weekly chest', note: 'Open for three rolls and 1,000 coins' },
    milestone_10: { label: 'Bronze crate', note: 'Open for one crate roll' },
    milestone_25: { label: 'Iron crate', note: 'Open for one crate roll' },
    milestone_50: { label: 'Gilded chest', note: 'Open for one crate roll' },
    milestone_100: { label: 'Elite vault', note: 'Open for one crate roll' },
  };
  const held = (reward.vouchers ?? []).filter((entry) => entry.key.startsWith('streak_') || entry.key.startsWith('milestone_'));
  const voucherBody = held.length
    ? `<div class="loop-list">${held
        .map((entry) => {
          const meta = VOUCHER_META[entry.key] ?? { label: entry.key, note: 'Voucher' };
          const open = CRATE_KEYS.has(entry.key);
          return `<div class="loop"><strong>${esc(meta.label)} x${num(entry.quantity)}</strong><span>${esc(meta.note)}</span>${
            open ? `<button class="ghost small" data-voucher="${esc(entry.key)}" data-voucher-user="${esc(account.user_id)}">Open</button>` : '<span class="muted">auto</span>'
          }</div>`;
        })
        .join('')}</div>`
    : '<div class="empty">No vouchers yet — claim a few days in a row.</div>';

  const circulation = Number(state.overview?.wallet ?? 0) + Number(state.overview?.bank ?? 0);
  const alertAt = Number(state.settings?.economy?.circulationAlert ?? 0);
  const overAlert = alertAt > 0 && circulation >= alertAt;

  const recentTx = (state.economy?.transactions ?? state.transactions ?? []).slice(0, 5);
  const ledger = `<table class="table"><thead><tr><th>When</th><th>Movement</th><th>Amount</th></tr></thead><tbody>${
    recentTx
      .map(
        (tx) => `<tr><td>${time(tx.created_at)}</td><td><span class="tag">${esc(String(tx.kind).replace(/^arcade_/, ''))}</span></td><td>${Number(tx.amount) > 0 ? '+' : ''}${num(tx.amount)}</td></tr>`,
      )
      .join('') || '<tr><td colspan="3" class="empty">No activity recorded yet.</td></tr>'
  }</tbody></table>`;

  const vaults = `<div class="vault-grid">
      <div class="vault wallet"><span>Wallet balance</span><strong class="data-pill">${num(account.wallet)}</strong><small>Drops if you die in-game</small></div>
      <div class="vault bank"><span>The vault</span><strong class="data-pill">${num(account.bank)}</strong><small>Protected from death penalties</small></div>
    </div>
    <div class="vault-actions">
      <button class="btn-vault" data-bank="deposit" data-bank-user="${esc(account.user_id)}" data-bank-wallet="${Number(account.wallet)}" data-bank-bank="${Number(account.bank)}">Deposit</button>
      <button class="btn-vault ghost" data-bank="withdraw" data-bank-user="${esc(account.user_id)}" data-bank-wallet="${Number(account.wallet)}" data-bank-bank="${Number(account.bank)}">Withdraw</button>
      <span class="circulation ${overAlert ? 'alert' : ''}">Coins in circulation ${num(circulation)}${alertAt ? ` / alert ${num(alertAt)}` : ''}</span>
    </div>
    <div class="ledger">
      <div class="ledger-head">Recent coin movement</div>
      ${ledger}
    </div>`;

  const referral = account.referral ?? (state.referrals ?? []).find((entry) => entry.owner_id === account.user_id) ?? null;
  const referralUses = Number(referral?.uses ?? 0);
  const referralMax = Number(referral?.max_uses ?? 0);
  const referralReward = Number(state.settings?.economy?.referralBonus ?? 0);
  const referralBody = referral
    ? `<div class="ref-card">
        <div class="ref-code"><span>Invite code</span><code>${esc(referral.code)}</code></div>
        <div class="ref-stats">
          <div><span>Invites</span><strong>${num(referralUses)}</strong></div>
          <div><span>Per invite</span><strong>${num(referralReward)}</strong></div>
          <div><span>Cap</span><strong>${referralMax ? num(referralMax) : '∞'}</strong></div>
        </div>
        <div class="ref-bar"><i style="width:${referralMax ? Math.min(100, Math.round((referralUses / referralMax) * 100)) : 100}%"></i></div>
        <div class="ref-foot">${referral.active ? 'Active' : 'Paused'} · share the code in Discord with /referral</div>
      </div>`
    : '<div class="empty">No referral code yet — create one in Discord with /referral.</div>';

  const refTop = [...(state.referrals ?? [])]
    .filter((entry) => Number(entry.uses) > 0)
    .sort((a, b) => Number(b.uses) - Number(a.uses))
    .slice(0, 5);
  const refTopList = refTop.length
    ? `<div class="ref-top"><span>Top referrers</span>${refTop
        .map(
          (entry, index) =>
            `<div class="ref-row"><b>${index + 1}</b><span class="ref-pill">${esc(entry.code)}</span><span>${num(entry.uses)}</span></div>`,
        )
        .join('')}</div>`
    : '';

  const clanBody = team
    ? `<div class="loop"><strong>${esc(team.name)} [${esc(team.tag)}]</strong><span>${esc(membership?.rank ?? 'member')} · ${num(team.members)} members</span></div>
       <div class="loop" style="margin-top:8px"><strong>Wars</strong><span>${activeWars.length ? `${activeWars.length} active` : 'none active'}</span></div>
       ${activeWars.map((war) => `<div class="loop" style="margin-top:8px"><strong>vs ${esc(war.opponent_name ?? '—')}</strong><span>${esc(war.score)} · since ${time(war.started_at)}</span></div>`).join('')}`
    : `<p class="muted">No clan on record. Create one with /team create, or join a clan in Discord.</p>`;

  const windows = state.hubs?.orp?.srpWindows ?? [];
  const srp = windows.length
    ? windows
        .map((window) => `<div class="loop"><strong>${esc((window.days ?? []).map((day) => ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][day] ?? day).join(' ') || 'Daily')}</strong><span>${String(window.startHour ?? 0).padStart(2, '0')}:00–${String(window.endHour ?? 0).padStart(2, '0')}:00 ${esc(window.timezone ?? 'UTC')}</span></div>`)
        .join('')
    : '<p class="muted">No raid-protection windows configured.</p>';

  const wipeBody = `<div class="vault-grid">
      <div class="vault"><span>Next wipe</span><strong>${wipe ? '<span data-countdown="' + Number(wipe.next_wipe_at) + '"></span>' : '—'}</strong><small>${wipe ? `${esc(wipe.name)} · every ${esc(wipe.interval_hours)}h` : 'No wipe scheduled'}</small></div>
      <div class="vault"><span>ZORP</span><strong>${state.hubs?.orp?.zorpEnabled ? `${state.hubs.orp.zorpDamageReduction}%` : 'off'}</strong><small>${state.hubs?.orp?.zorpGraceMinutes ?? 0} min grace after disconnect</small></div>
    </div>
    <div style="margin-top:12px">${srp}</div>`;

  const jackpot = state.jackpot;
  const jackpotHistory = (jackpot?.history ?? [])
    .slice(0, 5)
    .map(
      (entry) =>
        `<div class="loop"><strong>${esc(entry.userId)}</strong><span>${num(entry.amount)} coins · ${esc(entry.game)} · ${time(entry.createdAt)}</span></div>`,
    )
    .join('');
  const jackpotBody = jackpot
    ? `<div class="vault-grid">
        <div class="vault"><span>Current pool</span><strong>${num(jackpot.balance)}</strong><small>Progressive pool</small></div>
        <div class="vault"><span>Seed / minimum</span><strong>${num(jackpot.seed)} / ${num(jackpot.minimum)}</strong><small>${jackpot.rakePercent}% rake on eligible wagers</small></div>
      </div>
      <div class="loop-list" style="margin-top:12px">${jackpotHistory || '<div class="empty">No jackpot winners yet.</div>'}</div>`
    : '<div class="empty">Jackpot data is unavailable until the bot has started once.</div>';

  return `${head}
    ${card('Identity card', link ? link.platform : 'unlinked', 'pink', identity, `<span class="muted">Joined ${time(account.created_at)}</span>`)}
    ${card('Referral card', referral ? `${num(referralUses)} invites` : 'no code', 'teal', referralBody + refTopList)}
    ${card('Daily Run', `${num(reward.streak)} ${Number(reward.streak) === 1 ? 'Day' : 'Days'} Straight • Cycle ${Number(reward.cycle ?? 0) + 1}`, 'red', streak)}
    ${card('Progressive jackpot', jackpot ? `${num(jackpot.balance)} coins` : 'unavailable', 'gold', jackpotBody)}
    ${card('Safe &amp; bank inventory', 'wallet · bank', 'gold', vaults)}
    ${card('Streak vouchers', `${held.length} held`, 'purple', voucherBody)}
    <div class="hub-2">
      ${card('Active clan status', team ? `[${esc(team.tag)}]` : 'no clan', 'teal', clanBody)}
      ${card('Wipe tracker', wipe ? 'scheduled' : 'none', 'red', wipeBody)}
    </div>`;
}

function renderModeratorHub() {
  const hubs = state.hubs ?? {};
  const telemetry = hubs.telemetry ?? [];
  const events = (state.status?.events ?? []).slice(-40).reverse();
  const online = hubs.online ?? [];
  const decode = (value) => {
    try {
      return typeof value === 'string' ? JSON.parse(value || '{}') : value ?? {};
    } catch {
      return {};
    }
  };

  const feed = (telemetry.length ? telemetry : events)
    .slice(0, 40)
    .map((event) => {
      const detail = telemetry.length
        ? Object.entries(decode(event.payload))
            .map(([key, value]) => `${key}=${typeof value === 'object' ? JSON.stringify(value) : value}`)
            .join(' ') || '—'
        : `${serverLabel(event.server_id)} · ${event.players ?? 0} players`;
      return `<div class="feed-line"><time>${new Date(Number(event.created_at)).toLocaleTimeString()}</time><b>${esc(event.kind ?? event.status ?? 'event')}</b><span>${esc(detail)}</span></div>`;
    })
    .join('');

  const index = table(
    ['Gamertag', 'Platform', 'Server', 'Session', 'User'],
    online.map((session) => {
      const link = (state.links ?? []).find((entry) => entry.user_id === session.user_id);
      return [
        esc(session.gamertag ?? '—'),
        link ? tag(link.platform) : '<span class="muted">—</span>',
        esc(serverLabel(session.server_id)),
        `${Math.max(1, Math.round((Date.now() - Number(session.started_at)) / 60_000))}m`,
        `<code>${esc(session.user_id ?? '—')}</code>`,
      ];
    }),
    'No live sessions. They appear as WebRCON join telemetry arrives.',
  );

  const tickets = (state.tickets?.open ?? [])
    .map(
      (ticket) => `<div class="loop"><strong>${esc(ticket.subject)}</strong><span>${esc(ticket.priority ?? 'normal')} · ${ago(ticket.created_at)} ago · ${esc(ticket.owner_id)}</span></div>`,
    )
    .join('');

  const sanction = `<div class="sanction">
      <label class="field"><span>Target user ID</span><input data-sanction="target" placeholder="Discord user ID" /></label>
      <label class="field"><span>Action</span><select data-sanction="action"><option>note</option><option>warn</option><option>timeout</option><option>kick</option></select></label>
      <label class="field wide"><span>Reason</span><input data-sanction="reason" placeholder="What happened, and what should the next moderator know?" /></label>
    </div>
    <div class="sanction-foot">
      <span class="muted">Writes a case to the shared mod log with a settings audit entry.</span>
      <button class="primary small" data-sanction-send>Record case</button>
    </div>`;

  return `<div class="hub-head"><div><h2>Moderator dashboard</h2><p>Live telemetry, who is online, sanctions and the support queue.</p></div></div>
    <div class="metrics">
      ${metric('Players in session', num(online.length), 'teal')}
      ${metric('Open tickets', num((state.tickets?.open ?? []).length), toneFor((state.tickets?.open ?? []).length))}
      ${metric('Cases on file', num((state.moderation?.cases ?? []).length), 'red')}
      ${metric('Pending appeals', num((state.moderation?.appeals ?? []).length), 'orange')}
    </div>
    <div class="hub-2">
      ${card('Live telemetry terminal', `${telemetry.length || events.length} events`, 'teal', `<div class="terminal-feed">${feed || '<div class="empty">No activity recorded yet.</div>'}</div>`)}
      ${card('Sanction utility', 'writes a case', 'red', sanction)}
    </div>
    ${card('Active player index', `${online.length} live`, 'blue', index)}
    ${card('Support ticket queue', `${(state.tickets?.open ?? []).length} open`, 'orange', `<div class="loop-list">${tickets || '<div class="empty">Queue is clear.</div>'}</div>`)}`;
}

function renderAdministratorHub() {
  const hubs = state.hubs ?? {};
  const loops = hubs.loops ?? {};
  const orp = hubs.orp ?? {};
  const products = state.shop?.products ?? [];
  const tasks = state.tasks ?? [];
  const kits = hubs.kits ?? [];

  const store = `<div class="entity-list">${products.slice(0, 8).map(productCard).join('') || empty('No products. Add them with /shop-admin.')}</div>${products.length > 8 ? `<p class="muted">Showing 8 of ${num(products.length)} products — open Shop to browse the full catalog.</p>` : ''}`;

  const kitRows = table(
    ['Kit', 'Price', 'Command', 'Role'],
    kits.map((kit) => [
      `<strong>${esc(kit.name ?? '—')}</strong>`,
      num(kit.price ?? 0),
      `<code>${esc(kit.rconCommand ?? '—')}</code>`,
      kit.roleId ? `<code>${esc(kit.roleId)}</code>` : '<span class="muted">everyone</span>',
    ]),
    'No kits registered. Build them with /kit-panel.',
  );

  const taskRows = tasks.length
    ? tasks
        .map(
          (task) => `<div class="loop"><strong>${esc(task.name)}</strong><span>${esc(task.kind)} · ${Math.round(Number(task.interval_seconds) / 60)}m · ${task.next_run_at ? time(task.next_run_at) : 'not scheduled'}</span>${switchRow('task.toggle', task.id, Boolean(task.enabled), '')}</div>`,
        )
        .join('')
    : '<div class="empty">No scheduled tasks configured.</div>';

  const loopBody = `<div class="loop-list">
      <div class="loop"><strong>Rotating messages</strong><span>${loops.messageSeconds ? `every ${Math.round(Number(loops.messageSeconds) / 60)}m` : 'not configured'}</span></div>
      <div class="loop"><strong>Gift drops</strong><span>${loops.giftMinutes ? `every ${loops.giftMinutes}m` : 'not configured'}</span></div>
      <div class="loop"><strong>Playtime coins</strong><span>${num(loops.playtimeReward)} per tick · x${loops.boosterMultiplier} for boosters</span></div>
      <div class="loop"><strong>Auto-kits</strong><span>${loops.autoKits ? 'enabled' : 'disabled'}</span></div>
    </div>
    <div style="margin-top:12px">${taskRows}</div>`;

  const orpForm = `<div class="orp-form">
      <label class="field"><span>ZORP</span><select data-orp="zorpEnabled"><option value="true" ${orp.zorpEnabled ? 'selected' : ''}>Enabled</option><option value="false" ${orp.zorpEnabled ? '' : 'selected'}>Disabled</option></select></label>
      <label class="field"><span>Damage reduction (%)</span><input type="number" min="0" max="100" data-orp="zorpDamageReduction" value="${esc(orp.zorpDamageReduction ?? 75)}" /></label>
      <label class="field"><span>Grace minutes</span><input type="number" min="0" max="120" data-orp="zorpGraceMinutes" value="${esc(orp.zorpGraceMinutes ?? 10)}" /></label>
      <label class="field"><span>SRP</span><select data-orp="srpEnabled"><option value="true" ${orp.srpEnabled ? 'selected' : ''}>Enabled</option><option value="false" ${orp.srpEnabled ? '' : 'selected'}>Disabled</option></select></label>
      <label class="field"><span>RaidLink minimum damage</span><input type="number" min="0" data-orp="raidLinkMinDamage" value="${esc(orp.raidLinkMinDamage ?? 50)}" /></label>
      <label class="field"><span>SRP windows</span><input data-orp="srpWindows" value="${esc(JSON.stringify(orp.srpWindows ?? []))}" /></label>
    </div>
    <div class="sanction-foot"><span class="muted">Zones are defined per team with /team config; these are the network-wide thresholds.</span><button class="primary small" data-orp-save>Save protection</button></div>`;

  return `<div class="hub-head"><div><h2>Administrator dashboard</h2><p>Store paths, kit variables, automation loops and protection boundaries.</p></div></div>
    <div class="metrics">
      ${metric('Products', num(products.length), 'purple')}
      ${metric('Revenue · 30d', num(state.shop?.sales?.revenue ?? 0), 'teal')}
      ${metric('Scheduled tasks', num(tasks.length), 'blue')}
      ${metric('Kits registered', num(kits.length), 'gold')}
    </div>
    ${card('Server store architect', `${products.length} products`, 'teal', store)}
    <div class="hub-2">
      ${card('Kit builder matrix', `${kits.length} kits`, 'purple', kitRows)}
      ${card('System loop controllers', 'timings', 'blue', loopBody)}
    </div>
    ${card('ZORP boundary mapping', orp.srpEnabled ? 'SRP on' : 'ZORP only', 'red', orpForm)}`;
}

function renderOwnerHub() {
  const hubs = state.hubs ?? {};
  const health = hubs.health ?? {};
  const finance = hubs.finance ?? {};
  const staff = state.moderation?.staff ?? [];
  const transactions = state.economy?.transactions ?? [];
  const plan = state.plan ?? {};
  const seatInfo = plan.seats ?? null;
  const seatRows = seatInfo?.seats ?? [];

  const healthBody = `<div class="health-grid">
      <div class="health"><span>Console uptime</span><strong>${fmtDuration(Number(health.uptimeSeconds ?? 0) * 1000)}</strong></div>
      <div class="health"><span>Resident memory</span><strong>${num(health.memoryMb ?? 0)} MB</strong></div>
      <div class="health"><span>Database</span><strong>${(Number(health.dbBytes ?? 0) / 1_048_576).toFixed(1)} MB</strong></div>
      <div class="health"><span>Servers online</span><strong>${num(health.serversOnline ?? 0)}/${num(health.servers ?? 0)}</strong></div>
    </div>
    <div class="hub-3" style="margin-top:12px">
      ${(state.status?.servers ?? []).map((server) => `<div class="health"><span>${esc(server.label)}</span><strong>${server.uptimePercent}%</strong><div class="uptime" style="margin-top:8px"><i style="width:${Math.max(0, Math.min(100, server.uptimePercent))}%"></i></div><span style="margin-top:6px">${num(server.incidents)} incidents</span></div>`).join('') || empty('No servers connected.')}
    </div>`;

  const financeBody = `<div class="health-grid">
      <div class="health"><span>Coin supply</span><strong>${num(finance.supply ?? 0)}</strong></div>
      <div class="health"><span>Minted · 30d</span><strong>${num(finance.minted ?? 0)}</strong></div>
      <div class="health"><span>Burned · 30d</span><strong>${num(finance.burned ?? 0)}</strong></div>
      <div class="health"><span>Store · 30d</span><strong>${num(finance.revenue30 ?? 0)}</strong></div>
    </div>
    <div style="margin-top:12px">${table(
      ['When', 'User', 'Kind', 'Amount'],
      transactions.slice(0, 20).map((entry) => [time(entry.created_at), `<code>${esc(entry.user_id)}</code>`, esc(entry.kind), num(entry.amount)]),
      'No transactions recorded.',
    )}</div>`;

  const recovery = `<div class="danger-row">
      <button class="danger" data-backup>Download database backup</button>
      <button class="danger ghost" data-snapshot>Download config snapshot</button>
    </div>
    <p class="danger-note">Backups run SQLite VACUUM INTO inside data/backups and stream the file to you. Channel-scoped nuke cleanups are not exposed from the web console.</p>`;

  const registry = table(
    ['Moderator', 'Cases · 30d', 'Bans'],
    staff.map((entry) => [`<code>${esc(entry.moderator_id)}</code>`, num(entry.total), num(entry.bans)]),
    'No staff cases in the last 30 days.',
  );

  const roles = `<div class="loop-list">
      <div class="loop"><strong>Support roles</strong><span>${(hubs.staffRoles?.support ?? []).map(esc).join(', ') || 'not configured'}</span></div>
      <div class="loop"><strong>Recruiter roles</strong><span>${(hubs.staffRoles?.recruiters ?? []).map(esc).join(', ') || 'not configured'}</span></div>
    </div>
    <div style="margin-top:12px">${registry}</div>`;

  const seatBody = seatInfo?.active
    ? `<div class="health-grid">
        <div class="health"><span>Plan</span><strong>${esc(seatInfo.label ?? plan.label ?? '—')}</strong></div>
        <div class="health"><span>Seat usage</span><strong>${num(seatInfo.used)}/${num(seatInfo.seatLimit)}</strong></div>
        <div class="health"><span>Owner account</span><strong>${esc(seatInfo.membership?.user_id ?? '—')}</strong></div>
        <div class="health"><span>Renews</span><strong>${seatInfo.lifetime ? 'Lifetime' : time(seatInfo.expiresAt)}</strong></div>
      </div>
      <div style="margin-top:12px">${table(
        ['Attached server', 'Plan', 'Expires'],
        seatRows.map((seat) => [`<strong>${esc(seat.name || seat.id)}</strong>`, esc(seat.plan), time(seat.plan_expires_at)]),
        'No servers attached yet. Run /plan in Discord to use a seat.',
      )}</div>
      <p class="danger-note">Seats are owned by the Discord account. Use /plan to attach, release or move one; /transfer moves the whole server plan.</p>`
    : `<div class="empty">This server is not attached to a Pro or Max subscription seat. Open /plan in Discord to attach one, or buy an extra server from the plan panel.</div>`;

  return `<div class="hub-head"><div><h2>Owner dashboard</h2><p>Infrastructure health, the money trail, recovery and access clearances.</p></div></div>
    <div class="metrics">
      ${metric('Node', esc(health.node ?? '—'), 'blue')}
      ${metric('Incidents · 7d', num(health.incidents7d ?? 0), 'orange')}
      ${metric('Coin supply', num(finance.supply ?? 0), 'gold')}
      ${metric('Staff active · 30d', num(staff.length), 'purple')}
      ${metric('Server seats', seatInfo?.active ? `${num(seatInfo.used)}/${num(seatInfo.seatLimit)}` : '—', 'teal')}
    </div>
    ${card('Global node health', `${num(health.servers ?? 0)} servers`, 'teal', healthBody)}
    ${card('Subscription & server seats', seatInfo?.active ? `${num(seatInfo.used)}/${num(seatInfo.seatLimit)} used` : 'not attached', 'gold', seatBody)}
    ${card('Financial transaction audit', '30 days', 'gold', financeBody)}
    ${card('Disaster recovery', 'destructive', 'red', recovery)}
    ${card('Staff authorization registry', `${staff.length} staff`, 'purple', roles)}`;
}

/* ── Hub actions ───────────────────────────────────────── */

function openBankSheet(direction, userId, wallet, bank) {
  let host = document.getElementById('bank');
  if (!host) {
    host = document.createElement('div');
    host.id = 'bank';
    host.className = 'bank-modal';
    document.body.appendChild(host);
  }
  const toVault = direction === 'deposit';
  host.dataset.direction = direction;
  host.dataset.user = userId;
  host.classList.add('open');
  host.innerHTML = `<div class="bank-sheet" role="dialog" aria-modal="true">
    <header><strong>${toVault ? 'Deposit to vault' : 'Withdraw to wallet'}</strong><button data-bank-close aria-label="Close">✕</button></header>
    <div class="bank-body">
      <p class="bank-msg">Wallet ${num(wallet)} · vault ${num(bank)}</p>
      <div class="wager-row">
        <label for="bank-amount">Amount</label>
        <input id="bank-amount" type="number" min="1" step="1" inputmode="numeric" value="100" />
        <button class="primary" data-bank-confirm="${direction}">${toVault ? 'Deposit' : 'Withdraw'}</button>
      </div>
      <p class="bank-msg">${toVault ? 'Moves coins straight into the protected vault.' : 'Moves coins from the vault into your wallet.'} Confirmed in one step.</p>
    </div>
  </div>`;
  document.getElementById('bank-amount')?.focus();
}

function closeBankSheet() {
  const host = document.getElementById('bank');
  if (!host) return;
  host.classList.remove('open');
  host.innerHTML = '';
}

async function confirmBank(direction) {
  const host = document.getElementById('bank');
  const amount = Number(document.getElementById('bank-amount')?.value ?? 0);
  try {
    const result = await post('bank.move', { userId: host?.dataset.user, direction, amount });
    closeBankSheet();
    toast(`${direction === 'deposit' ? 'Deposited' : 'Withdrew'} ${num(amount)} · wallet ${num(result.wallet)} · vault ${num(result.bank)}`);
    await load();
  } catch (error) {
    toast(error.message, 'error');
  }
}

function tickCountdowns() {
  document.querySelectorAll('[data-countdown]').forEach((element) => {
    const at = Number(element.dataset.countdown ?? 0);
    element.textContent = at ? fmtDuration(at - Date.now()) : '—';
  });
}
setInterval(tickCountdowns, 1000);

function downloadSnapshot() {
  const blob = new Blob(
    [JSON.stringify({ exportedAt: new Date().toISOString(), guildId, settings: state.settings, guilds: state.guilds }, null, 2)],
    { type: 'application/json' },
  );
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `astrobot-config-${guildId || 'guild'}.json`;
  anchor.click();
  URL.revokeObjectURL(url);
}

document.body.addEventListener('click', async (event) => {
  const claim = event.target.closest('[data-claim]');
  if (claim) {
    claim.disabled = true;
    try {
      const result = await post('player.claimDaily', { userId: claim.dataset.claim });
      toast(`Day ${result.day} claimed · +${num(result.amount)} coins${result.voucher ? ` · ${result.voucher.replace('streak_', '').replaceAll('_', ' ')}` : ''}`);
      await load();
    } catch (error) {
      toast(error.message, 'error');
      claim.disabled = false;
    }
    return;
  }

  const bankBtn = event.target.closest('[data-bank]');
  if (bankBtn) {
    openBankSheet(bankBtn.dataset.bank, bankBtn.dataset.bankUser, bankBtn.dataset.bankWallet, bankBtn.dataset.bankBank);
    return;
  }
  if (event.target.closest('[data-bank-close]')) {
    closeBankSheet();
    return;
  }
  const bankConfirm = event.target.closest('[data-bank-confirm]');
  if (bankConfirm) {
    await confirmBank(bankConfirm.dataset.bankConfirm);
    return;
  }

  const voucher = event.target.closest('[data-voucher]');
  if (voucher) {
    voucher.disabled = true;
    try {
      const result = await post('voucher.use', { userId: voucher.dataset.voucherUser, itemKey: voucher.dataset.voucher });
      const loot = (result.rewards ?? []).map((reward) => (reward.kind === 'coins' ? `${num(reward.quantity)} coins` : `${reward.itemKey} x${reward.quantity}`)).join(', ');
      toast(`Crate opened · ${loot || 'nothing'}${result.coins ? ` · +${num(result.coins)} coins` : ''}`);
      await load();
    } catch (error) {
      toast(error.message, 'error');
      voucher.disabled = false;
    }
    return;
  }

  const sanction = event.target.closest('[data-sanction-send]');
  if (sanction) {
    const host = sanction.closest('.card');
    const targetId = host.querySelector('[data-sanction="target"]')?.value.trim() ?? '';
    const action = host.querySelector('[data-sanction="action"]')?.value ?? 'note';
    const reason = host.querySelector('[data-sanction="reason"]')?.value.trim() ?? '';
    try {
      await post('mod.note', { targetId, kind: action, reason });
      toast('Case recorded.');
      await load();
    } catch (error) {
      toast(error.message, 'error');
    }
    return;
  }

  const orpSave = event.target.closest('[data-orp-save]');
  if (orpSave) {
    const host = orpSave.closest('.card');
    const next = { ...(state.hubs?.orp ?? {}) };
    try {
      host.querySelectorAll('[data-orp]').forEach((input) => {
        const key = input.dataset.orp;
        if (key === 'srpWindows') next[key] = JSON.parse(input.value || '[]');
        else if (input.tagName === 'SELECT') next[key] = input.value === 'true';
        else next[key] = Number(input.value);
      });
      await post('settings.saveMany', { groups: { orp: next } });
      toast('Protection thresholds saved.');
      await load();
    } catch (error) {
      toast(error.message, 'error');
    }
    return;
  }

  if (event.target.closest('[data-backup]')) {
    window.location.href = '/api/backup';
    return;
  }
  if (event.target.closest('[data-snapshot]')) {
    downloadSnapshot();
  }
});

document.body.addEventListener('change', (event) => {
  const select = event.target.closest('[data-hub-player]');
  if (!select) return;
  hubUser = select.value;
  render();
});

