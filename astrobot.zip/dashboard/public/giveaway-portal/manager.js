(() => {
  const state = {
    guildId: '',
    rootDomain: 'giveaway.astro.com',
    brandName: 'Astro',
    giveaways: [],
    editing: null,
    editingTasks: [],
    editingFaq: [],
    analyticsGiveaway: null,
  };
  const TASK_ICONS = ['twitch', 'discord', 'x', 'youtube', 'instagram', 'tiktok', 'kick', 'xbox', 'playstation', 'steam', 'link'];
  let taskDragIndex = null;
  let faqDragIndex = null;
  const DEFAULT_BONUS_TASKS = [
    { title: 'Follow on Twitch', subtitle: 'The live draw happens on stream', points: 5, icon: 'twitch', url: 'https://twitch.tv/' },
    { title: 'Join the Discord', subtitle: 'Members-only drops and early reveals', points: 10, icon: 'discord', url: 'https://discord.gg/' },
    { title: 'Follow on X', subtitle: 'Winner announcements post there first', points: 5, icon: 'x', url: 'https://x.com/' },
  ];
  const DEFAULT_FAQ = [
    { question: 'Do I really not have to pay anything?', answer: 'Correct — entry is 100% free. No purchase is ever necessary to enter or win.' },
    { question: 'How is the winner picked?', answer: "Every completed task adds weighted entries into a live, on-stream random draw. More entries = better odds, not a guarantee — it's still a raffle." },
    { question: 'When do entries close?', answer: 'The instant the countdown above hits zero. There are no extensions and no late entries, regardless of task completion status.' },
    { question: 'How will I know if I won?', answer: 'Winners are announced live on stream and contacted via the email and gamertag, PSN ID or Steam username submitted at entry. Check the Discord #winners channel too.' },
  ];
  let statusTimer = null;
  const DEFAULT_THEME = {
    brand: 'Astro',
    colors: { bg: '#07070d', cyan: '#00f0ff', magenta: '#ff2ec4', lime: '#c6ff3d', ink: '#eef0f8' },
  };

  const $ = (id) => document.getElementById(id);
  const escapeHtml = (value) =>
    String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
  const escapeAttr = (value) => escapeHtml(value);

  function cookie(name) {
    const part = document.cookie.split('; ').find((entry) => entry.startsWith(`${name}=`));
    if (!part) return '';
    try {
      return decodeURIComponent(part.slice(name.length + 1));
    } catch {
      return part.slice(name.length + 1);
    }
  }

  function setStatus(message, kind = '') {
    const el = $('manager-status');
    if (!el) return;
    el.textContent = message || '';
    el.className = `manager-status${kind ? ` ${kind}` : ''}`;
    clearTimeout(statusTimer);
    if (message && kind !== 'err') {
      statusTimer = setTimeout(() => {
        el.textContent = '';
        el.className = 'manager-status';
      }, 4500);
    }
  }

  async function api(path, options = {}) {
    const headers = { 'x-dashboard': '1', ...(options.headers || {}) };
    if (options.body) headers['Content-Type'] = 'application/json';
    const csrf = cookie('astro_csrf');
    if (csrf) headers['x-csrf-token'] = csrf;
    const response = await fetch(path, {
      credentials: 'same-origin',
      cache: 'no-store',
      ...options,
      headers,
    });
    const body = await response.json().catch(() => ({}));
    if (response.status === 401) throw new Error('Sign in to the dashboard to manage giveaways.');
    if (!response.ok) throw new Error(body.error || `Request failed (${response.status}).`);
    return body;
  }

  function toLocalInputValue(timestamp) {
    const date = new Date(timestamp);
    const pad = (value) => String(value).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
  }

  function formatDate(timestamp) {
    return new Date(timestamp).toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  }

  function renderGuilds(guilds) {
    const select = $('manager-guild');
    if (!select) return;
    select.innerHTML = (guilds || [])
      .map((guild) => `<option value="${escapeAttr(guild.id)}">${escapeHtml(guild.name || guild.id)}</option>`)
      .join('');
    if (state.guildId) select.value = state.guildId;
  }

  function renderList() {
    const list = $('giveaway-list');
    if (!list) return;
    if (!state.giveaways.length) {
      list.innerHTML = '<p class="manager-empty">No giveaways yet. Create one to get a public page and analytics.</p>';
      return;
    }
    list.innerHTML = state.giveaways
      .map((giveaway) => {
        const conversion = Number(giveaway.views)
          ? `${Math.round((giveaway.entries / giveaway.views) * 1000) / 10}%`
          : '0%';
        const health = giveaway.domainHealth;
        const healthLabel = health ? `domain ${health.status}` : 'domain unchecked';
        return `<article class="giveaway-row" data-id="${escapeAttr(giveaway.id)}">
          <div class="giveaway-row-head">
            <div>
              <div class="giveaway-host">${escapeHtml(giveaway.username)}<span class="status-pill ${escapeAttr(giveaway.status)}">${escapeHtml(giveaway.status)}</span></div>
              <div class="giveaway-prize">${escapeHtml(giveaway.prize)}</div>
              <div class="giveaway-meta">Ends ${escapeHtml(formatDate(giveaway.endsAt))} · ${escapeHtml(giveaway.host)} · <span class="domain-pill ${escapeAttr(health?.status || '')}">${escapeHtml(healthLabel)}</span></div>
            </div>
            <div class="giveaway-actions">
              <a class="btn btn-outline btn-sm" href="${escapeAttr(giveaway.publicPath)}" target="_blank" rel="noopener">Open page</a>
              <a class="btn btn-outline btn-sm" href="${escapeAttr(giveaway.linksPath)}" target="_blank" rel="noopener">Link page</a>
              <button class="btn btn-outline btn-sm" type="button" data-action="analytics">Analytics</button>
              <button class="btn btn-outline btn-sm" type="button" data-action="domain">Domain check</button>
              <button class="btn btn-outline btn-sm" type="button" data-action="export">Export CSV</button>
              <button class="btn btn-outline btn-sm" type="button" data-action="edit">Edit</button>
              <button class="btn btn-danger btn-sm" type="button" data-action="delete">Delete</button>
            </div>
          </div>
          <div class="giveaway-stats">
            <div class="giveaway-stat"><strong>${Number(giveaway.views).toLocaleString()}</strong><span>views</span></div>
            <div class="giveaway-stat"><strong>${Number(giveaway.entries).toLocaleString()}</strong><span>entries</span></div>
            <div class="giveaway-stat"><strong>${conversion}</strong><span>conversion</span></div>
            <div class="giveaway-stat"><strong>${Number(giveaway.linkClicks).toLocaleString()}</strong><span>link clicks</span></div>
          </div>
        </article>`;
      })
      .join('');
  }

  function renderAnalytics(giveaway, analytics) {
    const panel = $('giveaway-analytics');
    const body = $('analytics-body');
    if (!panel || !body) return;
    state.analyticsGiveaway = giveaway;
    const daily = Array.isArray(analytics.daily) ? analytics.daily.slice(-14) : [];
    const max = Math.max(1, ...daily.map((day) => Number(day.views) || 0));
    $('analytics-title').textContent = `@${giveaway.username} · Analytics`;
    const bars = daily.length
      ? daily
          .map((day) => {
            const height = Math.max(3, Math.round(((Number(day.views) || 0) / max) * 72));
            return `<div class="analytics-day" title="${escapeAttr(day.day)}: ${Number(day.views)} views, ${Number(day.entries)} entries">
              <div class="analytics-bar" style="height:${height}px"></div>
              <span>${escapeHtml(String(day.day).slice(5))}</span>
            </div>`;
          })
          .join('')
      : '<p class="manager-empty">No traffic recorded yet.</p>';
    const taskRows = Array.isArray(analytics.taskAnalytics) ? analytics.taskAnalytics : [];
    const taskTable = taskRows.length
      ? `<div class="analytics-tasks"><div class="analytics-tasks-head"><h4>Public task claims</h4><button class="btn btn-outline btn-sm" data-export-tasks type="button">Export CSV</button></div>
          <div class="analytics-task-row head"><strong>Task</strong><span>Claims</span><span>Tickets</span><span>Points</span></div>
          ${taskRows.map((task) => `<div class="analytics-task-row"><strong>${escapeHtml(task.title)}</strong><span>${Number(task.claims).toLocaleString()}</span><span>${Number(task.tickets).toLocaleString()}</span><span>${Number(task.points)}</span></div>`).join('')}
        </div>`
      : '';
    body.innerHTML = `<div class="analytics-grid">
      <div class="analytics-stat"><strong>${Number(analytics.views).toLocaleString()}</strong><span>Page views</span></div>
      <div class="analytics-stat"><strong>${Number(analytics.entries).toLocaleString()}</strong><span>Entries</span></div>
      <div class="analytics-stat"><strong>${Number(analytics.conversion).toLocaleString()}%</strong><span>Conversion</span></div>
      <div class="analytics-stat"><strong>${Number(analytics.linkClicks).toLocaleString()}</strong><span>Link clicks</span></div>
      <div class="analytics-stat"><strong>${Number(analytics.linkPageViews).toLocaleString()}</strong><span>Link page views</span></div>
      <div class="analytics-stat"><strong>${Number(analytics.bonusClaims).toLocaleString()}</strong><span>Bonus claims</span></div>
    </div>
    <div class="analytics-chart">${bars}</div>
    ${taskTable}`;
    panel.hidden = false;
    panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function updateHostHint() {
    const input = $('g-username');
    const hint = $('g-host-hint');
    if (!input || !hint) return;
    const username = input.value.trim().toLowerCase() || 'username';
    hint.textContent = `${username}.${state.rootDomain} · also /g/${username}`;
  }

  function showEditor(giveaway = null) {
    state.editing = giveaway ? giveaway.id : null;
    $('editor-title').textContent = giveaway ? 'Edit giveaway' : 'New giveaway';
    $('g-username').value = giveaway?.username || '';
    $('g-status').value = giveaway?.status || 'active';
    $('g-prize').value = giveaway?.prize || '';
    $('g-description').value = giveaway?.description || '';
    const theme = giveaway?.theme || DEFAULT_THEME;
    const colors = theme.colors || DEFAULT_THEME.colors;
    $('g-brand').value = theme.brand || state.brandName;
    $('g-bg').value = colors.bg || DEFAULT_THEME.colors.bg;
    $('g-cyan').value = colors.cyan || DEFAULT_THEME.colors.cyan;
    $('g-magenta').value = colors.magenta || DEFAULT_THEME.colors.magenta;
    $('g-lime').value = colors.lime || DEFAULT_THEME.colors.lime;
    $('g-ink').value = colors.ink || DEFAULT_THEME.colors.ink;
    $('g-winners').value = giveaway?.winners || 1;
    $('g-ends').value = toLocalInputValue(giveaway?.endsAt || Date.now() + 7 * 86_400_000);
    $('g-links').value = (giveaway?.links || []).map((link) => `${link.label} | ${link.url}`).join('\n');
    state.editingTasks = (giveaway?.tasks || DEFAULT_BONUS_TASKS).map((task) => ({
      title: task.title || '',
      subtitle: task.subtitle || '',
      points: Math.max(0, Math.min(25, Number(task.points) || 0)),
      icon: TASK_ICONS.includes(task.icon) ? task.icon : 'link',
      url: task.url || '',
      enabled: task.enabled !== false,
    }));
    state.editingFaq = (Array.isArray(giveaway?.faq) ? giveaway.faq : DEFAULT_FAQ).map((item) => ({
      question: String(item?.question || '').slice(0, 180),
      answer: String(item?.answer || '').slice(0, 1200),
    }));
    $('g-faq-enabled').checked = giveaway?.faqEnabled !== false;
    renderTaskEditor();
    renderFaqEditor();
    $('editor-status').textContent = '';
    updateHostHint();
    $('giveaway-editor').hidden = false;
    $('giveaway-editor').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function closeEditor() {
    state.editing = null;
    $('giveaway-editor').hidden = true;
  }

  function closeAnalytics() {
    $('giveaway-analytics').hidden = true;
  }

  function closeDomain() {
    $('domain-health').hidden = true;
  }

  async function exportTaskAnalytics(giveaway) {
    if (!giveaway) return;
    try {
      const response = await fetch(
        `/api/giveaway-admin/giveaways/${encodeURIComponent(giveaway.id)}/task-analytics.csv?guild=${encodeURIComponent(state.guildId)}`,
        { headers: { 'x-dashboard': '1' }, credentials: 'same-origin', cache: 'no-store' },
      );
      if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        throw new Error(body.error || `Export failed (${response.status}).`);
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${giveaway.username}-task-analytics.csv`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setStatus(`Exported task analytics for @${giveaway.username}.`, 'ok');
    } catch (error) {
      setStatus(error.message, 'err');
    }
  }

  async function exportEntries(giveaway) {
    try {
      const response = await fetch(
        `/api/giveaway-admin/giveaways/${encodeURIComponent(giveaway.id)}/entries.csv?guild=${encodeURIComponent(state.guildId)}`,
        { headers: { 'x-dashboard': '1' }, credentials: 'same-origin', cache: 'no-store' },
      );
      if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        throw new Error(body.error || `Export failed (${response.status}).`);
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${giveaway.username}-entries.csv`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setStatus(`Exported entries for @${giveaway.username}.`, 'ok');
    } catch (error) {
      setStatus(error.message, 'err');
    }
  }

  async function showDomainCheck(giveaway) {
    const panel = $('domain-health');
    const body = $('domain-body');
    if (!panel || !body) return;
    body.innerHTML = '<p class="manager-empty">Checking DNS, Host routing and HTTPS…</p>';
    panel.hidden = false;
    panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    try {
      const data = await api(
        `/api/giveaway-admin/giveaways/${encodeURIComponent(giveaway.id)}/domain-check?guild=${encodeURIComponent(state.guildId)}`,
      );
      let history = [];
      try {
        const historyData = await api(
          `/api/giveaway-admin/giveaways/${encodeURIComponent(giveaway.id)}/domain-history?guild=${encodeURIComponent(state.guildId)}`,
        );
        history = Array.isArray(historyData.history) ? historyData.history : [];
      } catch {
        history = [];
      }
      const listed = state.giveaways.find((entry) => entry.id === giveaway.id);
      if (listed && data.giveaway?.domainHealth) {
        listed.domainHealth = data.giveaway.domainHealth;
        listed.domainAlertAcknowledgedAt = data.giveaway.domainAlertAcknowledgedAt;
        renderList();
        renderDomainAlerts();
      }
      const ackAction =
        data.giveaway?.domainHealth?.status === 'fail'
          ? data.giveaway.domainAlertAcknowledgedAt
            ? '<p class="task-editor-hint" style="margin:10px 0">Alert acknowledged. It stays suppressed until the domain recovers.</p>'
            : `<button class="btn btn-outline btn-sm" type="button" data-ack-domain="${escapeAttr(giveaway.id)}" style="margin:10px 0">Acknowledge alert</button>`
          : '';
      const webhookAction = `<button class="btn btn-outline btn-sm" type="button" data-test-webhook="${escapeAttr(giveaway.id)}" style="margin:10px 0 10px 8px">Test webhook</button>`;
      const webhookTest = data.giveaway?.domainWebhookTest;
      const webhookTestLine = webhookTest
        ? `Last webhook test: ${webhookTest.ok ? 'delivered' : 'failed'} · ${escapeHtml(new Date(webhookTest.testedAt).toLocaleString())}${webhookTest.detail ? ` · ${escapeHtml(webhookTest.detail)}` : ''}`
        : 'No webhook test recorded yet.';
      $('domain-title').textContent = `${data.host} · Domain health`;
      body.innerHTML = `<p class="manager-empty">Checked ${escapeHtml(new Date(data.checkedAt).toLocaleString())} · ${escapeHtml(data.publicUrl)}</p>
        <div class="domain-checks">
          ${(data.checks || [])
            .map(
              (check) => `<div class="domain-check"><span class="domain-dot ${escapeAttr(check.status)}">${check.status === 'ok' ? '✓' : '✕'}</span><div><strong>${escapeHtml(check.label)}</strong><p>${escapeHtml(check.detail)}</p></div></div>`,
            )
            .join('')}
        </div>
        ${ackAction}${webhookAction}
        <p class="task-editor-hint" id="webhook-test-status" style="margin:0 0 12px">${webhookTestLine}</p>
        <div class="domain-history">
          <h4>Check history</h4>
          ${
            history.length
              ? history
                  .slice(0, 12)
                  .map((entry) => {
                    const failures = (entry.checks || []).filter((check) => check.status !== 'ok').map((check) => check.label);
                    return `<div class="domain-history-row"><span class="state ${escapeAttr(entry.status)}">${escapeHtml(entry.status)}</span><span class="detail">${failures.length ? escapeHtml(failures.join(', ')) : 'All checks passed'}</span><time>${escapeHtml(new Date(entry.checkedAt).toLocaleString())}</time></div>`;
                  })
                  .join('')
              : '<p class="manager-empty">No saved checks yet.</p>'
          }
        </div>`;
    } catch (error) {
      body.innerHTML = `<p class="manager-status err">${escapeHtml(error.message)}</p>`;
    }
  }

  function renderTaskEditor() {
    const container = $('g-tasks-editor');
    if (!container) return;
    if (!state.editingTasks.length) {
      container.innerHTML = '<div class="task-editor-empty">No public bonus tasks. Entry still awards one base ticket.</div>';
      return;
    }
    container.innerHTML = state.editingTasks
      .map(
        (task, index) => `<div class="task-editor-row" draggable="true" data-task-row="${index}">
          <span class="task-drag" title="Drag to reorder" aria-hidden="true">⠿</span>
          <input data-task-field="title" maxlength="80" value="${escapeAttr(task.title)}" placeholder="Task title" aria-label="Task ${index + 1} title" required>
          <input data-task-field="subtitle" maxlength="140" value="${escapeAttr(task.subtitle)}" placeholder="Short description" aria-label="Task ${index + 1} subtitle">
          <input data-task-field="points" type="number" min="0" max="25" value="${Number(task.points) || 0}" aria-label="Task ${index + 1} points">
          <select data-task-field="icon" aria-label="Task ${index + 1} icon">${TASK_ICONS.map((icon) => `<option value="${icon}"${icon === task.icon ? ' selected' : ''}>${icon}</option>`).join('')}</select>
          <input data-task-field="url" type="url" class="task-url" value="${escapeAttr(task.url)}" placeholder="https://… (optional)" aria-label="Task ${index + 1} URL">
          <label class="task-enabled"><input data-task-field="enabled" type="checkbox"${task.enabled ? ' checked' : ''}> on</label>
          <button class="btn btn-danger btn-sm" data-remove-task="${index}" type="button" aria-label="Remove task ${index + 1}">×</button>
        </div>`,
      )
      .join('');
  }

  function collectTasks() {
    return state.editingTasks.map((task, index) => {
      const title = String(task.title || '').trim();
      if (!title) throw new Error(`Task ${index + 1} needs a title.`);
      const points = Number(task.points);
      if (!Number.isFinite(points) || points < 0 || points > 25) {
        throw new Error(`Task ${index + 1} points must be between 0 and 25.`);
      }
      const url = String(task.url || '').trim();
      if (url && !/^https?:\/\//i.test(url)) throw new Error(`Task ${index + 1} URL must start with http:// or https://.`);
      return {
        title: title.slice(0, 80),
        subtitle: String(task.subtitle || '').trim().slice(0, 140),
        points: Math.round(points),
        icon: TASK_ICONS.includes(task.icon) ? task.icon : 'link',
        url,
        enabled: task.enabled !== false,
      };
    });
  }

  function renderFaqEditor() {
    const container = $('g-faq-editor');
    if (!container) return;
    if (!state.editingFaq.length) {
      container.innerHTML = '<div class="task-editor-empty">No FAQ entries. The public Quick FAQ section will be hidden.</div>';
      return;
    }
    container.innerHTML = state.editingFaq
      .map(
        (item, index) => `<div class="task-card" draggable="true" data-faq-row="${index}">
          <div class="task-card-head">
            <div class="task-card-title"><span class="task-drag" title="Drag to reorder" aria-hidden="true">⠿</span><b>Question ${index + 1}</b></div>
            <div class="task-card-actions"><button class="btn btn-danger btn-sm" data-remove-faq="${index}" type="button">Remove</button></div>
          </div>
          <div class="field"><label>Question</label><input data-faq-field="question" maxlength="180" value="${escapeAttr(item.question)}" placeholder="Do I need to pay to enter?"></div>
          <div class="field"><label>Answer</label><textarea data-faq-field="answer" maxlength="1200" placeholder="Explain it clearly for entrants.">${escapeHtml(item.answer)}</textarea></div>
        </div>`,
      )
      .join('');
  }

  function collectFaq() {
    return state.editingFaq
      .map((item, index) => {
        const question = String(item.question || '').trim();
        const answer = String(item.answer || '').trim();
        if (!question && !answer) return null;
        if (!question) throw new Error(`FAQ ${index + 1} needs a question.`);
        if (!answer) throw new Error(`FAQ ${index + 1} needs an answer.`);
        return { question: question.slice(0, 180), answer: answer.slice(0, 1200) };
      })
      .filter(Boolean)
      .slice(0, 12);
  }

  function renderDomainAlerts() {
    const container = $('domain-alerts');
    if (!container) return;
    const failures = state.giveaways.filter(
      (giveaway) => giveaway.status === 'active' && giveaway.domainHealth?.status === 'fail' && !giveaway.domainAlertAcknowledgedAt,
    );
    container.hidden = failures.length === 0;
    if (!failures.length) {
      container.innerHTML = '';
      return;
    }
    container.innerHTML = failures
      .map(
        (giveaway) => `<div class="domain-alert">
          <div><strong>Domain health needs attention · @${escapeHtml(giveaway.username)}</strong><p>${escapeHtml(giveaway.domainHealth.host)} last failed at ${escapeHtml(new Date(giveaway.domainHealth.checkedAt).toLocaleString())}.</p></div>
          <div class="domain-alert-actions"><button class="btn btn-outline btn-sm" type="button" data-alert-giveaway="${escapeAttr(giveaway.id)}">Check now</button><button class="btn btn-outline btn-sm" type="button" data-ack-alert="${escapeAttr(giveaway.id)}">Acknowledge</button></div>
        </div>`,
      )
      .join('');
  }

  function parseLinks(text) {
    return String(text || '')
      .split('\n')
      .map((line) => {
        const separator = line.indexOf('|');
        if (separator < 0) return null;
        return {
          label: line.slice(0, separator).trim(),
          url: line.slice(separator + 1).trim(),
        };
      })
      .filter((link) => link && link.label && /^https?:\/\//i.test(link.url));
  }

  async function load() {
    setStatus('Loading giveaways…');
    const query = state.guildId ? `?guild=${encodeURIComponent(state.guildId)}` : '';
    const [data, branding] = await Promise.all([
      api(`/api/giveaway-admin${query}`),
      fetch('/api/branding', { cache: 'no-store', credentials: 'same-origin' })
        .then((response) => (response.ok ? response.json() : null))
        .catch(() => null),
    ]);
    state.guildId = data.guildId || '';
    state.brandName = branding?.name || 'Astro';
    state.rootDomain = data.rootDomain || 'giveaway.astro.com';
    state.giveaways = Array.isArray(data.giveaways) ? data.giveaways : [];
    $('manager-root').value = state.rootDomain;
    renderGuilds(data.guilds || []);
    renderList();
    renderDomainAlerts();
    updateHostHint();
    setStatus('');
  }

  async function deleteGiveaway(giveaway) {
    if (!confirm(`Delete @${giveaway.username}? This removes its page, entries and analytics.`)) return;
    try {
      await api(`/api/giveaway-admin/giveaways/${encodeURIComponent(giveaway.id)}`, {
        method: 'DELETE',
        body: JSON.stringify({ guildId: state.guildId }),
      });
      if (state.editing === giveaway.id) closeEditor();
      closeAnalytics();
      closeDomain();
      setStatus(`Deleted @${giveaway.username}.`, 'ok');
      await load();
    } catch (error) {
      setStatus(error.message, 'err');
    }
  }

  async function testDomainWebhook(giveaway, button = null) {
    if (button) button.disabled = true;
    try {
      const data = await api(`/api/giveaway-admin/giveaways/${encodeURIComponent(giveaway.id)}/domain-alert/test`, {
        method: 'POST',
        body: JSON.stringify({ guildId: state.guildId }),
      });
      const listed = state.giveaways.find((entry) => entry.id === giveaway.id);
      if (listed && data.giveaway?.domainWebhookTest) listed.domainWebhookTest = data.giveaway.domainWebhookTest;
      const line = $('webhook-test-status');
      if (line && data.giveaway?.domainWebhookTest) {
        line.textContent = `Last webhook test: delivered · ${new Date(data.giveaway.domainWebhookTest.testedAt).toLocaleString()} · ${data.giveaway.domainWebhookTest.detail || ''}`;
      }
      setStatus('Test alert sent to the Discord webhook.', 'ok');
    } catch (error) {
      const line = $('webhook-test-status');
      if (line) line.textContent = `Last webhook test failed · ${error.message}`;
      setStatus(error.message, 'err');
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function acknowledgeDomain(giveaway, button = null) {
    if (button) button.disabled = true;
    try {
      const data = await api(`/api/giveaway-admin/giveaways/${encodeURIComponent(giveaway.id)}/domain-alert/ack`, {
        method: 'POST',
        body: JSON.stringify({ guildId: state.guildId }),
      });
      const listed = state.giveaways.find((entry) => entry.id === giveaway.id);
      if (listed) {
        listed.domainAlertAcknowledgedAt = data.giveaway?.domainAlertAcknowledgedAt || new Date().toISOString();
        if (data.giveaway?.domainHealth) listed.domainHealth = data.giveaway.domainHealth;
      }
      renderList();
      renderDomainAlerts();
      if (button) button.outerHTML = '<span class="task-editor-hint">Acknowledged. It stays suppressed until the domain recovers.</span>';
      setStatus(`Acknowledged the domain alert for @${giveaway.username}.`, 'ok');
    } catch (error) {
      if (button) button.disabled = false;
      setStatus(error.message, 'err');
    }
  }

  async function showAnalytics(giveaway) {
    try {
      const data = await api(
        `/api/giveaway-admin/giveaways/${encodeURIComponent(giveaway.id)}/analytics?guild=${encodeURIComponent(state.guildId)}`,
      );
      renderAnalytics(data.giveaway, data.analytics);
    } catch (error) {
      setStatus(error.message, 'err');
    }
  }

  $('new-giveaway').addEventListener('click', () => {
    if (!state.guildId) {
      setStatus('Add a Discord server before creating a giveaway.', 'err');
      return;
    }
    showEditor();
  });

  $('cancel-editor').addEventListener('click', closeEditor);
  $('close-analytics').addEventListener('click', closeAnalytics);
  $('close-domain').addEventListener('click', closeDomain);
  $('g-username').addEventListener('input', updateHostHint);
  $('g-add-task').addEventListener('click', () => {
    state.editingTasks.push({ title: '', subtitle: '', points: 5, icon: 'link', url: '', enabled: true });
    renderTaskEditor();
    document.querySelector(`[data-task-row="${state.editingTasks.length - 1}"] [data-task-field="title"]`)?.focus();
  });

  const taskContainer = $('g-tasks-editor');
  const taskIndex = (target) => Number(target.closest('[data-task-row]')?.dataset.taskRow);
  const updateTask = (target) => {
    const index = taskIndex(target);
    const field = target.dataset.taskField;
    if (!Number.isInteger(index) || !field || !state.editingTasks[index]) return;
    state.editingTasks[index][field] = field === 'enabled' ? target.checked : field === 'points' ? Number(target.value) : target.value;
  };
  taskContainer.addEventListener('input', (event) => {
    if (event.target.matches('[data-task-field]')) updateTask(event.target);
  });
  taskContainer.addEventListener('change', (event) => {
    if (event.target.matches('[data-task-field]')) updateTask(event.target);
  });
  taskContainer.addEventListener('click', (event) => {
    const button = event.target.closest('[data-remove-task]');
    if (!button) return;
    state.editingTasks.splice(Number(button.dataset.removeTask), 1);
    renderTaskEditor();
  });
  taskContainer.addEventListener('dragstart', (event) => {
    const row = event.target.closest('[data-task-row]');
    if (!row) return;
    taskDragIndex = Number(row.dataset.taskRow);
    row.classList.add('dragging');
    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = 'move';
      event.dataTransfer.setData('text/plain', String(taskDragIndex));
    }
  });
  taskContainer.addEventListener('dragover', (event) => {
    if (taskDragIndex === null) return;
    const row = event.target.closest('[data-task-row]');
    if (!row) return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
  });
  taskContainer.addEventListener('drop', (event) => {
    const row = event.target.closest('[data-task-row]');
    if (!row || taskDragIndex === null) return;
    event.preventDefault();
    const to = Number(row.dataset.taskRow);
    if (to !== taskDragIndex) {
      const [moved] = state.editingTasks.splice(taskDragIndex, 1);
      state.editingTasks.splice(to, 0, moved);
    }
    taskDragIndex = null;
    renderTaskEditor();
  });
  taskContainer.addEventListener('dragend', () => {
    taskDragIndex = null;
    taskContainer.querySelectorAll('.dragging').forEach((row) => row.classList.remove('dragging'));
  });

  const faqContainer = $('g-faq-editor');
  const faqIndex = (target) => Number(target.closest('[data-faq-row]')?.dataset.faqRow);
  const updateFaq = (target) => {
    const index = faqIndex(target);
    const field = target.dataset.faqField;
    if (!Number.isInteger(index) || !field || !state.editingFaq[index]) return;
    state.editingFaq[index][field] = target.value;
  };
  faqContainer.addEventListener('dragstart', (event) => {
    const row = event.target.closest('[data-faq-row]');
    if (!row) return;
    faqDragIndex = Number(row.dataset.faqRow);
    row.classList.add('dragging');
    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = 'move';
      event.dataTransfer.setData('text/plain', String(faqDragIndex));
    }
  });
  faqContainer.addEventListener('dragover', (event) => {
    if (faqDragIndex === null) return;
    if (!event.target.closest('[data-faq-row]')) return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
  });
  faqContainer.addEventListener('drop', (event) => {
    if (faqDragIndex === null) return;
    const row = event.target.closest('[data-faq-row]');
    if (!row) return;
    event.preventDefault();
    const to = Number(row.dataset.faqRow);
    if (to !== faqDragIndex) {
      const [moved] = state.editingFaq.splice(faqDragIndex, 1);
      state.editingFaq.splice(to, 0, moved);
      faqDragIndex = null;
      renderFaqEditor();
    } else {
      faqDragIndex = null;
    }
  });
  faqContainer.addEventListener('dragend', () => {
    faqDragIndex = null;
    faqContainer.querySelectorAll('.dragging').forEach((row) => row.classList.remove('dragging'));
  });
  faqContainer.addEventListener('input', (event) => {
    if (event.target.matches('[data-faq-field]')) updateFaq(event.target);
  });
  faqContainer.addEventListener('change', (event) => {
    if (event.target.matches('[data-faq-field]')) updateFaq(event.target);
  });
  faqContainer.addEventListener('click', (event) => {
    const button = event.target.closest('[data-remove-faq]');
    if (!button) return;
    state.editingFaq.splice(Number(button.dataset.removeFaq), 1);
    renderFaqEditor();
  });
  $('g-add-faq').addEventListener('click', () => {
    if (state.editingFaq.length >= 12) {
      setStatus('You can add up to 12 FAQ entries.', 'err');
      return;
    }
    state.editingFaq.push({ question: '', answer: '' });
    renderFaqEditor();
    document.querySelector(`[data-faq-row="${state.editingFaq.length - 1}"] [data-faq-field="question"]`)?.focus();
  });

  $('domain-alerts').addEventListener('click', (event) => {
    const check = event.target.closest('[data-alert-giveaway]');
    const ack = event.target.closest('[data-ack-alert]');
    const id = check?.dataset.alertGiveaway || ack?.dataset.ackAlert;
    const giveaway = state.giveaways.find((entry) => entry.id === id);
    if (!giveaway) return;
    if (check) showDomainCheck(giveaway);
    if (ack) acknowledgeDomain(giveaway, ack);
  });
  $('domain-body').addEventListener('click', (event) => {
    const ack = event.target.closest('[data-ack-domain]');
    const test = event.target.closest('[data-test-webhook]');
    const giveaway = state.giveaways.find((entry) => entry.id === (ack?.dataset.ackDomain || test?.dataset.testWebhook));
    if (!giveaway) return;
    if (ack) acknowledgeDomain(giveaway, ack);
    if (test) testDomainWebhook(giveaway, test);
  });
  $('analytics-body').addEventListener('click', (event) => {
    if (event.target.closest('[data-export-tasks]')) exportTaskAnalytics(state.analyticsGiveaway);
  });
  $('manager-guild').addEventListener('change', async (event) => {
    state.guildId = event.target.value;
    closeEditor();
    closeAnalytics();
    closeDomain();
    try {
      await load();
    } catch (error) {
      setStatus(error.message, 'err');
    }
  });

  $('giveaway-list').addEventListener('click', (event) => {
    const button = event.target.closest('[data-action]');
    if (!button) return;
    const row = button.closest('.giveaway-row');
    const giveaway = state.giveaways.find((entry) => entry.id === row?.dataset.id);
    if (!giveaway) return;
    if (button.dataset.action === 'edit') showEditor(giveaway);
    if (button.dataset.action === 'analytics') showAnalytics(giveaway);
    if (button.dataset.action === 'domain') showDomainCheck(giveaway);
    if (button.dataset.action === 'export') exportEntries(giveaway);
    if (button.dataset.action === 'delete') deleteGiveaway(giveaway);
  });

  $('giveaway-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const username = $('g-username').value.trim().toLowerCase();
    const prize = $('g-prize').value.trim();
    const endsAt = new Date($('g-ends').value);
    const editorStatus = $('editor-status');
    if (!username) {
      editorStatus.textContent = 'Enter a username.';
      editorStatus.style.color = 'var(--magenta)';
      return;
    }
    if (!prize) {
      editorStatus.textContent = 'Give the giveaway a prize or title.';
      editorStatus.style.color = 'var(--magenta)';
      return;
    }
    if (Number.isNaN(endsAt.getTime())) {
      editorStatus.textContent = 'Choose a valid end date and time.';
      editorStatus.style.color = 'var(--magenta)';
      return;
    }
    let tasks;
    try {
      tasks = collectTasks();
    } catch (error) {
      editorStatus.textContent = error.message;
      editorStatus.style.color = 'var(--magenta)';
      return;
    }
    let faq;
    try {
      faq = collectFaq();
    } catch (error) {
      editorStatus.textContent = error.message;
      editorStatus.style.color = 'var(--magenta)';
      return;
    }
    const payload = {
      guildId: state.guildId,
      username,
      prize,
      description: $('g-description').value.trim(),
      winners: Number($('g-winners').value) || 1,
      endsAt: endsAt.toISOString(),
      status: $('g-status').value,
      links: parseLinks($('g-links').value),
      tasks,
      faq,
      faqEnabled: $('g-faq-enabled').checked,
      theme: {
        brand: $('g-brand').value.trim() || state.brandName,
        colors: {
          bg: $('g-bg').value,
          cyan: $('g-cyan').value,
          magenta: $('g-magenta').value,
          lime: $('g-lime').value,
          ink: $('g-ink').value,
        },
      },
    };
    const button = $('save-giveaway');
    button.disabled = true;
    editorStatus.textContent = 'Saving…';
    editorStatus.style.color = 'var(--muted)';
    try {
      const path = state.editing
        ? `/api/giveaway-admin/giveaways/${encodeURIComponent(state.editing)}`
        : '/api/giveaway-admin/giveaways';
      await api(path, {
        method: state.editing ? 'PATCH' : 'POST',
        body: JSON.stringify(payload),
      });
      const wasEditing = Boolean(state.editing);
      closeEditor();
      setStatus(wasEditing ? 'Giveaway updated.' : `Created @${username}.`, 'ok');
      await load();
    } catch (error) {
      editorStatus.textContent = error.message;
      editorStatus.style.color = 'var(--magenta)';
    } finally {
      button.disabled = false;
    }
  });

  load().catch((error) => setStatus(error.message, 'err'));
})();
