/*
 * Shared config for the giveaway landing page + its admin dashboard.
 * Loaded by both pages via <script src="config.js">. Persists through
 * localStorage under STORAGE_KEY, which Chrome/Firefox both share across
 * all file:// pages in the same profile — so editing in admin-dashboard.html
 * and reloading index.html (same folder, same browser)
 * picks up the change with no server needed.
 */
const STORAGE_KEY = "battledrop_config_v1";
// Separate key for unsaved draft edits, written by the dashboard's Preview
// button. Kept apart from STORAGE_KEY so previewing a draft never touches
// (or gets confused with) the actually-saved/live config.
const PREVIEW_STORAGE_KEY = "battledrop_config_preview_v1";

// The actual field name each platform uses for a handle — "username" isn't
// universal. Xbox calls it a Gamertag, PlayStation a PSN ID; getting this
// wrong reads as not knowing the platforms at all to anyone who games on them.
// (Previously this map was missing xbox/playstation/steam entirely, which
// meant tasks using those icons silently skipped the username requirement
// that every other platform enforced — fixed by adding them here.)
const PLATFORM_FIELD_LABELS = {
  twitch: "Twitch username",
  discord: "Discord username",
  x: "X username",
  youtube: "YouTube channel name",
  instagram: "Instagram username",
  tiktok: "TikTok username",
  kick: "Kick username",
  xbox: "Xbox Gamertag",
  playstation: "PlayStation PSN ID",
  steam: "Steam username",
  link: "",
};

const ICONS = {
  twitch: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true" focusable="false"><path d="M11.571 4.714h1.715v5.143H11.57zm4.715 0H18v5.143h-1.714zM6 0L1.714 4.286v15.428h5.143V24l4.286-4.286h3.428L22.286 12V0zm14.571 11.143l-3.428 3.428h-3.429l-3 3v-3H6.857V1.714h13.714Z"/></svg>',
  discord: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true" focusable="false"><path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z"/></svg>',
  x: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true" focusable="false"><path d="M14.234 10.162 22.977 0h-2.072l-7.591 8.824L7.251 0H.258l9.168 13.343L.258 24H2.33l8.016-9.318L16.749 24h6.993zm-2.837 3.299-.929-1.329L3.076 1.56h3.182l5.965 8.532.929 1.329 7.754 11.09h-3.182z"/></svg>',
  youtube: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true" focusable="false"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
  instagram: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true" focusable="false"><path d="M7.0301.084c-1.2768.0602-2.1487.264-2.911.5634-.7888.3075-1.4575.72-2.1228 1.3877-.6652.6677-1.075 1.3368-1.3802 2.127-.2954.7638-.4956 1.6365-.552 2.914-.0564 1.2775-.0689 1.6882-.0626 4.947.0062 3.2586.0206 3.6671.0825 4.9473.061 1.2765.264 2.1482.5635 2.9107.308.7889.72 1.4573 1.388 2.1228.6679.6655 1.3365 1.0743 2.1285 1.38.7632.295 1.6361.4961 2.9134.552 1.2773.056 1.6884.069 4.9462.0627 3.2578-.0062 3.668-.0207 4.9478-.0814 1.28-.0607 2.147-.2652 2.9098-.5633.7889-.3086 1.4578-.72 2.1228-1.3881.665-.6682 1.0745-1.3378 1.3795-2.1284.2957-.7632.4966-1.636.552-2.9124.056-1.2809.0692-1.6898.063-4.948-.0063-3.2583-.021-3.6668-.0817-4.9465-.0607-1.2797-.264-2.1487-.5633-2.9117-.3084-.7889-.72-1.4568-1.3876-2.1228C21.2982 1.33 20.628.9208 19.8378.6165 19.074.321 18.2017.1197 16.9244.0645 15.6471.0093 15.236-.005 11.977.0014 8.718.0076 8.31.0215 7.0301.0839m.1402 21.6932c-1.17-.0509-1.8053-.2453-2.2287-.408-.5606-.216-.96-.4771-1.3819-.895-.422-.4178-.6811-.8186-.9-1.378-.1644-.4234-.3624-1.058-.4171-2.228-.0595-1.2645-.072-1.6442-.079-4.848-.007-3.2037.0053-3.583.0607-4.848.05-1.169.2456-1.805.408-2.2282.216-.5613.4762-.96.895-1.3816.4188-.4217.8184-.6814 1.3783-.9003.423-.1651 1.0575-.3614 2.227-.4171 1.2655-.06 1.6447-.072 4.848-.079 3.2033-.007 3.5835.005 4.8495.0608 1.169.0508 1.8053.2445 2.228.408.5608.216.96.4754 1.3816.895.4217.4194.6816.8176.9005 1.3787.1653.4217.3617 1.056.4169 2.2263.0602 1.2655.0739 1.645.0796 4.848.0058 3.203-.0055 3.5834-.061 4.848-.051 1.17-.245 1.8055-.408 2.2294-.216.5604-.4763.96-.8954 1.3814-.419.4215-.8181.6811-1.3783.9-.4224.1649-1.0577.3617-2.2262.4174-1.2656.0595-1.6448.072-4.8493.079-3.2045.007-3.5825-.006-4.848-.0608M16.953 5.5864A1.44 1.44 0 1 0 18.39 4.144a1.44 1.44 0 0 0-1.437 1.4424M5.8385 12.012c.0067 3.4032 2.7706 6.1557 6.173 6.1493 3.4026-.0065 6.157-2.7701 6.1506-6.1733-.0065-3.4032-2.771-6.1565-6.174-6.1498-3.403.0067-6.156 2.771-6.1496 6.1738M8 12.0077a4 4 0 1 1 4.008 3.9921A3.9996 3.9996 0 0 1 8 12.0077"/></svg>',
  tiktok: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true" focusable="false"><path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/></svg>',
  kick: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true" focusable="false"><path d="M1.333 0h8v5.333H12V2.667h2.667V0h8v8H20v2.667h-2.667v2.666H20V16h2.667v8h-8v-2.667H12v-2.666H9.333V24h-8Z"/></svg>',
  xbox: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true" focusable="false"><path d="M4.102 21.033C6.211 22.881 8.977 24 12 24c3.026 0 5.789-1.119 7.902-2.967 1.877-1.912-4.316-8.709-7.902-11.417-3.582 2.708-9.779 9.505-7.898 11.417zm11.16-14.406c2.5 2.961 7.484 10.313 6.076 12.912C23.002 17.48 24 14.861 24 12.004c0-3.34-1.365-6.362-3.57-8.536 0 0-.027-.022-.082-.042-.063-.022-.152-.045-.281-.045-.592 0-1.985.434-4.805 3.246zM3.654 3.426c-.057.02-.082.041-.086.042C1.365 5.642 0 8.664 0 12.004c0 2.854.998 5.473 2.661 7.533-1.401-2.605 3.579-9.951 6.08-12.91-2.82-2.813-4.216-3.245-4.806-3.245-.131 0-.223.021-.281.046v-.002zM12 3.551S9.055 1.828 6.755 1.746c-.903-.033-1.454.295-1.521.339C7.379.646 9.659 0 11.984 0H12c2.334 0 4.605.646 6.766 2.085-.068-.046-.615-.372-1.52-.339C14.946 1.828 12 3.545 12 3.545v.006z"/></svg>',
  playstation: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true" focusable="false"><path d="M8.984 2.596v17.547l3.915 1.261V6.688c0-.69.304-1.151.794-.991.636.18.76.814.76 1.505v5.875c2.441 1.193 4.362-.002 4.362-3.152 0-3.237-1.126-4.675-4.438-5.827-1.307-.448-3.728-1.186-5.39-1.502zm4.656 16.241l6.296-2.275c.715-.258.826-.625.246-.818-.586-.192-1.637-.139-2.357.123l-4.205 1.5V14.98l.24-.085s1.201-.42 2.913-.615c1.696-.18 3.785.03 5.437.661 1.848.601 2.04 1.472 1.576 2.072-.465.6-1.622 1.036-1.622 1.036l-8.544 3.107V18.86zM1.807 18.6c-1.9-.545-2.214-1.668-1.352-2.32.801-.586 2.16-1.052 2.16-1.052l5.615-2.013v2.313L4.205 17c-.705.271-.825.632-.239.826.586.195 1.637.15 2.343-.12L8.247 17v2.074c-.12.03-.256.044-.39.073-1.939.331-3.996.196-6.038-.479z"/></svg>',
  steam: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true" focusable="false"><path d="M11.979 0C5.678 0 .511 4.86.022 11.037l6.432 2.658c.545-.371 1.203-.59 1.912-.59.063 0 .125.004.188.006l2.861-4.142V8.91c0-2.495 2.028-4.524 4.524-4.524 2.494 0 4.524 2.031 4.524 4.527s-2.03 4.525-4.524 4.525h-.105l-4.076 2.911c0 .052.004.105.004.159 0 1.875-1.515 3.396-3.39 3.396-1.635 0-3.016-1.173-3.331-2.727L.436 15.27C1.862 20.307 6.486 24 11.979 24c6.627 0 11.999-5.373 11.999-12S18.605 0 11.979 0zM7.54 18.21l-1.473-.61c.262.543.714.999 1.314 1.25 1.297.539 2.793-.076 3.332-1.375.263-.63.264-1.319.005-1.949s-.75-1.121-1.377-1.383c-.624-.26-1.29-.249-1.878-.03l1.523.63c.956.4 1.409 1.5 1.009 2.455-.397.957-1.497 1.41-2.454 1.012H7.54zm11.415-9.303c0-1.662-1.353-3.015-3.015-3.015-1.665 0-3.015 1.353-3.015 3.015 0 1.665 1.35 3.015 3.015 3.015 1.663 0 3.015-1.35 3.015-3.015zm-5.273-.005c0-1.252 1.013-2.266 2.265-2.266 1.249 0 2.266 1.014 2.266 2.266 0 1.251-1.017 2.265-2.266 2.265-1.253 0-2.265-1.014-2.265-2.265z"/></svg>',
  link: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.5.4l2-2a5 5 0 0 0-7-7l-1.1 1.1"/><path d="M14 11a5 5 0 0 0-7.5-.4l-2 2a5 5 0 0 0 7 7l1.1-1.1"/></svg>',
};

const DEFAULT_CONFIG = {
  colors: {
    bg: "#07070d",
    cyan: "#00f0ff",
    magenta: "#ff2ec4",
    lime: "#c6ff3d",
    ink: "#eef0f8",
  },
  content: {
    brand: "Astro",
    logoDataUrl: "", // base64 data URL from the dashboard's logo upload; empty = white Astro wordmark for Astro brands, otherwise the text brand
    logoWidth: 140, // px, height auto-scales (object-fit:contain)
    logoMatchTheme: false, // adds a neon glow behind the logo using the current accent colors
    bgImageDataUrl: "", // optional custom page background image; empty = use the default color glow
    fomoBar: "Entries close the instant the timer hits zero — no extensions, no exceptions.",
    kicker: "Live Giveaway — Winner Announced On Stream",
    headlineMain: "Don't Miss Your Shot At",
    headlineAccent: "The Prize",
    subheadline:
      'Enter for your chance to win. Complete bonus tasks to earn extra entries before the timer runs out.',
    // {brand} and {year} are replaced at render time — fully custom otherwise.
    footerText: "© {year} {brand} - All Rights Reserved.",
  },
  prize: {
    tag: "Grand Prize",
    title: "Giveaway Prize",
    value: "",
    items: [],
    // Prize showcase media. type: "none" | "image" | "video".
    // source: "upload" (uses dataUrl, from the dashboard's file picker) or
    // "url" (uses externalUrl) — video especially should usually be a URL,
    // since embedding video as base64 can blow past localStorage's quota.
    media: {
      type: "none",
      source: "upload",
      dataUrl: "",
      externalUrl: "",
    },
  },
  // Fixed absolute end time (ISO string). Computed once via the dashboard,
  // NOT re-derived from "now" on every page load — a countdown that resets
  // itself every visit isn't a countdown, it's decoration.
  endTimestamp: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
  tasks: [
    { title: "Enter with your gamertag, PSN ID or Steam username", subtitle: "Your base entry — required to qualify", points: 1, icon: "link", url: "", required: true },
    { title: "Follow on Twitch", subtitle: "Live raffle draw happens on stream", points: 5, icon: "twitch", url: "https://twitch.tv/" },
    { title: "Join the Discord", subtitle: "Members-only giveaways and early prize reveals", points: 10, icon: "discord", url: "https://discord.gg/" },
    { title: "Follow on X", subtitle: "Winner announcements post there first", points: 5, icon: "x", url: "https://x.com/" },
    { title: "Subscribe on YouTube", subtitle: "Subs get first access to next month's drop", points: 5, icon: "youtube", url: "https://youtube.com/" },
    { title: "Tag a squadmate", subtitle: "You both get bonus entries when they enter too", points: 8, icon: "instagram", url: "https://instagram.com/" },
    { title: "Share this giveaway", subtitle: "Share to your story for bonus entries", points: 15, icon: "tiktok", url: "https://tiktok.com/" },
  ],
  animations: {
    bgGlow: true,
    scanlines: true,
    liveTicker: true,
    entryCounter: true,
    kickerPulse: true,
  },
  stats: {
    entryCountStart: 0,
    winners: 1,
  },
  faq: [
    {
      question: "Do I really not have to pay anything?",
      answer: "Correct — entry is 100% free. No purchase is ever necessary to enter or win.",
    },
    {
      question: "How is the winner picked?",
      answer: "Every completed task adds weighted entries into a live, on-stream random draw. More entries = better odds, not a guarantee — it's still a raffle.",
    },
    {
      question: "When do entries close?",
      answer: "The instant the countdown above hits zero. There are no extensions and no late entries, regardless of task completion status.",
    },
    {
      question: "How will I know if I won?",
      answer: "Winners are announced live on stream and contacted via the email and gamertag, PSN ID or Steam username submitted at entry. Check the Discord #winners channel too.",
    },
  ],
  faqEnabled: true,
};

// Some browsers — Firefox in particular — block localStorage entirely for
// file:// pages (throws a SecurityError/DOMException on access, not just
// returns null). Everything below has to survive that, not just a missing
// key. deepClone avoids depending on window.structuredClone, which isn't
// guaranteed either.
function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

function storageAvailable() {
  try {
    const testKey = "__battledrop_storage_test__";
    localStorage.setItem(testKey, "1");
    localStorage.removeItem(testKey);
    return true;
  } catch (e) {
    return false;
  }
}

function mergeWithDefaults(parsed) {
  // shallow-merge each top-level section so old saved configs missing new
  // fields still work instead of crashing the page.
  return {
    colors: { ...DEFAULT_CONFIG.colors, ...parsed.colors },
    content: { ...DEFAULT_CONFIG.content, ...parsed.content },
    prize: {
      ...DEFAULT_CONFIG.prize,
      ...parsed.prize,
      media: { ...DEFAULT_CONFIG.prize.media, ...(parsed.prize && parsed.prize.media) },
    },
    endTimestamp: parsed.endTimestamp || DEFAULT_CONFIG.endTimestamp,
    tasks: Array.isArray(parsed.tasks) ? parsed.tasks : DEFAULT_CONFIG.tasks,
    faq: (Array.isArray(parsed.faq) ? parsed.faq : DEFAULT_CONFIG.faq)
      .filter((item) => item && typeof item === "object")
      .map((item) => ({ ...item })),
    faqEnabled: parsed.faqEnabled !== false,
    animations: { ...DEFAULT_CONFIG.animations, ...parsed.animations },
    stats: { ...DEFAULT_CONFIG.stats, ...parsed.stats },
    recentEntries: Array.isArray(parsed.recentEntries) ? parsed.recentEntries : [],
  };
}

// key defaults to STORAGE_KEY (the live/saved config). The landing page
// passes PREVIEW_STORAGE_KEY instead when opened with ?preview=1, so a
// draft can be viewed without ever touching what real visitors see.
function hostedConfig() {
  const payload = window.__ASTRO_GIVEAWAY__;
  if (!payload || !payload.config || typeof payload.config !== "object") return null;
  return mergeWithDefaults(payload.config);
}

function loadConfig(key) {
  const hosted = hostedConfig();
  if (hosted) return hosted;
  key = key || STORAGE_KEY;
  if (!storageAvailable()) {
    console.warn("localStorage is unavailable (common on file:// pages in some browsers) — using template defaults. Use Export/Import in the admin dashboard to save changes instead.");
    return deepClone(DEFAULT_CONFIG);
  }
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return deepClone(DEFAULT_CONFIG);
    return mergeWithDefaults(JSON.parse(raw));
  } catch (e) {
    console.warn("Config failed to parse, using defaults:", e);
    return deepClone(DEFAULT_CONFIG);
  }
}

// Returns { ok: true } on success, or { ok: false, reason: "quota" | "blocked" }
// on failure so callers (the dashboard's Save button) can give a specific,
// actionable message instead of a generic "couldn't save":
//   "blocked" — the browser refuses localStorage on this page at all
//               (e.g. Firefox on file:// URLs).
//   "quota"   — storage works, but this write is too big (typically an
//               uploaded background image/video pushing the config over
//               the ~5-10MB per-origin localStorage limit).
function saveConfig(config) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
    return { ok: true };
  } catch (e) {
    const isQuota = e && (e.name === "QuotaExceededError" || e.name === "NS_ERROR_DOM_QUOTA_REACHED" || e.code === 22);
    console.warn("Could not save to localStorage:", e);
    return { ok: false, reason: isQuota ? "quota" : "blocked" };
  }
}

function resetConfig() {
  try { localStorage.removeItem(STORAGE_KEY); } catch (e) { /* nothing to remove if storage is blocked */ }
}
