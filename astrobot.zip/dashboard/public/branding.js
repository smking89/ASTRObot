(() => {
  const root = document.documentElement;

  function setIcon(url) {
    if (!url) return;
    document.querySelectorAll('link[rel~="icon"], link[rel="apple-touch-icon"]').forEach((link) => {
      link.href = url;
    });
  }

  async function applyBranding() {
    let branding;
    try {
      const response = await fetch('/api/branding', { cache: 'no-store', credentials: 'same-origin' });
      if (!response.ok) return;
      branding = await response.json();
    } catch {
      return;
    }
    if (!branding?.name) return;

    const name = String(branding.name);
    document.title = document.title.replace(/AstroBot|Astro/g, name);
    document.querySelectorAll('.brand-text strong').forEach((element) => {
      element.textContent = name.toUpperCase();
    });
    document.querySelectorAll('.brand-text').forEach((element) => {
      element.setAttribute('aria-label', name);
      let wordmark = element.querySelector('.brand-wordmark');
      const fallback = element.querySelector('strong');
      if (branding.wordmarkUrl) {
        if (!wordmark) {
          wordmark = document.createElement('img');
          wordmark.className = 'brand-wordmark';
          element.prepend(wordmark);
        }
        wordmark.src = branding.wordmarkUrl;
        wordmark.alt = `${name} logo`;
        wordmark.hidden = false;
        if (fallback) fallback.hidden = true;
      } else {
        if (wordmark) wordmark.hidden = true;
        if (fallback) fallback.hidden = false;
      }
    });

    const adminTitle = document.getElementById('admin-title');
    if (adminTitle) adminTitle.textContent = name;
    const adminWordmark = document.getElementById('admin-wordmark');
    if (adminWordmark && branding.wordmarkUrl) {
      adminWordmark.src = branding.wordmarkUrl;
      adminWordmark.hidden = false;
      adminWordmark.alt = `${name} logo`;
    }

    if (branding.faviconUrl) {
      document.querySelectorAll('.brand-mark').forEach((image) => {
        image.src = branding.faviconUrl;
        image.alt = '';
      });
    }
    setIcon(branding.faviconUrl || branding.wordmarkUrl);

    const colors = branding.colors || {};
    if (colors.brand) {
      root.style.setProperty('--red', colors.brand);
      root.style.setProperty('--brand', colors.brand);
    }
    if (colors.accent) {
      root.style.setProperty('--accent', colors.accent);
      root.style.setProperty('--cyan', colors.accent);
    }
    if (colors.background) root.style.setProperty('--magenta', colors.brand || colors.background);
    document.querySelectorAll('meta[name="theme-color"]').forEach((meta) => {
      if (colors.background) meta.setAttribute('content', colors.background);
    });

    // The giveaway admin uses its own dark palette; apply the full white-label
    // scheme there without turning the light control panel dark.
    if (adminWordmark) {
      if (colors.background) root.style.setProperty('--bg', colors.background);
      if (colors.text) root.style.setProperty('--ink', colors.text);
      if (colors.brand) root.style.setProperty('--lime', colors.brand);
    }
  }

  applyBranding();
})();
