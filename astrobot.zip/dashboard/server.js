import { createServer, request as httpRequest } from 'node:http';
import { execFile } from 'node:child_process';
import { resolve4, resolve6, resolveCname } from 'node:dns/promises';
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { readFileSync, readdirSync, unlinkSync, writeFileSync } from 'node:fs';
import { dirname, extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';
import { DEFAULT_GUILD_SETTINGS, SETTINGS_ROOT_KEYS } from '../src/config/defaults.js';
import { CONFIG_SECTIONS } from '../src/config/settings-schema.js';
import { summarizeSessions } from '../src/services/analytics-service.js';
import { computeUptime } from '../src/services/status-service.js';
import { initDatabase } from '../src/db/index.js';
import { balances, claimDaily, economyScopeKey } from '../src/services/economy-service.js';
import { deliverCrateLoot, openCrate } from '../src/services/voucher-service.js';
import { getJackpot, getJackpotHistory } from '../src/services/jackpot-service.js';
import { listBadges } from '../src/services/badge-service.js';
import { personalRank } from '../src/ui/rank-icons.js';
import { adjustBalances } from '../src/db/repositories/players.js';
import { mkdirSync, statSync } from 'node:fs';
import { createDatabaseBackup } from '../src/services/database-backup-service.js';
import { createZip } from '../src/services/zip-service.js';
import {
  getPortalConfig,
  markGiveawayEntryTokenUsed,
  savePortalConfig,
  validateGiveawayEntryToken,
  validatePortalToken,
} from '../src/db/repositories/giveaway-portals.js';
import {
  addGiveawayBonus,
  addGiveawayEntry,
  getGiveaway,
  giveawayTickets,
  listGiveawayBonuses,
  listGiveawayEntries,
  listGiveaways,
} from '../src/db/repositories/onboarding.js';
import { DEFAULT_PORTAL_CONFIG, normalizePortalConfig } from '../src/config/giveaway-portal.js';
import { giveawayRegion, giveawayRegionLabel } from '../src/config/giveaway-regions.js';
import { getBranding, saveBranding } from '../src/db/repositories/branding.js';
import { loadRegistry } from '../src/core/loader.js';
import {
  assertEntrantCapacity,
  assertPlanLimit,
  countActiveHostedGiveaways,
  planHasFeature,
  planSnapshot,
} from '../src/services/plan-service.js';
import {
  DEFAULT_GIVEAWAY_THEME,
  claimPageBonus,
  createManagedGiveaway,
  deleteManagedGiveaway,
  getManagedGiveaway,
  getManagedGiveawayByUsername,
  getPageEntryState,
  giveawayAnalytics,
  acknowledgeDomainAlert,
  latestDomainCheck,
  latestDomainWebhookTest,
  recordDomainWebhookTest,
  listDiscordEntries,
  listDomainChecks,
  listManagedGiveaways,
  listPageEntries,
  normalizeLinkTree,
  normalizeTheme,
  normalizeUsername,
  recentPageEntries,
  recordDomainCheck,
  recordGiveawayEvent,
  clearDomainAlertAcknowledgement,
  domainAlertAcknowledgement,
  recordPageEntry,
  updateManagedGiveaway,
  usernameError,
  usernameTaken,
} from '../src/db/repositories/giveaway-pages.js';

/**
 * AstroBot control panel. Read/write over the bot's SQLite database, styled
 * after the KOBAbot console: grouped sidebar, coloured system cards, toggles,
 * inline forms and per-section Save buttons. Binds to loopback only.
 */

const PORT = Number(process.env.DASHBOARD_PORT || 4173);
const HOST = process.env.DASHBOARD_HOST || '127.0.0.1';
const DB_PATH = process.env.DATABASE_PATH || './data/astrobot.db';
const PUBLIC = fileURLToPath(new URL('./public/', import.meta.url));
const WEEK = 7 * 86_400_000;
const DASHBOARD_PASSWORD = String(process.env.DASHBOARD_PASSWORD ?? '');
const SESSION_TTL_MS = 12 * 60 * 60 * 1000;
const LOOPBACK_HOSTS = new Set(['127.0.0.1', 'localhost', '::1', '[::1]']);
const GIVEAWAY_ROOT_DOMAIN = String(process.env.GIVEAWAY_ROOT_DOMAIN || 'giveaway.astro.com').toLowerCase();
const GIVEAWAY_PUBLIC_PROTOCOL = String(process.env.GIVEAWAY_PUBLIC_PROTOCOL || 'https');
const sessions = new Map();
const rateBuckets = new Map();

if (!DASHBOARD_PASSWORD && !LOOPBACK_HOSTS.has(HOST)) {
  console.error('Refusing to bind the dashboard to a non-loopback interface without DASHBOARD_PASSWORD.');
  process.exit(1);
}

if (DB_PATH !== ':memory:') mkdirSync(dirname(DB_PATH), { recursive: true });
const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA busy_timeout = 5000;');
// The services behind claims and wagers use their own connection; open it once.
initDatabase({ path: DB_PATH });

const all = (sql, ...params) => {
  try {
    return db.prepare(sql).all(...params);
  } catch {
    return [];
  }
};
const get = (sql, ...params) => {
  try {
    return db.prepare(sql).get(...params) ?? null;
  } catch {
    return null;
  }
};
const run = (sql, ...params) => db.prepare(sql).run(...params);

const isObject = (value) => value && typeof value === 'object' && !Array.isArray(value);
const deepMerge = (base, patch) => {
  if (!isObject(base) || !isObject(patch)) return patch ?? base;
  const out = { ...base };
  for (const [key, value] of Object.entries(patch)) {
    out[key] = isObject(value) && isObject(out[key]) ? deepMerge(out[key], value) : value;
  }
  return out;
};

function readSettings(guildId) {
  let merged = structuredClone(DEFAULT_GUILD_SETTINGS);
  if (!guildId) return merged;
  for (const row of all('SELECT key, value FROM guild_settings WHERE guild_id = ?', guildId)) {
    if (!(row.key in merged)) continue;
    try {
      merged[row.key] = deepMerge(merged[row.key], JSON.parse(row.value));
    } catch {
      // Ignore corrupt rows; defaults stay in place.
    }
  }
  return merged;
}

function audit(guildId, key, before, after) {
  try {
    run(
      `INSERT INTO settings_audit (guild_id, actor_id, key, old_value, new_value, created_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
      guildId,
      'dashboard',
      key,
      JSON.stringify(before ?? null),
      JSON.stringify(after ?? null),
      Date.now(),
    );
  } catch {
    // Audit is best-effort; never lose the actual write.
  }
}

function parsePayload(value) {
  try {
    return JSON.parse(value ?? '{}') ?? {};
  } catch {
    return {};
  }
}

let landingStatsPromise = null;
function landingStats() {
  landingStatsPromise ??= loadRegistry()
    .then(({ commands }) => ({ commands: commands.size }))
    .catch(() => ({ commands: 59 }));
  return landingStatsPromise;
}

function buildSummary(guildParam) {
  const now = Date.now();
  const since7 = now - WEEK;
  const guilds = all('SELECT id, name, icon, plan, approved FROM guilds ORDER BY joined_at ASC');
  const guildId = guildParam || guilds[0]?.id || null;
  const settings = readSettings(guildId);
  const plan = planSnapshot(guildId);
  const analyticsDays = Math.max(1, Number(plan.limits.analyticsDays) || 14);
  const sinceAnalytics = now - analyticsDays * 86_400_000;

  let jackpot = null;
  if (guildId) {
    try {
      const pool = getJackpot(guildId);
      jackpot = { ...pool, history: getJackpotHistory(guildId, 8) };
    } catch {
      // The bot may not have applied the jackpot migration yet.
    }
  }

  const statusEvents = guildId
    ? all('SELECT * FROM server_status_events WHERE guild_id = ? AND created_at >= ? ORDER BY created_at ASC', guildId, since7)
    : [];
  const eventsByServer = new Map();
  for (const event of statusEvents) {
    eventsByServer.set(event.server_id, [...(eventsByServer.get(event.server_id) ?? []), event]);
  }

  let liveByServer = new Map();
  try {
    liveByServer = new Map(all('SELECT * FROM server_live_stats').map((row) => [row.server_id, row]));
  } catch {
    // The bot may not have applied the live-stats migration yet.
  }

  const servers = (guildId ? all('SELECT * FROM servers WHERE guild_id = ? ORDER BY created_at ASC', guildId) : []).map((server) => {
    const uptime = computeUptime(eventsByServer.get(server.id) ?? [], now, WEEK);
    const live = liveByServer.get(server.id);
    return {
      id: server.id,
      label: server.label,
      host: server.host,
      port: server.port,
      enabled: Boolean(server.enabled),
      hasPassword: Boolean(server.password),
      current: uptime.current,
      players: Number(live?.players ?? uptime.players) || 0,
      maxPlayers: Number(live?.max_players) || null,
      queue: Number(live?.queue) || 0,
      uptimePercent: uptime.uptimePercent,
      incidents: uptime.incidents,
    };
  });

  const links = guildId ? all('SELECT * FROM player_links WHERE guild_id = ? ORDER BY verified_at DESC', guildId) : [];
  const linkByUser = new Map(links.map((entry) => [entry.user_id, entry]));
  const accounts = guildId
    ? all('SELECT * FROM players WHERE guild_id = ? ORDER BY astro_score DESC, wallet DESC LIMIT 200', guildId)
    : [];
  const badgeById = new Map((guildId ? listBadges(guildId) : []).map((badge) => [badge.id, badge]));
  const badgesByUser = new Map();
  if (guildId) {
    for (const row of all('SELECT user_id, badge_id FROM player_badges WHERE guild_id = ? ORDER BY awarded_at DESC', guildId)) {
      const definition = badgeById.get(row.badge_id);
      if (!definition) continue;
      const art =
        definition.requirement === 'Clan badge'
          ? `/badge-art/${encodeURIComponent(definition.id)}.png`
          : `/badges/${encodeURIComponent(definition.icon ?? definition.id)}.png`;
      if (!badgesByUser.has(row.user_id)) badgesByUser.set(row.user_id, []);
      badgesByUser.get(row.user_id).push({ id: definition.id, label: definition.label, art });
    }
  }

  const referrals = guildId ? all('SELECT * FROM referrals WHERE guild_id = ? ORDER BY uses DESC LIMIT 50', guildId) : [];
  const referralByUser = new Map(referrals.map((entry) => [entry.owner_id, entry]));

  const players = accounts.map((account) => {
    const rank = personalRank(account.level);
    return {
      ...account,
      link: linkByUser.get(account.user_id) ?? null,
      rankBadge: { key: rank.key, label: rank.label },
      badges: badgesByUser.get(account.user_id) ?? [],
      referral: referralByUser.get(account.user_id) ?? null,
    };
  });
  const economy = accounts.reduce(
    (total, account) => ({
      wallet: total.wallet + Number(account.wallet ?? 0),
      bank: total.bank + Number(account.bank ?? 0),
    }),
    { wallet: 0, bank: 0 },
  );

  const cases = guildId ? all('SELECT * FROM mod_cases WHERE guild_id = ? ORDER BY created_at DESC LIMIT 60', guildId) : [];
  const appeals = cases.filter((entry) => entry.appeal_status === 'pending');
  const staff = guildId
    ? all(
        `SELECT moderator_id, COUNT(*) AS total, SUM(CASE WHEN action = 'ban' THEN 1 ELSE 0 END) AS bans
         FROM mod_cases WHERE guild_id = ? AND created_at >= ? GROUP BY moderator_id ORDER BY total DESC`,
        guildId,
        now - 30 * 86_400_000,
      )
    : [];

  const openTickets = guildId
    ? all("SELECT * FROM tickets WHERE guild_id = ? AND status = 'open' ORDER BY created_at ASC", guildId)
    : [];
  const closedTickets = guildId
    ? all("SELECT * FROM tickets WHERE guild_id = ? AND status = 'closed' ORDER BY closed_at DESC LIMIT 30", guildId)
    : [];
  const ticketRating = guildId ? get('SELECT AVG(rating) AS avg FROM tickets WHERE guild_id = ? AND rating IS NOT NULL', guildId) : null;

  const shopProducts = (settings.shop?.products ?? []).map((product) => ({
    id: String(product.id),
    name: product.name ?? product.shortname ?? String(product.id),
    shortname: product.shortname ?? null,
    category: product.category ?? 'Uncategorised',
    image: product.image ?? null,
    description: product.description ?? null,
    stackSize: Number(product.stackSize ?? 1),
    price: Number(product.price ?? 0),
    quantity: Number(product.quantity ?? 1),
    stock: product.stock === null || product.stock === undefined ? null : Number(product.stock),
    requiredRoleId: product.requiredRoleId ?? null,
    alertMuted: Boolean(product.alertMuted),
  }));
  const purchases = guildId
    ? all('SELECT * FROM shop_purchases WHERE guild_id = ? ORDER BY created_at DESC LIMIT 30', guildId)
    : [];
  const sales = guildId
    ? get(
        `SELECT COUNT(*) AS purchases, COALESCE(SUM(quantity),0) AS units, COALESCE(SUM(price),0) AS revenue
         FROM shop_purchases WHERE guild_id = ? AND created_at >= ?`,
        guildId,
        since7,
      )
    : null;
  const topSellers = guildId
    ? all(
        `SELECT product_id, COUNT(*) AS purchases, COALESCE(SUM(quantity),0) AS units,
                COALESCE(SUM(price),0) AS revenue
         FROM shop_purchases WHERE guild_id = ? AND created_at >= ?
         GROUP BY product_id ORDER BY revenue DESC LIMIT 8`,
        guildId,
        now - 30 * 86_400_000,
      )
    : [];

  const wipes = guildId ? all('SELECT * FROM wipe_profiles WHERE guild_id = ? ORDER BY next_wipe_at ASC', guildId) : [];
  const templates = (guildId ? all('SELECT * FROM server_templates WHERE guild_id = ? ORDER BY created_at DESC', guildId) : []).map((row) => {
    const payload = parsePayload(row.payload);
    return {
      id: row.id,
      name: row.name,
      created_at: row.created_at,
      roles: payload.roles?.length ?? 0,
      categories: payload.categories?.length ?? 0,
      channels: payload.channels?.length ?? 0,
      description: payload.description ?? null,
    };
  });

  const teams = guildId
    ? all(
        `SELECT t.*, (SELECT COUNT(*) FROM team_members m WHERE m.team_id = t.id) AS members
         FROM teams t WHERE t.guild_id = ? ORDER BY members DESC, created_at ASC`,
        guildId,
      )
    : [];
  const teamMembers = guildId ? all('SELECT * FROM team_members WHERE guild_id = ?', guildId) : [];
  const wars = guildId
    ? all(
        `SELECT w.*, t.name AS team_name, o.name AS opponent_name
         FROM team_wars w JOIN teams t ON t.id = w.team_id
         LEFT JOIN teams o ON o.id = w.opponent_team_id
         WHERE w.guild_id = ? ORDER BY w.started_at DESC LIMIT 20`,
        guildId,
      )
    : [];

  const clanRanks = guildId ? all('SELECT * FROM clan_ranks WHERE guild_id = ? ORDER BY position ASC', guildId) : [];
  const clanBadges = guildId ? all('SELECT * FROM clan_badges WHERE guild_id = ? ORDER BY created_at DESC', guildId) : [];
  const badgeAwards = guildId
    ? all('SELECT badge_id, COUNT(*) AS awarded FROM player_badges WHERE guild_id = ? GROUP BY badge_id', guildId)
    : [];
  const awardedByBadge = new Map(badgeAwards.map((entry) => [entry.badge_id, Number(entry.awarded)]));

  // The catalogue spans built-in badges and clan uploads, so the console can
  // show every badge with its real artwork and award count rather than a file path.
  const badgeCatalogue = guildId
    ? listBadges(guildId).map((badge) => ({
        id: badge.id,
        label: badge.label,
        requirement: badge.requirement,
        awarded: awardedByBadge.get(badge.id) ?? 0,
        art:
          badge.requirement === 'Clan badge'
            ? `/badge-art/${encodeURIComponent(badge.id)}.png`
            : `/badges/${encodeURIComponent(badge.icon ?? badge.id)}.png`,
      }))
    : [];

  const tasks = guildId ? all('SELECT * FROM scheduled_tasks WHERE guild_id = ? ORDER BY created_at ASC', guildId) : [];
  const bounties = guildId ? all('SELECT * FROM bounties WHERE guild_id = ? ORDER BY created_at DESC LIMIT 40', guildId) : [];
  const battlePass = guildId
    ? all('SELECT * FROM battle_pass WHERE guild_id = ? ORDER BY tier DESC, xp DESC LIMIT 60', guildId)
    : [];
  const lfg = guildId
    ? all(
        `SELECT p.*, (SELECT COUNT(*) FROM lfg_members m WHERE m.post_id = p.id) AS joined
         FROM lfg_posts p WHERE p.guild_id = ? ORDER BY p.created_at DESC LIMIT 40`,
        guildId,
      )
    : [];

  const auditTrail = guildId
    ? all('SELECT * FROM settings_audit WHERE guild_id = ? ORDER BY created_at DESC LIMIT 100', guildId)
    : [];
  const transactions = guildId
    ? all('SELECT * FROM transactions WHERE guild_id = ? ORDER BY created_at DESC LIMIT 40', guildId)
    : [];

  const sessions = guildId ? all('SELECT * FROM player_sessions WHERE guild_id = ? AND started_at >= ?', guildId, sinceAnalytics) : [];
  const retention = summarizeSessions(sessions, now, analyticsDays);
  const recentSessions = guildId
    ? all('SELECT * FROM player_sessions WHERE guild_id = ? ORDER BY started_at DESC LIMIT 80', guildId)
    : [];

  // Daily streak state, lifetime claims and voucher inventory, per player.
  const DAY = 86_400_000;
  const claimRows = guildId
    ? all("SELECT user_id, COUNT(*) AS claims FROM transactions WHERE guild_id = ? AND kind = 'daily_streak' GROUP BY user_id", guildId)
    : [];
  const claimByUser = new Map(claimRows.map((row) => [row.user_id, Number(row.claims)]));
  const voucherRows = guildId
    ? all('SELECT user_id, item_key, quantity FROM inventory WHERE guild_id = ? AND quantity > 0', guildId)
    : [];
  const vouchersByUser = new Map();
  for (const row of voucherRows) {
    vouchersByUser.set(row.user_id, [...(vouchersByUser.get(row.user_id) ?? []), { key: row.item_key, quantity: Number(row.quantity) }]);
  }
  const rewards = {};
  for (const player of players) {
    const last = Number(player.last_daily ?? 0);
    const streak = Number(player.streak ?? 0);
    const claimedToday = last > 0 && now - last < DAY;
    const inCycle = streak % 7;
    const lifetime = Number(player.daily_claims ?? claimByUser.get(player.user_id) ?? 0);
    rewards[player.user_id] = {
      streak,
      lastDaily: last || null,
      claimedToday,
      nextAt: last ? last + DAY : null,
      cycle: Math.floor(streak / 7),
      claimableDay: claimedToday ? null : inCycle + 1,
      lifetime,
      milestones: [10, 25, 50, 100].map((at) => ({ at, reached: lifetime >= at })),
      vouchers: vouchersByUser.get(player.user_id) ?? [],
    };
  }

  const telemetry = guildId
    ? all('SELECT * FROM telemetry_events WHERE guild_id = ? ORDER BY created_at DESC LIMIT 60', guildId)
    : [];
  const onlineSessions = guildId
    ? all('SELECT * FROM player_sessions WHERE guild_id = ? AND ended_at IS NULL ORDER BY started_at DESC LIMIT 60', guildId)
    : [];
  const finance = guildId
    ? get(
        `SELECT COALESCE(SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END), 0) AS minted,
                COALESCE(SUM(CASE WHEN amount < 0 THEN -amount ELSE 0 END), 0) AS burned
         FROM transactions WHERE guild_id = ? AND created_at >= ?`,
        guildId,
        now - 30 * DAY,
      )
    : null;
  const revenue30 = guildId
    ? get('SELECT COALESCE(SUM(price), 0) AS revenue, COUNT(*) AS orders FROM shop_purchases WHERE guild_id = ? AND created_at >= ?', guildId, now - 30 * DAY)
    : null;

  const currencyScope = settings.economy?.scope ?? 'local';
  const currencyScopeKey = guildId ? economyScopeKey(guildId, settings) : null;
  const currencyRows = currencyScopeKey
    ? all(
        'SELECT user_id, wallet, bank FROM players WHERE guild_id = ? ORDER BY (wallet + bank) DESC LIMIT 25',
        currencyScopeKey,
      )
    : [];
  const currencyTotals = currencyScopeKey
    ? get(
        'SELECT COALESCE(SUM(wallet), 0) AS wallet, COALESCE(SUM(bank), 0) AS bank FROM players WHERE guild_id = ?',
        currencyScopeKey,
      ) ?? { wallet: 0, bank: 0 }
    : { wallet: 0, bank: 0 };
  let dbBytes = 0;
  try {
    dbBytes = statSync(DB_PATH).size;
  } catch {
    dbBytes = 0;
  }

  return {
    generatedAt: now,
    guilds,
    guildId,
    plan,
    analytics: { days: analyticsDays },
    jackpot,
    overview: {
      players: accounts.length,
      wallet: economy.wallet,
      bank: economy.bank,
      activeCases: cases.filter((entry) => Number(entry.active)).length,
      openTickets: openTickets.length,
      onlineServers: servers.filter((server) => server.current === 'online').length,
      servers: servers.length,
      teams: teams.length,
      sessionsToday: retention.daily.at(-1)?.sessions ?? 0,
      uniquePlayers28d: retention.uniquePlayers,
      revenue7d: Number(sales?.revenue ?? 0),
      purchases7d: Number(sales?.purchases ?? 0),
      nextWipeAt: wipes.find((entry) => entry.next_wipe_at)?.next_wipe_at ?? null,
    },
    servers,
    players,
    links,
    economy: { ...economy, transactions },
    currency: {
      scope: currencyScope,
      scopeKey: currencyScopeKey,
      partnerNetworkId: settings.economy?.partnerNetworkId ?? null,
      currency: settings.economy?.currency ?? 'coins',
      minted: Boolean(settings.economy?.minted),
      mintSources: settings.economy?.mintSources ?? {},
      wallet: currencyTotals.wallet,
      bank: currencyTotals.bank,
      total: currencyTotals.wallet + currencyTotals.bank,
      topWallets: currencyRows.map((row) => ({
        userId: row.user_id,
        wallet: Number(row.wallet ?? 0),
        bank: Number(row.bank ?? 0),
        total: Number(row.wallet ?? 0) + Number(row.bank ?? 0),
      })),
      transactions,
    },
    shop: {
      enabled: Boolean(settings.shop?.enabled),
      products: shopProducts,
      purchases,
      topSellers,
      sales: {
        purchases: Number(sales?.purchases ?? 0),
        units: Number(sales?.units ?? 0),
        revenue: Number(sales?.revenue ?? 0),
      },
      stockAlertChannelId: settings.shop?.stockAlertChannelId ?? null,
    },
    wipes: wipes.map((entry) => ({ ...entry, serverLabel: servers.find((server) => server.id === entry.server_id)?.label ?? null })),
    templates,
    teams: teams.map((team) => ({ ...team, memberList: teamMembers.filter((member) => member.team_id === team.id) })),
    wars,
    clans: {
      ranks: clanRanks,
      badges: clanBadges.map((badge) => ({ ...badge, awarded: awardedByBadge.get(badge.id) ?? 0 })),
      catalogue: badgeCatalogue,
      awards: [...awardedByBadge.values()].reduce((total, count) => total + count, 0),
    },
    tickets: {
      open: openTickets,
      closed: closedTickets,
      overdue: openTickets.filter((ticket) => ticket.sla_due_at && ticket.sla_due_at < now).length,
      unassigned: openTickets.filter((ticket) => !ticket.assigned_to).length,
      averageRating: ticketRating?.avg ? Math.round(Number(ticketRating.avg) * 10) / 10 : null,
    },
    moderation: { cases, appeals, staff },
    audit: auditTrail,
    tasks,
    bounties,
    battlePass,
    lfg,
    retention,
    sessions: recentSessions,
    status: { servers, events: statusEvents.slice(-120) },
    settings,
    rewards,
    referrals,
    hubs: {
      telemetry,
      online: onlineSessions,
      kits: settings.kits ?? [],
      orp: settings.orp ?? {},
      loops: {
        messageSeconds: settings.messages?.intervalSeconds ?? null,
        giftMinutes: settings.events?.giftIntervalMinutes ?? null,
        playtimeReward: settings.economy?.playtimeReward ?? 0,
        boosterMultiplier: settings.economy?.boosterMultiplier ?? 1,
        autoKits: Boolean(settings.misc?.autoKitsEnabled),
      },
      staffRoles: {
        support: settings.tickets?.supportRoleIds ?? [],
        recruiters: settings.staff?.recruiterRoleIds ?? [],
      },
      finance: {
        minted: Number(finance?.minted ?? 0),
        burned: Number(finance?.burned ?? 0),
        revenue30: Number(revenue30?.revenue ?? 0),
        orders30: Number(revenue30?.orders ?? 0),
        supply: economy.wallet + economy.bank,
      },
      health: {
        uptimeSeconds: Math.round(process.uptime()),
        memoryMb: Math.round(process.memoryUsage().rss / 1_048_576),
        dbBytes,
        node: process.version,
        serversOnline: servers.filter((server) => server.current === 'online').length,
        servers: servers.length,
        incidents7d: servers.reduce((total, server) => total + Number(server.incidents ?? 0), 0),
      },
    },
    configSections: Object.entries(CONFIG_SECTIONS).map(([id, section]) => ({ id, ...section })),
  };
}

const PRIORITIES = new Set(['low', 'normal', 'high', 'urgent']);
const APPEAL_STATES = new Set(['none', 'pending', 'approved', 'denied']);
const ACTIONS = {
  'settings.saveMany': (guildId, body) => {
    if (!isObject(body.groups)) throw new Error('Missing settings groups.');
    for (const [root, value] of Object.entries(body.groups)) {
      if (!SETTINGS_ROOT_KEYS.includes(root)) throw new Error(`Unknown settings group "${root}".`);
      const before = readSettings(guildId)[root];
      run(
        `INSERT INTO guild_settings (guild_id, key, value, updated_at) VALUES (?, ?, ?, ?)
         ON CONFLICT(guild_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
        guildId,
        root,
        JSON.stringify(value ?? null),
        Date.now(),
      );
      audit(guildId, `settings.${root}`, before, value);
    }
  },

  'server.update': (guildId, body) => {
    const server = get('SELECT * FROM servers WHERE id = ? AND guild_id = ?', body.id, guildId);
    if (!server) throw new Error('That server no longer exists.');
    const label = String(body.label ?? server.label).trim().slice(0, 80);
    const host = String(body.host ?? server.host).trim().slice(0, 120);
    const port = Number(body.port ?? server.port);
    if (!label || !host) throw new Error('Server label and host are required.');
    if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('RCON port must be 1-65535.');
    run('UPDATE servers SET label = ?, host = ?, port = ? WHERE id = ? AND guild_id = ?', label, host, port, server.id, guildId);
    audit(guildId, `server.${server.id}`, server, { label, host, port });
  },

  'server.toggle': (guildId, body) => {
    const server = get('SELECT * FROM servers WHERE id = ? AND guild_id = ?', body.id, guildId);
    if (!server) throw new Error('That server no longer exists.');
    const enabled = body.enabled ? 1 : 0;
    run('UPDATE servers SET enabled = ? WHERE id = ? AND guild_id = ?', enabled, server.id, guildId);
    audit(guildId, `server.${server.id}.enabled`, Boolean(server.enabled), Boolean(enabled));
  },

  'task.toggle': (guildId, body) => {
    const task = get('SELECT * FROM scheduled_tasks WHERE id = ? AND guild_id = ?', body.id, guildId);
    if (!task) throw new Error('That scheduled task no longer exists.');
    const enabled = body.enabled ? 1 : 0;
    run('UPDATE scheduled_tasks SET enabled = ? WHERE id = ? AND guild_id = ?', enabled, task.id, guildId);
    audit(guildId, `task.${task.id}.enabled`, Boolean(task.enabled), Boolean(enabled));
  },

  'wipe.update': (guildId, body) => {
    const profile = get('SELECT * FROM wipe_profiles WHERE id = ? AND guild_id = ?', body.id, guildId);
    if (!profile) throw new Error('That wipe profile no longer exists.');
    const interval = Number(body.interval_hours ?? profile.interval_hours);
    if (!Number.isFinite(interval) || interval < 1 || interval > 8760) throw new Error('Wipe interval must be 1-8760 hours.');
    const autoRestart = body.auto_restart === undefined ? profile.auto_restart : body.auto_restart ? 1 : 0;
    const nextWipe = body.next_wipe_at === undefined || body.next_wipe_at === null ? profile.next_wipe_at : Number(body.next_wipe_at);
    if (!Number.isFinite(nextWipe)) throw new Error('Next wipe must be a valid date.');
    run(
      'UPDATE wipe_profiles SET interval_hours = ?, auto_restart = ?, next_wipe_at = ? WHERE id = ? AND guild_id = ?',
      interval,
      autoRestart,
      nextWipe,
      profile.id,
      guildId,
    );
    audit(guildId, `wipe.${profile.id}`, profile, { interval_hours: interval, auto_restart: autoRestart, next_wipe_at: nextWipe });
  },

  'ticket.update': (guildId, body) => {
    const ticket = get('SELECT * FROM tickets WHERE id = ? AND guild_id = ?', body.id, guildId);
    if (!ticket) throw new Error('That ticket no longer exists.');
    const priority = body.priority === undefined ? ticket.priority : String(body.priority).slice(0, 16);
    if (priority && !PRIORITIES.has(priority)) throw new Error('Priority must be low, normal, high or urgent.');
    const assignedTo = body.assigned_to === undefined ? ticket.assigned_to : body.assigned_to ? String(body.assigned_to).slice(0, 32) : null;
    const slaDueAt = body.sla_due_at === undefined ? ticket.sla_due_at : body.sla_due_at ? Number(body.sla_due_at) : null;
    run('UPDATE tickets SET priority = ?, assigned_to = ?, sla_due_at = ? WHERE id = ? AND guild_id = ?', priority, assignedTo, slaDueAt, ticket.id, guildId);
    audit(guildId, `ticket.${ticket.id}`, ticket, { priority, assigned_to: assignedTo, sla_due_at: slaDueAt });
  },

  'case.appeal': (guildId, body) => {
    const record = get('SELECT * FROM mod_cases WHERE id = ? AND guild_id = ?', body.id, guildId);
    if (!record) throw new Error('That case no longer exists.');
    const status = String(body.appeal_status ?? 'none');
    if (!APPEAL_STATES.has(status)) throw new Error('Unknown appeal state.');
    run('UPDATE mod_cases SET appeal_status = ? WHERE id = ? AND guild_id = ?', status, record.id, guildId);
    audit(guildId, `case.${record.id}.appeal`, record.appeal_status, status);
  },

  'team.update': (guildId, body) => {
    const team = get('SELECT * FROM teams WHERE id = ? AND guild_id = ?', body.id, guildId);
    if (!team) throw new Error('That team no longer exists.');
    const tag = String(body.tag ?? team.tag).trim().slice(0, 8);
    const color = String(body.color ?? team.color ?? '').trim().slice(0, 16);
    run('UPDATE teams SET tag = ?, color = ? WHERE id = ? AND guild_id = ?', tag, color || null, team.id, guildId);
    audit(guildId, `team.${team.id}`, { tag: team.tag, color: team.color }, { tag, color });
  },

  'lfg.close': (guildId, body) => {
    const post = get('SELECT * FROM lfg_posts WHERE id = ? AND guild_id = ?', body.id, guildId);
    if (!post) throw new Error('That LFG post no longer exists.');
    run("UPDATE lfg_posts SET status = 'closed', closed_at = ? WHERE id = ? AND guild_id = ?", Date.now(), post.id, guildId);
    audit(guildId, `lfg.${post.id}`, post.status, 'closed');
  },

  'product.update': (guildId, body) => {
    const settings = readSettings(guildId);
    const products = settings.shop?.products ?? [];
    const product = products.find((entry) => String(entry.id) === String(body.id));
    if (!product) throw new Error('That product no longer exists.');

    const stockRaw = body.stock === null || body.stock === '' ? null : Number(body.stock);
    if (stockRaw !== null && (!Number.isInteger(stockRaw) || stockRaw < 0)) throw new Error('Stock must be blank or a whole number.');
    const price = Number(body.price ?? product.price);
    if (!Number.isInteger(price) || price < 0) throw new Error('Price must be a whole number.');
    const quantity = Number(body.quantity ?? product.quantity ?? 1);
    if (!Number.isInteger(quantity) || quantity < 1) throw new Error('Quantity must be at least 1.');

    const next = products.map((entry) =>
      String(entry.id) === String(product.id)
        ? { ...entry, stock: stockRaw, price, quantity, alertMuted: body.alertMuted === undefined ? entry.alertMuted : Boolean(body.alertMuted) }
        : entry,
    );
    run(
      `INSERT INTO guild_settings (guild_id, key, value, updated_at) VALUES (?, 'shop', ?, ?)
       ON CONFLICT(guild_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
      guildId,
      JSON.stringify({ ...settings.shop, products: next }),
      Date.now(),
    );
    if (Number(product.stock ?? -1) !== Number(stockRaw ?? -1)) {
      run(
        `INSERT INTO shop_stock_events (guild_id, product_id, delta, stock_after, kind, actor_id, note, created_at)
         VALUES (?, ?, 0, ?, 'dashboard', ?, ?, ?)`,
        guildId,
        String(product.id),
        stockRaw,
        'dashboard',
        'Stock edited from the dashboard',
        Date.now(),
      );
    }
    audit(guildId, `product.${product.id}`, product, next.find((entry) => String(entry.id) === String(product.id)));
  },

  'product.delete': (guildId, body) => {
    const settings = readSettings(guildId);
    const products = settings.shop?.products ?? [];
    const product = products.find((entry) => String(entry.id) === String(body.id));
    if (!product) throw new Error('That product no longer exists.');
    const next = products.filter((entry) => String(entry.id) !== String(product.id));
    run(
      `INSERT INTO guild_settings (guild_id, key, value, updated_at) VALUES (?, 'shop', ?, ?)
       ON CONFLICT(guild_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
      guildId,
      JSON.stringify({ ...settings.shop, products: next }),
      Date.now(),
    );
    audit(guildId, `product.${product.id}`, product, null);
  },

  'shop.clear': (guildId) => {
    const settings = readSettings(guildId);
    run(
      `INSERT INTO guild_settings (guild_id, key, value, updated_at) VALUES (?, 'shop', ?, ?)
       ON CONFLICT(guild_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
      guildId,
      JSON.stringify({ ...settings.shop, products: [], enabled: false }),
      Date.now(),
    );
    audit(guildId, 'shop.clear', { products: settings.shop?.products?.length ?? 0 }, { products: 0, enabled: false });
  },

  'player.claimDaily': (guildId, body) => {
    const userId = String(body.userId ?? '').trim();
    if (!/^\d{5,32}$/.test(userId)) throw new Error('Pick a player before claiming.');
    const result = claimDaily(guildId, userId);
    if (!result.claimed) throw new Error(`Already claimed — next claim ${new Date(result.nextAt).toLocaleString()}.`);
    return { streak: result.streak, amount: result.amount, day: result.day, voucher: result.voucher ?? null, bonusXp: result.bonusXp };
  },

  'mod.note': (guildId, body) => {
    const targetId = String(body.targetId ?? '').trim();
    const reason = String(body.reason ?? '').trim().slice(0, 400);
    const kind = String(body.kind ?? 'note').trim().slice(0, 24);
    if (!/^\d{5,32}$/.test(targetId)) throw new Error('Target must be a Discord user ID.');
    if (!reason) throw new Error('A reason is required so the case is defensible.');
    const id = `web_${Date.now().toString(36)}`;
    run(
      `INSERT INTO mod_cases (id, guild_id, target_id, moderator_id, action, reason, duration_ms, expires_at, active, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      id,
      guildId,
      targetId,
      'dashboard',
      kind,
      reason,
      null,
      null,
      0,
      Date.now(),
    );
    audit(guildId, `case.${id}`, null, { action: kind, target: targetId, reason });
    return { id };
  },

  'voucher.use': async (guildId, body) => {
    const userId = String(body.userId ?? '').trim();
    const itemKey = String(body.itemKey ?? '').trim();
    if (!/^\d{5,32}$/.test(userId)) throw new Error('Pick a player first.');
    const result = openCrate(guildId, userId, itemKey);
    const delivery = await deliverCrateLoot({ guildId, userId, rewards: result.rewards });
    audit(guildId, `voucher.${itemKey}`, null, { userId, coins: result.coins, delivered: delivery.delivered });
    return { crate: result.crate, coins: result.coins, rewards: result.rewards, delivery };
  },

  'bank.move': (guildId, body) => {
    const userId = String(body.userId ?? '').trim();
    const direction = String(body.direction ?? '').trim();
    const amount = Math.trunc(Number(body.amount));
    if (!/^\d{5,32}$/.test(userId)) throw new Error('Pick a player first.');
    if (direction !== 'deposit' && direction !== 'withdraw') throw new Error('Choose deposit or withdraw.');
    if (!Number.isFinite(amount) || amount < 1) throw new Error('Amount must be a whole number of coins.');

    const account = balances(guildId, userId);
    const settings = readSettings(guildId);
    if (direction === 'deposit') {
      if (amount > account.wallet) throw new Error(`Wallet holds ${account.wallet}; cannot deposit ${amount}.`);
      const cap = Number(settings.economy.bankCap) || 0;
      if (cap && account.bank + amount > cap) throw new Error(`The vault is capped at ${cap} coins.`);
      adjustBalances(guildId, userId, { wallet: -amount, bank: amount }, { kind: 'bank_deposit', amount });
    } else {
      if (amount > account.bank) throw new Error(`Vault holds ${account.bank}; cannot withdraw ${amount}.`);
      const cap = Number(settings.economy.walletCap) || 0;
      if (cap && account.wallet + amount > cap) throw new Error(`The wallet is capped at ${cap} coins.`);
      adjustBalances(guildId, userId, { wallet: amount, bank: -amount }, { kind: 'bank_withdraw', amount: -amount });
    }

    audit(guildId, `bank.${direction}`, null, { userId, amount });
    const after = balances(guildId, userId);
    return { direction, amount, wallet: after.wallet, bank: after.bank };
  },

  'owner.backup': () => {
    const dir = join('data', 'backups');
    mkdirSync(dir, { recursive: true });
    const name = `astrobot-${new Date().toISOString().replace(/[:.]/g, '-')}.db`;
    const target = join(dir, name);
    db.exec(`VACUUM INTO '${target.replaceAll("'", "''")}'`);
    return { name, bytes: statSync(target).size };
  },
};

function parseCookies(header = '') {
  const cookies = {};
  for (const part of String(header).split(';')) {
    const index = part.indexOf('=');
    if (index < 1) continue;
    const name = part.slice(0, index).trim();
    const value = part.slice(index + 1).trim();
    try {
      cookies[name] = decodeURIComponent(value);
    } catch {
      cookies[name] = value;
    }
  }
  return cookies;
}

function currentSession(request) {
  if (!DASHBOARD_PASSWORD) return null;
  const token = parseCookies(request.headers.cookie).astro_session;
  const session = token ? sessions.get(token) : null;
  if (!session) return null;
  if (session.expires <= Date.now()) {
    sessions.delete(token);
    return null;
  }
  return session;
}

function sessionCookies({ token, csrf }, secure) {
  const suffix = `; Path=/; SameSite=Strict${secure ? '; Secure' : ''}`;
  return [
    `astro_session=${token}; HttpOnly; Max-Age=${Math.floor(SESSION_TTL_MS / 1000)}${suffix}`,
    `astro_csrf=${csrf}; Max-Age=${Math.floor(SESSION_TTL_MS / 1000)}${suffix}`,
  ];
}

function expireCookies(secure) {
  const suffix = `; Path=/; SameSite=Strict${secure ? '; Secure' : ''}`;
  return [`astro_session=; HttpOnly; Max-Age=0${suffix}`, `astro_csrf=; Max-Age=0${suffix}`];
}

/** Simple fixed-window limiter, keyed per IP for the public portal endpoints. */
function allowRequest(key, limit, windowMs) {
  const now = Date.now();
  const bucket = rateBuckets.get(key);
  if (!bucket || bucket.reset <= now) {
    rateBuckets.set(key, { count: 1, reset: now + windowMs });
    return true;
  }
  if (bucket.count >= limit) return false;
  bucket.count += 1;
  if (rateBuckets.size > 5000) {
    for (const [entry, value] of rateBuckets) if (value.reset <= now) rateBuckets.delete(entry);
  }
  return true;
}

function readBody(request, limit = 200_000) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    request.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error('Request body too large.'));
        request.destroy();
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch {
        reject(new Error('Invalid JSON body.'));
      }
    });
    request.on('error', reject);
  });
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.webm': 'video/webm',
};

function requestHostname(request) {
  const forwarded = String(request.headers['x-forwarded-host'] ?? '').split(',')[0].trim();
  const host = forwarded || String(request.headers.host ?? '');
  return host.split(':')[0].toLowerCase();
}

function giveawaySubdomain(hostname) {
  if (!hostname.endsWith(`.${GIVEAWAY_ROOT_DOMAIN}`)) return null;
  const subdomain = hostname.slice(0, -(GIVEAWAY_ROOT_DOMAIN.length + 1));
  return subdomain && !subdomain.includes('.') ? subdomain : null;
}

function publicHostFor(username) {
  return `${normalizeUsername(username)}.${GIVEAWAY_ROOT_DOMAIN}`;
}

function publicUrlFor(username, path = '') {
  return `${GIVEAWAY_PUBLIC_PROTOCOL}://${publicHostFor(username)}${path}`;
}

function publicBonusTask(giveaway, index) {
  const position = Math.trunc(Number(index) || 0);
  const task = giveaway.tasks?.[position - 1];
  if (!task || position < 1 || task.enabled === false) return null;
  return { index: position, points: Math.max(0, Math.min(25, Math.trunc(Number(task.points) || 0))) };
}

function csvCell(value) {
  return `"${String(value ?? '').replaceAll('"', '""')}"`;
}

function probeLocalHost(host) {
  return new Promise((resolve) => {
    const req = httpRequest(
      {
        hostname: '127.0.0.1',
        port: PORT,
        path: '/?health=1',
        method: 'GET',
        headers: { Host: host },
        timeout: 5000,
      },
      (res) => {
        let body = '';
        res.setEncoding('utf8');
        res.on('data', (chunk) => {
          if (body.length < 200_000) body += chunk;
        });
        res.on('end', () => resolve({ status: res.statusCode, body }));
      },
    );
    req.on('timeout', () => req.destroy(new Error('Timed out after 5 seconds.')));
    req.on('error', (error) => resolve({ error: error.message }));
    req.end();
  });
}

async function checkGiveawayDomain(giveaway) {
  const host = publicHostFor(giveaway.username);
  const publicUrl = publicUrlFor(giveaway.username);
  const [a, aaaa, cname] = await Promise.allSettled([resolve4(host), resolve6(host), resolveCname(host)]);
  const records = [
    ...(a.status === 'fulfilled' ? a.value.map((value) => `A ${value}`) : []),
    ...(aaaa.status === 'fulfilled' ? aaaa.value.map((value) => `AAAA ${value}`) : []),
    ...(cname.status === 'fulfilled' ? cname.value.map((value) => `CNAME ${value}`) : []),
  ];
  const local = await probeLocalHost(host);
  const checks = [
    {
      id: 'dns',
      label: 'Wildcard DNS',
      status: records.length ? 'ok' : 'fail',
      detail: records.length ? records.join(' · ') : `No A, AAAA or CNAME record found for ${host}.`,
    },
    {
      id: 'local',
      label: 'Host routing',
      status: local.status === 200 && String(local.body ?? '').includes(giveaway.username) ? 'ok' : 'fail',
      detail: local.error
        ? local.error
        : local.status === 200 && String(local.body ?? '').includes(giveaway.username)
          ? 'The app resolved this subdomain to the giveaway page.'
          : `Local probe returned HTTP ${local.status ?? 'unknown'} without the giveaway page.`,
    },
  ];

  try {
    const response = await fetch(`${publicUrl}?health=1`, { redirect: 'manual', signal: AbortSignal.timeout(6000) });
    const body = await response.text();
    const ok = response.status === 200 && body.includes(giveaway.username);
    checks.push({
      id: 'public',
      label: 'Public HTTPS',
      status: ok ? 'ok' : 'fail',
      detail: ok ? `HTTP 200 from ${publicUrl}.` : `HTTP ${response.status} from ${publicUrl}.`,
    });
  } catch (error) {
    checks.push({
      id: 'public',
      label: 'Public HTTPS',
      status: 'fail',
      detail:
        error.name === 'TimeoutError'
          ? 'Timed out after 6 seconds.'
          : error.cause?.code
            ? `${error.message} (${error.cause.code})`
            : error.message,
    });
  }

  return { host, publicUrl, checks, checkedAt: new Date().toISOString() };
}

function serializeManagedGiveaway(giveaway) {
  const host = publicHostFor(giveaway.username);
  return {
    ...giveaway,
    domainAlertAcknowledgedAt: domainAlertAcknowledgement(giveaway.id),
    host,
    publicPath: `/g/${giveaway.username}`,
    linksPath: `/g/${giveaway.username}/links`,
    publicUrl: `${GIVEAWAY_PUBLIC_PROTOCOL}://${host}`,
    linksUrl: `${GIVEAWAY_PUBLIC_PROTOCOL}://${host}/links`,
    domainHealth: latestDomainCheck(giveaway.id),
    domainWebhookTest: latestDomainWebhookTest(giveaway.id),
  };
}

async function sendDomainAlert(giveaway, result, status, previous) {
  const webhook = String(process.env.GIVEAWAY_ALERT_WEBHOOK_URL ?? '').trim();
  if (!webhook) return false;
  const failed = result.checks.filter((check) => check.status !== 'ok');
  const recovering = status === 'ok' && previous?.status === 'fail';
  const content = [
    recovering ? `✅ **Giveaway domain recovered** · @${giveaway.username}` : `🚨 **Giveaway domain failing** · @${giveaway.username}`,
    `Host: \`${result.host}\``,
    ...failed.map((check) => `• ${check.label}: ${check.detail}`),
    `Checked: ${new Date(result.checkedAt).toUTCString()}`,
  ].join('\n');
  try {
    const response = await fetch(webhook, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: content.slice(0, 1900) }),
      signal: AbortSignal.timeout(6000),
    });
    if (!response.ok) {
      console.error(`[domain-alert] Webhook returned ${response.status}.`);
      return false;
    }
    return true;
  } catch (error) {
    console.error('[domain-alert]', error.message);
    return false;
  }
}

async function persistDomainResult(giveaway, result) {
  const previous = latestDomainCheck(giveaway.id);
  const status = result.checks.every((check) => check.status === 'ok') ? 'ok' : 'fail';
  recordDomainCheck({
    giveawayId: giveaway.id,
    guildId: giveaway.guildId,
    host: result.host,
    status,
    checks: result.checks,
    checkedAt: result.checkedAt,
  });
  if (status === 'ok') clearDomainAlertAcknowledgement(giveaway.id);
  if (previous?.status !== status) await sendDomainAlert(giveaway, result, status, previous);
  return status;
}

let domainMonitorBusy = false;
async function monitorGiveawayDomains() {
  if (domainMonitorBusy) return;
  domainMonitorBusy = true;
  try {
    const rows = all("SELECT id, guild_id FROM giveaways WHERE username IS NOT NULL AND status = 'active'");
    for (const row of rows) {
      const giveaway = getManagedGiveaway(row.id, row.guild_id);
      if (!giveaway || giveaway.endsAt <= Date.now()) continue;
      const result = await checkGiveawayDomain(giveaway);
      await persistDomainResult(giveaway, result);
    }
  } catch (error) {
    console.error('[domain-monitor]', error.message);
  } finally {
    domainMonitorBusy = false;
  }
}

function buildHostedGiveawayConfig(giveaway) {
  const isActive = giveaway.status === 'active' && giveaway.endsAt > Date.now();
  const branding = getBranding();
  const bonusTasks = (giveaway.tasks ?? []).map((task) => ({ ...task, required: false, enabled: task.enabled !== false }));
  const theme = normalizeTheme(giveaway.theme);
  const brandName =
    theme.brand === DEFAULT_GIVEAWAY_THEME.brand && branding.name !== DEFAULT_GIVEAWAY_THEME.brand
      ? branding.name
      : theme.brand;
  return {
    colors: { ...DEFAULT_PORTAL_CONFIG.colors, ...theme.colors },
    content: {
      brand: brandName,
      logoDataUrl: branding.wordmarkUrl || '',
      logoWidth: DEFAULT_PORTAL_CONFIG.logoWidth,
      logoMatchTheme: false,
      bgImageDataUrl: '',
      fomoBar: isActive ? DEFAULT_PORTAL_CONFIG.fomoBar : 'This giveaway has ended. Thanks for entering.',
      kicker: `Live Giveaway · @${giveaway.username}`,
      headlineMain: DEFAULT_PORTAL_CONFIG.headlineMain,
      headlineAccent: giveaway.prize,
      subheadline: giveaway.description || DEFAULT_PORTAL_CONFIG.subheadline,
      footerText: '© {year} {brand} - All Rights Reserved.',
    },
    prize: {
      tag: DEFAULT_PORTAL_CONFIG.prize.tag,
      title: giveaway.prize,
      value: '',
      items: [],
      media: { type: 'none', source: 'upload', dataUrl: '', externalUrl: '' },
    },
    endTimestamp: new Date(giveaway.endsAt).toISOString(),
    tasks: [
      {
        title: 'Enter with your gamertag, PSN ID or Steam username',
        subtitle: 'Your base entry — required to qualify',
        points: 1,
        icon: 'link',
        url: '',
        required: true,
        enabled: true,
      },
      ...bonusTasks,
    ],
    animations: { bgGlow: true, scanlines: true, liveTicker: true, entryCounter: true, kickerPulse: true },
    stats: {
      entryCountStart: Math.max(0, Number(giveaway.entries) || 0),
      winners: Math.max(1, Math.trunc(Number(giveaway.winners) || 1)),
    },
    faq: giveaway.faq,
    faqEnabled: giveaway.faqEnabled !== false,
    recentEntries: recentPageEntries(giveaway.id, 12).map((entry) => ({
      ...entry,
      regionLabel: giveawayRegionLabel(entry.region),
    })),
  };
}

function hostedPage({ file, marker, globalName, payload, absoluteConfig = false }) {
  let html = readFileSync(join(PUBLIC, 'giveaway-portal', file), 'utf8');
  const json = JSON.stringify(payload).replace(/</g, '\\u003c');
  html = html.replace(marker, `<script>window.${globalName} = ${json};</script>`);
  if (absoluteConfig) {
    html = html.replace('<script src="config.js"></script>', '<script src="/giveaway-portal/config.js"></script>');
  }
  return html;
}

function publicNotFound(response, message = 'Giveaway not found.') {
  const safe = String(message).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
  response.writeHead(404, {
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Content-Type': 'text/html; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  response.end(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Giveaway not found</title></head><body style="background:#07070d;color:#eef0f8;font-family:Arial,sans-serif;display:grid;place-items:center;min-height:100vh;margin:0"><main style="text-align:center;padding:24px"><h1 style="font-size:2rem">404</h1><p style="color:#8b8fa8">${safe}</p></main></body></html>`);
}

function serveGiveawayPage(request, response, giveaway, { isSubdomain = false } = {}) {
  if (!planHasFeature(giveaway.guildId, 'hostedPages')) {
    return publicNotFound(response, 'This giveaway page is not available on the current plan.');
  }
  if (new URL(request.url, 'http://localhost').searchParams.get('health') !== '1') {
    recordGiveawayEvent({
      giveawayId: giveaway.id,
      guildId: giveaway.guildId,
      kind: 'view',
      path: request.url,
      referrer: request.headers.referer ?? null,
    });
  }
  const linkPagePath = isSubdomain ? '/links' : `/g/${giveaway.username}/links`;
  const payload = {
    giveaway: { id: giveaway.id, username: giveaway.username, prize: giveaway.prize, endsAt: giveaway.endsAt, status: giveaway.status },
    config: buildHostedGiveawayConfig(giveaway),
    links: giveaway.links,
    linkPagePath,
    entryEndpoint: '/api/giveaway-portal/public/enter',
    entryStateEndpoint: '/api/giveaway-portal/public/entry',
    bonusEndpoint: '/api/giveaway-portal/public/bonus',
    publicUrl: publicUrlFor(giveaway.username),
  };
  response.writeHead(200, {
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Content-Type': 'text/html; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  response.end(
    hostedPage({
      file: 'index.html',
      marker: '<!-- ASTRO_GIVEAWAY_BOOTSTRAP -->',
      globalName: '__ASTRO_GIVEAWAY__',
      payload,
      absoluteConfig: true,
    }),
  );
}

function serveLinksPage(request, response, giveaway, { isSubdomain = false } = {}) {
  if (!planHasFeature(giveaway.guildId, 'hostedPages')) {
    return publicNotFound(response, 'This giveaway page is not available on the current plan.');
  }
  recordGiveawayEvent({
    giveawayId: giveaway.id,
    guildId: giveaway.guildId,
    kind: 'links_view',
    path: request.url,
    referrer: request.headers.referer ?? null,
  });
  response.writeHead(200, {
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Content-Type': 'text/html; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  response.end(
    hostedPage({
      file: 'links.html',
      marker: '<!-- ASTRO_LINKS_BOOTSTRAP -->',
      globalName: '__ASTRO_LINKS__',
      payload: {
        username: giveaway.username,
        title: giveaway.prize,
        bio: giveaway.description,
        links: giveaway.links,
        giveawayPath: isSubdomain ? '/' : `/g/${giveaway.username}`,
        linkBase: isSubdomain ? '/go' : `/g/${giveaway.username}/go`,
        host: publicHostFor(giveaway.username),
        theme: giveaway.theme,
      },
    }),
  );
}

function redirectGiveawayLink(request, response, giveaway, index) {
  if (!planHasFeature(giveaway.guildId, 'hostedPages')) {
    return publicNotFound(response, 'This giveaway page is not available on the current plan.');
  }
  const link = giveaway.links[index];
  if (!link) {
    publicNotFound(response, 'That link no longer exists.');
    return;
  }
  recordGiveawayEvent({
    giveawayId: giveaway.id,
    guildId: giveaway.guildId,
    kind: 'link_click',
    path: request.url,
    referrer: request.headers.referer ?? null,
    linkIndex: index,
  });
  response.writeHead(302, {
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Cache-Control': 'no-store',
    Location: link.url,
  });
  response.end();
}

async function handlePublicGiveawayEntry(request, response, headers, clientIp) {
  try {
    const origin = request.headers.origin;
    if (origin && new URL(origin).host !== request.headers.host) throw new Error('Cross-origin writes are blocked.');
    if (request.headers['x-dashboard'] !== '1') throw new Error('Missing dashboard header.');
    if (!allowRequest(`public-entry:${clientIp}`, 20, 60_000)) throw new Error('Too many entries. Try again in a minute.');
    if (!String(request.headers['content-type'] ?? '').includes('application/json')) throw new Error('Expected JSON.');
    const body = await readBody(request, 30_000);
    const giveaway = getManagedGiveawayByUsername(body.username);
    if (!giveaway) throw new Error('That giveaway no longer exists.');
    if (giveaway.status !== 'active' || giveaway.endsAt <= Date.now()) throw new Error('That giveaway has closed.');
    assertEntrantCapacity(giveaway.guildId, giveaway.id);
    const displayName = String(body.handle ?? '').trim().slice(0, 80);
    const email = String(body.email ?? '').trim().toLowerCase().slice(0, 200);
    const region = giveawayRegion(body.region);
    if (displayName.length < 2) throw new Error('Enter your gamertag or username.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Enter a valid email address.');
    if (!region) throw new Error('Select your region.');
    const result = recordPageEntry({
      giveawayId: giveaway.id,
      guildId: giveaway.guildId,
      displayName,
      email,
      region: region.id,
    });
    if (result.inserted) {
      recordGiveawayEvent({ giveawayId: giveaway.id, guildId: giveaway.guildId, kind: 'entry', path: request.url, referrer: request.headers.referer ?? null });
    }
    response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(
      JSON.stringify({
        ok: true,
        duplicate: !result.inserted,
        entries: result.count,
        entryId: result.entryId,
        accessToken: result.accessToken,
        tickets: result.tickets,
        claims: result.claims || [],
        displayName,
        createdAt: Date.now(),
        region: region.id,
        regionLabel: region.label,
      }),
    );
  } catch (error) {
    response.writeHead(400, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(JSON.stringify({ error: error.message }));
  }
}

async function handlePublicEntryState(request, response, headers, url) {
  try {
    if (request.headers['x-dashboard'] !== '1') throw new Error('Missing dashboard header.');
    const giveaway = getManagedGiveawayByUsername(url.searchParams.get('username'));
    if (!giveaway) throw new Error('That giveaway no longer exists.');
    const state = getPageEntryState({
      giveawayId: giveaway.id,
      entryId: url.searchParams.get('entryId'),
      token: url.searchParams.get('token'),
    });
    if (!state) throw new Error('That entry could not be found.');
    response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(JSON.stringify({ ok: true, ...state }));
  } catch (error) {
    response.writeHead(400, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(JSON.stringify({ error: error.message }));
  }
}

async function handlePublicBonus(request, response, headers, clientIp) {
  try {
    const origin = request.headers.origin;
    if (origin && new URL(origin).host !== request.headers.host) throw new Error('Cross-origin writes are blocked.');
    if (request.headers['x-dashboard'] !== '1') throw new Error('Missing dashboard header.');
    if (!allowRequest(`public-bonus:${clientIp}`, 60, 60_000)) throw new Error('Too many bonus claims. Try again in a minute.');
    if (!String(request.headers['content-type'] ?? '').includes('application/json')) throw new Error('Expected JSON.');
    const body = await readBody(request, 30_000);
    const giveaway = getManagedGiveawayByUsername(body.username);
    if (!giveaway) throw new Error('That giveaway no longer exists.');
    if (giveaway.status !== 'active' || giveaway.endsAt <= Date.now()) throw new Error('That giveaway has closed.');
    const task = publicBonusTask(giveaway, body.taskIndex);
    if (!task) throw new Error('That bonus task is not available.');
    const result = claimPageBonus({
      giveawayId: giveaway.id,
      entryId: body.entryId,
      token: body.token,
      taskIndex: task.index,
      points: task.points,
    });
    if (!result) throw new Error('That entry could not be found. Enter the giveaway again.');
    response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(JSON.stringify({ ok: true, ...result }));
  } catch (error) {
    response.writeHead(400, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(JSON.stringify({ error: error.message }));
  }
}

function adminWriteAllowed(request, session) {
  const origin = request.headers.origin;
  if (origin && new URL(origin).host !== request.headers.host) throw new Error('Cross-origin writes are blocked.');
  if (request.headers['x-dashboard'] !== '1') throw new Error('Missing dashboard header.');
  if (DASHBOARD_PASSWORD && String(request.headers['x-csrf-token'] ?? '') !== session?.csrf) {
    throw new Error('Your session expired or the security token is missing. Reload the dashboard.');
  }
  if (!String(request.headers['content-type'] ?? '').includes('application/json')) throw new Error('Expected JSON.');
}

let smokeCheckPromise = null;
function runSmokeCheck() {
  if (!smokeCheckPromise) {
    smokeCheckPromise = new Promise((resolve) => {
      execFile(
        process.execPath,
        ['--experimental-sqlite', 'scripts/smoke.js'],
        { cwd: process.cwd(), timeout: 180_000, maxBuffer: 8 * 1024 * 1024, env: { ...process.env, DATABASE_PATH: ':memory:' } },
        (error, stdout = '', stderr = '') => {
          const output = String(stdout || stderr || '').trim();
          const summary = output.split('\n').filter(Boolean).slice(-8).join('\n');
          const match = output.match(/(\d+)\/(\d+) smoke checks passed/);
          resolve({
            ok: !error,
            exitCode: error?.code ?? 0,
            passed: match ? Number(match[1]) : null,
            total: match ? Number(match[2]) : null,
            summary,
          });
        },
      );
    }).finally(() => {
      smokeCheckPromise = null;
    });
  }
  return smokeCheckPromise;
}

const server = createServer(async (request, response) => {
  const url = new URL(request.url, `http://${request.headers.host ?? 'localhost'}`);
  const headers = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer' };
  const secure = request.headers['x-forwarded-proto'] === 'https';
  const clientIp = request.socket.remoteAddress ?? 'unknown';
  const hostname = requestHostname(request);
  const subdomain = giveawaySubdomain(hostname);

  // Public giveaway pages can be served either from a username subdomain or
  // from /g/:username while DNS is still being configured.
  if (subdomain && subdomain !== 'www' && subdomain !== 'api') {
    if (request.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
      const giveaway = getManagedGiveawayByUsername(subdomain);
      if (!giveaway) return publicNotFound(response);
      return serveGiveawayPage(request, response, giveaway, { isSubdomain: true });
    }
    if (request.method === 'GET' && (url.pathname === '/links' || url.pathname === '/links/')) {
      const giveaway = getManagedGiveawayByUsername(subdomain);
      if (!giveaway) return publicNotFound(response);
      return serveLinksPage(request, response, giveaway, { isSubdomain: true });
    }
    const subdomainLink = url.pathname.match(/^\/go\/(\d+)\/?$/);
    if (request.method === 'GET' && subdomainLink) {
      const giveaway = getManagedGiveawayByUsername(subdomain);
      if (!giveaway) return publicNotFound(response);
      return redirectGiveawayLink(request, response, giveaway, Number(subdomainLink[1]));
    }
  }

  if (url.pathname.startsWith('/g/')) {
    if (request.method !== 'GET') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    const parts = url.pathname.split('/').filter(Boolean);
    let username = '';
    try {
      username = normalizeUsername(decodeURIComponent(parts[1] || ''));
    } catch {
      return publicNotFound(response, 'Invalid giveaway address.');
    }
    const giveaway = getManagedGiveawayByUsername(username);
    if (!giveaway) return publicNotFound(response);
    if (!parts[2]) return serveGiveawayPage(request, response, giveaway);
    if (parts[2] === 'links' && !parts[3]) return serveLinksPage(request, response, giveaway);
    if (parts[2] === 'go' && parts[3] && /^\d+$/.test(parts[3])) {
      return redirectGiveawayLink(request, response, giveaway, Number(parts[3]));
    }
    return publicNotFound(response, 'That page does not exist.');
  }

  if (url.pathname.startsWith('/brand-assets/')) {
    const assetName = url.pathname.slice('/brand-assets/'.length);
    if (!/^[a-z0-9-]+\.(?:png|svg)$/i.test(assetName)) {
      response.writeHead(404, headers).end('Not found');
      return;
    }
    try {
      const asset = readFileSync(join('data', 'branding', assetName));
      response.writeHead(200, {
        ...headers,
        'Content-Type': assetName.toLowerCase().endsWith('.svg') ? 'image/svg+xml' : 'image/png',
        'Cache-Control': 'public, max-age=3600',
      });
      response.end(asset);
    } catch {
      response.writeHead(404, headers).end('Not found');
    }
    return;
  }

  if (url.pathname === '/api/login' && request.method === 'POST') {
    try {
      if (request.headers['x-dashboard'] !== '1') throw new Error('Missing dashboard header.');
      if (!allowRequest(`login:${clientIp}`, 8, 10 * 60_000)) throw new Error('Too many sign-in attempts. Try again later.');
      const body = await readBody(request);
      const given = Buffer.from(String(body.password ?? ''));
      const expected = Buffer.from(DASHBOARD_PASSWORD);
      const valid = given.length === expected.length && timingSafeEqual(given, expected);
      if (!DASHBOARD_PASSWORD || !valid) throw new Error('Incorrect password.');

      for (const [key, value] of sessions) if (value.expires <= Date.now()) sessions.delete(key);
      const token = randomBytes(32).toString('hex');
      const csrf = randomBytes(24).toString('hex');
      sessions.set(token, { csrf, expires: Date.now() + SESSION_TTL_MS });
      response.writeHead(200, {
        ...headers,
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'no-store',
        'Set-Cookie': sessionCookies({ token, csrf }, secure),
      });
      response.end(JSON.stringify({ ok: true }));
    } catch (error) {
      response.writeHead(401, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  if (url.pathname === '/api/logout' && request.method === 'POST') {
    const token = parseCookies(request.headers.cookie).astro_session;
    if (token) sessions.delete(token);
    response.writeHead(200, { ...headers, 'Set-Cookie': expireCookies(secure), 'Content-Type': 'application/json' });
    response.end(JSON.stringify({ ok: true }));
    return;
  }

  if (url.pathname === '/api/landing-stats') {
    if (request.method !== 'GET') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    const stats = await landingStats();
    response.writeHead(200, {
      ...headers,
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'public, max-age=300',
    });
    response.end(JSON.stringify(stats));
    return;
  }

  const session = currentSession(request);
  const authenticated = !DASHBOARD_PASSWORD || Boolean(session);

  if (
    DASHBOARD_PASSWORD &&
    !authenticated &&
    url.pathname.startsWith('/api/') &&
    !url.pathname.startsWith('/api/giveaway-portal')
  ) {
    response.writeHead(401, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(JSON.stringify({ error: 'Sign in required.' }));
    return;
  }

  if (url.pathname === '/api/branding') {
    if (request.method !== 'GET') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(JSON.stringify({ ok: true, ...getBranding() }));
    return;
  }

  if (url.pathname === '/api/dev/smoke') {
    if (request.method !== 'POST') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    try {
      adminWriteAllowed(request, session);
      await readBody(request);
      const result = await runSmokeCheck();
      response.writeHead(result.ok ? 200 : 422, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify(result));
    } catch (error) {
      response.writeHead(400, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  if (url.pathname === '/api/white-label/assets/export') {
    if (request.method !== 'GET') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    try {
      let names = [];
      try {
        names = readdirSync(join('data', 'branding')).filter((name) => /^[a-z0-9-]+\.(?:png|svg)$/i.test(name)).sort();
      } catch {
        names = [];
      }
      const branding = getBranding();
      const assets = names.map((name) => {
        const stats = statSync(join('data', 'branding', name));
        return {
          name,
          kind: name.startsWith('wordmark-') ? 'wordmark' : 'favicon',
          url: `/brand-assets/${name}`,
          bytes: stats.size,
          modifiedAt: stats.mtime.toISOString(),
        };
      });
      const manifest = JSON.stringify(
        {
          exportedAt: new Date().toISOString(),
          branding,
          assets,
        },
        null,
        2,
      );
      const zip = createZip([
        ...names.map((name) => ({ name: `assets/${name}`, data: readFileSync(join('data', 'branding', name)) })),
        { name: 'manifest.json', data: manifest },
      ]);
      const filename = `astrobot-brand-assets-${new Date().toISOString().slice(0, 10)}.zip`;
      response.writeHead(200, {
        ...headers,
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length': zip.length,
        'Cache-Control': 'no-store',
      });
      response.end(zip);
    } catch (error) {
      response.writeHead(500, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  if (url.pathname === '/api/white-label/assets') {
    if (request.method === 'GET') {
      const used = new Set([getBranding().faviconUrl, getBranding().wordmarkUrl].filter(Boolean));
      let names = [];
      try {
        names = readdirSync(join('data', 'branding')).filter((name) => /^[a-z0-9-]+\.(?:png|svg)$/i.test(name));
      } catch {
        names = [];
      }
      const assets = names
        .map((name) => {
          const stats = statSync(join('data', 'branding', name));
          return {
            name,
            url: `/brand-assets/${name}`,
            kind: name.startsWith('wordmark-') ? 'wordmark' : 'favicon',
            bytes: stats.size,
            modifiedAt: stats.mtime.toISOString(),
            inUse: used.has(`/brand-assets/${name}`),
          };
        })
        .sort((a, b) => b.modifiedAt.localeCompare(a.modifiedAt));
      response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify({ ok: true, assets }));
      return;
    }
    if (request.method !== 'POST') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    try {
      adminWriteAllowed(request, session);
      const body = await readBody(request, 3_500_000);
      const kind = body.kind === 'wordmark' ? 'wordmark' : 'favicon';
      const match = String(body.dataUrl ?? '').match(/^data:image\/(png|svg\+xml);base64,([a-z0-9+/=\s]+)$/i);
      if (!match) throw new Error('Upload a transparent PNG or SVG image.');
      const buffer = Buffer.from(match[2], 'base64');
      if (!buffer.length || buffer.length > 2_000_000) throw new Error('Image must be under 2 MB.');
      const extension = match[1].toLowerCase() === 'png' ? 'png' : 'svg';
      if (extension === 'png') {
        if (buffer.subarray(0, 8).toString('hex') !== '89504e470d0a1a0a' || buffer[25] !== 6 && buffer[25] !== 4) {
          throw new Error('PNG assets must have a transparent background.');
        }
      } else {
        const svg = buffer.toString('utf8');
        if (!/<svg[\s>]/i.test(svg) || /<script[\s>]|on\w+\s*=/i.test(svg)) {
          throw new Error('That SVG is not safe to use as a brand asset.');
        }
      }
      mkdirSync(join('data', 'branding'), { recursive: true });
      const filename = `${kind}-${Date.now()}-${randomBytes(4).toString('hex')}.${extension}`;
      writeFileSync(join('data', 'branding', filename), buffer);
      response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify({ ok: true, url: `/brand-assets/${filename}`, kind, bytes: buffer.length }));
    } catch (error) {
      response.writeHead(400, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  if (url.pathname === '/api/white-label/assets/delete') {
    if (request.method !== 'POST') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    try {
      adminWriteAllowed(request, session);
      const body = await readBody(request);
      const name = String(body.name ?? '');
      if (!/^[a-z0-9-]+\.(?:png|svg)$/i.test(name)) throw new Error('Invalid asset name.');
      const url = `/brand-assets/${name}`;
      const branding = getBranding();
      if (branding.faviconUrl === url || branding.wordmarkUrl === url) {
        throw new Error('This asset is in use. Choose another asset and save branding before deleting it.');
      }
      unlinkSync(join('data', 'branding', name));
      response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify({ ok: true }));
    } catch (error) {
      response.writeHead(400, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  if (url.pathname === '/api/white-label') {
    if (request.method !== 'POST') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    try {
      adminWriteAllowed(request, session);
      const body = await readBody(request);
      const current = getBranding();
      const name = String(body.name ?? '').trim();
      if (name.length < 2 || name.length > 40) throw new Error('Brand name must be 2–40 characters.');
      const asset = (label, value) => {
        const text = String(value ?? '').trim();
        if (text && !/^(?:https?:\/\/|\/|data:image\/)/i.test(text)) {
          throw new Error(`${label} must be a public URL or a path beginning with /.`);
        }
        return text.slice(0, 500);
      };
      const colors = { ...current.colors, ...(body.colors ?? {}) };
      for (const key of ['brand', 'accent', 'background', 'text']) {
        if (!/^#[0-9a-f]{6}$/i.test(String(colors[key] ?? ''))) {
          throw new Error('Colours must be six-digit hex values such as #e62127.');
        }
      }
      const patch = {
        name,
        faviconUrl: asset('Favicon', body.faviconUrl),
        wordmarkUrl: asset('Wordmark', body.wordmarkUrl),
        colors,
      };
      const backup = createDatabaseBackup('white-label');
      const branding = saveBranding(patch, 'dashboard');
      response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify({ ok: true, branding, backup: { name: backup.name, bytes: backup.bytes } }));
    } catch (error) {
      response.writeHead(400, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  if (url.pathname === '/api/giveaway-portal/public/enter') {
    if (request.method !== 'POST') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    await handlePublicGiveawayEntry(request, response, headers, clientIp);
    return;
  }

  if (url.pathname === '/api/giveaway-portal/public/entry') {
    if (request.method !== 'GET') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    await handlePublicEntryState(request, response, headers, url);
    return;
  }

  if (url.pathname === '/api/giveaway-portal/public/bonus') {
    if (request.method !== 'POST') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    await handlePublicBonus(request, response, headers, clientIp);
    return;
  }

  if (url.pathname === '/api/giveaway-portal') {
    const guildId = String(url.searchParams.get('guild') ?? '').trim();
    if (guildId && !planHasFeature(guildId, 'hostedPages')) {
      response.writeHead(403, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify({ error: 'The branded giveaway portal is a Pro feature.' }));
      return;
    }
    const portalSettings = guildId ? readSettings(guildId).giveawayPortal : null;
    if (portalSettings && portalSettings.enabled === false) {
      response.writeHead(404, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: 'This giveaway portal is switched off.' }));
      return;
    }
    let config = null;
    if (guildId) {
      const row = getPortalConfig(guildId);
      if (row) {
        try {
          config = JSON.parse(row.config);
        } catch {
          config = null;
        }
      }
    }

    // The public page renders the live giveaway and the checkout link from the
    // guild's bot configuration, so entries and results stay in one place.
    const active = guildId
      ? listGiveaways(guildId, 25).find((entry) => entry.status === 'active' && Number(entry.ends_at) > Date.now()) ?? null
      : null;
    const giveaway = active
      ? {
          id: active.id,
          prize: active.prize,
          endsAt: Number(active.ends_at),
          entries: listGiveawayEntries(active.id).length,
          winners: Number(active.winners) || 1,
        }
      : null;
    const checkoutUrl = guildId ? readSettings(guildId).checkout?.proUrl ?? '' : '';

    response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(JSON.stringify({ ...normalizePortalConfig(config), giveaway, checkoutUrl }));
    return;
  }

  // Exchanges a personal /giveaway-entry link for a recorded giveaway entry.
  if (url.pathname === '/api/giveaway-portal/enter') {
    if (request.method !== 'POST') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    try {
      const origin = request.headers.origin;
      if (origin && new URL(origin).host !== request.headers.host) throw new Error('Cross-origin writes are blocked.');
      if (request.headers['x-dashboard'] !== '1') throw new Error('Missing dashboard header.');
      if (!allowRequest(`portal-enter:${clientIp}`, 12, 60_000)) throw new Error('Too many attempts. Try again in a minute.');
      const body = await readBody(request);
      const token = validateGiveawayEntryToken(body.token);
      if (!token) throw new Error('That entry link is invalid or expired. Run /giveaway-entry in Discord again.');
      if (token.used_at) throw new Error('That entry link has already been used. Run /giveaway-entry in Discord for a fresh one.');
      const portalSettings = readSettings(token.guild_id).giveawayPortal;
      if (portalSettings && portalSettings.enabled === false) throw new Error('This giveaway portal is switched off.');

      const giveaway = getGiveaway(token.giveaway_id);
      if (!giveaway || giveaway.guild_id !== token.guild_id) throw new Error('That giveaway no longer exists.');
      if (giveaway.status !== 'active' || Number(giveaway.ends_at) <= Date.now()) throw new Error('That giveaway has closed.');

      const entered = addGiveawayEntry(giveaway.id, giveaway.guild_id, token.user_id);
      markGiveawayEntryTokenUsed(body.token);
      const entries = listGiveawayEntries(giveaway.id).length;
      response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify({ ok: true, entered, entries, prize: giveaway.prize, endsAt: Number(giveaway.ends_at) }));
    } catch (error) {
      response.writeHead(400, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  // Returns the tasks this member already claimed, plus their live ticket count.
  if (url.pathname === '/api/giveaway-portal/bonus') {
    const token = validateGiveawayEntryToken(url.searchParams.get('token'));
    if (!token) {
      response.writeHead(401, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify({ error: 'That entry link is invalid or expired.' }));
      return;
    }
    const claimed = listGiveawayBonuses(token.giveaway_id, token.user_id).map((entry) => entry.task_index);
    response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(
      JSON.stringify({
        tickets: giveawayTickets(token.giveaway_id, token.user_id),
        claimed,
        entered: Boolean(token.used_at),
      }),
    );
    return;
  }

  // Awards bonus tickets for one portal task. The task points come from the
  // saved builder config, never from the browser.
  if (url.pathname === '/api/giveaway-portal/task') {
    if (request.method !== 'POST') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    try {
      const origin = request.headers.origin;
      if (origin && new URL(origin).host !== request.headers.host) throw new Error('Cross-origin writes are blocked.');
      if (request.headers['x-dashboard'] !== '1') throw new Error('Missing dashboard header.');
      if (!allowRequest(`portal-task:${clientIp}`, 40, 60_000)) throw new Error('Too many task claims. Try again in a minute.');
      const body = await readBody(request);
      const token = validateGiveawayEntryToken(body.token);
      if (!token) throw new Error('That entry link is invalid or expired. Run /giveaway-entry in Discord again.');
      if (readSettings(token.guild_id).giveawayPortal?.enabled === false) throw new Error('This giveaway portal is switched off.');

      const giveaway = getGiveaway(token.giveaway_id);
      if (!giveaway || giveaway.guild_id !== token.guild_id) throw new Error('That giveaway no longer exists.');
      if (giveaway.status !== 'active' || Number(giveaway.ends_at) <= Date.now()) throw new Error('That giveaway has closed.');

      const index = Math.trunc(Number(body.taskIndex));
      const row = getPortalConfig(token.guild_id);
      const config = normalizePortalConfig(row ? JSON.parse(row.config) : null);
      if (!Number.isInteger(index) || index <= 0 || index >= config.tasks.length) throw new Error('That bonus task does not exist.');
      const task = config.tasks[index];
      if (!Number(task.points) || Number(task.points) <= 0) throw new Error('That task is not worth bonus tickets.');

      const awarded = addGiveawayBonus({
        giveawayId: giveaway.id,
        guildId: giveaway.guild_id,
        userId: token.user_id,
        taskIndex: index,
        points: task.points,
      });
      response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(
        JSON.stringify({
          ok: true,
          awarded,
          points: Number(task.points),
          tickets: giveawayTickets(giveaway.id, token.user_id),
          entries: listGiveawayEntries(giveaway.id).length,
        }),
      );
    } catch (error) {
      response.writeHead(400, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  if (url.pathname === '/api/giveaway-portal/admin') {
    const guildId = String(url.searchParams.get('guild') ?? '').trim();
    const token = String(url.searchParams.get('token') ?? '').trim();
    const session = validatePortalToken(token, guildId);
    if (!session) {
      response.writeHead(401, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: 'Builder access expired. Open /giveaway-portal in Discord again.' }));
      return;
    }
    const row = getPortalConfig(guildId);
    let config = null;
    if (row) {
      try {
        config = JSON.parse(row.config);
      } catch {
        config = null;
      }
    }
    response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(JSON.stringify(normalizePortalConfig(config)));
    return;
  }

  if (url.pathname === '/api/giveaway-portal/save') {
    if (request.method !== 'POST') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    try {
      const origin = request.headers.origin;
      if (origin && new URL(origin).host !== request.headers.host) throw new Error('Cross-origin writes are blocked.');
      if (request.headers['x-dashboard'] !== '1') throw new Error('Missing dashboard header.');
      if (!String(request.headers['content-type'] ?? '').includes('application/json')) throw new Error('Expected JSON.');
      const body = await readBody(request);
      const guildId = String(body.guildId ?? '').trim();
      const token = String(body.token ?? '').trim();
      if (!validatePortalToken(token, guildId)) throw new Error('Builder access expired. Open /giveaway-portal in Discord again.');
      if (!planHasFeature(guildId, 'hostedPages')) throw new Error('The branded giveaway portal is a Pro feature.');
      const config = normalizePortalConfig(body.config);
      savePortalConfig(guildId, config, 'dashboard');
      response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify({ ok: true, config }));
    } catch (error) {
      response.writeHead(400, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  if (url.pathname === '/api/giveaway-admin') {
    if (request.method !== 'GET') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    const guilds = all('SELECT id, name FROM guilds ORDER BY joined_at ASC');
    const guildId = String(url.searchParams.get('guild') ?? '').trim() || guilds[0]?.id || '';
    const plan = planSnapshot(guildId);
    const serialized = (guildId ? listManagedGiveaways(guildId) : []).map(serializeManagedGiveaway);
    response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(
      JSON.stringify({
        guilds,
        guildId,
        plan,
        rootDomain: GIVEAWAY_ROOT_DOMAIN,
        protocol: GIVEAWAY_PUBLIC_PROTOCOL,
        giveaways: serialized,
        alerts: serialized
          .filter(
            (giveaway) =>
              giveaway.status === 'active' &&
              giveaway.domainHealth?.status === 'fail' &&
              !giveaway.domainAlertAcknowledgedAt,
          )
          .map((giveaway) => ({
            id: giveaway.id,
            username: giveaway.username,
            host: giveaway.domainHealth.host,
            checkedAt: giveaway.domainHealth.checkedAt,
          })),
      }),
    );
    return;
  }

  const giveawayAnalyticsMatch = url.pathname.match(/^\/api\/giveaway-admin\/giveaways\/([^/]+)\/analytics$/);
  if (giveawayAnalyticsMatch) {
    if (request.method !== 'GET') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    const guildId = String(url.searchParams.get('guild') ?? '').trim();
    const giveaway = guildId ? getManagedGiveaway(decodeURIComponent(giveawayAnalyticsMatch[1]), guildId) : null;
    if (!giveaway) {
      response.writeHead(404, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: 'Giveaway not found.' }));
      return;
    }
    const analytics = giveawayAnalytics(giveaway.id);
    analytics.taskAnalytics = giveaway.tasks.map((task, index) => {
      const claims = Number(analytics.publicTaskClaims?.[String(index + 1)]) || 0;
      return { index: index + 1, title: task.title, points: Number(task.points) || 0, claims, tickets: claims * (Number(task.points) || 0) };
    });
    response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(JSON.stringify({ giveaway: serializeManagedGiveaway(giveaway), analytics }));
    return;
  }

  const giveawayTaskExportMatch = url.pathname.match(/^\/api\/giveaway-admin\/giveaways\/([^/]+)\/task-analytics\.csv$/);
  if (giveawayTaskExportMatch) {
    if (request.method !== 'GET') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    const guildId = String(url.searchParams.get('guild') ?? '').trim();
    const giveaway = guildId ? getManagedGiveaway(decodeURIComponent(giveawayTaskExportMatch[1]), guildId) : null;
    if (!giveaway) {
      response.writeHead(404, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: 'Giveaway not found.' }));
      return;
    }
    if (!planHasFeature(guildId, 'csvExports')) {
      response.writeHead(403, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: 'CSV exports are a Pro feature. Upgrade from /checkout.' }));
      return;
    }
    const analytics = giveawayAnalytics(giveaway.id);
    const rows = giveaway.tasks.map((task, index) => {
      const claims = Number(analytics.publicTaskClaims?.[String(index + 1)]) || 0;
      return [index + 1, task.title, task.points || 0, claims, claims * (task.points || 0)];
    });
    const totalClaims = rows.reduce((sum, row) => sum + row[3], 0);
    const totalTickets = rows.reduce((sum, row) => sum + row[4], 0);
    const csv = [['Task index', 'Task', 'Points', 'Claims', 'Tickets'], ...rows, ['', 'Total', '', totalClaims, totalTickets]]
      .map((row) => row.map(csvCell).join(','))
      .join('\r\n');
    response.writeHead(200, {
      ...headers,
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="${giveaway.username}-task-analytics.csv"`,
      'Cache-Control': 'no-store',
    });
    response.end(csv);
    return;
  }

  const giveawayExportMatch = url.pathname.match(/^\/api\/giveaway-admin\/giveaways\/([^/]+)\/entries\.csv$/);
  if (giveawayExportMatch) {
    if (request.method !== 'GET') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    const guildId = String(url.searchParams.get('guild') ?? '').trim();
    const giveaway = guildId ? getManagedGiveaway(decodeURIComponent(giveawayExportMatch[1]), guildId) : null;
    if (!giveaway) {
      response.writeHead(404, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: 'Giveaway not found.' }));
      return;
    }
    if (!planHasFeature(guildId, 'csvExports')) {
      response.writeHead(403, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: 'CSV exports are a Pro feature. Upgrade from /checkout.' }));
      return;
    }
    const entries = [
      ...listPageEntries(giveaway.id, guildId).map((entry) => ({ ...entry, source: 'public' })),
      ...listDiscordEntries(giveaway.id, guildId),
    ].sort((a, b) => b.createdAt - a.createdAt);
    const taskLabel = (entry, index) =>
      entry.source === 'public'
        ? giveaway.tasks[index - 1]?.title ?? `Task ${index}`
        : DEFAULT_PORTAL_CONFIG.tasks[index]?.title ?? `Task ${index}`;
    const rows = entries.map((entry) => {
      const tasks = entry.taskIndexes.map((index) => taskLabel(entry, index)).join('; ');
      return [
        entry.source === 'public' ? 'Public' : 'Discord',
        entry.displayName,
        entry.email,
        entry.region ? giveawayRegionLabel(entry.region) : '',
        entry.tickets,
        tasks,
        new Date(entry.createdAt).toISOString(),
      ];
    });
    const csv = [['Source', 'Gamertag / user ID', 'Email', 'Region', 'Tickets', 'Bonus tasks', 'Entered at'], ...rows]
      .map((row) => row.map(csvCell).join(','))
      .join('\r\n');
    response.writeHead(200, {
      ...headers,
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="${giveaway.username}-entries.csv"`,
      'Cache-Control': 'no-store',
    });
    response.end(csv);
    return;
  }

  const giveawayDomainMatch = url.pathname.match(/^\/api\/giveaway-admin\/giveaways\/([^/]+)\/domain-check$/);
  if (giveawayDomainMatch) {
    if (request.method !== 'GET') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    const guildId = String(url.searchParams.get('guild') ?? '').trim();
    const giveaway = guildId ? getManagedGiveaway(decodeURIComponent(giveawayDomainMatch[1]), guildId) : null;
    if (!giveaway) {
      response.writeHead(404, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: 'Giveaway not found.' }));
      return;
    }
    try {
      const result = await checkGiveawayDomain(giveaway);
      await persistDomainResult(giveaway, result);
      response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify({ ok: true, giveaway: serializeManagedGiveaway(giveaway), ...result }));
    } catch (error) {
      response.writeHead(500, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  const giveawayDomainTestMatch = url.pathname.match(/^\/api\/giveaway-admin\/giveaways\/([^/]+)\/domain-alert\/test$/);
  if (giveawayDomainTestMatch) {
    if (request.method !== 'POST') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    let giveaway = null;
    let guildId = '';
    try {
      adminWriteAllowed(request, session);
      const body = await readBody(request);
      guildId = String(body.guildId ?? '').trim();
      giveaway = guildId ? getManagedGiveaway(decodeURIComponent(giveawayDomainTestMatch[1]), guildId) : null;
      if (!giveaway) throw new Error('Giveaway not found.');
      if (!String(process.env.GIVEAWAY_ALERT_WEBHOOK_URL ?? '').trim()) {
        recordDomainWebhookTest({ giveawayId: giveaway.id, guildId, ok: false, detail: 'No webhook configured.' });
        throw new Error('Set GIVEAWAY_ALERT_WEBHOOK_URL to test Discord alerts.');
      }
      const result = {
        host: publicHostFor(giveaway.username),
        checks: [{ id: 'webhook', label: 'Webhook test', status: 'fail', detail: 'Manual test from the giveaway manager.' }],
        checkedAt: new Date().toISOString(),
      };
      const sent = await sendDomainAlert(giveaway, result, 'fail', { status: 'ok' });
      if (!sent) {
        recordDomainWebhookTest({ giveawayId: giveaway.id, guildId, ok: false, detail: 'Discord did not accept the test message.' });
        throw new Error('The Discord webhook did not accept the test message.');
      }
      recordDomainWebhookTest({ giveawayId: giveaway.id, guildId, ok: true, detail: 'Discord accepted the test message.' });
      response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify({ ok: true, sent: true, giveaway: serializeManagedGiveaway(giveaway) }));
    } catch (error) {
      if (giveaway && !/Discord did not accept|No webhook configured/.test(error.message)) {
        recordDomainWebhookTest({ giveawayId: giveaway.id, guildId, ok: false, detail: error.message });
      }
      response.writeHead(400, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  const giveawayDomainAckMatch = url.pathname.match(/^\/api\/giveaway-admin\/giveaways\/([^/]+)\/domain-alert\/ack$/);
  if (giveawayDomainAckMatch) {
    if (request.method !== 'POST') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    try {
      adminWriteAllowed(request, session);
      const body = await readBody(request);
      const guildId = String(body.guildId ?? '').trim();
      const giveaway = guildId ? getManagedGiveaway(decodeURIComponent(giveawayDomainAckMatch[1]), guildId) : null;
      if (!giveaway) throw new Error('Giveaway not found.');
      acknowledgeDomainAlert({ giveawayId: giveaway.id, guildId, actorId: 'dashboard' });
      response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify({ ok: true, giveaway: serializeManagedGiveaway(giveaway) }));
    } catch (error) {
      response.writeHead(400, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  const giveawayDomainHistoryMatch = url.pathname.match(/^\/api\/giveaway-admin\/giveaways\/([^/]+)\/domain-history$/);
  if (giveawayDomainHistoryMatch) {
    if (request.method !== 'GET') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    const guildId = String(url.searchParams.get('guild') ?? '').trim();
    const giveaway = guildId ? getManagedGiveaway(decodeURIComponent(giveawayDomainHistoryMatch[1]), guildId) : null;
    if (!giveaway) {
      response.writeHead(404, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: 'Giveaway not found.' }));
      return;
    }
    const limit = Number(url.searchParams.get('limit') || 25);
    response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(JSON.stringify({ ok: true, history: listDomainChecks(giveaway.id, guildId, limit) }));
    return;
  }

  if (url.pathname === '/api/giveaway-admin/giveaways') {
    if (request.method !== 'POST') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    try {
      adminWriteAllowed(request, session);
      const body = await readBody(request);
      const guildId = String(body.guildId ?? '').trim();
      if (!guildId) throw new Error('Choose a server first.');
      const username = normalizeUsername(body.username);
      const usernameIssue = usernameError(username);
      if (usernameIssue) throw new Error(usernameIssue);
      if (usernameTaken(username)) throw new Error('That username is already taken.');
      const prize = String(body.prize ?? '').trim().slice(0, 160);
      if (!prize) throw new Error('Give the giveaway a prize or title.');
      const endsAt = new Date(body.endsAt).getTime();
      if (!Number.isFinite(endsAt)) throw new Error('Choose a valid end date and time.');
      assertPlanLimit(guildId, 'hostedGiveawayPages', countActiveHostedGiveaways(guildId), 'Hosted giveaway pages');
      const giveaway = createManagedGiveaway({
        guildId,
        username,
        prize,
        description: body.description,
        winners: body.winners,
        endsAt,
        status: body.status,
        links: normalizeLinkTree(body.links),
        theme: body.theme,
        tasks: body.tasks,
        faq: body.faq,
        faqEnabled: body.faqEnabled,
      });
      response.writeHead(201, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ ok: true, giveaway: serializeManagedGiveaway(giveaway) }));
    } catch (error) {
      response.writeHead(400, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  const giveawayAdminMatch = url.pathname.match(/^\/api\/giveaway-admin\/giveaways\/([^/]+)$/);
  if (giveawayAdminMatch) {
    const id = decodeURIComponent(giveawayAdminMatch[1]);
    try {
      adminWriteAllowed(request, session);
      const body = await readBody(request);
      const guildId = String(body.guildId ?? '').trim();
      if (!guildId) throw new Error('Choose a server first.');
      if (request.method === 'DELETE') {
        if (!deleteManagedGiveaway(id, guildId)) {
          response.writeHead(404, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
          response.end(JSON.stringify({ error: 'Giveaway not found.' }));
          return;
        }
        response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
        response.end(JSON.stringify({ ok: true }));
        return;
      }
      if (request.method !== 'PATCH') {
        response.writeHead(405, headers).end('Method not allowed');
        return;
      }
      const current = getManagedGiveaway(id, guildId);
      if (!current) throw new Error('Giveaway not found.');
      const nextStatus = body.status === undefined ? current.status : body.status;
      if (nextStatus === 'active' && current.status !== 'active') {
        assertPlanLimit(guildId, 'hostedGiveawayPages', countActiveHostedGiveaways(guildId), 'Hosted giveaway pages');
      }
      const username = body.username === undefined ? current.username : normalizeUsername(body.username);
      const usernameIssue = usernameError(username);
      if (usernameIssue) throw new Error(usernameIssue);
      if (usernameTaken(username, id)) throw new Error('That username is already taken.');
      if (body.prize !== undefined && !String(body.prize).trim()) throw new Error('Give the giveaway a prize or title.');
      const endsAt = body.endsAt === undefined ? current.endsAt : new Date(body.endsAt).getTime();
      if (!Number.isFinite(endsAt)) throw new Error('Choose a valid end date and time.');
      const giveaway = updateManagedGiveaway(id, guildId, {
        username,
        prize: body.prize,
        description: body.description,
        winners: body.winners,
        endsAt,
        status: body.status,
        links: body.links === undefined ? undefined : normalizeLinkTree(body.links),
        theme: body.theme,
        tasks: body.tasks,
        faq: body.faq,
        faqEnabled: body.faqEnabled,
      });
      response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ ok: true, giveaway: serializeManagedGiveaway(giveaway) }));
    } catch (error) {
      const status = error.message === 'Giveaway not found.' ? 404 : 400;
      response.writeHead(status, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  if (url.pathname === '/api/summary') {
    try {
      response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(JSON.stringify(buildSummary(url.searchParams.get('guild'))));
    } catch (error) {
      response.writeHead(500, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  if (url.pathname === '/api/backup') {
    try {
      const result = ACTIONS['owner.backup'](null, {});
      response.writeHead(200, {
        ...headers,
        'Content-Type': 'application/x-sqlite3',
        'Content-Disposition': `attachment; filename="${result.name}"`,
      });
      response.end(readFileSync(join('data', 'backups', result.name)));
    } catch (error) {
      response.writeHead(500, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  if (url.pathname === '/api/action') {
    if (request.method !== 'POST') {
      response.writeHead(405, headers).end('Method not allowed');
      return;
    }
    const origin = request.headers.origin;
    try {
      if (origin && new URL(origin).host !== request.headers.host) throw new Error('Cross-origin writes are blocked.');
      if (request.headers['x-dashboard'] !== '1') throw new Error('Missing dashboard header.');
      if (DASHBOARD_PASSWORD && String(request.headers['x-csrf-token'] ?? '') !== session.csrf) {
        throw new Error('Your session expired or the security token is missing. Reload the dashboard.');
      }
      if (!String(request.headers['content-type'] ?? '').includes('application/json')) throw new Error('Expected JSON.');

      const body = await readBody(request);
      if (!body.guildId) throw new Error('Missing guild.');
      const handler = ACTIONS[body.action];
      if (!handler) throw new Error(`Unknown action "${body.action}".`);
      const result = await handler(String(body.guildId), body);
      response.writeHead(200, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ ok: true, ...(result && typeof result === 'object' ? result : {}) }));
    } catch (error) {
      response.writeHead(400, { ...headers, 'Content-Type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ error: error.message }));
    }
    return;
  }

  // Clan badge artwork lives outside the public directory, so stream it from
  // the row rather than exposing an arbitrary filesystem path.
  if (url.pathname.startsWith('/badge-art/')) {
    const id = decodeURIComponent(url.pathname.slice('/badge-art/'.length)).replace(/\.png$/i, '');
    const row = /^[A-Za-z0-9_-]{1,64}$/.test(id) ? get('SELECT file FROM clan_badges WHERE id = ?', id) : null;
    if (row?.file) {
      try {
        const file = readFileSync(row.file);
        response.writeHead(200, { ...headers, 'Content-Type': MIME[extname(row.file)] ?? 'image/png', 'Cache-Control': 'no-store' });
        response.end(file);
        return;
      } catch {
        response.writeHead(404, headers).end('Not found');
        return;
      }
    }
  }

  if (
    DASHBOARD_PASSWORD &&
    !authenticated &&
    url.pathname !== '/login' &&
    url.pathname !== '/login/' &&
    !url.pathname.startsWith('/giveaway-portal')
  ) {
    response.writeHead(302, { ...headers, Location: '/login' });
    response.end();
    return;
  }

  const name =
    url.pathname === '/login' || url.pathname === '/login/'
      ? 'login.html'
      : url.pathname === '/'
        ? 'index.html'
        : url.pathname === '/landing' || url.pathname === '/landing/'
          ? 'landing.html'
          : url.pathname === '/white-label' || url.pathname === '/white-label/'
            ? 'white-label.html'
            : url.pathname === '/giveaway-portal' || url.pathname === '/giveaway-portal/'
          ? 'giveaway-portal/index.html'
          : url.pathname === '/giveaway-portal/admin' || url.pathname === '/giveaway-portal/admin/'
            ? 'giveaway-portal/admin.html'
            : url.pathname.replace(/^\/+/, '');
  if (name.includes('..')) {
    response.writeHead(400, headers).end('Bad request');
    return;
  }

  try {
    const file = readFileSync(join(PUBLIC, name));
    response.writeHead(200, { ...headers, 'Content-Type': MIME[extname(name)] ?? 'application/octet-stream', 'Cache-Control': 'no-store' });
    response.end(file);
  } catch {
    response.writeHead(404, { ...headers, 'Content-Type': 'text/plain' });
    response.end('Not found');
  }
});

server.listen(PORT, HOST, () => {
  console.log(`AstroBot dashboard on http://${HOST}:${PORT}`);
});

const DOMAIN_MONITOR_INTERVAL = Math.max(
  60_000,
  Number(process.env.GIVEAWAY_DOMAIN_MONITOR_MS) || 15 * 60_000,
);
const domainMonitorStart = setTimeout(() => {
  monitorGiveawayDomains();
}, 10_000);
const domainMonitorTimer = setInterval(() => {
  monitorGiveawayDomains();
}, DOMAIN_MONITOR_INTERVAL);
domainMonitorStart.unref?.();
domainMonitorTimer.unref?.();
