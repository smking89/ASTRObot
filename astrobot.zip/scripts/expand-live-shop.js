import { initDatabase, closeDatabase } from '../src/db/index.js';
import { ensureGuild, getGuildSettings } from '../src/db/repositories/guilds.js';
import { applyQuickSetup } from '../src/services/shop-quick-setup.js';

/**
 * Adds every catalogued Rust item to the guild's shop in one pass. Existing
 * products (and their prices, stock and role gates) are left untouched; only
 * shortnames that are not already listed are appended.
 */

const guildId = process.env.GUILD_ID ?? '1558725505736245299';

initDatabase();
ensureGuild({ id: guildId, name: 'AstroBot guild' });

const settings = getGuildSettings(guildId);
const before = settings.shop.products?.length ?? 0;
const state = {
  tier: 'mid',
  currency: settings.economy?.currency ?? 'coins',
  roleId: null,
  tier3: false,
  explosives: false,
};

const result = applyQuickSetup({ guildId, state });
console.log(
  JSON.stringify(
    {
      guildId,
      before,
      added: result.added,
      skipped: result.skipped,
      total: result.total,
      categories: new Set((result.settings.shop.products ?? []).map((product) => product.category)).size,
    },
    null,
    2,
  ),
);

closeDatabase();
