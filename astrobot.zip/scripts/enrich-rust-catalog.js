import { readFileSync, writeFileSync } from 'node:fs';

const PATH = 'src/data/rust-items.json';
const data = JSON.parse(readFileSync(PATH, 'utf8'));

// Classify from the shortname first (structural prefixes such as `ammo.` or
// `rifle.` are reliable), then from the display name for the rest.
const SHORTNAME_RULES = [
  ['Ammo', /^(ammo\.|arrow\.|arrow$|bolt\.|grenade\.smoke|flare\.|ammo_)/],
  ['Explosives', /^(explosive\.|explosives\.|grenade\.|rocket\.|beancan\.|satchel|landmine|mine\.|c4|dynamite|mortar|catapult)/],
  ['Attachments', /^(attachment\.|weapon\.mod|modifier\.|muzzle|scope|sight|holosight|silencer|laser|flashlight|barrel\.|grip|magazine|extended)/],
  ['Vehicles', /^(minicopter|scraptransporthelicopter|attackhelicopter|modularcar|chassis|vehicle\.|rowboat|rhib|kayak|tugboat|submarine|locomotive|train|snowmobile|motorbike|horse|saddle|balloon)/],
  ['Weapons', /^(rifle\.|smg\.|pistol\.|shotgun\.|lmg\.|minigun|bow\.|crossbow|spear\.|knife\.|machete|rock|flamethrower|multiple\.|launcher|sickle|paddle|torch\.|weapon\.)/],
  ['Tools', /^(hammer|pickaxe|axe\.|hatchet|shovel|sickle|pitchfork|hoe|bucket|hose|wrench|planner|chainsaw|jackhammer|salvage|mining|fishing|binoculars|compass|map|note|blueprint|tool\.|torch$)/],
  ['Armor', /(facemask|plate\.torso|heavy\.plate|riot|coffeecan|wood\.armor|roadsign|hazmat|bone\.armor|helmet|armor)/],
  ['Clothing', /(shirt|pants|hoodie|boots|shoes|gloves|jacket|bandana|hat\.|cap$|mask|glasses|kilt|suit|attire|poncho|socks|underwear|burlap|leather\.|fins|diving)/],
  ['Medical', /(syringe|bandage|medkit|medical|pills|antirad|antidote|antiserum|injector|blood|health)/],
  ['Building', /(foundation|wall|floor|roof|stairs|frame|door|window|gate|barricade|building|shutter|embrasure|hatch|ladder|steps|ramp|twig|garage|high\.external)/],
  ['Deployables', /(turret|trap|spike|barbeque|bbq|furnace|refinery|workbench|repair|bench|campfire|box\.|locker|sleeping\.bag|bed$|shelf|table|chair|rug|sign|purifier|pump|solar|wind|battery|generator|switch|sam\.site|elevator|lift|storage|mailbox|lantern|light|hobo|barrel|composter|mixing|stash|vending|fridge|fireplace|cupboard)/],
  ['Resources', /^(wood|stones|metal\.fragments|metal\.refined|sulfur|charcoal|cloth|leather|scrap|lowgradefuel|gunpowder|bone\.fragments|hq\.metal|crude|fat\.|water|salt)/],
  ['Components', /(gear|spring|pipe|blade|tarp|rope|fuse|targeting|computer|cctv|camera|rf\.|transmitter|receiver|timer|igniter|spark|valve|propane|tech\.trash|laptop|wire|circuit|electric|component|body|semi\.automatic)/],
  ['Food', /^(food|meat|fish|berry|corn|potato|mushroom|apple|pumpkin|egg|honey|bread|taco|pizza|sushi|jar|can\.|chocolate|granola|tea|coffee|beer|wine|seed|clone|water\.|salt\.water)/],
];

const NAME_RULES = [
  ['Ammo', /\b(ammo|ammunition|arrow|arrows|bolt|bolts|bullet|bullets|shell|shells|grenade round)\b/i],
  ['Explosives', /\b(explosive|explosives|grenade|rocket|satchel|beancan|landmine|mine|dynamite|mortar|catapult|c4)\b/i],
  ['Attachments', /\b(scope|sight|holosight|silencer|muzzle|laser|flashlight|magazine|grip|barrel|attachment|modifier)\b/i],
  ['Vehicles', /\b(minicopter|helicopter|car|boat|rhib|kayak|tugboat|submarine|train|locomotive|snowmobile|motorbike|horse|saddle|balloon|vehicle)\b/i],
  ['Weapons', /\b(rifle|smg|pistol|shotgun|machine gun|lmg|minigun|bow|crossbow|spear|knife|machete|rock|flamethrower|launcher|sickle|paddle)\b/i],
  ['Tools', /\b(hammer|pickaxe|axe|hatchet|shovel|sickle|pitchfork|hoe|bucket|hose|wrench|planner|chainsaw|jackhammer|salvage|binoculars|compass|map|blueprint|torch)\b/i],
  ['Armor', /\b(facemask|helmet|armor|plate|hazmat|riot|coffeecan|roadsign|wetsuit|diving)\b/i],
  ['Clothing', /\b(shirt|pants|hoodie|boots|shoes|gloves|jacket|bandana|hat|cap|mask|glasses|kilt|suit|attire|poncho|socks|underwear|burlap|fins)\b/i],
  ['Medical', /\b(syringe|bandage|medkit|medical|pills|antirad|antidote|antiserum|injector|blood)\b/i],
  ['Food', /\b(apple|berry|berries|mushroom|corn|pumpkin|potato|meat|fish|water|tuna|chocolate|granola|jar|egg|honey|salt|pie|cookie|bread|taco|pizza|sushi|tea|coffee|beer|wine)\b/i],
  ['Building', /\b(foundation|wall|floor|roof|stairs|frame|door|window|gate|barricade|building|shutter|embrasure|hatch|ladder|steps|ramp|twig|garage|external)\b/i],
  ['Deployables', /\b(turret|trap|spike|barbeque|furnace|refinery|workbench|repair bench|campfire|locker|sleeping bag|bed|shelf|table|chair|rug|sign|purifier|pump|solar|wind turbine|battery|generator|switch|sam site|elevator|lift|storage|mailbox|lantern|light|hobo|barrel|composter|mixing table|stash|vending|fridge|fireplace|cupboard)\b/i],
  ['Resources', /\b(wood|stones|stone|metal fragments|metal refined|sulfur|charcoal|cloth|leather|scrap|low grade fuel|gunpowder|bone fragments|hqm|crude oil|fat)\b/i],
  ['Components', /\b(gears|spring|metal pipe|sheet metal|blade|tarp|rope|fuse|targeting computer|cctv|camera|rf transmitter|receiver|timer|igniter|spark plug|valve|propane|tech trash|laptop|wire|circuit|electric|component|body)\b/i],
];

function classify(name, shortname) {
  const short = String(shortname).toLowerCase();
  const display = String(name).toLowerCase();

  for (const [category, pattern] of SHORTNAME_RULES) if (pattern.test(short)) return category;
  for (const [category, pattern] of NAME_RULES) if (pattern.test(display)) return category;
  return 'Misc';
}

const counts = {};
const items = data.items.map((item) => {
  const category = classify(item.Name ?? '', item['Short Name'] ?? '');
  counts[category] = (counts[category] ?? 0) + 1;
  return { ...item, Category: category };
});

const enriched = {
  _meta: {
    ...data._meta,
    total_items: items.length,
    items_with_image: items.filter((item) => String(item.image ?? '').startsWith('https://')).length,
    categories: Object.keys(counts).sort(),
    note: `${data._meta?.note ?? ''} Every item carries a Category for the shop catalog; images are the official corrosionhour item icons.`.trim(),
  },
  items,
};

writeFileSync(PATH, `${JSON.stringify(enriched, null, 1)}\n`);
console.log('items', items.length);
console.log('with image', enriched._meta.items_with_image);
console.log('categories', counts);
