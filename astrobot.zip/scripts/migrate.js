import { initDatabase, getDb, closeDatabase } from '../src/db/index.js';

/** Applies schema.sql and prints the resulting tables. */
function main() {
  initDatabase();
  const tables = getDb()
    .prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
    .all();

  console.log(`Schema applied. ${tables.length} tables:`);
  for (const table of tables) console.log(` - ${table.name}`);
  closeDatabase();
}

main();
