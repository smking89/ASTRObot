import { initDatabase, closeDatabase } from '../src/db/index.js';
import { loadRegistry } from '../src/core/loader.js';
import { logger } from '../src/core/logger.js';
import { featureCatalogueIssues } from '../src/services/panel-deploy.js';

/**
 * Boot-time validation without a Discord connection:
 *  - every command/component/panel module imports cleanly
 *  - the command tree is deployable (names, descriptions, nesting, limits)
 *  - component ids and panel ids are unique
 */
const errors = [];

function expect(condition, message) {
  if (!condition) errors.push(message);
}

function validatePayload(payload, command) {
  expect(payload.name === payload.name.toLowerCase(), `/${payload.name}: name must be lowercase.`);
  expect(payload.description.length > 0 && payload.description.length <= 100, `/${payload.name}: description must be 1-100 chars.`);

  const options = payload.options ?? [];
  const hasSubcommands = options.some((option) => option.type === 1);
  const hasGroups = options.some((option) => option.type === 2);

  expect(!(hasSubcommands || hasGroups) || options.every((option) => option.type === 1 || option.type === 2), `/${payload.name}: cannot mix subcommands with top-level options.`);

  if (hasGroups) {
    for (const group of options.filter((option) => option.type === 2)) {
      expect((group.options ?? []).every((option) => option.type === 1), `/${payload.name} ${group.name}: groups may only contain subcommands.`);
    }
  }

  expect(!command.subcommands || command.subcommands.size <= 25, `/${payload.name}: more than 25 subcommand entries.`);

  for (const sub of command.subcommands?.values() ?? []) {
    expect(!sub.name.includes(' '), `/${payload.name}: invalid subcommand name "${sub.name}".`);
  }
}

async function main() {
  initDatabase();

  const { commands, components, panels, payloads } = await loadRegistry();

  for (const [name, command] of commands) {
    expect(command.name === name, `Command collection key ${name} does not match data.name ${command.name}.`);
    validatePayload(command.data, command);
    if (!command.execute && !command.panel && !command.subcommands) {
      errors.push(`/${name}: has no execute handler, panel or subcommands.`);
    }
  }

  expect(payloads.length <= 100, `Too many top-level commands: ${payloads.length}/100.`);
  for (const issue of featureCatalogueIssues()) errors.push(issue);

  const panelIds = new Set(panels.keys());
  for (const [id, panel] of panels) {
    expect(typeof panel.render === 'function', `Panel ${id} has no render().`);
  }

  logger.info(`Commands: ${commands.size} · components: ${components.size} · panels: ${panels.size}`);
  logger.info(`Top-level payloads: ${payloads.length}`);

  if (errors.length > 0) {
    console.error(`\n${errors.length} validation error(s):`);
    for (const error of errors) console.error(` - ${error}`);
    process.exitCode = 1;
  } else {
    console.log('\nAstroBot structure OK.');
  }

  closeDatabase();
}

main().catch((error) => {
  logger.error('Check failed', error);
  process.exitCode = 1;
});
