import 'dotenv/config';
import { initDatabase, closeDatabase } from '../src/db/index.js';
import { env } from '../src/config/env.js';
import { loadRegistry } from '../src/core/loader.js';
import { getGuildSettings } from '../src/db/repositories/guilds.js';
import { PANEL_DEFINITIONS, planTemplatePanels } from '../src/services/panel-deploy.js';
import { normalizeStructureName } from '../src/services/template-builder.js';

const API = 'https://discord.com/api/v10';
const deploy = process.argv.includes('--deploy');
const onlyArg = process.argv.find((arg) => arg.startsWith('--only='));
const only = onlyArg ? onlyArg.slice('--only='.length) : null;
const guildId = process.env.GUILD_ID || env.discord.devGuildId || env.discord.officialGuildId;
const FALLBACKS = Object.freeze({ support: 'tickets', lfg: 'lfg' });
const PANEL_CHANNEL_SPECS = Object.freeze({
  lfg: {
    name: '🤝・lfg',
    category: /astro-network/i,
    topic: 'Find teammates for your next wipe. Open the panel to browse or create a squad.',
  },
  teams: {
    name: '🛡️・teams',
    category: /astro-rivals/i,
    topic: 'Create a team, invite players and manage your clan.',
  },
  kits: {
    name: '🎒・kits',
    category: /astro-network/i,
    topic: 'Claim the kits your roles unlock and receive them in game.',
  },
  battlepass: {
    name: '🎖️・battle-pass',
    category: /astro-network/i,
    topic: 'Track tiers and claim battle pass rewards.',
  },
  bounties: {
    name: '🎯・bounties',
    category: /astro-rivals/i,
    topic: 'Place and track bounties on rival players.',
  },
});

function requireConfig() {
  if (!env.discord.token) throw new Error('DISCORD_TOKEN is not configured.');
  if (!guildId) throw new Error('Set GUILD_ID, DISCORD_DEV_GUILD_ID or OFFICIAL_GUILD_ID.');
}

async function api(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      Authorization: `Bot ${env.discord.token}`,
      'Content-Type': 'application/json',
      ...(options.headers ?? {}),
    },
  });
  const body = response.status === 204 ? null : await response.text();
  if (!response.ok) throw new Error(`${options.method ?? 'GET'} ${path} -> ${response.status} ${body?.slice(0, 200) ?? ''}`);
  return body ? JSON.parse(body) : null;
}

const isTextChannel = (channel) => channel?.type === 0 || channel?.type === 5;

function serializePayload(payload) {
  const json = (value) => (typeof value?.toJSON === 'function' ? value.toJSON() : value);
  return {
    embeds: (payload.embeds ?? []).map(json),
    components: (payload.components ?? []).map(json),
    allowed_mentions: { parse: [] },
  };
}

function channelFor(type, channels, plan, settings) {
  const entry = plan.find((item) => item.type === type);
  const key = entry?.channelName ? normalizeStructureName(entry.channelName) : null;
  const byName = key
    ? channels.find((channel) => isTextChannel(channel) && normalizeStructureName(channel.name) === key)
    : null;
  const fallbackId = FALLBACKS[type] ? settings.channels?.[FALLBACKS[type]] : null;
  return byName ?? channels.find((channel) => channel.id === fallbackId && isTextChannel(channel)) ?? null;
}

async function ensurePanelChannel(type, channels) {
  const spec = PANEL_CHANNEL_SPECS[type];
  if (!spec) return null;
  const category = channels.find(
    (channel) => channel.type === 4 && spec.category.test(normalizeStructureName(channel.name)),
  );
  if (!category) return null;

  const channel = await api(`/guilds/${guildId}/channels`, {
    method: 'POST',
    body: JSON.stringify({
      name: spec.name,
      type: 0,
      parent_id: category.id,
      topic: spec.topic,
    }),
  });
  channels.push(channel);
  return channel;
}

async function panelState(channel, definition) {
  const messages = await api(`/channels/${channel.id}/messages?limit=50`);
  const found = messages.find((message) =>
    String(message.embeds?.[0]?.footer?.text ?? '').includes(definition.marker),
  );
  const footer = String(found?.embeds?.[0]?.footer?.text ?? '');
  return {
    found: Boolean(found),
    hasButtons: Array.isArray(found?.components) && found.components.length > 0,
    stale: Boolean(found && definition.revision && !footer.includes(`v${definition.revision}`)),
    message: found ?? null,
  };
}

async function main() {
  requireConfig();
  initDatabase();

  const { panels } = await loadRegistry();
  const brokenLocal = [...panels].filter(([, panel]) => typeof panel.render !== 'function').map(([id]) => id);
  const invalidDefinitions = Object.entries(PANEL_DEFINITIONS)
    .filter(([, definition]) => !definition.marker || typeof definition.payload !== 'function')
    .map(([type]) => type);

  console.log(`Local panel audit: ${panels.size} registered, ${brokenLocal.length} missing render().`);
  if (brokenLocal.length) console.log(`  broken: ${brokenLocal.join(', ')}`);
  console.log(
    `Entry panel definitions: ${Object.keys(PANEL_DEFINITIONS).length}, ${invalidDefinitions.length} invalid.`,
  );

  const channels = await api(`/guilds/${guildId}/channels`);
  const settings = getGuildSettings(guildId);
  const plan = planTemplatePanels({ channels: channels.map((channel) => ({ name: channel.name })) });
  const results = [];

  const definitions = Object.entries(PANEL_DEFINITIONS).filter(([type]) => !only || type === only);
  for (const [type, definition] of definitions) {
    let channel = channelFor(type, channels, plan, settings);
    if (!channel && deploy) {
      try {
        channel = await ensurePanelChannel(type, channels);
      } catch (error) {
        results.push({ type, status: 'error', detail: error.message });
        continue;
      }
    }
    if (!channel) {
      results.push({ type, status: 'no-channel', detail: 'no matching text channel' });
      continue;
    }

    try {
      const state = await panelState(channel, definition);
      if (state.found && state.hasButtons && !state.stale) {
        results.push({ type, status: 'present', detail: `<#${channel.id}>` });
      } else if (!deploy) {
        results.push({
          type,
          status: state.stale ? 'stale' : state.found ? 'buttons-missing' : 'missing',
          detail: `<#${channel.id}> (${deploy ? 'deploying' : 'deploy with --deploy'})`,
        });
      } else {
        const payload = serializePayload(definition.payload());
        if (state.found) {
          await api(`/channels/${channel.id}/messages/${state.message.id}`, {
            method: 'PATCH',
            body: JSON.stringify(payload),
          });
          results.push({ type, status: 'repaired', detail: `<#${channel.id}>` });
        } else {
          await api(`/channels/${channel.id}/messages`, { method: 'POST', body: JSON.stringify(payload) });
          results.push({ type, status: 'deployed', detail: `<#${channel.id}>` });
        }
      }
    } catch (error) {
      results.push({ type, status: 'error', detail: error.message });
    }
  }

  for (const result of results) console.log(`  ${result.type}: ${result.status} — ${result.detail}`);

  const summary = results.reduce((counts, result) => {
    counts[result.status] = (counts[result.status] ?? 0) + 1;
    return counts;
  }, {});
  console.log(`Entry panel result: ${JSON.stringify(summary)}`);

  const failed = brokenLocal.length > 0 || invalidDefinitions.length > 0 || results.some((result) => result.status === 'error');
  if (!deploy) {
    const pending = results.filter((result) => ['missing', 'buttons-missing', 'stale', 'no-channel'].includes(result.status));
    if (pending.length) console.log(`${pending.length} entry panel(s) are not deployed; rerun with --deploy to repair them.`);
  }

  closeDatabase();
  if (failed) process.exitCode = 1;
}

main().catch((error) => {
  closeDatabase();
  console.error(`Panel audit failed: ${error.message}`);
  process.exitCode = 1;
});