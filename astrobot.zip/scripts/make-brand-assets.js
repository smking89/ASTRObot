import { deflateSync } from 'node:zlib';
import { writeFileSync, mkdirSync } from 'node:fs';

const crcTable = (() => {
  const table = [];
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();
const crc32 = (buf) => {
  let c = 0xffffffff;
  for (const byte of buf) c = crcTable[(c ^ byte) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
};
const chunk = (type, data) => {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const body = Buffer.concat([Buffer.from(type), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(body));
  return Buffer.concat([len, body, crc]);
};
const encodePng = (w, h, rgba) => {
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y += 1) {
    raw[y * (w * 4 + 1)] = 0;
    rgba.copy(raw, y * (w * 4 + 1) + 1, y * w * 4, (y + 1) * w * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
};

/** Draws the Astro D-pad on an opaque white tile, supersampled 4x. */
function render(size) {
  const s = 4;
  const W = size * s;
  const px = new Uint8Array(W * W * 4).fill(255);
  const set = (x, y, r, g, b, a = 255) => {
    if (x < 0 || y < 0 || x >= W || y >= W) return;
    const i = (y * W + x) * 4;
    px[i] = r; px[i + 1] = g; px[i + 2] = b; px[i + 3] = a;
  };
  const rect = (x0, y0, x1, y1, r, g, b) => {
    for (let y = Math.round(y0); y < Math.round(y1); y += 1) for (let x = Math.round(x0); x < Math.round(x1); x += 1) set(x, y, r, g, b);
  };
  const disc = (cx, cy, rad, r, g, b) => {
    for (let y = Math.round(cy - rad); y <= Math.round(cy + rad); y += 1) {
      for (let x = Math.round(cx - rad); x <= Math.round(cx + rad); x += 1) {
        if ((x - cx) ** 2 + (y - cy) ** 2 <= rad * rad) set(x, y, r, g, b);
      }
    }
  };

  const arm = Math.round(W * 0.21);
  const span = Math.round(W * 0.72);
  const mid = Math.round(W / 2);
  rect(mid - arm / 2, mid - span / 2, mid + arm / 2, mid + span / 2, 17, 17, 17);
  rect(mid - span / 2, mid - arm / 2, mid + span / 2, mid + arm / 2, 17, 17, 17);
  disc(mid, mid, Math.round(W * 0.115), 255, 255, 255);
  disc(mid, mid, Math.round(W * 0.05), 230, 33, 39);

  const out = Buffer.alloc(size * size * 4);
  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      let r = 0, g = 0, b = 0;
      for (let oy = 0; oy < s; oy += 1) for (let ox = 0; ox < s; ox += 1) {
        const i = ((y * s + oy) * W + (x * s + ox)) * 4;
        r += px[i]; g += px[i + 1]; b += px[i + 2];
      }
      const n = s * s;
      const o = (y * size + x) * 4;
      out[o] = Math.round(r / n); out[o + 1] = Math.round(g / n); out[o + 2] = Math.round(b / n); out[o + 3] = 255;
    }
  }
  return encodePng(size, size, out);
}

mkdirSync('dashboard/public/brand', { recursive: true });
for (const size of [16, 32, 48, 180, 512]) {
  const name = size === 180 ? 'apple-touch-icon.png' : `favicon-${size}.png`;
  writeFileSync(`dashboard/public/brand/${name}`, render(size));
  console.log(name, size + 'px');
}
writeFileSync(
  'dashboard/public/brand/favicon.svg',
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" role="img" aria-label="AstroBot">
  <rect width="64" height="64" fill="#ffffff"/>
  <path d="M27 6h10v21h21v10H37v21H27V37H6V27h21V6Z" fill="#111111"/>
  <circle cx="32" cy="32" r="7" fill="#ffffff"/>
  <circle cx="32" cy="32" r="3.4" fill="#e62127"/>
</svg>
`,
);
console.log('favicon.svg');
