import { REST, Routes } from 'discord.js';
import { assertRuntimeEnv, env } from '../src/config/env.js';
import { initDatabase, closeDatabase } from '../src/db/index.js';
import { loadRegistry } from '../src/core/loader.js';
import { logger } from '../src/core/logger.js';

/**
 * Registers the command tree. Uses DISCORD_DEV_GUILD_ID for instant updates when
 * present, otherwise registers globally.
 */
async function main() {
  assertRuntimeEnv();
  initDatabase();

  const { payloads } = await loadRegistry();
  const rest = new REST({ version: '10' }).setToken(env.discord.token);

  if (env.discord.devGuildId) {
    await rest.put(Routes.applicationGuildCommands(env.discord.clientId, env.discord.devGuildId), { body: payloads });
    logger.info(`Registered ${payloads.length} commands to guild ${env.discord.devGuildId}.`);
  } else {
    await rest.put(Routes.applicationCommands(env.discord.clientId), { body: payloads });
    logger.info(`Registered ${payloads.length} global commands. Propagation can take up to one hour.`);
  }

  closeDatabase();
}

main().catch((error) => {
  logger.error('Command deployment failed', error);
  process.exitCode = 1;
});
