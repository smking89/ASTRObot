import { copyFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

/**
 * Imports the outlined RhosGFX Vector Ranks artwork as the bot's badge icons.
 *
 * The pack (assets/vector-ranks, CC0) ships two sets:
 *   v1 - Diamond, Shield and Hexagon shapes in outline/solid, ten metals and
 *        twelve levels. Used for achievement badges and clan ranks.
 *   v2 - the winged rank medal in eight metals and seven levels. Used for the
 *        personal level tiers shown on /progression and the dashboard.
 *
 * Every icon is written as a 256px transparent PNG to the Discord attachment
 * folder and the dashboard's public copy.
 */

const PACK = fileURLToPath(new URL('../assets/vector-ranks/', import.meta.url));
const OUT = fileURLToPath(new URL('../assets/badges/', import.meta.url));
const WEB = fileURLToPath(new URL('../dashboard/public/badges/', import.meta.url));

const shape = (name, variant, colour, level) => {
  const slug = name.toLowerCase();
  return `v1/${name}/${name} (${variant})/${colour}/${slug}-${colour.toLowerCase()}-${level}.png`;
};

const DIAMOND = (colour, level) => shape('Diamond', 'outline', colour, level);
const SHIELD = (colour, level) => shape('Shield', 'outline', colour, level);
const HEXAGON = (colour, level) => shape('Hexagon', 'outline', colour, level);
const MEDAL = (colour, level) => `v2/Outline/${colour}/rank-${colour.toLowerCase()}-${level}.png`;

/** Badge key -> pack file. Exported so tests/builds can inspect the mapping. */
export const RANK_BADGE_SOURCES = Object.freeze({
  // Personal rank tiers (/progression + dashboard) - v2 winged medals.
  stone: MEDAL('Stone', 1),
  bronze: MEDAL('Bronze', 2),
  silver: MEDAL('Silver', 3),
  gold: MEDAL('Gold', 4),
  diamond: MEDAL('Platinum', 5),
  elite: MEDAL('Amethyst', 6),

  // Earned achievement badges - v1 outlines, one shape/colour family each.
  first_blood: DIAMOND('Ruby', 3),
  hunter: SHIELD('Sapphire', 4),
  survivor: SHIELD('Silver', 6),
  banker: HEXAGON('Gold', 9),
  prestige: DIAMOND('Master', 12),

  // Clan ranks (/team) - roles read as shields and diamonds.
  leader: DIAMOND('Ruby', 12),
  officer: SHIELD('Gold', 7),
  member: HEXAGON('Silver', 2),
  recruit: HEXAGON('Wood', 1),
  veteran: SHIELD('Bronze', 8),
  raider: DIAMOND('Onyx', 7),
  scout: SHIELD('Sapphire', 2),
  builder: HEXAGON('Bronze', 5),
  medic: SHIELD('Silver', 3),
});

mkdirSync(OUT, { recursive: true });
mkdirSync(WEB, { recursive: true });

const missing = [];
let imported = 0;

for (const [key, relative] of Object.entries(RANK_BADGE_SOURCES)) {
  const source = join(PACK, relative);
  if (!existsSync(source)) {
    missing.push(`${key}: ${relative}`);
    continue;
  }

  copyFileSync(source, join(OUT, `${key}.png`));
  copyFileSync(source, join(WEB, `${key}.png`));
  imported += 1;
}

if (missing.length > 0) {
  console.error(`Missing ${missing.length} vector-ranks file(s):\n${missing.join('\n')}`);
  process.exitCode = 1;
}

const license = join(PACK, 'License.txt');
if (existsSync(license) && !existsSync(join(OUT, 'VECTOR-RANKS.md'))) {
  const text = readFileSync(license, 'utf8').trim();
  writeFileSync(
    join(OUT, 'VECTOR-RANKS.md'),
    `# Vector Ranks artwork\n\nRank and achievement icons are from the RhosGFX Vector Ranks Pack (CC0).\n\n${text}\n`,
  );
}

console.log(`Imported ${imported}/${Object.keys(RANK_BADGE_SOURCES).length} outlined rank badge(s) from vector-ranks.`);
