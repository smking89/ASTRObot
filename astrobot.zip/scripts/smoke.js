import { ChannelType, Collection, MessageFlags, PermissionFlagsBits } from 'discord.js';
import { initDatabase, getDb, closeDatabase } from '../src/db/index.js';
import { ensureGuild, getGuildSettings, patchGuildSetting } from '../src/db/repositories/guilds.js';
import { loadRegistry } from '../src/core/loader.js';
import { createSession, registerLoaded } from '../src/core/registry.js';
import gamePanel from '../src/components/game-panel.js';
import wipeComponent from '../src/components/wipe.js';
import { resolveGrants, hasAccess, hasPermissionBits, ACCESS } from '../src/core/permissions.js';
import { ValidationError } from '../src/core/errors.js';
import { reportError } from '../src/core/reporter.js';
import { InteractionContext } from '../src/core/context.js';
import { isStandaloneCommand } from '../src/core/router.js';
import { assertManualMintAllowed, balances, claimDaily, credit, debit, depositToBank, mint, transfer } from '../src/services/economy-service.js';
import { awardXp, summary } from '../src/services/progression-service.js';
import { parseLine } from '../src/services/rcon/parser.js';
import { dispatchKillfeed, formatKillfeed } from '../src/services/rcon/killfeed.js';
import { TelemetryRouter } from '../src/services/rcon/telemetry.js';
import { evaluateProtection, isSrpActive, withinZone } from '../src/services/rcon/protection.js';
import { startRound, hit, renderState } from '../src/services/games/blackjack.js';
import { rollDice } from '../src/services/games/dice.js';
import { spinSlots } from '../src/services/games/slots.js';
import { spinWheel } from '../src/services/games/wheel.js';
import { climb, startTower, cashOut } from '../src/services/games/tower.js';
import { startUno, playableIndexes } from '../src/services/games/uno.js';
import { openLootbox } from '../src/services/games/lootbox.js';
import { startDefuse, cutWire } from '../src/services/games/defuse.js';
import { startMinefield, revealMinefield } from '../src/services/games/minefield.js';
import { spinRecycler } from '../src/services/games/recycler.js';
import { fireRange, RANGE_WEAPONS } from '../src/services/games/range.js';
import { SCRATCH_THEMES, scratchCell, startScratch } from '../src/services/games/scratch.js';
import { MINES_TILES, cashOutMines, revealMine, startMines } from '../src/services/games/mines.js';
import { CRASH_MAX_MS, crashMultiplierAt, startCrash, tickCrash } from '../src/services/games/crash.js';
import { parseRouletteBet, spinRoulette } from '../src/services/games/roulette.js';
import { PLINKO_MULTIPLIERS, PLINKO_ROWS, dropPlinko } from '../src/services/games/plinko.js';
import { JACKPOT_ODDS, JACKPOT_SEED, awardJackpot, contributeJackpot, getJackpot, getJackpotHistory } from '../src/services/jackpot-service.js';
import { buyJackpotTicket, drawJackpot, getJackpotDrawHistory, getJackpotDrawState } from '../src/services/jackpot-raffle-service.js';
import { getGameConfig } from '../src/services/games/game-config.js';
import { awardGamePrize } from '../src/services/game-prize-service.js';
import { liveTotals, recordLiveStats } from '../src/services/server-live-service.js';
import { statsLine } from '../src/services/stats-channels.js';
import { buildEmbed, setEmbedChannelLookup } from '../src/ui/embeds.js';
import {
  blackjackView,
  defuseView,
  lootboxView,
  minefieldView,
  rangeView,
  recyclerView,
  scratchView,
  unoView,
} from '../src/ui/game-views.js';
import { button } from '../src/ui/components.js';
import { createPost as createLfgPost, closePost, getPost as getLfgPost, isMember, joinPost, leavePost, listMembers, listOpenGlobal } from '../src/db/repositories/lfg.js';
import { createPartnershipRequest, getPartnership } from '../src/db/repositories/partnerships.js';
import { submitPartnershipRequest } from '../src/commands/partner/request.js';
import { createTemplate, deleteTemplate, getTemplate, listTemplates } from '../src/db/repositories/templates.js';
import {
  applyGuildTemplate,
  captureGuildTemplate,
  decodeTemplateSections,
  encodeTemplateSections,
  filterTemplateParts,
  planGuildTemplate,
  wipeGuildStructure,
} from '../src/services/template-service.js';
import { deployTemplatePanels, planTemplatePanels } from '../src/services/panel-deploy.js';
import { scanGuildLayout } from '../src/services/repair-service.js';
import {
  announceServerOnline,
  dueStage,
  executeWipe,
  nextWipeAt,
  parseCountdowns,
  parseWipeMessages,
  planWipe,
  renderWipeMessage,
  tickWipes,
} from '../src/services/wipe-service.js';
import { summarizeSessions } from '../src/services/analytics-service.js';
import { computeUptime } from '../src/services/status-service.js';
import { closeSession, listSessions, openSession } from '../src/db/repositories/sessions.js';
import { listStatusEvents, recordStatus } from '../src/db/repositories/status.js';
import { appealQueue, createCase, staffCaseStats, updateCase } from '../src/db/repositories/moderation.js';
import { createTicket, rateTicket, updateTicket } from '../src/db/repositories/tickets.js';
import { createWipeProfile, deleteWipeProfile, getWipeProfile, listWipeProfiles } from '../src/db/repositories/wipes.js';
import { allRustItems, buildItemCommand, getRustItem, searchRustItems } from '../src/services/rust-items.js';
import {
  adjustStock,
  defaultStockValue,
  groupByCategory,
  isSoldOut,
  restockAt,
  restockCountdown,
  restockProduct,
  stockLabel,
  stockOf,
} from '../src/services/shop-stock.js';
import {
  listStockEvents,
  pruneStockEvents,
  recordPurchase,
  recordStockEvent,
  salesTotals,
  topSellers,
} from '../src/db/repositories/shop.js';
import { runShopMaintenance } from '../src/services/shop-maintenance.js';
import { maybeAlertLowStock } from '../src/services/shop-alerts.js';
import { buildKitCommand } from '../src/services/kit-service.js';
import { autoPrice, priceMultipliers, quickSetupPreview } from '../src/services/shop-quick-setup.js';
import { existsSync as badgeExists, readFileSync as readBadgeFile } from 'node:fs';
import { clanRankIcon, personalBadgeIcon, personalRank } from '../src/ui/rank-icons.js';
import { BADGE_ICON_KEYS, badgeIconPath } from '../src/ui/badge-assets.js';
import { TEMPLATE_PRESETS, getPresetTemplate } from '../src/config/server-templates.js';
import {
  addDraftCategory,
  addDraftChannel,
  addDraftOverwrite,
  addDraftRole,
  buildTemplatePayload,
  loadTemplateDraft,
  parsePermissions,
  removeDraftEntry,
  removeDraftOverwrite,
  resetTemplateDraft,
  saveTemplateDraft,
  templateDraft,
} from '../src/services/template-builder.js';
import {
  addClanBadge,
  awardBadge,
  badgeDefinition,
  badgesFor,
  listClanBadges,
  removeClanBadge,
  revokeBadge,
  validateBadgeUpload,
} from '../src/services/badge-service.js';
import { clanRanks, createClanRank, deleteClanRank, updateClanRank } from '../src/services/clan-service.js';
import { upsertLink } from '../src/db/repositories/links.js';
import { getProgress } from '../src/db/repositories/battlepass.js';
import { CARD_BACKS } from '../src/services/games/cards.js';
import { cardBackPath } from '../src/services/blackjack-image.js';
import { getPref } from '../src/db/repositories/prefs.js';
import { recordKillStats, recordPveDeath, recordPveKill } from '../src/db/repositories/players.js';
import { deliverPurchase, findProduct } from '../src/services/tip4serv-service.js';
import { runtime } from '../src/core/runtime.js';
import { CONFIG_SECTIONS } from '../src/config/settings-schema.js';
import { assertFeatureEnabled, featureForCommand } from '../src/services/feature-service.js';
import { QUICK_SECTIONS } from '../src/panels/set.js';
import { getKillfeedEvent, recordKillfeedEvent } from '../src/db/repositories/killfeed.js';
import {
  GLOBAL_KILLFEED_INTERVAL_MS,
  processGlobalKillfeed,
  validateKillfeedEvent,
} from '../src/services/global-killfeed-service.js';
import { attachGuildSeat, guildPlan, seatSummary, setManualPlan, transferGuildSeat } from '../src/services/plan-service.js';
import { getMembership, revokeMembership } from '../src/db/repositories/memberships.js';
import { issueLicense } from '../src/db/repositories/licenses.js';
import { activateUserLicense, revokeUserLicense, transferUserLicense } from '../src/services/license-service.js';

/**
 * Runtime smoke test with no gateway connection and an in-memory database.
 * Covers the logic that the structural check cannot execute: economy, XP,
 * parsing, protection windows, every game engine and every panel render.
 */
initDatabase({ path: ':memory:' });

const GUILD = '100000000000000001';
const ALICE = '200000000000000001';
const BOB = '200000000000000002';
const CAROL = '200000000000000003';
const DAVE = '200000000000000004';
const ROLE = '300000000000000001';

let checks = 0;
const failures = [];

function ok(name, condition, detail = '') {
  checks += 1;
  if (!condition) failures.push(`${name}${detail ? ` — ${detail}` : ''}`);
}

async function okAsync(name, work) {
  try {
    await work();
    checks += 1;
  } catch (error) {
    failures.push(`${name} — ${error.message}`);
  }
}

function makeTemplateGuild(name = 'Template Guild') {
  const roles = new Collection();
  const channels = new Collection();
  const everyone = {
    id: 'template-guild',
    name: '@everyone',
    managed: false,
    color: 0,
    hoist: false,
    mentionable: false,
    permissions: { bitfield: 0n },
    position: 0,
  };
  roles.set(everyone.id, everyone);

  const guild = {
    id: 'template-guild',
    name,
    client: { user: { id: 'bot' } },
    members: {
      me: { permissions: { has: () => true } },
      fetch: async () => ({ permissions: { has: () => true } }),
    },
    roles: {
      everyone,
      fetch: async () => roles,
      create: async (options) => {
        const role = {
          id: `role-${roles.size}`,
          name: options.name,
          managed: false,
          color: options.color ?? 0,
          hoist: options.hoist ?? false,
          mentionable: options.mentionable ?? false,
          permissions: { bitfield: BigInt(options.permissions ?? 0) },
          position: roles.size,
        };
        roles.set(role.id, role);
        return role;
      },
    },
    channels: {
      fetch: async () => channels,
      create: async (options) => {
        const channel = {
          id: `channel-${channels.size}`,
          name: options.name,
          type: options.type,
          position: channels.size,
          parentId: options.parent ?? null,
          permissionOverwrites: { cache: new Map() },
          topic: options.topic ?? null,
          nsfw: options.nsfw ?? false,
          rateLimitPerUser: options.rateLimitPerUser ?? 0,
          bitrate: options.bitrate ?? 0,
          userLimit: options.userLimit ?? 0,
        };
        channels.set(channel.id, channel);
        return channel;
      },
    },
  };

  return { guild, roles, channels };
}

function makeCtx() {
  const guild = {
    id: GUILD,
    name: 'Smoke Guild',
    ownerId: ALICE,
    channels: { fetch: async () => null },
    members: { fetch: async () => new Map() },
    roles: { cache: new Map() },
  };

  return {
    guildId: GUILD,
    userId: ALICE,
    guild,
    team: null,
    guildConfig: getGuildSettings(GUILD),
    client: { user: { id: 'bot' }, guilds: { fetch: async () => guild, cache: new Map() } },
    interaction: {
      user: { id: ALICE, username: 'smoke' },
      guildId: GUILD,
      replied: false,
      deferred: false,
      isMessageComponent: () => false,
      isModalSubmit: () => false,
      editReply: async () => null,
    },
    isComponent: false,
    isModal: false,
    deferred: false,
    replied: false,
    panelCalls: [],
    option(name) {
      if (this.isModal && this.fields) return this.fields.getTextInputValue?.(name) ?? null;
      return null;
    },
    async panel(id, params) {
      this.panelCalls.push({ id, params });
    },
    async reply() {},
    async edit() {},
    async update() {},
    async modal() {},
    async defer() {},
  };
}

async function main() {
  ensureGuild({ id: GUILD, name: 'Smoke Guild' });
  const registry = registerLoaded(await loadRegistry());

  // --- permissions -------------------------------------------------------
  const plainMember = {
    id: BOB,
    guild: { id: GUILD, ownerId: ALICE },
    roles: { cache: new Map() },
    permissions: { has: () => false },
  };
  const plainGrants = resolveGrants({ member: plainMember, guildConfig: getGuildSettings(GUILD) });
  ok('plain member has player tier', plainGrants.has(ACCESS.PLAYER));
  ok('plain member cannot use restricted commands', !hasAccess(plainGrants, ACCESS.RESTRICTED));

  const ownerMember = { ...plainMember, id: ALICE };
  const ownerGrants = resolveGrants({ member: ownerMember, guildConfig: getGuildSettings(GUILD) });
  ok('owner gets restricted + developer-level ladder grants', hasAccess(ownerGrants, ACCESS.RESTRICTED) && ownerGrants.has(ACCESS.ADMIN));

  // Discord sends a raw member (no .guild, roles as an array, permissions as a
  // bitfield string) when the member is not cached. It must not crash the router.
  const rawAdmin = { id: BOB, roles: [], permissions: String(PermissionFlagsBits.Administrator) };
  const rawGrants = resolveGrants({
    member: rawAdmin,
    guild: { id: GUILD, ownerId: ALICE },
    guildConfig: getGuildSettings(GUILD),
  });
  ok('raw API member resolves through the guild parameter', hasAccess(rawGrants, ACCESS.ADMIN));
  ok('raw permission bitfield string is checked', hasPermissionBits(rawAdmin, PermissionFlagsBits.Administrator));

  const rawOwnerGrants = resolveGrants({
    member: { id: ALICE, roles: [], permissions: '0' },
    guild: { id: GUILD, ownerId: ALICE },
    guildConfig: getGuildSettings(GUILD),
  });
  ok('raw API owner resolves through the guild parameter', hasAccess(rawOwnerGrants, ACCESS.ADMIN));

  // --- modal context -----------------------------------------------------
  const modalCtx = new InteractionContext({
    interaction: { isModalSubmit: () => true, user: { id: BOB } },
    grants: new Set([ACCESS.PLAYER]),
  });
  modalCtx.fields = { getTextInputValue: (field) => (field === 'guild' ? GUILD : null) };
  ok('modal options read from interaction.fields', modalCtx.option('guild') === GUILD);

  const optionalModalCtx = new InteractionContext({
    interaction: { isModalSubmit: () => true, user: { id: BOB } },
    grants: new Set([ACCESS.PLAYER]),
  });
  optionalModalCtx.fields = {
    fields: new Map([['guild', {}]]),
    getTextInputValue: (field) => (field === 'guild' ? GUILD : null),
  };
  ok('missing optional modal fields return null', optionalModalCtx.option('choice') === null);

  // --- error responses --------------------------------------------------
  const fakeInteraction = (capture) => ({
    isChatInputCommand: () => true,
    commandName: 'coins',
    customId: null,
    user: { tag: 'smoke#0001', id: BOB },
    guildId: GUILD,
    deferred: false,
    replied: false,
    reply: async (payload) => capture(payload),
  });

  let validationReply = null;
  await reportError(
    { isReady: () => false },
    new ValidationError('Insufficient funds — you need 5 more coins.'),
    fakeInteraction((payload) => { validationReply = payload; }),
  );
  ok(
    'validation errors reply with their specific message',
    validationReply?.content === 'Insufficient funds — you need 5 more coins.' &&
      validationReply?.flags === MessageFlags.Ephemeral,
  );

  let genericReply = null;
  await reportError(
    { isReady: () => false },
    new Error('boom'),
    fakeInteraction((payload) => { genericReply = payload; }),
  );
  ok('unexpected errors reply with the generic message', genericReply?.content === 'Something went wrong processing your request.');

  // --- economy -----------------------------------------------------------
  credit({ guildId: GUILD, userId: ALICE, amount: 1000, respectCap: true });
  debit({ guildId: GUILD, userId: ALICE, amount: 200 });
  const deposit = depositToBank(GUILD, ALICE, 300);
  ok('bank deposit moved funds', deposit.moved === 300);

  const afterDeposit = balances(GUILD, ALICE);
  ok('wallet/bank split is correct', afterDeposit.wallet === 500 && afterDeposit.bank === 300, JSON.stringify(afterDeposit));

  transfer({ guildId: GUILD, fromId: ALICE, toId: BOB, amount: 100 });
  ok('transfer debits sender', balances(GUILD, ALICE).wallet === 400);
  ok('transfer credits recipient', balances(GUILD, BOB).wallet === 100);

  let blocked = false;
  try {
    debit({ guildId: GUILD, userId: BOB, amount: 10_000 });
  } catch {
    blocked = true;
  }
  ok('overdraft is rejected', blocked);

  const daily = claimDaily(GUILD, ALICE);
  ok('daily bonus can be claimed', daily.claimed === true && daily.streak === 1);
  ok('daily bonus cannot be double-claimed', claimDaily(GUILD, ALICE).claimed === false);

  // --- account-owned licenses and seat add-ons ---------------------------
  await okAsync('a seat add-on is granted once per subscription', async () => {
    const seatUser = '200000000000000009';
    revokeMembership(seatUser);
    const product = { id: 'seat-smoke', seatAddon: true, seatDays: 30 };
    const first = await deliverPurchase({
      guildId: GUILD,
      userId: seatUser,
      product,
      transactionId: 'tx-seat-1',
      subscriptionRef: 'sub-seat-1',
    });
    const afterFirst = seatSummary(seatUser);
    const second = await deliverPurchase({
      guildId: GUILD,
      userId: seatUser,
      product,
      transactionId: 'tx-seat-2',
      subscriptionRef: 'sub-seat-1',
    });
    const afterRenewal = seatSummary(seatUser);
    await deliverPurchase({
      guildId: GUILD,
      userId: seatUser,
      product,
      transactionId: 'tx-seat-3',
      subscriptionRef: 'sub-seat-2',
    });
    const afterSecondAddon = seatSummary(seatUser);

    if (!first.includes('extra Discord server seat') || afterFirst.seatLimit !== 2) {
      throw new Error(`first grant failed: ${JSON.stringify(afterFirst)}`);
    }
    if (afterRenewal.seatLimit !== 2) {
      throw new Error(`renewal stacked seats: ${JSON.stringify(afterRenewal)}`);
    }
    if (afterSecondAddon.seatLimit !== 3) {
      throw new Error(`second subscription did not add a seat: ${JSON.stringify(afterSecondAddon)}`);
    }
    revokeMembership(seatUser);
  });

  await okAsync('license ownership moves with the Discord account', async () => {
    const owner = '200000000000000010';
    const newOwner = '200000000000000011';
    revokeMembership(owner);
    revokeMembership(newOwner);

    const issued = issueLicense({ key: 'AB-SMOKE-USER-0001', tier: 'enterprise', serverLimit: 5 });
    const activated = activateUserLicense({ key: issued.key, userId: owner });
    const ownerMembership = getMembership(owner);
    if (activated.guild_id !== null || ownerMembership?.tier !== 'max') {
      throw new Error(`activation did not grant an account-owned Max plan: ${JSON.stringify(ownerMembership)}`);
    }

    transferUserLicense({ licenseId: issued.id, newOwnerId: newOwner, actorId: owner });
    if (getMembership(owner)) throw new Error('old owner kept the transferred membership');
    if (getMembership(newOwner)?.tier !== 'max') throw new Error('new owner did not receive the Max plan');

    const sourceGuild = '100000000000000020';
    const targetGuild = '100000000000000021';
    ensureGuild({ id: sourceGuild, name: 'License source' });
    ensureGuild({ id: targetGuild, name: 'License target' });
    attachGuildSeat({ guildId: sourceGuild, userId: newOwner });
    const moved = transferGuildSeat({ guildId: targetGuild, userId: newOwner, fromGuildId: sourceGuild });
    if (moved.plan.id !== 'max' || moved.summary.used !== 1 || guildPlan(sourceGuild).id !== 'basic') {
      throw new Error(`license seat did not move with the account: ${JSON.stringify(moved)}`);
    }

    revokeUserLicense({ licenseId: issued.id, actorId: owner });
    if (getMembership(newOwner)) throw new Error('revoked license left a membership behind');
    if (guildPlan(targetGuild).id !== 'basic') throw new Error('revoked license left a server plan behind');
  });

  // --- game configuration ------------------------------------------------
  const gameConfig = getGameConfig(GUILD);
  ok(
    'casino config exposes defaults',
    gameConfig.enabled && gameConfig.minWager === 1 && gameConfig.maxWager === 100_000 && gameConfig.solo.blackjack,
    JSON.stringify(gameConfig),
  );

  // --- LFG membership -----------------------------------------------------
  const lfgPost = createLfgPost({
    guildId: GUILD,
    ownerId: ALICE,
    title: 'Smoke party',
    playersNeeded: 3,
  });
  ok('LFG owner is counted as the first member', isMember(lfgPost.id, ALICE) && listMembers(lfgPost.id).length === 1 && lfgPost.filled === 1);

  const joinedPost = joinPost(lfgPost.id, BOB);
  ok('LFG join tracks the member', isMember(lfgPost.id, BOB) && joinedPost.filled === 2 && listMembers(lfgPost.id).length === 2);

  let duplicateJoinBlocked = false;
  try {
    joinPost(lfgPost.id, BOB);
  } catch {
    duplicateJoinBlocked = true;
  }
  ok('LFG duplicate join is blocked', duplicateJoinBlocked);

  const leftPost = leavePost(lfgPost.id, BOB);
  ok('LFG leave updates capacity', !isMember(lfgPost.id, BOB) && leftPost.filled === 1 && listMembers(lfgPost.id).length === 1);
  closePost(lfgPost.id);

  // --- scoped economy and minted-currency governance ---------------------
  const GLOBAL_A = `${GUILD}8`;
  const GLOBAL_B = `${GUILD}9`;
  ensureGuild({ id: GLOBAL_A, name: 'Global A' });
  ensureGuild({ id: GLOBAL_B, name: 'Global B' });
  patchGuildSetting(GLOBAL_A, 'economy.scope', 'global', { actorId: ALICE });
  patchGuildSetting(GLOBAL_B, 'economy.scope', 'global', { actorId: ALICE });

  const globalBefore = balances(GLOBAL_A, CAROL).wallet;
  credit({ guildId: GLOBAL_A, userId: CAROL, amount: 75 });
  ok('global currency is shared across servers', balances(GLOBAL_B, CAROL).wallet === globalBefore + 75);

  patchGuildSetting(GLOBAL_A, 'economy.minted', true, { actorId: ALICE });
  let manualMintBlocked = false;
  try {
    mint({ guildId: GLOBAL_A, userId: CAROL, amount: 10, actorId: ALICE });
  } catch {
    manualMintBlocked = true;
  }
  ok('minted currency blocks manual minting', manualMintBlocked);

  let manualGiveBlocked = false;
  try {
    assertManualMintAllowed(GLOBAL_A);
  } catch {
    manualGiveBlocked = true;
  }
  ok('minted currency blocks manual /give', manualGiveBlocked);

  let disabledSourceBlocked = false;
  patchGuildSetting(GLOBAL_A, 'economy.mintSources.games', false, { actorId: ALICE });
  try {
    credit({ guildId: GLOBAL_A, userId: CAROL, amount: 10, kind: 'casino_win' });
  } catch {
    disabledSourceBlocked = true;
  }
  ok('minted currency respects disabled game sources', disabledSourceBlocked);
  patchGuildSetting(GLOBAL_A, 'economy.mintSources.games', true, { actorId: ALICE });
  ok('enabled game source can still mint', credit({ guildId: GLOBAL_A, userId: CAROL, amount: 10, kind: 'casino_win' }).credited === 10);

  // --- global LFG --------------------------------------------------------
  patchGuildSetting(GLOBAL_A, 'lfg.scope', 'global', { actorId: ALICE });
  const globalPost = createLfgPost({ guildId: GLOBAL_A, ownerId: CAROL, title: 'Global smoke party', playersNeeded: 4 });
  ok('global LFG lists opted-in server posts', listOpenGlobal({ limit: 50 }).some((post) => post.id === globalPost.id));
  patchGuildSetting(GLOBAL_A, 'lfg.enabled', false, { actorId: ALICE });
  ok('global LFG hides servers with LFG disabled', !listOpenGlobal({ limit: 50 }).some((post) => post.id === globalPost.id));
  patchGuildSetting(GLOBAL_A, 'lfg.enabled', true, { actorId: ALICE });
  closePost(globalPost.id);

  // --- config dropdowns and partnership handshake -----------------------
  ok('feature switches are grouped in a config section', CONFIG_SECTIONS.features.fields.some((field) => field.path === 'lfg.enabled'));
  ok('rules and features have direct config subcommands', registry.commands.get('config').subcommands.has('rules') && registry.commands.get('config').subcommands.has('features'));

  const selectCtx = makeCtx();
  selectCtx.isComponent = true;
  selectCtx.args = ['choicesave', 'config', 'lfg', 'lfg.scope'];
  selectCtx.values = ['global'];
  await registry.components.get('cfg').execute(selectCtx);
  ok('config select saves a dropdown choice', getGuildSettings(GUILD).lfg.scope === 'global');
  patchGuildSetting(GUILD, 'lfg.scope', 'local', { actorId: ALICE });

  const MIGRATE = `${GUILD}7`;
  ensureGuild({ id: MIGRATE, name: 'Migrate Guild' });
  credit({ guildId: MIGRATE, userId: DAVE, amount: 44 });
  const migrateCtx = makeCtx();
  migrateCtx.guildId = MIGRATE;
  migrateCtx.guildConfig = getGuildSettings(MIGRATE);
  migrateCtx.isComponent = true;
  migrateCtx.args = ['choicesave', 'config', 'shop', 'economy.scope'];
  migrateCtx.values = ['global'];
  await registry.components.get('cfg').execute(migrateCtx);
  ok(
    'switching to global moves existing local balances',
    balances(MIGRATE, DAVE).wallet === 44,
    JSON.stringify({ wallet: balances(MIGRATE, DAVE).wallet, scope: getGuildSettings(MIGRATE).economy.scope }),
  );

  const featureCtx = makeCtx();
  featureCtx.isComponent = true;
  featureCtx.args = ['field', 'config', 'features', 'lfg.enabled'];
  featureCtx.values = ['lfg.enabled'];
  const featureBefore = getGuildSettings(GUILD).lfg.enabled;
  await registry.components.get('cfg').execute(featureCtx);
  ok('feature dropdown toggles a switch', getGuildSettings(GUILD).lfg.enabled !== featureBefore);
  await registry.components.get('cfg').execute(featureCtx);

  const request = createPartnershipRequest({
    fromGuildId: GLOBAL_A,
    toGuildId: GLOBAL_B,
    requesterId: ALICE,
    brandName: 'Smoke Brand',
    duration: '1 month',
    description: 'Test partnership',
    memberCount: 50,
  });
  const partnerCtx = makeCtx();
  partnerCtx.guildId = GLOBAL_B;
  partnerCtx.isComponent = true;
  partnerCtx.args = ['accept', request.id];
  await registry.components.get('partner').execute(partnerCtx);
  const accepted = getPartnership(request.id);
  ok(
    'accepted partnership links both economies',
    accepted.status === 'accepted' &&
      getGuildSettings(GLOBAL_A).economy.scope === 'partner' &&
      getGuildSettings(GLOBAL_B).economy.scope === 'partner' &&
      getGuildSettings(GLOBAL_A).economy.partnerNetworkId === accepted.network_id &&
      getGuildSettings(GLOBAL_B).economy.partnerNetworkId === accepted.network_id,
  );

  const targetGuild = { id: GLOBAL_B, name: 'Global B', ownerId: BOB, memberCount: 50 };
  const delivered = [];
  const channelCtx = makeCtx();
  channelCtx.guild.memberCount = 42;
  channelCtx.isModal = true;
  channelCtx.fields = {
    getTextInputValue: (field) =>
      ({
        brand: 'Channel Brand',
        duration: '2 months',
        description: 'Channel-targeted offer',
        target: '400000000000000001',
      })[field] ?? null,
  };
  channelCtx.client = {
    guilds: { cache: new Map([[GLOBAL_B, targetGuild]]), fetch: async () => targetGuild },
    channels: {
      fetch: async () => ({ id: '400000000000000001', guild: targetGuild, send: async (payload) => delivered.push(payload) }),
    },
    users: { fetch: async () => null },
  };
  channelCtx.reply = async (payload) => delivered.push(payload);
  await submitPartnershipRequest(channelCtx);
  const channelRequest = getDb()
    .prepare("SELECT * FROM partnerships WHERE brand_name = 'Channel Brand' ORDER BY created_at DESC LIMIT 1")
    .get();
  ok(
    'partnership requests can target a channel and capture live members',
    channelRequest?.to_guild_id === GLOBAL_B && channelRequest?.member_count === 42 && delivered.length === 2,
  );

  // --- server templates ---------------------------------------------------
  const template = createTemplate({
    guildId: GUILD,
    name: 'Smoke layout',
    payload: { version: 1, roles: [], categories: [], channels: [] },
    createdBy: ALICE,
  });
  ok(
    'server templates save and load',
    Boolean(template) && listTemplates(GUILD).some((entry) => entry.id === template.id) && getTemplate(GUILD, template.id)?.name === 'Smoke layout',
  );
  ok('server templates delete by guild', deleteTemplate(GUILD, template.id) && !getTemplate(GUILD, template.id));

  const source = makeTemplateGuild('Source Guild');
  await source.guild.roles.create({ name: 'Member', permissions: 0 });
  const sourceCategory = await source.guild.channels.create({ name: 'General', type: ChannelType.GuildCategory });
  await source.guild.channels.create({ name: 'welcome', type: ChannelType.GuildText, parent: sourceCategory.id, topic: 'Hello' });
  const captured = await captureGuildTemplate(source.guild);
  ok(
    'server template captures roles, categories and channels',
    captured.roles.length === 1 && captured.categories.length === 1 && captured.channels.length === 1,
    JSON.stringify({ roles: captured.roles.length, categories: captured.categories.length, channels: captured.channels.length }),
  );

  const destination = makeTemplateGuild('Destination Guild');
  const applied = await applyGuildTemplate(destination.guild, captured);
  ok(
    'server template applies missing structure',
    applied.rolesCreated === 1 && applied.categoriesCreated === 1 && applied.channelsCreated === 1 && applied.errors.length === 0,
    JSON.stringify(applied),
  );

  // --- progression -------------------------------------------------------
  const xp = awardXp({ guildId: GUILD, userId: ALICE, xp: 500 });
  ok('XP levels the player', xp.level >= 3, `level ${xp.level}`);
  const progress = summary(GUILD, ALICE);
  ok('progression summary exposes level and battle pass', progress.level >= 3 && progress.pass !== null);

  // --- RCON parser + killfeed -------------------------------------------
  const kill = parseLine(
    'Alice[76561198000000000] was killed by Bob[76561198000000001] using AssaultRifle at (120.4, 3.0, -890.2)',
    { guildId: GUILD, serverId: 'srv1' },
  );
  ok('parser detects kills', kill?.kind === 'kill', JSON.stringify(kill));
  ok('parser splits victim name', kill?.victim?.name === 'Alice');
  ok('parser splits killer steam id', kill?.killer?.externalId === '76561198000000001');
  ok('parser normalises weapon', kill?.weapon === 'Assault Rifle', kill?.weapon);
  ok('parser extracts coordinates + grid', kill?.coordinates?.grid?.length >= 2);

  const suicide = parseLine('Alice[76561198000000000] committed suicide', { guildId: GUILD });
  ok('parser detects suicides', suicide?.kind === 'suicide');

  const join = parseLine('Bob joined the server', { guildId: GUILD });
  ok('parser detects joins', join?.kind === 'join' && join.player.name === 'Bob');

  const damage = parseLine('Stone Wall took 250 damage from Alice[76561198000000000] at (10, 2, 30) owned by Bob', {
    guildId: GUILD,
  });
  ok('parser detects structure damage with owner', damage?.kind === 'damage' && damage.owner?.name === 'Bob', JSON.stringify(damage));

  const line = formatKillfeed(kill, {
    settings: getGuildSettings(GUILD),
    serverLabel: 'Smoke',
    identity: { killer: { teamTag: 'ABC' }, victim: {} },
  });
  ok('killfeed layout interpolates placeholders', line.includes('Bob') && line.includes('Assault Rifle') && line.includes('[ABC]'), line);
  ok('killfeed does not leave empty clan brackets', !line.includes('[]'));

  // --- Helios-style killfeed placeholders --------------------------------
  const FEED_KILLER = '200000000000000101';
  const FEED_VICTIM = '200000000000000102';
  upsertLink({ guildId: GUILD, userId: FEED_KILLER, platform: 'xbox', gamertag: 'FeedKiller' });
  upsertLink({ guildId: GUILD, userId: FEED_VICTIM, platform: 'xbox', gamertag: 'FeedVictim' });
  credit({ guildId: GUILD, userId: FEED_KILLER, amount: 500 });
  credit({ guildId: GUILD, userId: FEED_VICTIM, amount: 1_000 });
  recordKillStats({ guildId: GUILD, killerId: FEED_KILLER, victimId: FEED_VICTIM });

  const feedKill = parseLine(
    'FeedVictim[76561198000000102] was killed by FeedKiller[76561198000000101] using AssaultRifle at (120.4, 3.0, -890.2)',
    { guildId: GUILD },
  );
  const feedIdentity = {
    killer: { userId: FEED_KILLER, gamertag: 'FeedKiller' },
    victim: { userId: FEED_VICTIM, gamertag: 'FeedVictim' },
  };
  const placeholderLine = formatKillfeed(feedKill, {
    settings: getGuildSettings(GUILD),
    identity: feedIdentity,
    layout:
      '{KillerPlayerName}|{VictimPlayerName}|{KillerKills}|{KillerDeaths}|{KillerKD}|{KillerCurrentStreak}|{KillerBestStreak}|{KillerStreak}|{KillerWallet}|{VictimWallet}|{Currency}|{Stolen}|{Distance}|{KillerPvPKills}|{KillerPvPDeaths}|{KillerPvPKD}|{VictimPvPKills}|{VictimPvPDeaths}|{VictimPvPKD}',
  });
  ok(
    'helios placeholders interpolate names, stats, wallets and ratios',
    placeholderLine === 'FeedKiller|FeedVictim|1|0|1.00|1|1|1|500|1,000|coins|0|Mystery Box|1|0|1.00|0|1|0.00',
    placeholderLine,
  );

  recordPveKill(GUILD, FEED_KILLER);
  recordPveKill(GUILD, FEED_KILLER);
  recordPveDeath(GUILD, FEED_KILLER);
  const pvePlaceholders = formatKillfeed(feedKill, {
    settings: getGuildSettings(GUILD),
    identity: feedIdentity,
    layout: '{KillerPvEKills}|{KillerPvEDeaths}|{KillerPvEKD}|{VictimPvEKills}|{VictimPvEDeaths}|{VictimPvEKD}|{KillerStreak}|{KillerBestStreak}',
  });
  ok('pve placeholders use their own kills and deaths', pvePlaceholders === '2|1|2.00|0|0|0.00|0|3', pvePlaceholders);

  const trackedPlaceholders = formatKillfeed(
    { ...feedKill, distance: 42.4, stolen: 100 },
    { settings: getGuildSettings(GUILD), identity: feedIdentity, layout: '{Distance}|{Stolen}' },
  );
  ok('tracked distance and stolen wallet render their values', trackedPlaceholders === '42m|100', trackedPlaceholders);
  ok(
    'unknown placeholders stay visible instead of vanishing',
    formatKillfeed(feedKill, { settings: getGuildSettings(GUILD), identity: feedIdentity, layout: '{NotAPlaceholder}' }) ===
      '{NotAPlaceholder}',
  );

  getDb()
    .prepare('UPDATE players SET xp = 1234, level = 25, rival_wins = 7 WHERE guild_id = ? AND user_id = ?')
    .run(GUILD, FEED_KILLER);
  const statPlaceholders = formatKillfeed(feedKill, {
    settings: getGuildSettings(GUILD),
    identity: {
      killer: { ...feedIdentity.killer, teamTag: 'ABC', teamName: 'Astro Clan' },
      victim: { ...feedIdentity.victim, teamTag: 'XYZ', teamName: 'Rivals' },
    },
    layout:
      '{KillerXP}|{KillerLevel}|{KillerRank}|{KillerRankIcon}|{KillerRivalPoints}|{KillerClanTag}|{KillerTeamTag}|{KillerTeamName}|{VictimRank}|{VictimClanTag}|{VictimTeamName}',
  });
  ok(
    'xp, rank, rival points and clan/team tags render',
    statPlaceholders === '1,234|25|Silver|silver|7|[ABC]|ABC|Astro Clan|Stone|[XYZ]|Rivals',
    statPlaceholders,
  );

  patchGuildSetting(GUILD, 'killfeed.embed', true, { actorId: ALICE });
  patchGuildSetting(GUILD, 'channels.killfeed', 'killfeed-embed', { actorId: ALICE });
  const embedFeed = [];
  await dispatchKillfeed({
    client: {
      channels: {
        fetch: async (id) => ({ id, isTextBased: () => true, send: async (payload) => embedFeed.push(payload) }),
      },
    },
    event: feedKill,
    serverLabel: 'Embed',
  });
  ok(
    'killfeed embeds attach the killer rank badge icon',
    embedFeed[0]?.embeds?.[0]?.data?.thumbnail?.url === 'attachment://silver.png' &&
      embedFeed[0]?.files?.[0]?.name === 'silver.png',
    JSON.stringify({ embed: embedFeed[0]?.embeds?.[0]?.data, files: embedFeed[0]?.files?.map((file) => file.name) }),
  );
  patchGuildSetting(GUILD, 'killfeed.embed', false, { actorId: ALICE });

  const storedKillId = recordKillfeedEvent({
    guildId: GUILD,
    serverId: 'server-smoke',
    serverLabel: 'Smoke',
    event: kill,
  });
  patchGuildSetting(GUILD, 'channels.globalKillfeed', 'global-killfeed-smoke');
  patchGuildSetting(GUILD, 'killfeed.globalEnabled', true);
  const globalSent = [];
  const globalClient = {
    channels: {
      fetch: async (id) => ({
        id,
        isTextBased: () => true,
        send: async (payload) => globalSent.push(payload),
      }),
    },
  };
  const globalResult = await processGlobalKillfeed({ client: globalClient });
  const storedKill = getKillfeedEvent(storedKillId);
  ok(
    'local kills are stored and published by the 5-second global feed',
    GLOBAL_KILLFEED_INTERVAL_MS === 5_000 &&
      globalResult.posted === 1 &&
      globalSent[0]?.content?.includes('Smoke') &&
      storedKill?.status === 'posted',
    JSON.stringify({ globalResult, storedKill }),
  );
  ok(
    'global killfeed rejects malformed and stale rows',
    Boolean(validateKillfeedEvent({ ...storedKill, killer_name: '' })) &&
      Boolean(validateKillfeedEvent({ ...storedKill, occurred_at: Date.now() - 25 * 60 * 60 * 1000 })),
  );

  // The killfeed is formatted after stats are written, so the same kill shows
  // the new PvP totals and the wallet amount it is about to take.
  patchGuildSetting(GUILD, 'channels.killfeed', 'killfeed-placeholder', { actorId: ALICE });
  patchGuildSetting(
    GUILD,
    'killfeed.layout',
    '{KillerPlayerName} eliminated {VictimPlayerName} · {KillerPvPKills} PvP kills · {VictimPvPDeaths} PvP deaths · {Stolen} stolen · {Distance}',
    { actorId: ALICE },
  );
  const placeholderFeed = [];
  const placeholderRouter = new TelemetryRouter({
    client: {
      channels: {
        fetch: async (id) => ({ id, isTextBased: () => true, send: async (payload) => placeholderFeed.push(payload) }),
      },
      guilds: { cache: new Map() },
    },
    rconManager: {},
  });
  await placeholderRouter.handleKill({ id: 'placeholder-server', label: 'Placeholder' }, feedKill);
  ok(
    'telemetry fills placeholders after recording the kill',
    placeholderFeed[0]?.content?.includes('FeedKiller eliminated FeedVictim') &&
      placeholderFeed[0]?.content?.includes('2 PvP kills') &&
      placeholderFeed[0]?.content?.includes('2 PvP deaths') &&
      placeholderFeed[0]?.content?.includes('100 stolen') &&
      placeholderFeed[0]?.content?.includes('Mystery Box'),
    placeholderFeed[0]?.content,
  );

  const telemetry = new TelemetryRouter({
    client: { channels: { fetch: async () => null }, guilds: { cache: new Map() } },
    rconManager: {},
  });
  await telemetry.handleKill(
    { id: 'telemetry-smoke', label: 'Telemetry' },
    {
      ...kill,
      killer: { name: 'TelemetryKiller' },
      victim: { name: 'TelemetryVictim' },
      coordinates: null,
    },
  );
  const telemetryRow = getDb()
    .prepare('SELECT * FROM killfeed_events WHERE server_id = ? ORDER BY created_at DESC LIMIT 1')
    .get('telemetry-smoke');
  ok(
    'telemetry persists every local kill before display filters',
    telemetryRow?.killer_name === 'TelemetryKiller' && telemetryRow?.status === 'pending',
    JSON.stringify(telemetryRow),
  );

  // --- protection --------------------------------------------------------
  ok('circle zones contain a point', withinZone({ type: 'circle', x: 0, z: 0, radius: 50 }, { x: 10, z: 10 }));
  ok('circle zones reject outside points', !withinZone({ type: 'circle', x: 0, z: 0, radius: 50 }, { x: 90, z: 10 }));

  const srpSettings = {
    orp: { srpEnabled: true, srpWindows: [{ days: [new Date().getUTCDay()], startHour: 0, endHour: 24 }], zorpEnabled: true, zorpDamageReduction: 75 },
  };
  ok('SRP window is evaluated', isSrpActive(srpSettings, new Date()));

  const zorp = evaluateProtection({
    settings: srpSettings,
    team: { id: 't1' },
    onlineMembers: 0,
    zone: { type: 'circle', x: 0, z: 0, radius: 100 },
    damage: 200,
    point: { x: 5, z: 5 },
  });
  ok('ZORP reduces damage while offline', zorp.reductionPercent === 75 && zorp.appliedDamage === 50, JSON.stringify(zorp));

  // --- games -------------------------------------------------------------
  const shoe = [];
  const bj = startRound({ wager: 100, shoe });
  ok('blackjack deals two cards each', bj.player.length === 2 && bj.dealer.length === 2);
  if (bj.status === 'player') hit(bj);
  const bjView = renderState(bj);
  ok('blackjack renders totals', typeof bjView.playerTotal === 'number' && bjView.dealerTotal !== undefined);

  const dice = rollDice({ wager: 50, choice: 'seven' });
  ok('dice produces a valid total', dice.total >= 2 && dice.total <= 12);
  ok('dice payout follows the seven multiplier', dice.won === (dice.total === 7));

  const slots = spinSlots({ wager: 25 });
  ok('slots spin three reels', slots.reels.length === 3);

  const wheel = spinWheel({ wager: 25 });
  ok('wheel returns a known segment', typeof wheel.multiplier === 'number' && wheel.segment.length > 0);

  const tower = startTower({ wager: 100 });
  climb(tower);
  if (tower.status === 'climbing' && tower.floor > 0) cashOut(tower);
  ok('tower advances or ends deterministically', tower.floor >= 0 && ['climbing', 'fell', 'cashed_out', 'summit'].includes(tower.status));

  const uno = startUno({ wager: 100 });
  ok('uno deals seven cards', uno.player.length === 7 && uno.bot.length === 7);
  ok('uno exposes playable cards', Array.isArray(playableIndexes(uno)));

  const mines = startMines({ wager: 100, mines: 3 });
  ok(
    'mines starts with a 20-tile board and three mines',
    MINES_TILES === 20 && mines.minePositions.length === 3 && mines.status === 'playing',
  );
  const safeTile = [...Array(MINES_TILES).keys()].find((index) => !mines.minePositions.includes(index));
  revealMine(mines, safeTile);
  ok('mines raises the multiplier after a safe reveal', mines.safeRevealed === 1 && mines.multiplier > 1);
  cashOutMines(mines);
  ok('mines cash-out locks a payout', mines.status === 'cashed_out' && mines.payout > 0);

  const crash = startCrash({ wager: 100 });
  ok('crash starts at 1x with a valid crash point', crash.status === 'running' && crash.multiplier === 1 && crash.crashPoint >= 1);
  ok('crash multiplier rises over time', crashMultiplierAt(5_000) > 1);
  tickCrash(crash, crash.startedAt + CRASH_MAX_MS);
  ok('crash ends by crash or timeout', crash.status === 'crashed', crash.status);

  ok(
    'roulette parses outside, dozen and straight-number bets',
    parseRouletteBet('red').type === 'red' &&
      parseRouletteBet('dozen2').value === 2 &&
      parseRouletteBet('17').value === 17,
  );
  const roulette = spinRoulette({ wager: 100, bet: 'red' });
  ok(
    'roulette returns a valid European wheel result',
    roulette.number >= 0 && roulette.number <= 36 && ['red', 'black', 'green'].includes(roulette.color) && typeof roulette.won === 'boolean',
  );

  const plinko = dropPlinko({ wager: 100 });
  ok(
    'plinko follows an eight-row path into a known bucket',
    PLINKO_ROWS === 8 && plinko.path.length === 8 && plinko.bucket >= 0 && plinko.bucket < PLINKO_MULTIPLIERS.length && PLINKO_MULTIPLIERS.includes(plinko.multiplier),
  );

  const jackpot = getJackpot(GUILD);
  const contributedJackpot = contributeJackpot({ guildId: GUILD, wager: 1_000, game: 'slots' });
  ok('progressive jackpot accrues a two-percent rake', contributedJackpot.balance === jackpot.balance + 20);
  const jackpotWin = awardJackpot({ guildId: GUILD, userId: ALICE, game: 'slots' });
  ok(
    'progressive jackpot pays out and reseeds',
    jackpotWin?.amount === contributedJackpot.balance && getJackpot(GUILD).balance === JACKPOT_SEED,
  );
  const jackpotHistory = getJackpotHistory(GUILD, 5);
  ok(
    'jackpot history records the winner, game and amount',
    JACKPOT_ODDS.slots > 2_500 &&
      jackpotHistory[0]?.userId === ALICE &&
      jackpotHistory[0]?.game === 'slots' &&
      jackpotHistory[0]?.amount === jackpotWin?.amount,
  );

  const milestoneMessages = [];
  const milestoneClient = {
    channels: {
      fetch: async (id) => ({
        id,
        send: async (payload) => milestoneMessages.push(payload),
      }),
    },
  };
  patchGuildSetting(GUILD, 'games.jackpot.milestoneThreshold', 2_510, { actorId: ALICE });
  patchGuildSetting(GUILD, 'games.jackpot.milestoneChannelId', '900000000000000010', { actorId: ALICE });
  const milestoneContribution = contributeJackpot({
    guildId: GUILD,
    wager: 1_000,
    game: 'slots',
    client: milestoneClient,
  });
  const milestoneAnnouncement = await milestoneContribution.milestoneAnnouncement;
  ok(
    'jackpot milestone announces when the pool crosses the threshold',
    milestoneContribution.milestone?.threshold === 2_510 &&
      milestoneAnnouncement?.announced === true &&
      milestoneMessages.length === 1,
  );
  const aboveMilestone = contributeJackpot({
    guildId: GUILD,
    wager: 1_000,
    game: 'slots',
    client: milestoneClient,
  });
  ok('jackpot milestone does not repeat while above the threshold', !aboveMilestone.milestone);

  credit({ guildId: GUILD, userId: ALICE, amount: 1_000 });
  credit({ guildId: GUILD, userId: BOB, amount: 1_000 });
  credit({ guildId: GUILD, userId: CAROL, amount: 1_000 });
  buyJackpotTicket({ guildId: GUILD, userId: ALICE, tierId: 'gold' });
  buyJackpotTicket({ guildId: GUILD, userId: BOB, tierId: 'silver' });
  buyJackpotTicket({ guildId: GUILD, userId: CAROL, tierId: 'bronze' });
  const raffleState = getJackpotDrawState(GUILD, ALICE);
  ok(
    'jackpot raffle ticket tiers add configured entries and pool',
    raffleState.balance === 850 &&
      raffleState.tickets === 3 &&
      raffleState.entries === 11 &&
      raffleState.participants === 3 &&
      raffleState.userEntries === 7,
    JSON.stringify(raffleState),
  );

  const raffleDraw = drawJackpot({ guildId: GUILD, actorId: ALICE });
  const raffleHistory = getJackpotDrawHistory(GUILD, 1)[0];
  ok(
    'jackpot raffle draws three unique winners and pays pool shares',
    raffleDraw.winners.length === 3 &&
      new Set(raffleDraw.winners.map((winner) => winner.userId)).size === 3 &&
      raffleDraw.winners.reduce((sum, winner) => sum + winner.amount, 0) === 850 &&
      raffleDraw.remaining === 0 &&
      raffleHistory?.winners.length === 3,
    JSON.stringify({ raffleDraw, raffleHistory }),
  );

  const plainEmbed = buildEmbed({ title: 'Brand check', description: 'No default author' }).toJSON();
  ok('embeds omit the default ASTROBOT author', !plainEmbed.author && plainEmbed.title === 'Brand check');

  const pools = structuredClone(getGameConfig(GUILD).prizePools);
  pools.blackjack = { enabled: true, prizes: [321, 654] };
  patchGuildSetting(GUILD, 'games.prizePools', pools, { actorId: ALICE });
  const prizeBefore = balances(GUILD, ALICE).wallet;
  const gamePrize = awardGamePrize({ guildId: GUILD, userId: ALICE, game: 'blackjack', won: true });
  ok(
    'game prize pools award a random configured amount',
    Boolean(gamePrize) &&
      [321, 654].includes(gamePrize.amount) &&
      balances(GUILD, ALICE).wallet === prizeBefore + gamePrize.amount,
    JSON.stringify(gamePrize),
  );
  ok(
    'game prize pools stay optional per game',
    awardGamePrize({ guildId: GUILD, userId: ALICE, game: 'dice', won: true }) === null,
  );
  pools.blackjack = { enabled: false, prizes: [] };
  patchGuildSetting(GUILD, 'games.prizePools', pools, { actorId: ALICE });

  await okAsync('new casino games produce valid state and card views', async () => {
    const loot = openLootbox({ wager: 100 });
    const defuse = startDefuse({ wager: 100 });
    cutWire(defuse, defuse.bombIndex);
    const field = startMinefield({ wager: 100 });
    revealMinefield(field, 0);
    const recycler = spinRecycler({ wager: 100 });
    const range = fireRange({ wager: 100, weapon: 'rifle' });
    const scratchTheme = SCRATCH_THEMES['scratch-radiation'];
    const scratch = startScratch({ wager: 100, themeId: scratchTheme.id });

    if (loot.game !== 'lootbox' || !loot.loot?.label) throw new Error('lootbox result is incomplete');
    if (defuse.status !== 'exploded') throw new Error(`defuse did not resolve: ${defuse.status}`);
    if (!['playing', 'blown'].includes(field.status)) throw new Error(`minefield did not resolve: ${field.status}`);
    if (recycler.reels.length !== 3 || recycler.game !== 'recycler') throw new Error('recycler result is incomplete');
    if (range.game !== 'range' || range.shots.length !== 5) throw new Error('range result is incomplete');
    if (!Object.keys(RANGE_WEAPONS).includes(range.weapon)) throw new Error('range weapon is invalid');
    if (scratch.grid.length !== 9 || scratch.grid.filter((symbol) => symbol === scratchTheme.target).length !== 3) {
      throw new Error('scratch card does not contain exactly three targets');
    }

    const [firstTarget, secondTarget, thirdTarget] = scratch.targetPositions;
    scratchCell(scratch, firstTarget);
    scratchCell(scratch, secondTarget);
    const junkIndex = scratch.grid.findIndex(
      (symbol, index) => symbol !== scratchTheme.target && !scratch.revealed[index],
    );
    scratchCell(scratch, junkIndex);
    scratchCell(scratch, thirdTarget);
    if (
      scratch.status !== 'matched' ||
      scratch.clickCount !== 4 ||
      scratch.multiplier !== scratchTheme.multipliers[1] ||
      scratch.payout !== 700 ||
      !scratch.won
    ) {
      throw new Error(`scratch card did not settle correctly: ${JSON.stringify(scratch)}`);
    }

    for (const theme of Object.values(SCRATCH_THEMES)) {
      const card = startScratch({ wager: 100, themeId: theme.id });
      if (card.grid.filter((symbol) => symbol === theme.target).length !== 3 || card.revealed.length !== 9) {
        throw new Error(`scratch theme ${theme.id} generated an invalid card`);
      }
    }

    const payloads = [
      lootboxView(loot),
      defuseView(defuse, 'smoke-defuse'),
      minefieldView(field, 'smoke-minefield'),
      recyclerView(recycler),
      rangeView(range),
      scratchView(scratch, 'smoke-scratch'),
    ];
    for (const payload of payloads) {
      if (!payload.embeds?.length) throw new Error('new game view has no embed');
      if ((payload.components ?? []).length > 5) throw new Error('new game view exceeds five action rows');
    }

    const blackjack = await blackjackView(startRound({ wager: 100 }), 'smoke-blackjack');
    if (!blackjack.files?.length || blackjack.embeds[0].data.image?.url !== 'attachment://blackjack-board.png') {
      throw new Error('blackjack did not render its playing-card board');
    }

    const uno = startUno({ wager: 100 });
    uno.turn = 'player';
    uno.status = 'playing';
    uno.activeColor = 'red';
    uno.discard = [{ color: 'red', value: '9', wild: false }];
    uno.player = [{ color: 'red', value: '5', wild: false }];
    const unoPayload = await unoView(uno, 'smoke-uno');
    const selectId = String(unoPayload.components?.[0]?.components?.[0]?.data?.custom_id ?? '');
    if (!selectId.includes(':card:')) throw new Error('UNO did not expose a card selector');
    if (!unoPayload.files?.length || unoPayload.embeds[0].data.image?.url !== 'attachment://uno-board.png') {
      throw new Error('UNO did not render its card board');
    }

    uno.pendingWildIndex = 0;
    uno.player = [{ color: 'wild', value: 'wild', wild: true }];
    const wildPayload = await unoView(uno, 'smoke-uno-wild');
    const colorButtons = wildPayload.components?.[0]?.components ?? [];
    if (colorButtons.length !== 5 || !String(colorButtons[0].data.custom_id).includes(':color-red:')) {
      throw new Error('UNO did not expose wild-color controls');
    }
  });

  await okAsync('scratch card buttons reveal cells and pay out through the game router', async () => {
    const sessionId = 'smoke-scratch-router';
    const theme = SCRATCH_THEMES['scratch-voltage'];
    const state = startScratch({ wager: 100, themeId: theme.id });
    createSession(sessionId, { userId: ALICE, guildId: GUILD, game: theme.id, state, wager: 100, settled: false });

    const ctxFor = (index) => ({
      args: ['scratch', `scratch${index}`, sessionId],
      userId: ALICE,
      guildId: GUILD,
      update: (payload) => payload,
    });

    for (const index of state.targetPositions.slice(0, 2)) await gamePanel.execute(ctxFor(index));
    if (state.targetsFound !== 2 || state.status !== 'playing') {
      throw new Error(`scratch router did not reveal targets: ${state.status}/${state.targetsFound}`);
    }

    const before = balances(GUILD, ALICE).wallet;
    await gamePanel.execute(ctxFor(state.targetPositions[2]));
    if (state.status !== 'matched' || state.clickCount !== 3 || state.payout !== 1_000) {
      throw new Error(`scratch router did not settle correctly: ${state.status}/${state.clickCount}/${state.payout}`);
    }
    if (balances(GUILD, ALICE).wallet !== before + state.payout) {
      throw new Error('scratch payout was not credited by the game router');
    }
  });

  const statsNow = Date.now();
  recordLiveStats({ serverId: 'smoke-live-a', guildId: GUILD, players: 6, queue: 2, updatedAt: statsNow });
  recordLiveStats({ serverId: 'smoke-live-b', guildId: GUILD, players: 4, queue: 1, updatedAt: statsNow });
  recordLiveStats({ serverId: 'smoke-live-stale', guildId: GUILD, players: 99, queue: 99, updatedAt: statsNow - 300_000 });
  const totals = liveTotals({ guildId: GUILD, now: statsNow, staleMs: 60_000 });
  ok(
    'global player/queue totals come from fresh database snapshots',
    totals.players === 10 && totals.queue === 3,
    JSON.stringify(totals),
  );
  ok('global stats line uses player and queue counts', statsLine(totals.players, totals.queue) === '🌐 10｜⏰ 3');

  // --- panels ------------------------------------------------------------

  // --- rust item catalog -------------------------------------------------
  const catalog = allRustItems();
  ok('Rust item catalog loads', catalog.length === 1207, `loaded ${catalog.length}`);

  const rifle = getRustItem('rifle.ak');
  ok('catalog resolves shortnames', rifle?.name === 'Assault Rifle', JSON.stringify(rifle));
  ok('catalog carries item images', String(rifle?.image ?? '').startsWith('https://'), rifle?.image ?? 'none');
  ok('catalog search matches display names', searchRustItems('assault rifle')[0]?.shortname === 'rifle.ak');
  ok('catalog search ignores case and partial words', searchRustItems('ASSAULT RIF')[0]?.shortname === 'rifle.ak');

  const deliveryCommand = buildItemCommand({ gamertag: 'Bob "The Builder"', shortname: 'rifle.ak', quantity: 2 });
  ok(
    'item delivery command quotes player and shortname',
    deliveryCommand === 'inventory.giveto "Bob The Builder" "rifle.ak" 2',
    deliveryCommand,
  );

  const kitCommand = buildKitCommand({ kitName: 'Starter Kit', gamertag: 'AliceXbox' });
  ok(
    'kit delivery uses the documented givetoplayer order',
    kitCommand === 'kit givetoplayer "Starter Kit" "AliceXbox"',
    kitCommand,
  );

  ok(
    'stock helpers handle limited and unlimited products',
    stockOf({ stock: 3 }) === 3 &&
      stockOf({}) === null &&
      isSoldOut({ stock: 0 }) &&
      !isSoldOut({}) &&
      stockLabel({ stock: 3 }) === '3 left' &&
      stockLabel({}) === 'unlimited',
  );

  const categoryGroups = groupByCategory([{ id: 'a', category: 'Weapons' }, { id: 'b' }, { id: 'c', category: 'Weapons' }]);
  ok(
    'products group by category',
    categoryGroups.length === 2 &&
      categoryGroups[0].category === 'Weapons' &&
      categoryGroups[0].entries.length === 2 &&
      categoryGroups[1].category === 'General',
    JSON.stringify(categoryGroups.map((group) => group.category)),
  );

  const quickBase = quickSetupPreview({ tier: 'mid', currency: 'coins', roleId: null, tier3: false, explosives: false });
  const quickFull = quickSetupPreview({ tier: 'mid', currency: 'coins', roleId: null, tier3: true, explosives: true });
  ok(
    'quick setup hides Tier 3 and explosives by default',
    !quickBase.products.some((product) => product.shortname === 'rifle.ak') &&
      !quickBase.products.some((product) => product.category === 'Explosives'),
    JSON.stringify({ base: quickBase.products.length, full: quickFull.products.length }),
  );
  ok(
    'quick setup builds the full catalog shop when enabled',
    quickBase.categories.length >= 10 &&
      quickBase.products.length >= 900 &&
      quickFull.products.length > quickBase.products.length,
    JSON.stringify({ base: quickBase.products.length, full: quickFull.products.length }),
  );
  ok(
    'quick setup keeps every catalog item priced and categorised',
    quickBase.products.every((product) => product.category && product.price > 0),
    quickBase.products.filter((product) => !product.category || product.price <= 0).map((product) => product.shortname).join(', '),
  );
  ok(
    'quick setup resolves real catalog items with images',
    quickFull.products.every((product) => product.shortname && product.name && product.image),
    quickFull.products.filter((product) => !product.image).map((product) => product.shortname).join(', '),
  );
  ok(
    'quick setup includes weapons, ammo and explosives categories',
    ['Weapons', 'Ammo', 'Explosives'].every((category) =>
      quickFull.categories.some((entry) => entry.category === category),
    ),
    JSON.stringify(quickFull.categories.map((entry) => entry.category)),
  );

  const quickCheap = quickSetupPreview({ tier: 'cheap', roleId: null, tier3: false, explosives: false });
  const quickExpensive = quickSetupPreview({ tier: 'expensive', roleId: null, tier3: false, explosives: false });
  ok(
    'price tiers scale the generated prices',
    quickCheap.products[0].price < quickBase.products[0].price &&
      quickExpensive.products[0].price > quickBase.products[0].price,
    JSON.stringify([quickCheap.products[0].price, quickBase.products[0].price, quickExpensive.products[0].price]),
  );
  ok(
    'quick setup covers the whole Rust item catalog when enabled',
    quickFull.products.length >= 1000 && quickFull.products.some((product) => product.shortname === 'rifle.ak'),
    `${quickFull.products.length}`,
  );

  ok(
    'auto pricing values scarce high-tier items above resources',
    autoPrice(getRustItem('rifle.ak'), 'Weapons') > autoPrice(getRustItem('wood'), 'Resources'),
    JSON.stringify([autoPrice(getRustItem('rifle.ak'), 'Weapons'), autoPrice(getRustItem('wood'), 'Resources')]),
  );
  ok(
    'price multipliers default from settings',
    priceMultipliers(getGuildSettings(GUILD)).mid === 1,
    JSON.stringify(priceMultipliers(getGuildSettings(GUILD))),
  );
  ok(
    'clan ranks use icon style v1 and personal ranks use style v2',
    clanRankIcon('leader') === 'leader' &&
      clanRankIcon('unknown') === 'member' &&
      personalRank(5).key === 'stone' &&
      personalRank(100).key === 'elite' &&
      personalBadgeIcon('hunter') === 'hunter',
  );

  ok(
    'every rank and badge icon ships as a real PNG',
    BADGE_ICON_KEYS.every((key) => {
      const file = badgeIconPath(key);
      return badgeExists(file) && readBadgeFile(file).subarray(0, 4).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47]));
    }),
    `${BADGE_ICON_KEYS.length} icons`,
  );

  await okAsync('clan leaders can create, edit and delete ranks', async () => {
    const created = createClanRank(GUILD, { label: 'Warlord', icon: 'raider' }, { actorId: ALICE });
    if (created.key !== 'warlord') throw new Error(JSON.stringify(created));

    updateClanRank(GUILD, 'warlord', { label: 'Warlord Prime', icon: 'veteran' }, { actorId: ALICE });
    const edited = clanRanks(GUILD).find((rank) => rank.key === 'warlord');
    if (edited?.label !== 'Warlord Prime' || edited?.icon !== 'veteran') throw new Error(JSON.stringify(edited));

    deleteClanRank(GUILD, 'warlord', { actorId: ALICE });
    if (clanRanks(GUILD).some((rank) => rank.key === 'warlord')) throw new Error('rank was not deleted');
    if (!clanRanks(GUILD).some((rank) => rank.key === 'leader')) throw new Error('default ranks were lost');

    let blocked = false;
    try {
      deleteClanRank(GUILD, 'leader', { actorId: ALICE });
    } catch {
      blocked = true;
    }
    if (!blocked) throw new Error('the leader rank was deleted');
  });

  await okAsync('staff can award and revoke badges', async () => {
    const definition = badgeDefinition(GUILD, 'hunter');
    if (!definition) throw new Error('built-in badge missing');

    awardBadge({ guildId: GUILD, userId: ALICE, badgeId: definition.id, awardedBy: BOB });
    if (!badgesFor(GUILD, ALICE).some((badge) => badge.badge_id === 'hunter')) throw new Error('badge was not awarded');

    revokeBadge({ guildId: GUILD, userId: ALICE, badgeId: definition.id });
    if (badgesFor(GUILD, ALICE).some((badge) => badge.badge_id === 'hunter')) throw new Error('badge was not revoked');
  });

  ok(
    'badge uploads reject non-images and oversized files',
    (() => {
      const rejects = (input) => {
        try {
          validateBadgeUpload(input);
          return false;
        } catch {
          return true;
        }
      };
      return (
        rejects({ contentType: 'text/plain', size: 100 }) &&
        rejects({ contentType: 'image/png', size: 5_000_000 }) &&
        !rejects({ contentType: 'image/png', size: 1000 })
      );
    })(),
  );

  await okAsync('clan badge icons upload, list and delete', async () => {
    const guildId = `${GUILD}9`;
    const badge = addClanBadge({
      guildId,
      label: 'Test emblem',
      buffer: readBadgeFile(badgeIconPath('gold')),
      contentType: 'image/png',
      actorId: ALICE,
    });
    if (!badgeExists(badge.file)) throw new Error('badge file missing');
    if (!listClanBadges(guildId).some((entry) => entry.id === badge.id)) throw new Error('badge not listed');

    removeClanBadge(guildId, badge.id, { actorId: ALICE });
    if (listClanBadges(guildId).some((entry) => entry.id === badge.id)) throw new Error('badge not deleted');
  });

  ok(
    'built-in templates ship complete roles, categories and channels',
    TEMPLATE_PRESETS.length >= 2 &&
      new Set(TEMPLATE_PRESETS.map((entry) => entry.id)).size === TEMPLATE_PRESETS.length &&
      new Set(TEMPLATE_PRESETS.map((entry) => entry.name)).size === TEMPLATE_PRESETS.length &&
      TEMPLATE_PRESETS.every((entry) => {
        const payload = entry.payload;
        const categories = new Set(payload.categories.map((category) => category.name.toLowerCase()));
        return (
          entry.id.startsWith('preset:') &&
          payload.roles.length > 0 &&
          payload.categories.length > 0 &&
          payload.channels.length > 0 &&
          payload.roles.every((item) => item.name && /^\d+$/.test(item.permissions)) &&
          payload.channels.every(
            (channel) =>
              channel.name &&
              [0, 2, 5, 15].includes(channel.type) &&
              categories.has(String(channel.parentName ?? '').toLowerCase()),
          )
        );
      }),
  );

  ok(
    'every built-in template includes the essential roles, categories, channels and panels',
    TEMPLATE_PRESETS.every((entry) => {
      const payload = entry.payload;
      const roleNames = (payload.roles ?? []).map((item) => String(item.name ?? ''));
      const categoryNames = (payload.categories ?? []).map((item) => String(item.name ?? ''));
      const channelNames = (payload.channels ?? []).map((item) => String(item.name ?? ''));
      const hasRole = (pattern) => roleNames.some((name) => pattern.test(name));
      const hasCategory = (pattern) => categoryNames.some((name) => pattern.test(name));
      const hasChannel = (pattern) => channelNames.some((name) => pattern.test(name));
      const panelTypes = new Set(planTemplatePanels(payload).map((panel) => panel.type));

      return (
        roleNames.length >= 4 &&
        hasRole(/\b(admin|administrator)s?\b/i) &&
        hasRole(/\b(moderator|mod)s?\b/i) &&
        hasRole(/\b(staff|support team|support|manager|producer)\b/i) &&
        hasRole(/\bmember\b/i) &&
        categoryNames.length >= 3 &&
        hasCategory(/info|information|start|welcome|rules|announcement|official/i) &&
        hasCategory(/community|general|chat|lobby|talk/i) &&
        hasCategory(/staff|moderation|management|team|operations/i) &&
        channelNames.length >= 9 &&
        hasChannel(/welcome|start.here|introductions?/i) &&
        hasChannel(/rules|guidelines/i) &&
        hasChannel(/announcement|news|updates/i) &&
        hasChannel(/\b(general|talk)\b|main.chat|community.chat/i) &&
        hasChannel(/\b(support|tickets?)\b/i) &&
        hasChannel(/\b(shop|store)\b/i) &&
        hasChannel(/staff.chat|team.chat|management.chat|mod.chat|moderator.chat|admin.chat/i) &&
        hasChannel(/staff.logs|mod.logs|moderation.logs|admin.logs|network.logs|bot.logs|audit|security.logs/i) &&
        ['support', 'shop'].every((type) => panelTypes.has(type))
      );
    }),
  );

  ok(
    'every template ships staff tiers and kit roles, and the official layout exists',
    (() => {
      const required = ['server owner', 'server admin', 'server moderator', 'freekit', 'elitekit1', 'elitekit44'];
      const official = getPresetTemplate('astro-official');
      return (
        official?.name === 'AstroBot Official' &&
        getPresetTemplate('preset-astro-official')?.id === 'preset:astro-official' &&
        TEMPLATE_PRESETS.every((entry) => {
          const names = new Set((entry.payload.roles ?? []).map((role) => String(role.name ?? '').toLowerCase()));
          return required.every((name) => names.has(name));
        })
      );
    })(),
  );

  ok(
    'template sections filter what an apply creates and keep parents for channels',
    (() => {
      const preset = getPresetTemplate('minimal');
      const channelsOnly = filterTemplateParts(preset.payload, ['channels']);
      const rolesOnly = filterTemplateParts(preset.payload, ['roles']);
      return (
        channelsOnly.roles.length === 0 &&
        channelsOnly.categories.length === preset.payload.categories.length &&
        channelsOnly.channels.length === preset.payload.channels.length &&
        channelsOnly.panels.length === 0 &&
        rolesOnly.channels.length === 0 &&
        decodeTemplateSections(encodeTemplateSections(['roles', 'channels'])).join(',') === 'roles,channels'
      );
    })(),
  );

  await okAsync('confirmed apply wipes channels, categories and removable roles first', async () => {
    const deleted = [];
    const guild = {
      id: 'wipe-guild',
      members: { me: { roles: { highest: { position: 5 } } } },
      channels: {
        fetch: async () =>
          new Collection([
            ['c1', { id: 'c1', name: 'general', type: ChannelType.GuildText, delete: async () => deleted.push('channel') }],
            ['cat', { id: 'cat', name: 'Info', type: ChannelType.GuildCategory, delete: async () => deleted.push('category') }],
          ]),
      },
      roles: {
        fetch: async () =>
          new Collection([
            ['r1', { id: 'r1', name: 'Member', position: 1, managed: false, delete: async () => deleted.push('role') }],
            ['r2', { id: 'r2', name: 'AstroBot', position: 5, managed: false, delete: async () => deleted.push('bot-role') }],
            ['r3', { id: 'r3', name: 'Integration', position: 2, managed: true, delete: async () => deleted.push('managed') }],
          ]),
      },
    };

    const result = await wipeGuildStructure(guild);
    if (result.channelsDeleted !== 2) throw new Error(`channels ${result.channelsDeleted}`);
    if (result.rolesDeleted !== 1) throw new Error(`roles ${result.rolesDeleted}`);
    if (deleted.includes('bot-role') || deleted.includes('managed')) throw new Error('a protected role was deleted');
  });

  ok(
    'built-in template ids resolve with and without the preset prefix',
    Boolean(getPresetTemplate('preset:rust-community')) &&
      getPresetTemplate('rust-community')?.name === 'Rust Console Community' &&
      getPresetTemplate('preset-rust-community')?.name === 'Rust Console Community' &&
      getPresetTemplate('preset-astrobot-network')?.name === 'AstroBot Network' &&
      getPresetTemplate('missing') === null,
  );

  ok(
    'astrobot network layout ships map hubs, VIP rooms and staff-only areas',
    (() => {
      const preset = getPresetTemplate('astrobot-network');
      if (!preset) return false;
      const channels = preset.payload.channels;
      const byName = (name) => channels.find((channel) => channel.name === name);
      return (
        Boolean(byName('💀・killfeed')) &&
        Boolean(byName('🌐｜⏰・global-players-queue')) &&
        Boolean(byName('👑・map-owner-commands')) &&
        Boolean(byName('⚙️・map-admin-commands')) &&
        Boolean(byName('🔨・map-mod-commands')) &&
        Boolean(byName('👑・astro-owner-commands')) &&
        byName('💎・vip-chat')?.overwrites.some((entry) => entry.name === '@everyone') &&
        byName('🛡️・admin-chat')?.overwrites.some((entry) => entry.name === '🔨 AstroBot Moderator') &&
        !preset.payload.roles.some((entry) => entry.name === '👑 AstroBot Owner' && entry.permissions === '8')
      );
    })(),
  );

  ok(
    'official library ships all six server-owner and creator layouts',
    ['rust-standard', 'rust-professional', 'rust-network', 'gaming-streamer', 'content-creator', 'brand-community'].every(
      (id) => Boolean(getPresetTemplate(id)),
    ) && TEMPLATE_PRESETS.length >= 9,
  );

  await okAsync('owners can build and save a template in the bot', async () => {
    const guildId = `${GUILD}5`;
    resetTemplateDraft(guildId, ALICE);

    addDraftCategory(guildId, ALICE, { name: 'Test Category' });
    addDraftRole(guildId, ALICE, { name: 'Test Role', color: '#8b5cf6', permissions: 'kick_members', hoist: 'yes' });
    addDraftChannel(guildId, ALICE, { name: 'test-chat', type: 'text', category: 'Test Category' });
    addDraftChannel(guildId, ALICE, { name: 'Test VC', type: 'voice', category: 'Test Category' });

    const draft = templateDraft(guildId, ALICE);
    if (draft.roles[0].permissions !== '2' || !draft.roles[0].hoist) throw new Error(JSON.stringify(draft.roles[0]));

    const payload = buildTemplatePayload(draft);
    if (payload.categories.length !== 1 || payload.channels.length !== 2) throw new Error(JSON.stringify(payload));
    if (payload.channels[0].parentName !== 'Test Category') throw new Error('channel category was not linked');

    const saved = saveTemplateDraft({ guildId, userId: ALICE, actorId: ALICE, name: 'Owner Built', description: 'Built in Discord' });
    if (!listTemplates(guildId).some((template) => template.id === saved.id)) throw new Error('template was not saved');
    deleteTemplate(guildId, saved.id);
  });

  await okAsync('saved templates can be reopened, edited and saved in place', async () => {
    const guildId = `${GUILD}6`;
    resetTemplateDraft(guildId, ALICE);
    addDraftCategory(guildId, ALICE, { name: 'Edit Cat' });
    addDraftChannel(guildId, ALICE, { name: 'edit-chat', type: 'text', category: 'Edit Cat' });
    const first = saveTemplateDraft({ guildId, userId: ALICE, actorId: ALICE, name: 'Editable' });

    const draft = loadTemplateDraft(guildId, ALICE, first);
    if (draft.editingId !== first.id) throw new Error('draft was not linked to the saved template');

    addDraftRole(guildId, ALICE, { name: 'Edit Role', permissions: 'ViewChannel' });
    addDraftOverwrite(guildId, ALICE, {
      targetType: 'channel',
      target: 'edit-chat',
      role: 'Edit Role',
      allow: 'ViewChannel',
      deny: 'SendMessages',
    });

    const removed = removeDraftOverwrite(guildId, ALICE, 'channel', 0, 0);
    if (removed.name !== 'Edit Role') throw new Error('overwrite was not removed');
    addDraftOverwrite(guildId, ALICE, {
      targetType: 'category',
      target: 'Edit Cat',
      role: 'Edit Role',
      allow: 'ViewChannel',
      deny: 'SendMessages',
    });

    const updated = saveTemplateDraft({ guildId, userId: ALICE, actorId: ALICE, name: 'Editable v2' });
    if (updated.id !== first.id) throw new Error('editing created a second template');

    const stored = getTemplate(guildId, first.id);
    if (stored.name !== 'Editable v2') throw new Error('name was not updated');
    if (stored.payload.roles?.[0]?.name !== 'Edit Role') throw new Error('role was not saved');
    if (stored.payload.categories?.[0]?.overwrites?.[0]?.deny !== String(PermissionFlagsBits.SendMessages)) {
      throw new Error('category overwrite was not saved');
    }
    deleteTemplate(guildId, first.id);
  });

  ok(
    'template preview separates new structure from what already exists',
    (() => {
      const guild = { channels: { cache: new Collection() }, roles: { cache: new Collection() } };
      guild.roles.cache.set('role-1', { name: 'Member' });
      guild.channels.cache.set('cat-1', { id: 'cat-1', name: 'Info', type: ChannelType.GuildCategory });
      guild.channels.cache.set('chan-1', { id: 'chan-1', name: 'welcome', type: ChannelType.GuildText, parentId: 'cat-1' });

      const plan = planGuildTemplate(guild, {
        roles: [{ name: 'Member' }, { name: 'Admin' }],
        categories: [{ name: 'Info' }, { name: 'Staff' }],
        channels: [
          { name: 'welcome', type: ChannelType.GuildText, parentName: 'Info' },
          { name: 'rules', type: ChannelType.GuildText, parentName: 'Info' },
        ],
      });

      return (
        plan.roles.length === 1 &&
        plan.categories.length === 1 &&
        plan.channels.length === 1 &&
        plan.existing.roles === 1 &&
        plan.existing.categories === 1 &&
        plan.existing.channels === 1
      );
    })(),
  );

  ok(
    'template panels cover every panel mapped to a template channel',
    (() => {
      const plan = planTemplatePanels({
        panels: [
          { type: 'shop', channelName: 'store' },
          { type: 'tickets', channelName: 'support' },
        ],
        channels: [
          { name: 'store' },
          { name: 'support' },
          { name: 'lfg' },
          { name: 'games' },
          { name: 'clans' },
          { name: 'daily-rewards' },
          { name: 'kits' },
          { name: 'battle-pass' },
          { name: 'leaderboards' },
          { name: 'bounties' },
        ],
      });
      const types = new Set(plan.map((entry) => entry.type));
      const falseMatches = planTemplatePanels({
        channels: [{ name: 'how-to-play' }, { name: 'players-queue' }, { name: 'supporter-recognition' }],
      });
      return (
        types.size === 10 &&
        types.has('support') &&
        !types.has('tickets') &&
        falseMatches.length === 0 &&
        plan.find((entry) => entry.type === 'shop')?.channelName === 'store'
      );
    })(),
  );

  await okAsync('template panel deployment posts buttons that open the panel', async () => {
    const sent = [];
    const channel = {
      id: 'panel-games',
      name: 'games',
      type: ChannelType.GuildText,
      messages: { fetch: async () => new Collection() },
      send: async (payload) => sent.push(payload),
    };
    const guild = { channels: { cache: new Collection([['panel-games', channel]]) } };
    const result = await deployTemplatePanels({
      guild,
      template: { panels: [{ type: 'games', channelName: 'games' }] },
    });
    if (result.posted !== 1 || sent.length !== 1) throw new Error(`posted ${result.posted}, sent ${sent.length}`);
    const entry = sent[0]?.components?.[0]?.components?.[0];
    if (!String(entry?.data?.custom_id ?? '').includes('openpanel')) throw new Error('panel has no entry button');
  });

  await okAsync('layout scan reports missing roles, categories, channels and panels', async () => {
    const channels = new Collection();
    const roles = new Collection();
    const info = { id: 'cat-info', name: 'Info', type: ChannelType.GuildCategory };
    channels.set('cat-info', info);
    channels.set('c-welcome', { id: 'c-welcome', name: 'welcome', type: ChannelType.GuildText, parentId: 'cat-info' });
    channels.set('c-shop', {
      id: 'c-shop',
      name: 'shop',
      type: ChannelType.GuildText,
      parentId: null,
      messages: {
        fetch: async () =>
          new Collection([
            ['m1', { embeds: [{ footer: { text: 'AstroBot panel · shop' } }], components: new Collection([['row', {}]]) }],
          ]),
      },
    });
    roles.set('r-member', { name: 'Member' });
    const guild = {
      id: 'scan-guild',
      channels: { cache: channels, fetch: async () => channels },
      roles: { cache: roles, fetch: async () => roles },
    };

    const scan = await scanGuildLayout(guild, {
      payload: {
        roles: [{ name: 'Member' }, { name: 'Admin' }],
        categories: [{ name: 'Info' }, { name: 'Staff' }],
        channels: [
          { name: 'welcome', type: ChannelType.GuildText, parentName: 'Info' },
          { name: 'rules', type: ChannelType.GuildText, parentName: 'Info' },
        ],
        panels: [{ type: 'shop', channelName: 'shop' }],
      },
    });

    if (scan.roles.join() !== 'Admin') throw new Error(`roles ${scan.roles.join()}`);
    if (scan.categories.join() !== 'Staff') throw new Error(`categories ${scan.categories.join()}`);
    if (scan.channels.map((entry) => entry.name).join() !== 'rules') throw new Error('channels were not scanned');
    if (scan.panels.length !== 0) throw new Error(`existing panel flagged: ${scan.panels.length}`);
    if (scan.missing !== 3) throw new Error(`missing ${scan.missing}`);
  });

  ok(
    'wipe countdown stages announce once and in order',
    (() => {
      const now = 1_700_000_000_000;
      const base = { next_wipe_at: now + 45 * 60_000, countdowns: '60,30,10', announced_stages: '' };
      const first = dueStage(base, now);
      const second = dueStage({ ...base, announced_stages: '60' }, now + 16 * 60_000);
      const last = dueStage({ ...base, announced_stages: '60,30' }, now + 36 * 60_000);
      return first === 60 && second === 30 && last === 10 && parseCountdowns('10, 60, 30, 60').join(',') === '60,30,10';
    })(),
  );

  ok(
    'wipe plan applies the next map rotation entry and restart command',
    (() => {
      const plan = planWipe({
        auto_restart: 1,
        rotate_map: 1,
        rotation_index: 1,
        restart_command: 'restart 120',
        map_rotation: JSON.stringify([{ seed: 111, worldsize: 3000 }, { seed: 222 }]),
      });
      return plan.commands.join('|') === 'server.seed 222|restart 120' && plan.nextIndex === 0 && plan.map.seed === 222;
    })(),
  );

  await okAsync('wipe profiles are scoped per guild and server', async () => {
    const guildA = `${GUILD}7`;
    const guildB = `${GUILD}8`;
    const first = createWipeProfile({
      guildId: guildA,
      serverId: 'srv-a',
      name: 'A wipe',
      intervalHours: 24,
      nextWipeAt: nextWipeAt(Date.now(), 24),
    });
    createWipeProfile({
      guildId: guildB,
      serverId: 'srv-b',
      name: 'B wipe',
      intervalHours: 48,
      nextWipeAt: nextWipeAt(Date.now(), 48),
    });

    const listA = listWipeProfiles(guildA);
    if (listA.length !== 1 || listA[0].name !== 'A wipe') throw new Error('guild scoping failed');
    deleteWipeProfile(first.id);
    if (listWipeProfiles(guildA).length !== 0) throw new Error('delete failed');
  });

  ok('wipe messages accept plain text and HTML', () => {
    const vars = { server: 'Main', minutes: 10, wipe: 'BP wipe', time: '2026-12-01 20:30 UTC' };
    const discord = renderWipeMessage('<b>{server}</b><br>Wipe in <i>{minutes}</i> min', vars, 'discord');
    const game = renderWipeMessage('<b>{server}</b><br>Wipe in <i>{minutes}</i> min', vars, 'game');
    const parsed = parseWipeMessages(JSON.stringify({ first: 'First {minutes}', second: '', third: 'Third', online: 'Online' }));
    return (
      discord === '**Main**\nWipe in *10* min' &&
      game === 'Main Wipe in 10 min' &&
      parsed.first === 'First {minutes}' &&
      parsed.second.includes('{minutes}') &&
      parsed.third === 'Third'
    );
  });

  await okAsync('wipe posts custom Discord and in-game warnings, then announces back online', async () => {
    const now = Date.now();
    const serverId = 'wipe-smoke-server';
    const profile = createWipeProfile({
      guildId: `${GUILD}9`,
      serverId,
      name: 'Smoke wipe',
      intervalHours: 1,
      nextWipeAt: now + 5 * 60_000,
      channelId: 'wipe-channel',
      countdowns: [10],
      restartCommand: 'restart 0',
      wipeMessages: {
        first: '<b>First</b> in {minutes}m',
        second: 'Second',
        third: 'Third',
        online: '<b>{server}</b> back online',
      },
      announceInGame: true,
    });

    const sent = [];
    const commands = [];
    const client = {
      channels: {
        fetch: async () => ({
          send: async (payload) => {
            sent.push(payload);
            return { id: 'wipe-message' };
          },
        }),
      },
    };
    const connection = { serverId, connected: true, send: async (command) => commands.push(command) };
    const rconManager = { connections: new Map([[serverId, connection]]) };

    await tickWipes({ client, rconManager, now });
    if (!sent.some((payload) => String(payload.content).includes('**First** in 10m'))) throw new Error('custom Discord warning missing');
    if (!commands.includes('global.say "First in 10m"')) throw new Error(`in-game warning missing: ${commands.join('|')}`);

    const result = await executeWipe(profile, { client, rconManager, now: now + 6 * 60_000 });
    if (!result.awaitingOnline) throw new Error('wipe did not mark the server as awaiting online');
    if (!commands.includes('restart 0')) throw new Error('restart command not sent');

    const early = await announceServerOnline({ connection, client, now: now + 6 * 60_000 });
    if (early !== 0) throw new Error('announced before the restart delay elapsed');

    const announced = await announceServerOnline({ connection, client, now: now + 7 * 60_000 });
    if (announced !== 1) throw new Error(`online announcement count ${announced}`);
    if (!sent.some((payload) => String(payload.content).includes('back online'))) throw new Error('online message missing');
    if (!commands.some((command) => command.startsWith('global.say "') && command.includes('back online'))) throw new Error('in-game online message missing');

    deleteWipeProfile(profile.id);
  });

  await okAsync('wipe restart command and delay are editable', async () => {
    const profile = createWipeProfile({
      guildId: `${GUILD}10`,
      serverId: 'restart-smoke',
      name: 'Restart smoke',
      intervalHours: 24,
      nextWipeAt: nextWipeAt(Date.now(), 24),
      restartCommand: 'restart 300',
    });
    const ctx = {
      guildId: profile.guild_id,
      guild: { channels: { cache: new Map() } },
      args: ['restart', profile.id],
      isModal: true,
      option: (key) => ({ command: 'restart', delay: '45' })[key],
      panel: (id, params) => ({ id, params }),
    };

    const result = await wipeComponent.execute(ctx);
    const updated = getWipeProfile(profile.id);
    if (result?.params?.selected !== profile.id) throw new Error('panel not returned');
    if (updated.restart_command !== 'restart' || updated.restart_delay !== 45) {
      throw new Error(`saved ${updated.restart_command}/${updated.restart_delay}`);
    }
    if (!planWipe(updated).commands.includes('restart 45')) throw new Error('delay not applied to restart command');
    deleteWipeProfile(profile.id);
  });

  ok(
    'retention summary separates new and returning players',
    (() => {
      const now = 1_700_000_000_000;
      const D = 86_400_000;
      const rows = [
        { gamertag: 'Alice', started_at: now - 2 * D, duration_seconds: 3600 },
        { gamertag: 'Alice', started_at: now - 9 * D, duration_seconds: 1800 },
        { gamertag: 'Bob', started_at: now - 1 * D, duration_seconds: 600 },
        { gamertag: 'Bob', started_at: now - 10 * D, duration_seconds: 600 },
        { gamertag: 'Cara', started_at: now - 3 * D, duration_seconds: 1200 },
      ];
      const summary = summarizeSessions(rows, now, 28);
      return (
        summary.currentWeekPlayers === 3 &&
        summary.returningPlayers === 2 &&
        summary.newPlayers === 1 &&
        summary.retentionPercent === 100 &&
        summary.averageDurationSeconds === 1560 &&
        summary.daily.length === 28
      );
    })(),
  );

  ok(
    'uptime reports online share and incidents',
    (() => {
      const now = 1_700_000_000_000;
      const H = 3_600_000;
      const uptime = computeUptime(
        [
          { status: 'online', created_at: now - 10 * H },
          { status: 'offline', created_at: now - 6 * H },
          { status: 'online', created_at: now - 2 * H },
        ],
        now,
        24 * H,
      );
      return uptime.uptimePercent === 25 && uptime.incidents === 1 && uptime.current === 'online';
    })(),
  );

  await okAsync('RCON presence opens and closes player sessions', async () => {
    const guildId = `${GUILD}9`;
    const started = Date.now() - 120_000;
    const opened = openSession({ guildId, serverId: 'srv-session', gamertag: 'AliceXbox', startedAt: started });
    const closed = closeSession({ guildId, gamertag: 'AliceXbox', endedAt: started + 90_000 });
    if (!opened || !closed) throw new Error('session was not recorded');
    if (closed.duration_seconds !== 90) throw new Error(`duration was ${closed.duration_seconds}`);
    if (listSessions(guildId, 0).length !== 1) throw new Error('session list is wrong');
  });

  await okAsync('server status events drive uptime reporting', async () => {
    const guildId = `${GUILD}10`;
    recordStatus({ guildId, serverId: 'srv-status', status: 'online', players: 4, createdAt: Date.now() - 3_600_000 });
    recordStatus({ guildId, serverId: 'srv-status', status: 'offline', createdAt: Date.now() });
    const events = listStatusEvents(guildId, 0);
    if (events.length !== 2) throw new Error('status events not stored');
    const uptime = computeUptime(events, Date.now());
    if (uptime.current !== 'offline' || uptime.incidents !== 1) throw new Error('status summary wrong');
  });

  await okAsync('tickets carry assignment, SLA and feedback', async () => {
    const guildId = `${GUILD}11`;
    const ticket = createTicket({ guildId, ownerId: ALICE, subject: 'Crash on wipe', priority: 'high', category: 'bug' });
    const assigned = updateTicket(ticket.id, { assigned_to: BOB, sla_due_at: Date.now() + 3_600_000 });
    if (assigned.assigned_to !== BOB || !assigned.sla_due_at) throw new Error('assignment not saved');
    const rated = rateTicket(ticket.id, 5);
    if (rated.rating !== 5) throw new Error('rating not saved');
  });

  await okAsync('cases support evidence, appeals and staff stats', async () => {
    const guildId = `${GUILD}12`;
    const record = createCase({
      guildId,
      targetId: BOB,
      moderatorId: ALICE,
      action: 'ban',
      reason: 'cheating',
      scope: 'network',
      serverId: 'srv-1',
      evidence: 'clip.mp4',
    });
    updateCase(record.id, { appeal_status: 'pending', appeal_ticket_id: 'ticket-1' });

    const [pending] = appealQueue(guildId);
    if (!pending || pending.id !== record.id) throw new Error('appeal queue missed the case');

    const [stats] = staffCaseStats(guildId, 0);
    if (!stats || Number(stats.total) !== 1 || Number(stats.bans) !== 1) throw new Error('staff stats wrong');
  });

  await okAsync('template builder rejects bad entries and removes cleanly', async () => {
    const guildId = `${GUILD}4`;
    resetTemplateDraft(guildId, ALICE);
    addDraftCategory(guildId, ALICE, { name: 'Cat' });
    addDraftRole(guildId, ALICE, { name: 'Role', permissions: '' });

    let rejected = false;
    try {
      addDraftChannel(guildId, ALICE, { name: 'orphan', type: 'text', category: 'Missing' });
    } catch {
      rejected = true;
    }
    if (!rejected) throw new Error('channel with a missing category was accepted');

    removeDraftEntry(guildId, ALICE, 'role', 0);
    removeDraftEntry(guildId, ALICE, 'category', 0);
    if (templateDraft(guildId, ALICE).roles.length !== 0) throw new Error('role was not removed');

    let badPermission = false;
    try {
      parsePermissions('not_a_permission');
    } catch {
      badPermission = true;
    }
    if (!badPermission) throw new Error('unknown permission was accepted');
  });

  await okAsync('quick setup applies configured price multipliers', async () => {
    patchGuildSetting(GUILD, 'shop.priceTiers', { mid: 3 }, { actorId: ALICE });
    const multipliers = priceMultipliers(getGuildSettings(GUILD));
    const scaled = quickSetupPreview({ tier: 'mid', tier3: false, explosives: false }, multipliers);
    const base = quickSetupPreview({ tier: 'mid', tier3: false, explosives: false });
    if (scaled.products[0].price !== base.products[0].price * 3) {
      throw new Error(`${base.products[0].price} -> ${scaled.products[0].price}`);
    }
    patchGuildSetting(GUILD, 'shop.priceTiers', {}, { actorId: ALICE });
  });

  ok('bare /play routes as a standalone command', isStandaloneCommand(registry.commands.get('play')));
  ok('bare /give routes as a standalone command', isStandaloneCommand(registry.commands.get('give')));
  ok('parent /config still routes through subcommands', !isStandaloneCommand(registry.commands.get('config')));

  await okAsync('play panel renders 1v1 mode', async () => {
    const payload = await registry.panels.get('play').render({ ctx: makeCtx(), params: { mode: 'multiplayer' } });
    if (!payload?.embeds?.length) throw new Error('no embed returned');
  });

  await okAsync('play panel uses the game-first layout', async () => {
    const payload = await registry.panels.get('play').render({ ctx: makeCtx(), params: {} });
    const data = payload.embeds[0].toJSON();
    if (!String(data.title).includes('Games & Casino')) throw new Error(`title ${data.title}`);
    if ((data.fields ?? []).some((field) => field.name === 'Solo')) throw new Error('old mode layout');
    if (!payload.components.some((actionRow) => actionRow.components.some((component) => component.data?.type === 3))) {
      throw new Error('game selector missing');
    }
  });

  await okAsync('invalid Discord button emoji is rejected locally', () => {
    let rejected = false;
    try {
      button({ id: 'ab:test:emoji', label: 'Bad', emoji: '↺' });
    } catch {
      rejected = true;
    }
    if (!rejected) throw new Error('invalid emoji was accepted');
  });

  for (const [id, panel] of registry.panels) {
    await okAsync(`panel ${id} renders`, async () => {
      const payload = await panel.render({ ctx: makeCtx(), params: {} });
      if (!payload || !Array.isArray(payload.embeds) || payload.embeds.length === 0) {
        throw new Error('no embed returned');
      }
    });
  }

  for (const sectionId of Object.keys(CONFIG_SECTIONS)) {
    await okAsync(`config section ${sectionId} renders`, async () => {
      const payload = await registry.panels.get('config').render({ ctx: makeCtx(), params: { section: sectionId } });
      if (!payload?.embeds?.length) throw new Error('no embed returned');
    });
  }

  for (const sectionId of Object.keys(QUICK_SECTIONS)) {
    await okAsync(`quick setting ${sectionId} renders`, async () => {
      const payload = await registry.panels.get('set').render({ ctx: makeCtx(), params: { section: sectionId } });
      if (!payload?.embeds?.length) throw new Error('no embed returned');
    });
  }

  // --- premium battle pass (real money) ----------------------------------
  patchGuildSetting(GUILD, 'battlePass.premium.checkoutUrl', '', { actorId: ALICE });
  patchGuildSetting(GUILD, 'battlePass.premium.tip4servProductId', '', { actorId: ALICE });
  patchGuildSetting(GUILD, 'battlePass.premium.enableCoinPurchase', false, { actorId: ALICE });

  const bpHandler = registry.components.get('bp');
  const premiumBlockedCtx = makeCtx();
  premiumBlockedCtx.userId = BOB;
  premiumBlockedCtx.isComponent = true;
  premiumBlockedCtx.args = ['premium'];
  let premiumBlocked = null;
  try {
    await bpHandler.execute(premiumBlockedCtx);
  } catch (error) {
    premiumBlocked = error.message;
  }
  ok(
    'premium needs a real-money store link and cannot be unlocked with coins',
    Boolean(premiumBlocked?.includes('not configured')) && !(getProgress(GUILD, BOB)?.premium ?? 0),
    premiumBlocked,
  );

  patchGuildSetting(GUILD, 'battlePass.premium.checkoutUrl', 'https://example.com/store/premium', { actorId: ALICE });
  const premiumReplies = [];
  const premiumCtx = makeCtx();
  premiumCtx.userId = BOB;
  premiumCtx.interaction.user = { id: BOB, username: 'bob' };
  premiumCtx.isComponent = true;
  premiumCtx.args = ['premium'];
  premiumCtx.reply = async (payload) => premiumReplies.push(payload);
  await bpHandler.execute(premiumCtx);
  ok(
    'premium button links the owner checkout and grants nothing up front',
    premiumReplies[0]?.embeds?.[0]?.data?.description?.includes('https://example.com/store/premium') &&
      !(getProgress(GUILD, BOB)?.premium ?? 0),
    JSON.stringify(premiumReplies),
  );

  const battlePassPayload = await registry.panels.get('battle-pass').render({ ctx: makeCtx(), params: {} });
  const battlePassButtons = battlePassPayload.components.flatMap((actionRow) => actionRow.components);
  ok(
    'battle pass panel exposes the premium checkout link',
    battlePassButtons.some(
      (component) => component.data?.style === 5 && String(component.data?.url ?? '').includes('store/premium'),
    ),
    JSON.stringify(battlePassButtons.map((component) => component.data)),
  );

  patchGuildSetting(GUILD, 'battlePass.premium.tip4servProductId', 'premium-pass-499', { actorId: ALICE });
  const premiumProduct = findProduct(GUILD, 'premium-pass-499');
  const premiumDelivery = await deliverPurchase({
    client: { guilds: { fetch: async () => null } },
    rconManager: null,
    guildId: GUILD,
    userId: CAROL,
    product: premiumProduct,
    transactionId: 'tip4serv-premium-smoke',
  });
  ok(
    'tip4serv premium product delivery activates the premium track',
    premiumProduct?.premium === true &&
      premiumDelivery.includes('premium battle pass') &&
      getProgress(GUILD, CAROL)?.premium === 1,
    JSON.stringify({ premiumProduct, premiumDelivery }),
  );

  // --- card backs + rules embed ------------------------------------------
  ok(
    'card style offers the real card back artwork',
    ['classic', 'astro', 'nebula', 'custom'].every((key) => key in CARD_BACKS) &&
      cardBackPath('classic').endsWith('cardBackRed.png') &&
      cardBackPath('astro').endsWith('cardBackBlue.png') &&
      cardBackPath('nebula').endsWith('cardBackGreen.png'),
  );

  const cardCtx = makeCtx();
  cardCtx.isComponent = true;
  cardCtx.args = ['set', 'astro'];
  await registry.components.get('card').execute(cardCtx);
  ok('card back choice is saved per player', getPref(GUILD, ALICE, 'cardBack', null) === 'astro');

  const rulesMessages = [];
  const rulesCtx = makeCtx();
  rulesCtx.option = (name) => (name === 'channel' ? 'rules-channel' : null);
  rulesCtx.client = {
    ...rulesCtx.client,
    channels: {
      fetch: async (id) => ({ id, isTextBased: () => true, send: async (payload) => rulesMessages.push(payload) }),
    },
  };
  await registry.commands.get('rules').execute(rulesCtx);
  const rulesData = rulesMessages[0]?.embeds?.[0]?.data;
  ok(
    'rules command posts a branded rules embed',
    rulesData?.title === 'Rules' &&
      String(rulesData?.description).includes('**Be respectful.**') &&
      String(rulesData?.description).includes('#support') &&
      String(rulesData?.footer?.text).includes('KOBA GAMES') &&
      Boolean(rulesData?.timestamp),
    JSON.stringify(rulesData),
  );

  patchGuildSetting(GUILD, 'messages.rules.supportChannelId', '900000000000000099', { actorId: ALICE });
  rulesMessages.length = 0;
  await registry.commands.get('rules').execute(rulesCtx);
  ok(
    'rules embed links the configured support channel',
    String(rulesMessages[0]?.embeds?.[0]?.data?.description).includes('<#900000000000000099>') &&
      !String(rulesMessages[0]?.embeds?.[0]?.data?.description).includes('#support'),
    JSON.stringify(rulesMessages[0]?.embeds?.[0]?.data),
  );
  patchGuildSetting(GUILD, 'messages.rules.supportChannelId', null, { actorId: ALICE });

  setEmbedChannelLookup(
    () =>
      new Map([
        ['astro-rules', '900000000000000001'],
        ['💰・shop', '900000000000000002'],
      ]),
  );
  const formatted = buildEmbed({
    description: 'Run /link then read #astro-rules. Existing `/play` stays as it is.',
    fields: [{ name: 'Next /shop', value: 'Open #💰・shop or /battle-pass.' }],
  });
  ok(
    'embeds code slash commands and link known channels',
    formatted.data.description === 'Run `/link` then read <#900000000000000001>. Existing `/play` stays as it is.' &&
      formatted.data.fields[0].name === 'Next `/shop`' &&
      formatted.data.fields[0].value === 'Open <#900000000000000002> or `/battle-pass`.',
    JSON.stringify({ description: formatted.data.description, fields: formatted.data.fields }),
  );
  setEmbedChannelLookup(null);

  // --- shop item purchases -----------------------------------------------
  await okAsync('shop item purchase delivers to the linked gamertag', async () => {
    upsertLink({ guildId: GUILD, userId: ALICE, platform: 'xbox', gamertag: 'AliceXbox' });
    const sent = [];
    runtime.rconManager = {
      connectionFor: () => ({ connected: true, send: async (command) => sent.push(command) }),
    };

    patchGuildSetting(
      GUILD,
      'shop.products',
      [{ id: 'rifle.ak', name: 'Assault Rifle', shortname: 'rifle.ak', quantity: 2, price: 250 }],
      { actorId: ALICE },
    );

    const before = balances(GUILD, ALICE).wallet;
    const ctx = makeCtx();
    ctx.isComponent = true;
    ctx.args = ['buy', 'rifle.ak'];

    await registry.components.get('shop').execute(ctx);

    const after = balances(GUILD, ALICE).wallet;
    if (after !== before - 250) throw new Error(`wallet ${before} -> ${after}`);
    if (sent[0] !== 'inventory.giveto "AliceXbox" "rifle.ak" 2') throw new Error(`command ${sent[0]}`);
  });

  await okAsync('shop item purchase refunds a failed delivery', async () => {
    runtime.rconManager = {
      connectionFor: () => ({
        connected: true,
        send: async () => {
          throw new Error('socket closed');
        },
      }),
    };

    const before = balances(GUILD, ALICE).wallet;
    const ctx = makeCtx();
    ctx.isComponent = true;
    ctx.args = ['buy', 'rifle.ak'];

    let message = null;
    try {
      await registry.components.get('shop').execute(ctx);
    } catch (error) {
      message = error.message;
    }

    if (balances(GUILD, ALICE).wallet !== before) throw new Error('wallet was not refunded');
    if (!message?.includes('refunded')) throw new Error(`message: ${message}`);
  });

  await okAsync('shop item purchase requires a linked gamertag', async () => {
    runtime.rconManager = {
      connectionFor: () => ({ connected: true, send: async () => null }),
    };

    const before = balances(GUILD, BOB).wallet;
    const ctx = makeCtx();
    ctx.userId = BOB;
    ctx.interaction.user = { id: BOB, username: 'bob' };
    ctx.isComponent = true;
    ctx.args = ['buy', 'rifle.ak'];

    let message = null;
    try {
      await registry.components.get('shop').execute(ctx);
    } catch (error) {
      message = error.message;
    }

    if (!message?.includes('/link')) throw new Error(`message: ${message}`);
    if (balances(GUILD, BOB).wallet !== before) throw new Error('charged an unlinked buyer');
  });

  await okAsync('shop admin adds a catalog item by display name', async () => {
    patchGuildSetting(GUILD, 'shop.products', [], { actorId: ALICE });

    const ctx = makeCtx();
    ctx.isModal = true;
    ctx.args = ['add'];
    ctx.fields = {
      fields: new Map([['query', {}], ['price', {}], ['quantity', {}], ['category', {}], ['stock', {}]]),
      getTextInputValue: (field) =>
        ({ query: 'medical syringe', price: '500', quantity: '1', category: 'Medical', stock: '10' })[field] ?? null,
    };

    await registry.components.get('shopadm').execute(ctx);

    const products = getGuildSettings(GUILD).shop.products;
    if (products.length !== 1) throw new Error(`products: ${products.length}`);
    if (products[0].shortname !== 'syringe.medical' || !products[0].image) throw new Error(JSON.stringify(products[0]));
    if (products[0].price !== 500 || products[0].quantity !== 1) throw new Error(JSON.stringify(products[0]));
    if (products[0].category !== 'Medical' || products[0].stock !== 10) throw new Error(JSON.stringify(products[0]));
  });

  await okAsync('shop manager edits price, category and stock', async () => {
    const ctx = makeCtx();
    ctx.isModal = true;
    ctx.args = ['edit', 'syringe.medical'];
    ctx.fields = {
      fields: new Map([['price', {}], ['quantity', {}], ['category', {}], ['stock', {}]]),
      getTextInputValue: (field) => ({ price: '750', quantity: '3', category: 'Consumables', stock: '4' })[field] ?? null,
    };

    await registry.components.get('shopmgr').execute(ctx);

    const product = getGuildSettings(GUILD).shop.products[0];
    if (product.price !== 750 || product.quantity !== 3) throw new Error(JSON.stringify(product));
    if (product.category !== 'Consumables' || product.stock !== 4) throw new Error(JSON.stringify(product));
  });

  await okAsync('shop manager sets a required role with a native picker', async () => {
    const ctx = makeCtx();
    ctx.isComponent = true;
    ctx.args = ['role', 'syringe.medical'];
    ctx.values = [ROLE];

    await registry.components.get('shopmgr').execute(ctx);

    const product = getGuildSettings(GUILD).shop.products[0];
    if (product.requiredRoleId !== ROLE) throw new Error(JSON.stringify(product));
  });

  await okAsync('shop stock decrements and then sells out', async () => {
    runtime.rconManager = {
      connectionFor: () => ({ connected: true, send: async () => null }),
    };

    patchGuildSetting(
      GUILD,
      'shop.products',
      [
        {
          id: 'syringe.medical',
          name: 'Medical Syringe',
          shortname: 'syringe.medical',
          quantity: 1,
          price: 0,
          stock: 1,
          category: 'Medical',
        },
      ],
      { actorId: ALICE },
    );

    const ctx = makeCtx();
    ctx.isComponent = true;
    ctx.args = ['buy', 'syringe.medical'];

    await registry.components.get('shop').execute(ctx);
    if (getGuildSettings(GUILD).shop.products[0].stock !== 0) throw new Error('stock did not decrement');

    let message = null;
    try {
      await registry.components.get('shop').execute(ctx);
    } catch (error) {
      message = error.message;
    }
    if (!message?.includes('sold out')) throw new Error(`message: ${message}`);
  });

  await okAsync('quick setup creates categories, currency and a role requirement', async () => {
    patchGuildSetting(GUILD, 'shop.products', [], { actorId: ALICE });
    patchGuildSetting(GUILD, 'shop.currencies', ['coins', 'scrap'], { actorId: ALICE });

    const ctx = makeCtx();
    ctx.isComponent = true;

    ctx.args = ['currency'];
    ctx.values = ['scrap'];
    await registry.components.get('shopqs').execute(ctx);

    ctx.args = ['role'];
    ctx.values = [ROLE];
    await registry.components.get('shopqs').execute(ctx);

    ctx.args = ['tier3'];
    await registry.components.get('shopqs').execute(ctx);
    ctx.args = ['explosives'];
    await registry.components.get('shopqs').execute(ctx);

    ctx.args = ['create'];
    ctx.values = [];
    await registry.components.get('shopqs').execute(ctx);

    const settings = getGuildSettings(GUILD);
    const products = settings.shop.products;
    if (products.length < 1000) throw new Error(`products: ${products.length}`);
    if (!products.some((product) => product.shortname === 'rifle.ak')) throw new Error('catalog weapons missing');
    if (!products.every((product) => product.requiredRoleId === ROLE)) throw new Error('role requirement missing');
    if (settings.economy.currency !== 'scrap') throw new Error(`currency: ${settings.economy.currency}`);
  });

  await okAsync('shop manager applies a role to every product', async () => {
    const ctx = makeCtx();
    ctx.isComponent = true;
    ctx.args = ['role', 'all'];
    ctx.values = [ROLE];

    await registry.components.get('shopmgr').execute(ctx);

    const products = getGuildSettings(GUILD).shop.products;
    if (products.length === 0 || !products.every((product) => product.requiredRoleId === ROLE)) {
      throw new Error('role was not applied to every product');
    }
  });

  await okAsync('shop browse switches category', async () => {
    const category = getGuildSettings(GUILD).shop.products[0].category;
    const ctx = makeCtx();
    ctx.isComponent = true;
    ctx.args = ['cat'];
    ctx.values = [category];

    await registry.components.get('shop').execute(ctx);
    if (ctx.panelCalls[0]?.params?.category !== category) throw new Error(JSON.stringify(ctx.panelCalls[0]));
  });

  await okAsync('shop manager stores purchase limits and restock timers', async () => {
    const ctx = makeCtx();
    ctx.isModal = true;
    ctx.args = ['limits', 'rifle.ak'];
    ctx.fields = {
      fields: new Map([['limit', {}], ['window', {}], ['restock', {}], ['restockAmount', {}], ['stockMax', {}]]),
      getTextInputValue: (field) =>
        ({ limit: '2', window: '12', restock: '30', restockAmount: '1', stockMax: '5' })[field] ?? null,
    };

    await registry.components.get('shopmgr').execute(ctx);

    const product = getGuildSettings(GUILD).shop.products.find((entry) => entry.shortname === 'rifle.ak');
    if (product.limitPerMember !== 2 || product.limitWindowHours !== 12) throw new Error(JSON.stringify(product));
    if (product.restockMinutes !== 30 || product.restockAmount !== 1 || product.stockMax !== 5) {
      throw new Error(JSON.stringify(product));
    }
  });

  ok(
    'restock adds stock on its interval and caps at max stock',
    (() => {
      const now = 1_000_000_000_000;
      const next = restockProduct(
        { stock: 0, restockMinutes: 10, restockAmount: 2, stockMax: 3, restockAnchorAt: now - 25 * 60_000 },
        now,
      );
      return next.stock === 3 && restockProduct(next, now).stock === 3;
    })(),
  );

  ok(
    'restock countdown reports the next refill',
    (() => {
      const now = 1_000_000_000_000;
      const product = { stock: 0, restockMinutes: 10, restockAmount: 2, restockAnchorAt: now - 4 * 60_000 };
      return (
        restockCountdown(product, now) === 6 &&
        restockAt(product, now) === now + 6 * 60_000 &&
        restockCountdown({ stock: 1 }, now) === null &&
        restockAt({ stock: 1 }, now) === null
      );
    })(),
  );

  await okAsync('low stock alerts fire once at the threshold', async () => {
    const savedProducts = getGuildSettings(GUILD).shop.products;
    patchGuildSetting(GUILD, 'shop.stockAlertChannelId', '900000000000000001', { actorId: ALICE });
    patchGuildSetting(GUILD, 'shop.lowStockThreshold', 2, { actorId: ALICE });
    patchGuildSetting(
      GUILD,
      'shop.products',
      [{ id: 'alert-item', name: 'Alert Item', stock: 2, price: 10, category: 'Test' }],
      { actorId: ALICE },
    );

    const sent = [];
    const client = { channels: { fetch: async () => ({ send: async (payload) => sent.push(payload) }) } };

    await maybeAlertLowStock({ client, guildId: GUILD, product: getGuildSettings(GUILD).shop.products[0], stock: 2 });
    await maybeAlertLowStock({ client, guildId: GUILD, product: getGuildSettings(GUILD).shop.products[0], stock: 2 });
    if (sent.length !== 1) throw new Error(`sent ${sent.length}`);
    if (!JSON.stringify(sent[0].embeds[0].toJSON()).includes('No restock timer')) {
      throw new Error('stalled restock warning missing');
    }

    // A muted product stays silent; a forced manual-edit alert bypasses the stamp.
    await maybeAlertLowStock({ client, guildId: GUILD, product: { ...getGuildSettings(GUILD).shop.products[0], alertMuted: true }, stock: 1 });
    if (sent.length !== 1) throw new Error('a muted product alerted');
    await maybeAlertLowStock({
      client,
      guildId: GUILD,
      product: { ...getGuildSettings(GUILD).shop.products[0], alertMuted: false },
      stock: 1,
      force: true,
    });
    if (sent.length !== 2) throw new Error('a forced alert did not send');

    patchGuildSetting(GUILD, 'shop.stockAlertChannelId', null, { actorId: ALICE });
    patchGuildSetting(GUILD, 'shop.products', savedProducts, { actorId: ALICE });
  });

  ok(
    'default stock mode resolves unlimited or a starting count',
    defaultStockValue({ shop: { defaultStock: null } }) === null &&
      defaultStockValue({ shop: { defaultStock: '12' } }) === 12 &&
      defaultStockValue({ shop: { defaultStock: 'unlimited' } }) === null &&
      defaultStockValue({ shop: { defaultStock: '' } }) === null,
  );

  await okAsync('sales report ranks products by revenue', async () => {
    const guildId = `${GUILD}7`;
    recordPurchase({ guildId, userId: ALICE, productId: 'report-a', quantity: 2, price: 100 });
    recordPurchase({ guildId, userId: BOB, productId: 'report-a', quantity: 1, price: 50 });
    recordPurchase({ guildId, userId: ALICE, productId: 'report-b', quantity: 1, price: 200 });

    const top = topSellers(guildId, 0, 5);
    const totals = salesTotals(guildId, 0);
    if (top[0]?.product_id !== 'report-b' || Number(top[0].revenue) !== 200) throw new Error(JSON.stringify(top[0]));
    if (Number(totals.revenue) !== 350 || Number(totals.units) !== 4) throw new Error(JSON.stringify(totals));
  });

  await okAsync('shop maintenance prunes history and alerts stalled timers', async () => {
    const savedProducts = getGuildSettings(GUILD).shop.products;
    patchGuildSetting(GUILD, 'shop.stockAlertChannelId', '900000000000000002', { actorId: ALICE });
    patchGuildSetting(GUILD, 'shop.stallAlertHours', 1, { actorId: ALICE });
    patchGuildSetting(
      GUILD,
      'shop.products',
      [
        {
          id: 'stall-item',
          name: 'Stall Item',
          stock: 0,
          price: 5,
          category: 'Test',
          restockMinutes: 30,
          restockAmount: 1,
          restockAnchorAt: Date.now() - 5 * 3_600_000,
        },
      ],
      { actorId: ALICE },
    );

    const sent = [];
    const client = { channels: { fetch: async () => ({ send: async (payload) => sent.push(payload) }) } };
    const result = await runShopMaintenance({ client, guildIds: [GUILD] });
    if (result.alerted !== 1 || sent.length !== 1) throw new Error(JSON.stringify(result));
    if (!getGuildSettings(GUILD).shop.products[0].stallAlertAt) throw new Error('stall alert was not stamped');

    // A second sweep must stay quiet until the stock moves again.
    await runShopMaintenance({ client, guildIds: [GUILD] });
    if (sent.length !== 1) throw new Error('stalled alert repeated');

    const pruneGuild = `${GUILD}6`;
    recordStockEvent({ guildId: pruneGuild, productId: 'p', delta: 1, stockAfter: 1, kind: 'restock' });
    if (pruneStockEvents(pruneGuild, Date.now() + 1000) !== 1) throw new Error('stock event was not pruned');

    patchGuildSetting(GUILD, 'shop.stockAlertChannelId', null, { actorId: ALICE });
    patchGuildSetting(GUILD, 'shop.stallAlertHours', 72, { actorId: ALICE });
    patchGuildSetting(GUILD, 'shop.products', savedProducts, { actorId: ALICE });
  });

  await okAsync('stock changes are written to the product history', async () => {
    const savedProducts = getGuildSettings(GUILD).shop.products;
    patchGuildSetting(
      GUILD,
      'shop.products',
      [{ id: 'history-item', name: 'History Item', stock: 5, price: 1, category: 'Test' }],
      { actorId: ALICE },
    );

    adjustStock(GUILD, 'history-item', -2, { kind: 'sale', actorId: ALICE });
    const events = listStockEvents(GUILD, 'history-item', 5);
    if (events.length === 0 || events[0].kind !== 'sale' || events[0].delta !== -2 || events[0].stock_after !== 3) {
      throw new Error(JSON.stringify(events[0]));
    }

    patchGuildSetting(GUILD, 'shop.products', savedProducts, { actorId: ALICE });
  });

  await okAsync('shop role requirement blocks buyers without the role', async () => {
    credit({ guildId: GUILD, userId: ALICE, amount: 100_000, respectCap: false });
    runtime.rconManager = { connectionFor: () => ({ connected: true, send: async () => null }) };

    const product = getGuildSettings(GUILD).shop.products.find((entry) => entry.shortname === 'rifle.ak');
    if (!product) throw new Error('tier 3 rifle missing');

    const ctx = makeCtx();
    ctx.isComponent = true;
    ctx.args = ['buy', product.id];
    ctx.guild.members.fetch = async () => ({ roles: { cache: { has: () => false } } });

    let message = null;
    try {
      await registry.components.get('shop').execute(ctx);
    } catch (error) {
      message = error.message;
    }
    if (!message?.includes('requires')) throw new Error(`message: ${message}`);

    ctx.guild.members.fetch = async () => ({ roles: { cache: { has: () => true } } });
    await registry.components.get('shop').execute(ctx);
  });

  await okAsync('shop per-member purchase limit blocks repeats', async () => {
    patchGuildSetting(
      GUILD,
      'shop.products',
      [{ id: 'bandage', name: 'Bandage', shortname: 'bandage', quantity: 1, price: 0, limitPerMember: 1, limitWindowHours: 24 }],
      { actorId: ALICE },
    );

    const ctx = makeCtx();
    ctx.isComponent = true;
    ctx.args = ['buy', 'bandage'];

    await registry.components.get('shop').execute(ctx);

    let message = null;
    try {
      await registry.components.get('shop').execute(ctx);
    } catch (error) {
      message = error.message;
    }
    if (!message?.includes('limit')) throw new Error(`message: ${message}`);
  });

  patchGuildSetting(GUILD, 'shop.products', [], { actorId: ALICE });
  runtime.rconManager = null;

  // --- admin game setup -------------------------------------------------
  await okAsync('game setup toggles a solo game', async () => {
    const ctx = makeCtx();
    ctx.isComponent = true;
    ctx.args = ['toggle', 'solo', 'blackjack'];

    await registry.components.get('setup').execute(ctx);
    if (getGameConfig(GUILD).solo.blackjack !== false) throw new Error('game was not disabled');

    ctx.args = ['toggle', 'solo', 'blackjack'];
    await registry.components.get('setup').execute(ctx);
    if (getGameConfig(GUILD).solo.blackjack !== true) throw new Error('game was not re-enabled');

    ctx.args = ['casino', 'close'];
    await registry.components.get('setup').execute(ctx);
    if (getGameConfig(GUILD).enabled !== false) throw new Error('casino was not closed');

    ctx.args = ['casino', 'open'];
    await registry.components.get('setup').execute(ctx);
    if (getGameConfig(GUILD).enabled !== true) throw new Error('casino was not reopened');
  });

  await okAsync('game setup saves per-server jackpot controls', async () => {
    const ctx = makeCtx();
    ctx.isModal = true;
    ctx.args = ['save-jackpot'];
    ctx.fields = {
      getTextInputValue: (field) =>
        ({
          seed: '6000',
          min: '5500',
          rake: '4',
          milestone: '12000',
          odds: JSON.stringify({ slots: 5000, wheel: 4500, crash: 4000 }),
        })[field] ?? null,
    };

    await registry.components.get('setup').execute(ctx);
    const jackpot = getGameConfig(GUILD).jackpot;
    if (jackpot.seed !== 6000 || jackpot.min !== 5500 || jackpot.rakePercent !== 4 || jackpot.milestoneThreshold !== 12000) {
      throw new Error(`unexpected jackpot config: ${JSON.stringify(jackpot)}`);
    }
    if (jackpot.odds.slots !== 5000 || jackpot.odds.wheel !== 4500 || jackpot.odds.crash !== 4000) {
      throw new Error(`unexpected jackpot odds: ${JSON.stringify(jackpot.odds)}`);
    }
  });

  await okAsync('game setup saves custom raffle tiers and prizes', async () => {
    const ctx = makeCtx();
    ctx.isModal = true;
    ctx.args = ['save-jackpot-raffle'];
    ctx.fields = {
      getTextInputValue: (field) =>
        ({
          enabled: 'true',
          mode: 'fixed',
          prizes: JSON.stringify({ first: 900, second: 400, third: 100 }),
          shares: JSON.stringify({ first: 50, second: 30, third: 20 }),
          tiers: JSON.stringify([{ id: 'platinum', label: 'Platinum', cost: 1_000, entries: 10 }]),
        })[field] ?? null,
    };

    await registry.components.get('setup').execute(ctx);
    const raffle = getGameConfig(GUILD).jackpot.raffle;
    if (
      raffle.prizeMode !== 'fixed' ||
      raffle.prizes.first !== 900 ||
      raffle.prizes.second !== 400 ||
      raffle.prizes.third !== 100 ||
      raffle.tiers.length !== 1 ||
      raffle.tiers[0].id !== 'platinum' ||
      raffle.tiers[0].entries !== 10
    ) {
      throw new Error(`unexpected raffle config: ${JSON.stringify(raffle)}`);
    }
  });

  await okAsync('jackpot alert channel shortcut saves the selected channel', async () => {
    setManualPlan({ guildId: GUILD, tier: 'pro' });
    try {
      const ctx = makeCtx();
      ctx.grants = new Set(['admin']);
      ctx.isComponent = true;
      ctx.args = ['channel-save'];
      ctx.values = ['900000000000000011'];

      await registry.components.get('jackpot').execute(ctx);
      if (getGameConfig(GUILD).jackpot.milestoneChannelId !== '900000000000000011') {
        throw new Error('milestone channel was not saved');
      }
    } finally {
      setManualPlan({ guildId: GUILD, tier: 'basic' });
    }
  });

  // --- component-level settings edit ------------------------------------
  await okAsync('config editor toggles a boolean setting', async () => {
    const ctx = makeCtx();
    ctx.isComponent = true;
    ctx.args = ['field', 'config', 'misc', 'misc.playtimeCoinsEnabled'];
    ctx.values = ['misc.playtimeCoinsEnabled'];

    const before = getGuildSettings(GUILD).misc.playtimeCoinsEnabled;
    await registry.components.get('cfg').execute(ctx);
    const after = getGuildSettings(GUILD).misc.playtimeCoinsEnabled;

    if (before === after) throw new Error('value did not change');
  });

  await okAsync('shop manager deletes one product after confirmation', async () => {
    patchGuildSetting(
      GUILD,
      'shop.products',
      [{ id: 'delete-me', name: 'Delete me', price: 1, quantity: 1, category: 'Test' }],
      { actorId: ALICE },
    );
    const ctx = makeCtx();
    ctx.isModal = true;
    ctx.args = ['delete', 'delete-me'];
    ctx.fields = { getTextInputValue: () => 'DELETE' };
    await registry.components.get('shopmgr').execute(ctx);
    if ((getGuildSettings(GUILD).shop.products ?? []).length !== 0) throw new Error('product was not deleted');
  });

  await okAsync('shop admin deletes the whole shop after confirmation', async () => {
    patchGuildSetting(GUILD, 'shop.products', [{ id: 'shop-delete', name: 'Shop delete', price: 1, category: 'Test' }], { actorId: ALICE });
    patchGuildSetting(GUILD, 'shop.enabled', true, { actorId: ALICE });
    const ctx = makeCtx();
    ctx.isModal = true;
    ctx.args = ['deleteshop'];
    ctx.fields = { getTextInputValue: () => 'DELETE' };
    await registry.components.get('shopadm').execute(ctx);
    const settings = getGuildSettings(GUILD);
    if ((settings.shop.products ?? []).length !== 0 || settings.shop.enabled !== false) throw new Error('shop was not cleared');
  });

  ok(
    'feature switches cover the remaining major systems',
    ['tickets.enabled', 'moderation.enabled', 'bounties.enabled', 'leaderboards.enabled', 'challenges.enabled', 'referrals.enabled', 'events.enabled'].every(
      (path) => CONFIG_SECTIONS.features.fields.some((field) => field.path === path),
    ),
  );
  let gateBlocked = false;
  try {
    assertFeatureEnabled({ bounties: { enabled: false } }, 'bounties.enabled');
  } catch {
    gateBlocked = true;
  }
  ok(
    'feature gates block disabled player features',
    gateBlocked && featureForCommand('mod') === 'moderation.enabled' && featureForCommand('bounty') === 'bounties.enabled',
  );

  // --- recommendation regressions -------------------------------------
  {
    const { zonedTimeToUtc } = await import('../src/utils/timezone.js');
    const newYork = zonedTimeToUtc({ year: 2026, month: 7, day: 1, hour: 20, minute: 30 }, 'America/New_York');
    ok('announcement wall clock converts through IANA zones', newYork === Date.UTC(2026, 6, 2, 0, 30));

    const { default: announcementBuilder } = await import('../src/components/announcements.js');
    const builderModal = await announcementBuilder.execute({
      guildId: GUILD,
      userId: ALICE,
      args: ['create'],
      isModal: false,
      modal: (payload) => payload,
    });
    const modalJson = builderModal.toJSON();
    const zoneField = modalJson.components[4]?.component;
    ok(
      'announcement builder offers a timezone selector',
      modalJson.components.length === 5 &&
        zoneField?.type === 3 &&
        zoneField?.custom_id === 'timezone' &&
        zoneField.options.some((option) => option.value === '__guild__') &&
        zoneField.options.length <= 25,
    );

    const { weightedDraw } = await import('../src/utils/random.js');
    let bonusWins = 0;
    for (let i = 0; i < 300; i += 1) {
      if (weightedDraw([{ id: 'base', weight: 1 }, { id: 'bonus', weight: 9 }], 1)[0] === 'bonus') bonusWins += 1;
    }
    ok('weighted draw favours bonus tickets', bonusWins > 200 && weightedDraw([], 3).length === 0);

    const { beginPayment, abortPayment, finishPayment, getPayment } = await import('../src/db/repositories/payments.js');
    ok(
      'payment ledger claims a transaction once',
      beginPayment({ transactionId: 'smoke-tx-1', guildId: GUILD, userId: ALICE, productId: 'pro' }) === true &&
        beginPayment({ transactionId: 'smoke-tx-1', guildId: GUILD, userId: ALICE, productId: 'pro' }) === false,
    );
    finishPayment('smoke-tx-1', { delivered: ['pro'] });
    ok('payment ledger records delivery', getPayment('smoke-tx-1')?.status === 'delivered');
    beginPayment({ transactionId: 'smoke-tx-2', guildId: GUILD, userId: ALICE });
    abortPayment('smoke-tx-2', 'rcon down');
    ok('aborted payment can be retried', beginPayment({ transactionId: 'smoke-tx-2', guildId: GUILD, userId: ALICE }) === true);

    const { createGiveaway, addGiveawayEntry, addGiveawayBonus, giveawayTickets, giveawayTicketWeights } = await import(
      '../src/db/repositories/onboarding.js'
    );
    const giveaway = createGiveaway({
      guildId: GUILD,
      channelId: 'smoke-channel',
      hostId: ALICE,
      prize: 'Smoke prize',
      winners: 1,
      endsAt: Date.now() + 60_000,
    });
    addGiveawayEntry(giveaway.id, GUILD, ALICE);
    const firstBonus = addGiveawayBonus({ giveawayId: giveaway.id, guildId: GUILD, userId: ALICE, taskIndex: 2, points: 5 });
    const repeatBonus = addGiveawayBonus({ giveawayId: giveaway.id, guildId: GUILD, userId: ALICE, taskIndex: 2, points: 5 });
    ok(
      'portal bonus adds weighted tickets exactly once',
      firstBonus === true && repeatBonus === false && giveawayTickets(giveaway.id, ALICE) === 6 && giveawayTicketWeights(giveaway.id)[0]?.weight === 6,
    );

    const { createAnnouncement, removeAnnouncement } = await import('../src/db/repositories/announcements.js');
    const { sweepAnnouncements, sweepAnnouncementRetries } = await import('../src/services/announcement-service.js');
    const { listDeliveries } = await import('../src/db/repositories/announcement-deliveries.js');
    const announcement = createAnnouncement({
      guildId: GUILD,
      name: 'Smoke retry',
      message: 'Retry me',
      channelId: 'missing-channel',
      inGame: true,
      schedule: 'once',
      runAt: Date.now() - 1000,
    });
    await sweepAnnouncements({ client: { channels: { fetch: async () => null } }, rconManager: null, now: Date.now() });
    const pending = listDeliveries(announcement.id, 1)[0];
    ok(
      'failed announcement delivery is queued for both targets',
      pending?.status === 'pending' && Number(pending.need_discord) === 1 && Number(pending.need_game) === 1,
    );
    await sweepAnnouncementRetries({
      client: { channels: { fetch: async () => ({ isTextBased: () => true, send: async () => ({ id: 'retry-msg' }) }) } },
      rconManager: { connectionFor: () => ({ send: async () => true }) },
      now: Date.now() + 120_000,
    });
    ok('announcement retry records a successful delivery', listDeliveries(announcement.id, 1)[0]?.status === 'sent');
    removeAnnouncement(announcement.id);

    const { createPoll, getPoll } = await import('../src/db/repositories/polls.js');
    const { closeExpiredPolls } = await import('../src/services/poll-service.js');
    const poll = createPoll({
      id: `smoke-poll-${Date.now()}`,
      guildId: GUILD,
      channelId: 'smoke-channel',
      creatorId: ALICE,
      question: 'Auto close?',
      options: ['Yes', 'No'],
      hours: 1,
    });
    getDb().prepare('UPDATE polls SET ends_at = ? WHERE id = ?').run(Date.now() - 1000, poll.id);
    await closeExpiredPolls({ channels: { fetch: async () => ({ isTextBased: () => true, send: async () => ({ id: 'poll-msg' }) }) } });
    ok('poll automation closes an expired poll', getPoll(poll.id)?.status === 'ended');

    const { issueGiveawayEntryToken, validateGiveawayEntryToken, markGiveawayEntryTokenUsed } = await import(
      '../src/db/repositories/giveaway-portals.js'
    );
    const entryToken = issueGiveawayEntryToken({ guildId: GUILD, userId: ALICE, giveawayId: giveaway.id });
    ok(
      'portal entry token is single use',
      markGiveawayEntryTokenUsed(entryToken) === true &&
        markGiveawayEntryTokenUsed(entryToken) === false &&
        Boolean(validateGiveawayEntryToken(entryToken)?.used_at),
    );
  }

  console.log(`\n${checks - failures.length}/${checks} smoke checks passed.`);
  if (failures.length > 0) {
    console.error(`${failures.length} failure(s):`);
    for (const failure of failures) console.error(` - ${failure}`);
    process.exitCode = 1;
  } else {
    console.log('AstroBot runtime smoke OK.');
  }

  closeDatabase();
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
  closeDatabase();
});
