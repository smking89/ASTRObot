import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { deflateSync } from 'node:zlib';

/**
 * Generates the bot's rank and badge icons as real PNG files.
 *
 * Discord never renders SVG or emoji reliably inside embeds, so every badge is
 * shipped as a raster image and uploaded as an attachment when it is shown.
 * Icons use an outlined style: a coloured rim and stroked glyph on a
 * transparent background, so they sit cleanly on the dark console and embeds.
 * The rasteriser and PNG encoder are dependency-free on purpose: the bot has
 * no image libraries installed and must not gain any for static art.
 */

const SIZE = 128;
const CENTER = SIZE / 2;
const OUTPUT = fileURLToPath(new URL('../assets/badges/', import.meta.url));
const VECTOR_PACK = fileURLToPath(new URL('../assets/vector-ranks/', import.meta.url));

if (existsSync(VECTOR_PACK)) {
  console.log('Vector Ranks pack detected — run scripts/import-rank-badges.js to rebuild icons from it.');
  process.exit(0);
}

// --- PNG encoding -----------------------------------------------------------

const CRC_TABLE = (() => {
  const table = new Int32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c;
  }
  return table;
})();

function crc32(buffer) {
  let crc = 0xffffffff;
  for (const byte of buffer) crc = CRC_TABLE[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length);
  const typeBuffer = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuffer, data])));
  return Buffer.concat([length, typeBuffer, data, crc]);
}

function encodePng(width, height, rgba) {
  const stride = width * 4 + 1;
  const raw = Buffer.alloc(stride * height);
  for (let y = 0; y < height; y += 1) {
    raw[y * stride] = 0;
    rgba.copy(raw, y * stride + 1, y * width * 4, (y + 1) * width * 4);
  }

  const header = Buffer.alloc(13);
  header.writeUInt32BE(width, 0);
  header.writeUInt32BE(height, 4);
  header[8] = 8; // bit depth
  header[9] = 6; // RGBA
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', header),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

// --- colours ----------------------------------------------------------------

function hex(color) {
  const value = color.replace('#', '');
  return [parseInt(value.slice(0, 2), 16), parseInt(value.slice(2, 4), 16), parseInt(value.slice(4, 6), 16)];
}

function scale(rgb, factor) {
  return rgb.map((channel) => Math.max(0, Math.min(255, Math.round(channel * factor))));
}

// --- glyphs (all take coordinates relative to the centre) -------------------

const circle = (radius) => (x, y) => x * x + y * y <= radius * radius;

const ring = (inner, outer) => (x, y) => {
  const distance = Math.hypot(x, y);
  return distance >= inner && distance <= outer;
};

const star = (points, outer, inner) => (x, y) => {
  const angle = Math.atan2(y, x);
  const radius = inner + (outer - inner) * Math.pow(Math.abs(Math.cos((points * angle) / 2)), 0.62);
  return Math.hypot(x, y) <= radius;
};

const diamond = (x, y) => Math.abs(x) + Math.abs(y) <= 27;

const crown = (x, y) => {
  if (y >= 6 && y <= 17 && Math.abs(x) <= 27) return true;
  return [-17, 0, 17].some((spike) => y < 6 && y >= -26 && Math.abs(x - spike) <= (y + 26) * 0.55);
};

const chevron = (offset = 0) => (x, y) => {
  const shifted = y - offset;
  return shifted >= -2 && shifted <= 18 && Math.abs(Math.abs(x) - (shifted + 2) * 0.9) <= 6;
};

const crosshair = (x, y) => {
  const distance = Math.hypot(x, y);
  return (
    (distance >= 17 && distance <= 23) ||
    (Math.abs(x) <= 3 && Math.abs(y) <= 30) ||
    (Math.abs(y) <= 3 && Math.abs(x) <= 30)
  );
};

const shield = (x, y) => {
  if (y <= -10) return Math.abs(x) <= 22 && y >= -30;
  if (y <= 14) return Math.abs(x) <= 22 - (y + 10) * 0.3;
  return Math.abs(x) <= 28 - (y - 14) * 1.6;
};

const coin = (x, y) => {
  const distance = Math.hypot(x, y);
  if (distance >= 19 && distance <= 24) return true;
  return Math.abs(x) <= 14 && [8, 0, -8].some((row) => Math.abs(y - row) <= 3);
};

const drop = (x, y) => {
  if (Math.hypot(x, y - 7) <= 14) return true;
  return y <= 7 && Math.abs(x) <= (7 - y) * 0.6 + 2;
};

const eye = (x, y) => {
  const inEye = (x / 30) ** 2 + (y / 18) ** 2 <= 1;
  const distance = Math.hypot(x, y);
  return (inEye && distance >= 8) || distance <= 6;
};

const frame = (x, y) => Math.abs(x) <= 22 && Math.abs(y) <= 22 && !(Math.abs(x) <= 13 && Math.abs(y) <= 13);

const crossed = (x, y) => Math.abs(Math.abs(x) - Math.abs(y)) <= 5 && Math.hypot(x, y) <= 28;

const cross = (x, y) => (Math.abs(x) <= 8 && Math.abs(y) <= 28) || (Math.abs(y) <= 8 && Math.abs(x) <= 28);

const doubleChevron = (x, y) => chevron(6)(x, y) || chevron(-10)(x, y);

// --- icon definitions -------------------------------------------------------

const ICONS = {
  stone: { color: '#8b8f96', glyph: star(6, 26, 12) },
  bronze: { color: '#b87333', glyph: ring(14, 24) },
  silver: { color: '#b9c0ca', glyph: star(5, 27, 12) },
  gold: { color: '#dfa92d', glyph: star(5, 30, 14) },
  diamond: { color: '#4fc3d9', glyph: diamond },
  elite: { color: '#a259f7', glyph: star(8, 30, 13) },
  first_blood: { color: '#d64550', glyph: drop },
  hunter: { color: '#5aa84a', glyph: crosshair },
  survivor: { color: '#3a8fd6', glyph: shield },
  banker: { color: '#d8a92b', glyph: coin },
  prestige: { color: '#e8762f', glyph: star(12, 30, 10) },
  leader: { color: '#d9a93a', glyph: crown },
  officer: { color: '#8b9dc3', glyph: chevron() },
  member: { color: '#5f6b7a', glyph: circle(13) },
  recruit: { color: '#7d8a94', glyph: circle(9) },
  veteran: { color: '#a8703a', glyph: doubleChevron },
  raider: { color: '#c74a3c', glyph: crossed },
  scout: { color: '#3f9b9e', glyph: eye },
  builder: { color: '#94724a', glyph: frame },
  medic: { color: '#cf5a5a', glyph: cross },
};

function render({ color, glyph }) {
  const base = hex(color);
  const pixels = Buffer.alloc(SIZE * SIZE * 4);

  // Outlined style: transparent interior, a coloured rim and a stroked glyph.
  const mask = new Uint8Array(SIZE * SIZE);
  for (let y = 0; y < SIZE; y += 1) {
    for (let x = 0; x < SIZE; x += 1) {
      mask[y * SIZE + x] = glyph(x - CENTER + 0.5, y - CENTER + 0.5) ? 1 : 0;
    }
  }

  const isEdge = (x, y) => {
    if (!mask[y * SIZE + x]) return false;
    for (let oy = -3; oy <= 3; oy += 1) {
      for (let ox = -3; ox <= 3; ox += 1) {
        if (ox * ox + oy * oy > 9) continue;
        const nx = x + ox;
        const ny = y + oy;
        if (nx < 0 || ny < 0 || nx >= SIZE || ny >= SIZE) return true;
        if (!mask[ny * SIZE + nx]) return true;
      }
    }
    return false;
  };

  for (let y = 0; y < SIZE; y += 1) {
    for (let x = 0; x < SIZE; x += 1) {
      const distance = Math.hypot(x - CENTER + 0.5, y - CENTER + 0.5);
      let rgb;

      if (distance > 62) continue;
      // Slightly deepened so the outline stays legible on white cards;
      // the glyph itself keeps the true brand colour.
      if (distance > 54) rgb = scale(base, 0.82); // outer rim
      else if (distance > 50) continue; // breathing room inside the rim
      else if (isEdge(x, y)) rgb = scale(base, 0.98); // glyph outline
      else continue;

      const index = (y * SIZE + x) * 4;
      pixels[index] = rgb[0];
      pixels[index + 1] = rgb[1];
      pixels[index + 2] = rgb[2];
      pixels[index + 3] = 255;
    }
  }

  return encodePng(SIZE, SIZE, pixels);
}

mkdirSync(OUTPUT, { recursive: true });

for (const [key, definition] of Object.entries(ICONS)) {
  writeFileSync(new URL(`${key}.png`, `file://${OUTPUT.replace(/\/?$/, '/')}`), render(definition));
}

console.log(`Generated ${Object.keys(ICONS).length} badge icons in ${OUTPUT}`);
