#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

archive="astrobot.zip"
temporary="astrobot-new.zip"
mode="${1:-build}"

case "$mode" in
  build|--check|--validate) ;;
  *)
    echo "usage: $0 [--check|--validate]" >&2
    exit 2
    ;;
esac

for command in zip unzip; do
  if ! command -v "$command" >/dev/null 2>&1; then
    echo "packaging requires the '$command' command" >&2
    exit 1
  fi
done

validate_archive() {
  local file="$1"
  local entries required count

  if [[ ! -s "$file" ]]; then
    echo "archive validation failed: $file is missing or empty" >&2
    return 1
  fi

  if ! unzip -t "$file" >/dev/null; then
    echo "archive validation failed: zip integrity check failed" >&2
    return 1
  fi

  entries="$(unzip -Z1 "$file")"
  required=(.env.example README.md package.json package-lock.json scripts/package.sh src/index.js dashboard/server.js)
  for path in "${required[@]}"; do
    if ! grep -Fqx "$path" <<<"$entries"; then
      echo "archive validation failed: required entry missing: $path" >&2
      return 1
    fi
  done

  if grep -E '^(node_modules|data|logs|tmp|\.freebuff|\.git)/|(^|/)\.env$|(^|/)\.env\.(local|development|production|test)$|(^|/)astrobot(-new)?\.zip$|\.db(-wal|-shm)?$|\.log$' <<<"$entries" >/dev/null; then
    echo "archive validation failed: forbidden secret/runtime entry found" >&2
    return 1
  fi

  count="$(wc -l <<<"$entries" | tr -d ' ')"
  printf 'Validated %s (%s entries, %s)\n' "$file" "$count" "$(du -h "$file" | cut -f1)"
}

if [[ "$mode" == "--check" || "$mode" == "--validate" ]]; then
  validate_archive "$archive"
  exit 0
fi

rm -f "$temporary"
trap 'rm -f "$temporary"' EXIT

zip -r -q "$temporary" . \
  -x 'node_modules/*' \
     'data/*' \
     'logs/*' \
     'tmp/*' \
     '.freebuff/*' \
     '.git/*' \
     '.env' \
     '.env.local' \
     '.env.development' \
     '.env.production' \
     '.env.test' \
     '*.zip' \
     '*.db' \
     '*.db-wal' \
     '*.db-shm' \
     '*.log'

# Some zip builds treat the `.env` exclusion as a prefix match. Re-add the
# template explicitly so configuration examples always ship.
if [[ -f .env.example ]]; then
  zip -q "$temporary" .env.example
fi

validate_archive "$temporary"
mv -f "$temporary" "$archive"
trap - EXIT

printf 'Created %s (%s)\n' "$archive" "$(du -h "$archive" | cut -f1)"
