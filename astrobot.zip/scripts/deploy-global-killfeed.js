import 'dotenv/config';
import { initDatabase, closeDatabase } from '../src/db/index.js';
import { env } from '../src/config/env.js';
import { getGuildSettings, patchGuildSetting } from '../src/db/repositories/guilds.js';
import { normalizeStructureName } from '../src/services/template-builder.js';

const API = 'https://discord.com/api/v10';
const guildId = process.env.GUILD_ID || env.discord.devGuildId || env.discord.officialGuildId;

async function api(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      Authorization: `Bot ${env.discord.token}`,
      'Content-Type': 'application/json',
      ...(options.headers ?? {}),
    },
  });
  const body = response.status === 204 ? null : await response.text();
  if (!response.ok) throw new Error(`${options.method ?? 'GET'} ${path} -> ${response.status} ${body?.slice(0, 200) ?? ''}`);
  return body ? JSON.parse(body) : null;
}

async function main() {
  if (!env.discord.token) throw new Error('DISCORD_TOKEN is not configured.');
  if (!guildId) throw new Error('Set GUILD_ID, DISCORD_DEV_GUILD_ID or OFFICIAL_GUILD_ID.');

  initDatabase();
  const channels = await api(`/guilds/${guildId}/channels`);
  const category = channels.find(
    (channel) =>
      channel.type === 4 && /global-?status|network-?status/i.test(normalizeStructureName(channel.name)),
  );
  let global = channels.find(
    (channel) =>
      (channel.type === 0 || channel.type === 5) && /global-?killfeed/i.test(normalizeStructureName(channel.name)),
  );

  if (!global) {
    if (!category) throw new Error('No global/network status category found; create it or pass a configured guild.');
    global = await api(`/guilds/${guildId}/channels`, {
      method: 'POST',
      body: JSON.stringify({
        name: '🌐・global-killfeed',
        type: 0,
        parent_id: category.id,
        topic: 'Combined killfeed from every connected AstroBot Rust server, updated every 5 seconds.',
      }),
    });
    console.log(`Created #${global.name} (${global.id}) under ${category.name}.`);
  } else {
    console.log(`Using #${global.name} (${global.id}).`);
  }

  const settings = getGuildSettings(guildId);
  patchGuildSetting(guildId, 'channels.globalKillfeed', global.id);
  patchGuildSetting(guildId, 'killfeed.globalEnabled', true);

  if (!settings.channels?.killfeed) {
    const local = channels.find(
      (channel) => (channel.type === 0 || channel.type === 5) && /killfeed/i.test(String(channel.name)) && !/global/i.test(String(channel.name)),
    );
    if (local) {
      patchGuildSetting(guildId, 'channels.killfeed', local.id);
      console.log(`Local killfeed channel set to #${local.name} (${local.id}).`);
    }
  }

  console.log(`Global killfeed configured for guild ${guildId}.`);
  closeDatabase();
}

main().catch((error) => {
  closeDatabase();
  console.error(`Global killfeed deployment failed: ${error.message}`);
  process.exitCode = 1;
});