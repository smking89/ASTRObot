import { Events } from 'discord.js';
import { onGuildCreate } from './guild-create.js';
import { onMessageCreate } from './message-create.js';
import { createLogger } from '../core/logger.js';
import { registerMemberEvents } from './member-events.js';

const log = createLogger('events');

/** Event handlers stay small; the work lives in services. */
export function registerEvents(client) {
  client.on(Events.GuildCreate, (guild) => onGuildCreate(guild).catch((error) => log.error('guildCreate failed', error)));
  client.on(Events.MessageCreate, (message) => onMessageCreate(client, message).catch((error) => log.error('messageCreate failed', error)));
  registerMemberEvents(client);
}
