import { ensureGuild } from '../db/repositories/guilds.js';
import { env } from '../config/env.js';
import { createLogger } from '../core/logger.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';

const log = createLogger('events:guild');

/** Registers a guild on join and nudges the owner through install approval. */
export async function onGuildCreate(guild) {
  ensureGuild({ id: guild.id, name: guild.name, icon: guild.icon });
  log.info(`Joined guild ${guild.name} (${guild.id}).`);

  if (!env.runtime.enforceGuildApproval) return;

  const owner = await guild.fetchOwner().catch(() => null);
  if (!owner) return;

  await owner
    .send({
      embeds: [
        buildEmbed({
          title: 'AstroBot needs approval',
          description:
            'Thanks for adding AstroBot! This server still needs to be approved before commands are unlocked.\n\n' +
            'An AstroBot developer can approve it in the Developer Panel, or you can open a ticket in the official server.',
          color: COLORS.warning,
          footer: guild.name,
        }),
      ],
    })
    .catch(() => null);
}
