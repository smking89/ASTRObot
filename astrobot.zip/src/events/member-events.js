import { Events } from 'discord.js';
import { onMemberJoin, onMemberLeave, onVoiceStateUpdate } from '../services/onboarding-service.js';
import { createLogger } from '../core/logger.js';

const log = createLogger('member-events');

export function registerMemberEvents(client) {
  client.on(Events.GuildMemberAdd, (member) => onMemberJoin(member).catch((error) => log.error('member join onboarding failed', error)));
  client.on(Events.GuildMemberRemove, (member) => onMemberLeave(member).catch((error) => log.error('member leave onboarding failed', error)));
  client.on(Events.VoiceStateUpdate, (oldState, newState) =>
    onVoiceStateUpdate(oldState, newState).catch((error) => log.error('temporary voice channel failed', error)),
  );
}
