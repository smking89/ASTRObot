import { getGuildSettings } from '../db/repositories/guilds.js';
import { createLogger } from '../core/logger.js';
import { truncate } from '../utils/format.js';

const log = createLogger('events:frank');

/** One answer per channel per 15s so Frank cannot spam. */
const channelCooldowns = new Map();

/**
 * Frank: keyword-triggered FAQ agent for regular Discord channels.
 * Requires the MessageContent privileged intent.
 */
export async function onMessageCreate(client, message) {
  if (!message.inGuild() || message.author.bot || message.system) return;
  if (message.content.length < 3) return;

  const settings = getGuildSettings(message.guildId);
  if (!settings.frank.enabled) return;

  const answers = settings.frank.answers ?? [];
  if (answers.length === 0) return;

  const configuredChannels = settings.frank.channelIds ?? [];
  if (configuredChannels.length > 0 && !configuredChannels.includes(message.channelId)) return;

  const content = message.content.toLowerCase();
  const match = answers.find((entry) =>
    (entry.keywords ?? []).some((keyword) => content.includes(String(keyword).toLowerCase())),
  );
  if (!match?.response) return;

  const last = channelCooldowns.get(message.channelId) ?? 0;
  if (Date.now() - last < 15_000) return;

  channelCooldowns.set(message.channelId, Date.now());

  try {
    await message.reply({
      content: truncate(match.response, 1900),
      allowedMentions: { repliedUser: false, parse: [] },
    });
  } catch (error) {
    log.debug(`Frank reply failed: ${error.message}`);
  }
}
