import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { env } from '../config/env.js';
import { createLogger } from '../core/logger.js';
import { runMigrations } from './migrations.js';

const log = createLogger('db');
const SCHEMA_FILE = fileURLToPath(new URL('./schema.sql', import.meta.url));

/** @type {DatabaseSync|null} */
let database = null;
let transactionDepth = 0;

export function initDatabase({ path = env.databasePath } = {}) {
  if (database) return database;

  const file = path === ':memory:' ? path : resolve(path);
  if (file !== ':memory:') mkdirSync(dirname(file), { recursive: true });

  database = new DatabaseSync(file);
  database.exec('PRAGMA journal_mode = WAL;');
  database.exec('PRAGMA synchronous = NORMAL;');
  database.exec('PRAGMA foreign_keys = ON;');
  database.exec('PRAGMA busy_timeout = 5000;');
  database.exec(readFileSync(SCHEMA_FILE, 'utf8'));

  const migrated = runMigrations(database);
  if (migrated.length > 0) log.info(`Applied migration(s): ${migrated.join(', ')}`);

  log.info(`SQLite ready at ${file}`);
  return database;
}

export function getDb() {
  if (!database) throw new Error('Database not initialised. Call initDatabase() at boot.');
  return database;
}

/**
 * Synchronous transaction helper with savepoint support for nesting. All
 * economy mutations run through here so balances can never half-apply.
 */
export function transaction(work) {
  const db = getDb();
  const isNested = transactionDepth > 0;
  const savepoint = `sp_${transactionDepth}`;

  db.exec(isNested ? `SAVEPOINT ${savepoint}` : 'BEGIN IMMEDIATE');
  transactionDepth += 1;

  try {
    const result = work(db);
    transactionDepth -= 1;
    db.exec(isNested ? `RELEASE ${savepoint}` : 'COMMIT');
    return result;
  } catch (error) {
    transactionDepth -= 1;
    try {
      db.exec(isNested ? `ROLLBACK TO ${savepoint}` : 'ROLLBACK');
      if (isNested) db.exec(`RELEASE ${savepoint}`);
    } catch (rollbackError) {
      log.error('Rollback failed', rollbackError);
    }
    throw error;
  }
}

export function closeDatabase() {
  if (!database) return;
  try {
    database.close();
  } finally {
    database = null;
  }
}

export function nowSeconds() {
  return Math.floor(Date.now() / 1000);
}
