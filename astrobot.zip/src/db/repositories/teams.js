import { getDb, transaction } from '../index.js';
import { uniqueId } from '../../utils/random.js';

export const TEAM_RANKS = Object.freeze(['leader', 'officer', 'member']);

export function createTeam({ guildId, name, tag, ownerId, color = null, badge = null }) {
  const id = uniqueId('team');

  transaction((db) => {
    db.prepare(
      `INSERT INTO teams (id, guild_id, name, tag, owner_id, color, badge, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    ).run(id, guildId, name, tag, ownerId, color, badge, Date.now());

    db.prepare(
      `INSERT INTO team_members (team_id, guild_id, user_id, rank, joined_at) VALUES (?, ?, ?, 'leader', ?)`,
    ).run(id, guildId, ownerId, Date.now());
  });

  return getTeam(id);
}

export function getTeam(teamId) {
  return getDb().prepare('SELECT * FROM teams WHERE id = ?').get(teamId) ?? null;
}

export function getTeamByName(guildId, name) {
  return (
    getDb()
      .prepare('SELECT * FROM teams WHERE guild_id = ? AND (LOWER(name) = LOWER(?) OR LOWER(tag) = LOWER(?))')
      .get(guildId, name, name) ?? null
  );
}

export function getTeamForUser(guildId, userId) {
  return (
    getDb()
      .prepare(
        `SELECT t.*, m.rank AS member_rank, m.joined_at AS member_joined_at
         FROM teams t JOIN team_members m ON m.team_id = t.id
         WHERE m.guild_id = ? AND m.user_id = ?`,
      )
      .get(guildId, userId) ?? null
  );
}

export function listMembers(teamId) {
  return getDb()
    .prepare('SELECT * FROM team_members WHERE team_id = ? ORDER BY CASE rank WHEN \'leader\' THEN 0 WHEN \'officer\' THEN 1 ELSE 2 END, joined_at')
    .all(teamId);
}

export function memberCount(teamId) {
  const row = getDb().prepare('SELECT COUNT(*) AS count FROM team_members WHERE team_id = ?').get(teamId);
  return Number(row?.count ?? 0);
}

export function addMember(teamId, guildId, userId, rank = 'member') {
  getDb()
    .prepare('INSERT OR REPLACE INTO team_members (team_id, guild_id, user_id, rank, joined_at) VALUES (?, ?, ?, ?, ?)')
    .run(teamId, guildId, userId, rank, Date.now());
  return getTeamForUser(guildId, userId);
}

export function setMemberRank(teamId, userId, rank) {
  getDb().prepare('UPDATE team_members SET rank = ? WHERE team_id = ? AND user_id = ?').run(rank, teamId, userId);
}

export function removeMember(teamId, userId) {
  const result = getDb().prepare('DELETE FROM team_members WHERE team_id = ? AND user_id = ?').run(teamId, userId);
  return result.changes > 0;
}

export function deleteTeam(teamId) {
  transaction((db) => {
    db.prepare('DELETE FROM team_members WHERE team_id = ?').run(teamId);
    db.prepare('DELETE FROM teams WHERE id = ?').run(teamId);
  });
}

export function updateTeam(teamId, fields) {
  const allowed = ['name', 'tag', 'color', 'badge', 'role_id', 'orp_zone', 'raid_channel_id'];
  const entries = Object.entries(fields).filter(([key]) => allowed.includes(key));
  if (entries.length === 0) return getTeam(teamId);

  const assignments = entries.map(([key]) => `${key} = ?`).join(', ');
  getDb()
    .prepare(`UPDATE teams SET ${assignments} WHERE id = ?`)
    .run(...entries.map(([, value]) => value), teamId);
  return getTeam(teamId);
}

export function listTeams(guildId, limit = 25) {
  return getDb()
    .prepare(
      `SELECT t.*, (SELECT COUNT(*) FROM team_members m WHERE m.team_id = t.id) AS members
       FROM teams t WHERE t.guild_id = ? ORDER BY members DESC LIMIT ?`,
    )
    .all(guildId, limit);
}

export function createInvite({ guildId, teamId, inviterId, inviteeId, ttlMs = 86_400_000 }) {
  const id = uniqueId('invite');
  getDb()
    .prepare(
      `INSERT INTO team_invites (id, guild_id, team_id, inviter_id, invitee_id, status, created_at, expires_at)
       VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)`,
    )
    .run(id, guildId, teamId, inviterId, inviteeId, Date.now(), Date.now() + ttlMs);
  return getInvite(id);
}

export function getInvite(inviteId) {
  return getDb().prepare('SELECT * FROM team_invites WHERE id = ?').get(inviteId) ?? null;
}

export function closeInvite(inviteId, status) {
  getDb().prepare('UPDATE team_invites SET status = ? WHERE id = ?').run(status, inviteId);
}

export function pendingInvitesFor(guildId, inviteeId) {
  return getDb()
    .prepare("SELECT * FROM team_invites WHERE guild_id = ? AND invitee_id = ? AND status = 'pending' AND expires_at > ?")
    .all(guildId, inviteeId, Date.now());
}

export function createWar({ guildId, teamId, opponentTeamId }) {
  const id = uniqueId('war');
  getDb()
    .prepare(
      `INSERT INTO team_wars (id, guild_id, team_id, opponent_team_id, status, score, started_at)
       VALUES (?, ?, ?, ?, 'active', '0-0', ?)`,
    )
    .run(id, guildId, teamId, opponentTeamId, Date.now());
  return getWar(id);
}

export function getWar(warId) {
  return getDb().prepare('SELECT * FROM team_wars WHERE id = ?').get(warId) ?? null;
}

export function activeWarFor(teamId) {
  return (
    getDb()
      .prepare("SELECT * FROM team_wars WHERE status = 'active' AND (team_id = ? OR opponent_team_id = ?)")
      .get(teamId, teamId) ?? null
  );
}

export function endWar(warId) {
  getDb().prepare("UPDATE team_wars SET status = 'ended', ended_at = ? WHERE id = ?").run(Date.now(), warId);
}
