import { getDb } from '../index.js';
import { uniqueId } from '../../utils/random.js';

const EDITABLE = new Set([
  'category',
  'priority',
  'assigned_to',
  'sla_due_at',
  'first_response_at',
  'channel_id',
  'status',
  'closed_at',
  'closed_by',
  'transcript',
  'rating',
]);

export function createTicket({ guildId, ownerId, subject, channelId = null, category = 'general', priority = 'normal', slaDueAt = null }) {
  const id = uniqueId('ticket');
  getDb()
    .prepare(
      `INSERT INTO tickets (id, guild_id, channel_id, owner_id, subject, status, created_at, category, priority, sla_due_at)
       VALUES (?, ?, ?, ?, ?, 'open', ?, ?, ?, ?)`,
    )
    .run(id, guildId, channelId, ownerId, subject, Date.now(), category, priority, slaDueAt);
  return getTicket(id);
}

export function getTicket(ticketId) {
  return getDb().prepare('SELECT * FROM tickets WHERE id = ?').get(ticketId) ?? null;
}

export function openTicketsFor(guildId, ownerId) {
  return getDb()
    .prepare("SELECT * FROM tickets WHERE guild_id = ? AND owner_id = ? AND status = 'open'")
    .all(guildId, ownerId);
}

export function listOpenTickets(guildId, limit = 25) {
  return getDb()
    .prepare("SELECT * FROM tickets WHERE guild_id = ? AND status = 'open' ORDER BY created_at DESC LIMIT ?")
    .all(guildId, limit);
}

export function listTickets(guildId, { status = 'open', limit = 25 } = {}) {
  return getDb()
    .prepare('SELECT * FROM tickets WHERE guild_id = ? AND status = ? ORDER BY created_at DESC LIMIT ?')
    .all(guildId, status, limit);
}

export function updateTicket(ticketId, fields) {
  const entries = Object.entries(fields).filter(([key]) => EDITABLE.has(key));
  if (entries.length === 0) return getTicket(ticketId);
  getDb()
    .prepare(`UPDATE tickets SET ${entries.map(([key]) => `${key} = ?`).join(', ')} WHERE id = ?`)
    .run(...entries.map(([, value]) => value), ticketId);
  return getTicket(ticketId);
}

export function assignTicket(ticketId, staffId) {
  return updateTicket(ticketId, { assigned_to: staffId });
}

export function closeTicket(ticketId, { closedBy = null, transcript = null } = {}) {
  return updateTicket(ticketId, {
    status: 'closed',
    closed_at: Date.now(),
    closed_by: closedBy,
    transcript,
  });
}

export function rateTicket(ticketId, rating) {
  return updateTicket(ticketId, { rating: Math.max(1, Math.min(5, Math.trunc(Number(rating) || 0))) });
}

export function setTicketChannel(ticketId, channelId) {
  return updateTicket(ticketId, { channel_id: channelId });
}

export function ticketStats(guildId, now = Date.now()) {
  const row =
    getDb()
      .prepare(
        `SELECT COUNT(*) AS open,
                MIN(created_at) AS oldest,
                AVG(created_at) AS average_created,
                SUM(CASE WHEN sla_due_at IS NOT NULL AND sla_due_at < ? THEN 1 ELSE 0 END) AS overdue,
                SUM(CASE WHEN assigned_to IS NULL THEN 1 ELSE 0 END) AS unassigned
         FROM tickets WHERE guild_id = ? AND status = 'open'`,
      )
      .get(now, guildId) ?? {};

  return {
    open: Number(row.open ?? 0),
    oldest: row.oldest ?? null,
    averageAgeMs: row.average_created ? Math.max(0, now - Number(row.average_created)) : 0,
    overdue: Number(row.overdue ?? 0),
    unassigned: Number(row.unassigned ?? 0),
  };
}
