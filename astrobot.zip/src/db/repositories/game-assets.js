import { getDb } from '../index.js';

/** Per-guild uploaded game artwork. One row per game and slot. */

export function getGameAssetRow(guildId, gameId, slot) {
  return (
    getDb()
      .prepare('SELECT * FROM game_assets WHERE guild_id = ? AND game_id = ? AND slot = ?')
      .get(String(guildId), String(gameId), String(slot)) ?? null
  );
}

export function listGameAssetRows(guildId) {
  return getDb()
    .prepare('SELECT * FROM game_assets WHERE guild_id = ? ORDER BY game_id, slot')
    .all(String(guildId));
}

export function upsertGameAsset({ id, guildId, gameId, slot, label, file, mime, createdBy }) {
  getDb()
    .prepare(
      `INSERT INTO game_assets (id, guild_id, game_id, slot, label, file, mime, created_by, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(guild_id, game_id, slot) DO UPDATE SET
         id = excluded.id,
         label = excluded.label,
         file = excluded.file,
         mime = excluded.mime,
         created_by = excluded.created_by,
         created_at = excluded.created_at`,
    )
    .run(
      String(id),
      String(guildId),
      String(gameId),
      String(slot),
      label ?? null,
      String(file),
      String(mime),
      createdBy ?? null,
      Date.now(),
    );
  return getGameAssetRow(guildId, gameId, slot);
}

export function deleteGameAssetRow(guildId, gameId, slot) {
  return (
    getDb()
      .prepare('DELETE FROM game_assets WHERE guild_id = ? AND game_id = ? AND slot = ?')
      .run(String(guildId), String(gameId), String(slot)).changes > 0
  );
}
