import { getDb } from '../index.js';

/** RCON connection events used for uptime and incident reporting. */

export function recordStatus({ guildId, serverId, status, players = null, createdAt = Date.now() }) {
  getDb()
    .prepare(
      `INSERT INTO server_status_events (guild_id, server_id, status, players, created_at)
       VALUES (?, ?, ?, ?, ?)`,
    )
    .run(guildId, serverId, status, players, createdAt);
}

export function listStatusEvents(guildId, since = 0) {
  return getDb()
    .prepare('SELECT * FROM server_status_events WHERE guild_id = ? AND created_at >= ? ORDER BY created_at ASC')
    .all(guildId, since);
}

export function listStatusEventsFor(serverId, since = 0) {
  return getDb()
    .prepare('SELECT * FROM server_status_events WHERE server_id = ? AND created_at >= ? ORDER BY created_at ASC')
    .all(serverId, since);
}

export function latestStatus(serverId) {
  return getDb()
    .prepare('SELECT * FROM server_status_events WHERE server_id = ? ORDER BY created_at DESC LIMIT 1')
    .get(serverId) ?? null;
}

export function pruneStatusEvents(before) {
  return getDb().prepare('DELETE FROM server_status_events WHERE created_at < ?').run(before).changes;
}
