import { getDb } from '../index.js';
import { uniqueId } from '../../utils/random.js';

export const MOD_ACTIONS = Object.freeze(['warn', 'mute', 'kick', 'ban', 'jail', 'note']);

export function createCase({
  guildId,
  targetId,
  moderatorId,
  action,
  reason = null,
  durationMs = null,
  scope = 'guild',
  serverId = null,
  evidence = null,
}) {
  const id = uniqueId('case');
  getDb()
    .prepare(
      `INSERT INTO mod_cases
         (id, guild_id, target_id, moderator_id, action, reason, duration_ms, expires_at, active, created_at, scope, server_id, evidence)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?)`,
    )
    .run(
      id,
      guildId,
      targetId,
      moderatorId,
      action,
      reason,
      durationMs,
      durationMs ? Date.now() + durationMs : null,
      Date.now(),
      scope,
      serverId,
      evidence,
    );
  return getCase(id);
}

export function getCase(caseId) {
  return getDb().prepare('SELECT * FROM mod_cases WHERE id = ?').get(caseId) ?? null;
}

export function activeCasesFor(guildId, targetId) {
  return getDb()
    .prepare('SELECT * FROM mod_cases WHERE guild_id = ? AND target_id = ? AND active = 1 ORDER BY created_at DESC')
    .all(guildId, targetId);
}

export function casesForTarget(guildId, targetId) {
  return getDb()
    .prepare('SELECT * FROM mod_cases WHERE guild_id = ? AND target_id = ? ORDER BY created_at DESC')
    .all(guildId, targetId);
}

export function recentCases(guildId, limit = 10) {
  return getDb()
    .prepare('SELECT * FROM mod_cases WHERE guild_id = ? ORDER BY created_at DESC LIMIT ?')
    .all(guildId, limit);
}

export function updateCase(caseId, fields) {
  const allowed = ['reason', 'evidence', 'active', 'appeal_status', 'appeal_ticket_id', 'scope', 'server_id'];
  const entries = Object.entries(fields).filter(([key]) => allowed.includes(key));
  if (entries.length === 0) return getCase(caseId);
  getDb()
    .prepare(`UPDATE mod_cases SET ${entries.map(([key]) => `${key} = ?`).join(', ')} WHERE id = ?`)
    .run(...entries.map(([, value]) => value), caseId);
  return getCase(caseId);
}

export function deactivateCase(caseId) {
  getDb().prepare('UPDATE mod_cases SET active = 0 WHERE id = ?').run(caseId);
  return getCase(caseId);
}

export function appealQueue(guildId, limit = 25) {
  return getDb()
    .prepare("SELECT * FROM mod_cases WHERE guild_id = ? AND appeal_status = 'pending' ORDER BY created_at DESC LIMIT ?")
    .all(guildId, limit);
}

/** Case volume per moderator, for staff activity reporting. */
export function staffCaseStats(guildId, sinceMs = 0) {
  return getDb()
    .prepare(
      `SELECT moderator_id,
              COUNT(*) AS total,
              SUM(CASE WHEN action = 'ban' THEN 1 ELSE 0 END) AS bans,
              SUM(CASE WHEN action IN ('warn', 'mute') THEN 1 ELSE 0 END) AS soft_actions
       FROM mod_cases
       WHERE guild_id = ? AND created_at >= ?
       GROUP BY moderator_id
       ORDER BY total DESC`,
    )
    .all(guildId, sinceMs);
}

/** Linked gamertags shared by another Discord account (alt detection). */
export function findAltLinks(guildId, userId) {
  return getDb()
    .prepare(
      `SELECT other.user_id, other.gamertag, other.platform, other.verified_at
       FROM player_links mine
       JOIN player_links other
         ON mine.guild_id = other.guild_id
        AND LOWER(mine.gamertag) = LOWER(other.gamertag)
        AND other.user_id <> mine.user_id
       WHERE mine.guild_id = ? AND mine.user_id = ?`,
    )
    .all(guildId, userId);
}

/** Expires timed punishments; called by the scheduler loop. */
export function sweepExpiredCases() {
  const rows = getDb()
    .prepare('SELECT id FROM mod_cases WHERE active = 1 AND expires_at IS NOT NULL AND expires_at < ?')
    .all(Date.now());
  if (rows.length > 0) {
    const statement = getDb().prepare('UPDATE mod_cases SET active = 0 WHERE id = ?');
    for (const row of rows) statement.run(row.id);
  }
  return rows.length;
}
