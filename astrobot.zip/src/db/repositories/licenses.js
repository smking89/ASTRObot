import { getDb, transaction } from '../index.js';
import { uniqueId } from '../../utils/random.js';

export const LICENSE_TIERS = Object.freeze(['standard', 'pro', 'enterprise']);

export function generateLicenseKey() {
  const block = () => randomBlock(4);
  return `AB-${block()}-${block()}-${block()}`;
}

function randomBlock(length) {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let output = '';
  for (let index = 0; index < length; index += 1) {
    output += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return output;
}

function defaultServerLimit(tier) {
  return ['enterprise', 'max'].includes(String(tier ?? '').toLowerCase()) ? 5 : 1;
}

export function issueLicense({ key = generateLicenseKey(), ownerId = null, tier = 'standard', expiresAt = null, serverLimit = null }) {
  const id = uniqueId('lic');
  const seats = Number(serverLimit);
  getDb()
    .prepare(
      `INSERT INTO licenses (id, key, guild_id, owner_id, tier, status, issued_at, expires_at, server_limit)
       VALUES (?, ?, NULL, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      id,
      key,
      ownerId,
      tier,
      ownerId ? 'active' : 'unassigned',
      Date.now(),
      expiresAt,
      Number.isFinite(seats) && seats > 0 ? Math.trunc(seats) : defaultServerLimit(tier),
    );
  return getLicenseByKey(key);
}

export function getLicenseByKey(key) {
  return getDb().prepare('SELECT * FROM licenses WHERE key = ?').get(String(key).toUpperCase()) ?? null;
}

export function getLicenseById(id) {
  return getDb().prepare('SELECT * FROM licenses WHERE id = ?').get(id) ?? null;
}

export function listLicensesFor(ownerId) {
  return getDb().prepare('SELECT * FROM licenses WHERE owner_id = ? ORDER BY issued_at DESC').all(ownerId);
}

export function listAllLicenses({ limit = 25 } = {}) {
  return getDb().prepare('SELECT * FROM licenses ORDER BY issued_at DESC LIMIT ?').all(limit);
}

export function activateLicense({ key, ownerId }) {
  return transaction((db) => {
    const license = getLicenseByKey(key);
    if (!license) throw new Error('License not found.');
    if (license.status === 'revoked') throw new Error('That license has been revoked.');
    if (license.expires_at && Number(license.expires_at) <= Date.now()) {
      throw new Error('That license has expired.');
    }
    if (license.status === 'active' && license.owner_id && license.owner_id !== ownerId) {
      throw new Error('That license is already activated by another account.');
    }

    db.prepare(
      `UPDATE licenses SET guild_id = NULL, owner_id = ?, status = 'active', activated_at = ? WHERE id = ?`,
    ).run(ownerId, Date.now(), license.id);

    return getLicenseById(license.id);
  });
}

export function transferLicense({ licenseId, newOwnerId, actorId }) {
  return transaction((db) => {
    const license = getLicenseById(licenseId);
    if (!license) throw new Error('License not found.');
    if (license.status === 'revoked') throw new Error('That license has been revoked.');

    db.prepare(
      `UPDATE licenses SET guild_id = NULL, owner_id = ?, status = 'active', transferred_from = ?, activated_at = ? WHERE id = ?`,
    ).run(newOwnerId, license.owner_id ?? actorId, Date.now(), licenseId);

    return getLicenseById(licenseId);
  });
}

export function revokeLicense(licenseId, actorId) {
  getDb()
    .prepare("UPDATE licenses SET status = 'revoked', revoked_at = ?, revoked_by = ? WHERE id = ?")
    .run(Date.now(), actorId, licenseId);
  return getLicenseById(licenseId);
}

export function licenseCounts() {
  return getDb().prepare('SELECT status, COUNT(*) AS count FROM licenses GROUP BY status').all();
}
