import { getDb, transaction } from '../index.js';

export const LEADERBOARD_COLUMNS = Object.freeze({
  wallet: 'wallet',
  bank: 'bank',
  xp: 'xp',
  level: 'level',
  prestige: 'prestige',
  astro_score: 'astro_score',
  playtime: 'playtime_seconds',
  kills: 'kills',
  deaths: 'deaths',
  kd: '(CAST(kills AS REAL) / MAX(deaths, 1))',
  pve_kills: 'pve_kills',
  game_wins: 'game_wins',
  rival_wins: 'rival_wins',
  competition_wins: 'competition_wins',
});

/** Counters that only ever move up, updated by the features that own them. */
const PLAYER_STAT_COLUMNS = new Set(['pve_kills', 'game_wins', 'rival_wins', 'competition_wins']);

export function addPlayerStat(guildId, userId, column, amount = 1) {
  if (!PLAYER_STAT_COLUMNS.has(column)) throw new Error(`Unknown player stat: ${column}`);
  getOrCreateAccount(guildId, userId);
  getDb()
    .prepare(`UPDATE players SET ${column} = ${column} + ? WHERE guild_id = ? AND user_id = ?`)
    .run(Math.trunc(amount), guildId, userId);
  return getAccount(guildId, userId);
}

export function recordPveKill(guildId, userId) {
  getOrCreateAccount(guildId, userId);
  getDb()
    .prepare(
      `UPDATE players SET
         pve_kills = pve_kills + 1,
         kill_streak = kill_streak + 1,
         best_kill_streak = MAX(best_kill_streak, kill_streak + 1)
       WHERE guild_id = ? AND user_id = ?`,
    )
    .run(guildId, userId);
  return getAccount(guildId, userId);
}

/** A player killed by an NPC: PvE death and the kill streak is broken. */
export function recordPveDeath(guildId, userId) {
  getOrCreateAccount(guildId, userId);
  getDb()
    .prepare('UPDATE players SET pve_deaths = pve_deaths + 1, kill_streak = 0 WHERE guild_id = ? AND user_id = ?')
    .run(guildId, userId);
  return getAccount(guildId, userId);
}

/** Every player's current value for one leaderboard metric (used for prize periods). */
export function metricValues(guildId, metric) {
  if (metric === 'referrals') {
    return getDb()
      .prepare('SELECT owner_id AS user_id, uses AS value FROM referrals WHERE guild_id = ?')
      .all(guildId)
      .map((row) => ({ ...row, value: Number(row.value) || 0 }));
  }

  if (metric === 'kd') {
    return getDb()
      .prepare('SELECT user_id, CAST(kills AS REAL) / MAX(deaths, 1) AS value FROM players WHERE guild_id = ?')
      .all(guildId)
      .map((row) => ({ ...row, value: Number(row.value) || 0 }));
  }

  const column = LEADERBOARD_COLUMNS[metric];
  if (!column) return [];

  return getDb()
    .prepare(`SELECT user_id, ${column} AS value FROM players WHERE guild_id = ?`)
    .all(guildId)
    .map((row) => ({ ...row, value: Number(row.value) || 0 }));
}

export function getAccount(guildId, userId) {
  return getDb().prepare('SELECT * FROM players WHERE guild_id = ? AND user_id = ?').get(guildId, userId) ?? null;
}

export function getOrCreateAccount(guildId, userId) {
  const existing = getAccount(guildId, userId);
  if (existing) return existing;

  getDb()
    .prepare('INSERT OR IGNORE INTO players (guild_id, user_id, created_at) VALUES (?, ?, ?)')
    .run(guildId, userId, Date.now());

  return getAccount(guildId, userId);
}

export function adjustBalances(guildId, userId, { wallet = 0, bank = 0 }, { kind = 'adjust', metadata = null, amount = null } = {}) {
  return transaction((db) => {
    getOrCreateAccount(guildId, userId);
    db.prepare(
      `UPDATE players SET wallet = MAX(0, wallet + ?), bank = MAX(0, bank + ?)
       WHERE guild_id = ? AND user_id = ?`,
    ).run(Math.trunc(wallet), Math.trunc(bank), guildId, userId);

    const account = getAccount(guildId, userId);

    if (wallet !== 0 || bank !== 0) {
      db.prepare(
        `INSERT INTO transactions (guild_id, user_id, kind, amount, balance_after, metadata, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
      ).run(
        guildId,
        userId,
        kind,
        // Transfers between wallet and bank net to zero, so the caller can log
        // the moved amount explicitly.
        Math.trunc(amount ?? wallet + bank),
        account.wallet,
        metadata ? JSON.stringify(metadata) : null,
        Date.now(),
      );
    }

    return account;
  });
}

export function setBalances(guildId, userId, { wallet, bank }) {
  return transaction((db) => {
    getOrCreateAccount(guildId, userId);
    db.prepare(
      `UPDATE players SET wallet = COALESCE(?, wallet), bank = COALESCE(?, bank)
       WHERE guild_id = ? AND user_id = ?`,
    ).run(wallet === undefined ? null : Math.trunc(wallet), bank === undefined ? null : Math.trunc(bank), guildId, userId);
    return getAccount(guildId, userId);
  });
}

export function addProgress(guildId, userId, { xp = 0, astroScore = 0, playtimeSeconds = 0, level = null, prestige = null }) {
  return transaction((db) => {
    getOrCreateAccount(guildId, userId);
    db.prepare(
      `UPDATE players SET
         xp = MAX(0, xp + ?),
         astro_score = MAX(0, astro_score + ?),
         playtime_seconds = MAX(0, playtime_seconds + ?),
         level = COALESCE(?, level),
         prestige = COALESCE(?, prestige),
         last_playtime_at = ?
       WHERE guild_id = ? AND user_id = ?`,
    ).run(Math.trunc(xp), Math.trunc(astroScore), Math.trunc(playtimeSeconds), level, prestige, Date.now(), guildId, userId);
    return getAccount(guildId, userId);
  });
}

/** Lifetime daily claims — drives the 10/25/50/100 milestone crates. */
export function countDailyClaims(guildId, userId) {
  const row = getDb().prepare('SELECT daily_claims FROM players WHERE guild_id = ? AND user_id = ?').get(guildId, userId);
  return Number(row?.daily_claims ?? 0);
}

/** Adds one to the lifetime claim counter and returns the new total. */
export function incrementDailyClaims(guildId, userId) {
  getDb()
    .prepare('UPDATE players SET daily_claims = daily_claims + 1 WHERE guild_id = ? AND user_id = ?')
    .run(guildId, userId);
  return countDailyClaims(guildId, userId);
}

export function setStreak(guildId, userId, { streak, lastDaily }) {
  getDb()
    .prepare('UPDATE players SET streak = ?, last_daily = ? WHERE guild_id = ? AND user_id = ?')
    .run(streak, lastDaily, guildId, userId);
  return getAccount(guildId, userId);
}

/**
 * Increments the kill telemetry counters used by leaderboards and the feed
 * placeholders: PvP kills/deaths and the current/best kill streak move together.
 */
export function recordKillStats({ guildId, killerId, victimId }) {
  if (killerId) {
    getOrCreateAccount(guildId, killerId);
    getDb()
      .prepare(
        `UPDATE players SET
           kills = kills + 1,
           pvp_kills = pvp_kills + 1,
           kill_streak = kill_streak + 1,
           best_kill_streak = MAX(best_kill_streak, kill_streak + 1),
           astro_score = astro_score + 5
         WHERE guild_id = ? AND user_id = ?`,
      )
      .run(guildId, killerId);
  }
  if (victimId) {
    getOrCreateAccount(guildId, victimId);
    getDb()
      .prepare('UPDATE players SET deaths = deaths + 1, pvp_deaths = pvp_deaths + 1, kill_streak = 0 WHERE guild_id = ? AND user_id = ?')
      .run(guildId, victimId);
  }
}

export function topPlayers(guildId, column = 'wallet', limit = 15, scopeKey = guildId) {
  const safeColumn = LEADERBOARD_COLUMNS[column] ?? LEADERBOARD_COLUMNS.wallet;
  return getDb()
    .prepare(`SELECT * FROM players WHERE guild_id = ? ORDER BY ${safeColumn} DESC LIMIT ?`)
    .all(scopeKey, Math.min(25, Math.max(1, limit)));
}

/** Cross-server totals for the global leaderboards (one row per user). */
export function globalTopPlayers(metric = 'wallet', limit = 15) {
  if (metric === 'referrals') {
    return getDb()
      .prepare(
        `SELECT owner_id AS user_id, SUM(uses) AS value FROM referrals GROUP BY owner_id ORDER BY value DESC LIMIT ?`,
      )
      .all(Math.min(25, Math.max(1, limit)));
  }

  const expressions = {
    wallet: 'SUM(wallet)',
    bank: 'SUM(bank)',
    xp: 'SUM(xp)',
    level: 'MAX(level)',
    prestige: 'MAX(prestige)',
    astro_score: 'SUM(astro_score)',
    playtime: 'SUM(playtime_seconds)',
    kills: 'SUM(kills)',
    deaths: 'SUM(deaths)',
    pve_kills: 'SUM(pve_kills)',
    game_wins: 'SUM(game_wins)',
    rival_wins: 'SUM(rival_wins)',
    competition_wins: 'SUM(competition_wins)',
  };

  if (metric === 'kd') {
    return getDb()
      .prepare(
        `SELECT user_id, CAST(SUM(kills) AS REAL) / MAX(SUM(deaths), 1) AS value, SUM(kills) AS kills, SUM(deaths) AS deaths
         FROM players GROUP BY user_id ORDER BY value DESC LIMIT ?`,
      )
      .all(Math.min(25, Math.max(1, limit)));
  }

  const expression = expressions[metric] ?? expressions.wallet;
  return getDb()
    .prepare(`SELECT user_id, ${expression} AS value FROM players GROUP BY user_id ORDER BY value DESC LIMIT ?`)
    .all(Math.min(25, Math.max(1, limit)));
}

export function rankFor(guildId, userId, column = 'wallet') {
  const safeColumn = LEADERBOARD_COLUMNS[column] ?? LEADERBOARD_COLUMNS.wallet;
  const account = getAccount(guildId, userId);
  if (!account) return null;

  const row = getDb()
    .prepare(`SELECT COUNT(*) AS higher FROM players WHERE guild_id = ? AND ${safeColumn} > ?`)
    .get(guildId, account[safeColumn]);

  return Number(row?.higher ?? 0) + 1;
}

export function economyTotals(guildId, scopeKey = guildId) {
  return (
    getDb()
      .prepare('SELECT COUNT(*) AS players, COALESCE(SUM(wallet), 0) AS wallet, COALESCE(SUM(bank), 0) AS bank FROM players WHERE guild_id = ?')
      .get(scopeKey) ?? { players: 0, wallet: 0, bank: 0 }
  );
}

export function allAccounts(guildId) {
  return getDb().prepare('SELECT * FROM players WHERE guild_id = ?').all(guildId);
}

export function recentTransactions(guildId, userId, limit = 5) {
  return getDb()
    .prepare('SELECT * FROM transactions WHERE guild_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT ?')
    .all(guildId, userId, limit);
}
