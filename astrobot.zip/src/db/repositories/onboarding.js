import { getDb } from '../index.js';
import { uniqueId } from '../../utils/random.js';

/** Persistence for the onboarding suite. */

export function recordOnboardingEvent({ guildId, userId, kind }) {
  getDb()
    .prepare('INSERT INTO onboarding_events (guild_id, user_id, kind, created_at) VALUES (?, ?, ?, ?)')
    .run(guildId, userId, kind, Date.now());
}

export function onboardingGrowth(guildId, since = Date.now() - 30 * 86_400_000) {
  const rows = getDb()
    .prepare('SELECT kind, COUNT(*) AS count FROM onboarding_events WHERE guild_id = ? AND created_at >= ? GROUP BY kind')
    .all(guildId, since);
  const byKind = Object.fromEntries(rows.map((row) => [row.kind, Number(row.count) || 0]));
  const daily = getDb()
    .prepare(
      `SELECT substr(date(created_at / 1000, 'unixepoch'), 1, 10) AS day,
              SUM(CASE WHEN kind = 'join' THEN 1 ELSE 0 END) AS joins,
              SUM(CASE WHEN kind = 'leave' THEN 1 ELSE 0 END) AS leaves
       FROM onboarding_events WHERE guild_id = ? AND created_at >= ?
       GROUP BY day ORDER BY day ASC`,
    )
    .all(guildId, since);
  return { joins: byKind.join ?? 0, leaves: byKind.leave ?? 0, daily };
}

export function recentJoins(guildId, since = Date.now() - 30 * 86_400_000) {
  return getDb()
    .prepare("SELECT * FROM onboarding_events WHERE guild_id = ? AND kind = 'join' AND created_at >= ? ORDER BY created_at DESC LIMIT 500")
    .all(guildId, since);
}

export function createVerification({ guildId, userId, channelId = null, messageId = null, expiresAt }) {
  const id = uniqueId('verify');
  getDb()
    .prepare(
      'INSERT INTO onboarding_verifications (id, guild_id, user_id, channel_id, message_id, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    )
    .run(id, guildId, userId, channelId, messageId, expiresAt, Date.now());
  return getVerification(id);
}

export function getVerification(id) {
  return getDb().prepare('SELECT * FROM onboarding_verifications WHERE id = ?').get(id) ?? null;
}

export function markVerified(id) {
  getDb().prepare('UPDATE onboarding_verifications SET verified_at = ? WHERE id = ?').run(Date.now(), id);
  return getVerification(id);
}

export function pendingVerifications(guildId, now = Date.now()) {
  return getDb()
    .prepare('SELECT * FROM onboarding_verifications WHERE guild_id = ? AND verified_at IS NULL AND expires_at <= ?')
    .all(guildId, now);
}

export function expireVerification(id) {
  getDb().prepare('UPDATE onboarding_verifications SET verified_at = -1 WHERE id = ?').run(id);
}

export function createGiveaway({ guildId, channelId, hostId, prize, winners = 1, endsAt }) {
  const id = uniqueId('giveaway');
  getDb()
    .prepare(
      `INSERT INTO giveaways (id, guild_id, channel_id, host_id, prize, winners, ends_at, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'active', ?)`,
    )
    .run(id, guildId, channelId, hostId, prize, Math.max(1, Math.trunc(winners)), endsAt, Date.now());
  return getGiveaway(id);
}

export function getGiveaway(id) {
  return getDb().prepare('SELECT * FROM giveaways WHERE id = ?').get(id) ?? null;
}

export function setGiveawayMessage(id, messageId) {
  getDb().prepare('UPDATE giveaways SET message_id = ? WHERE id = ?').run(messageId, id);
}

export function listGiveaways(guildId, limit = 25) {
  return getDb()
    .prepare('SELECT * FROM giveaways WHERE guild_id = ? ORDER BY created_at DESC LIMIT ?')
    .all(guildId, Math.min(100, Math.max(1, limit)));
}

export function listDueGiveaways(now = Date.now()) {
  return getDb().prepare("SELECT * FROM giveaways WHERE status = 'active' AND ends_at <= ? LIMIT 25").all(now);
}

export function addGiveawayEntry(giveawayId, guildId, userId) {
  const result = getDb()
    .prepare('INSERT OR IGNORE INTO giveaway_entries (giveaway_id, guild_id, user_id, created_at) VALUES (?, ?, ?, ?)')
    .run(giveawayId, guildId, userId, Date.now());
  return result.changes > 0;
}

export function listGiveawayEntries(giveawayId) {
  return getDb().prepare('SELECT * FROM giveaway_entries WHERE giveaway_id = ? ORDER BY created_at ASC').all(giveawayId);
}

/** Portal bonus tasks add weighted tickets on top of the base entry. */
export function addGiveawayBonus({ giveawayId, guildId, userId, taskIndex, points }) {
  const result = getDb()
    .prepare(
      `INSERT OR IGNORE INTO giveaway_bonus_entries (giveaway_id, guild_id, user_id, task_index, points, created_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
    )
    .run(
      giveawayId,
      guildId,
      userId,
      Math.max(0, Math.trunc(Number(taskIndex) || 0)),
      Math.max(0, Math.min(1000, Math.trunc(Number(points) || 0))),
      Date.now(),
    );
  return result.changes > 0;
}

export function listGiveawayBonuses(giveawayId, userId = null) {
  const rows = userId
    ? getDb()
        .prepare('SELECT * FROM giveaway_bonus_entries WHERE giveaway_id = ? AND user_id = ? ORDER BY task_index ASC')
        .all(giveawayId, userId)
    : getDb().prepare('SELECT * FROM giveaway_bonus_entries WHERE giveaway_id = ? ORDER BY task_index ASC').all(giveawayId);
  return rows.map((row) => ({ ...row, task_index: Number(row.task_index), points: Number(row.points) }));
}

/** One ticket for each Discord entry plus task points, and one for each public page entry. */
export function giveawayTicketWeights(giveawayId) {
  const db = getDb();
  const discord = db
    .prepare(
      `SELECT e.user_id, 1 + COALESCE(SUM(b.points), 0) AS weight, NULL AS label
       FROM giveaway_entries e
       LEFT JOIN giveaway_bonus_entries b ON b.giveaway_id = e.giveaway_id AND b.user_id = e.user_id
       WHERE e.giveaway_id = ?
       GROUP BY e.user_id`,
    )
    .all(giveawayId);
  // Public email/gamertag entrants have no Discord id. Prefix a stable synthetic
  // id so they can share the draw without colliding with a real member id.
  const pageEntries = db
    .prepare(
      `SELECT 'web:' || p.id AS user_id,
              1 + COALESCE(SUM(b.points), 0) AS weight,
              p.display_name AS label
         FROM giveaway_page_entries p
         LEFT JOIN giveaway_page_bonus_entries b ON b.entry_id = p.id
        WHERE p.giveaway_id = ?
        GROUP BY p.id`,
    )
    .all(giveawayId);
  return [...discord, ...pageEntries].map((row) => ({
    userId: row.user_id,
    weight: Math.max(1, Math.min(25, Number(row.weight) || 1)),
    label: row.label ?? null,
  }));
}

export function giveawayTickets(giveawayId, userId) {
  const bonus = Number(
    getDb()
      .prepare('SELECT COALESCE(SUM(points), 0) AS points FROM giveaway_bonus_entries WHERE giveaway_id = ? AND user_id = ?')
      .get(giveawayId, userId)?.points ?? 0,
  );
  return Math.min(25, 1 + Math.max(0, bonus));
}

export function finishGiveaway(id, status, winnerIds = []) {
  getDb()
    .prepare('UPDATE giveaways SET status = ?, winner_ids = ? WHERE id = ?')
    .run(status, JSON.stringify(winnerIds), id);
  return getGiveaway(id);
}

export function setTempChannel({ channelId, guildId, ownerId, categoryId = null }) {
  getDb()
    .prepare('INSERT OR REPLACE INTO temp_channels (channel_id, guild_id, owner_id, category_id, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(channelId, guildId, ownerId, categoryId, Date.now());
}

export function getTempChannel(channelId) {
  return getDb().prepare('SELECT * FROM temp_channels WHERE channel_id = ?').get(channelId) ?? null;
}

export function deleteTempChannel(channelId) {
  return getDb().prepare('DELETE FROM temp_channels WHERE channel_id = ?').run(channelId).changes > 0;
}

export function hasTimeRole(guildId, userId, roleId) {
  return Boolean(
    getDb()
      .prepare('SELECT 1 FROM time_role_grants WHERE guild_id = ? AND user_id = ? AND role_id = ?')
      .get(guildId, userId, roleId),
  );
}

export function grantTimeRole(guildId, userId, roleId) {
  getDb()
    .prepare('INSERT OR IGNORE INTO time_role_grants (guild_id, user_id, role_id, granted_at) VALUES (?, ?, ?, ?)')
    .run(guildId, userId, roleId, Date.now());
}
