import { getDb } from '../index.js';
import { uniqueId } from '../../utils/random.js';

/** Delivery retries and history for scheduled announcements. */

export function enqueueDeliveryRetry({ announcementId, guildId, needDiscord = false, needGame = false, error = null, now = Date.now() }) {
  const db = getDb();
  const pending = db
    .prepare("SELECT * FROM announcement_deliveries WHERE announcement_id = ? AND status = 'pending'")
    .get(announcementId);

  if (pending) {
    db.prepare(
      `UPDATE announcement_deliveries
       SET need_discord = MAX(need_discord, ?), need_game = MAX(need_game, ?), error = ?, next_attempt_at = ?, updated_at = ?
       WHERE id = ?`,
    ).run(needDiscord ? 1 : 0, needGame ? 1 : 0, error, now, now, pending.id);
    return pending.id;
  }

  const id = uniqueId('delivery');
  db.prepare(
    `INSERT INTO announcement_deliveries
       (id, announcement_id, guild_id, need_discord, need_game, attempts, status, error, next_attempt_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, 0, 'pending', ?, ?, ?, ?)`,
  ).run(id, announcementId, guildId, needDiscord ? 1 : 0, needGame ? 1 : 0, error, now, now, now);
  return id;
}

export function dueDeliveryRetries(now = Date.now(), limit = 25) {
  return getDb()
    .prepare("SELECT * FROM announcement_deliveries WHERE status = 'pending' AND next_attempt_at <= ? ORDER BY next_attempt_at ASC LIMIT ?")
    .all(now, Math.max(1, Math.min(100, Number(limit) || 25)));
}

export function recordDeliveryAttempt(id, { status = 'pending', error = null, nextAttemptAt = null } = {}) {
  getDb()
    .prepare(
      `UPDATE announcement_deliveries
       SET attempts = attempts + 1, status = ?, error = ?, next_attempt_at = COALESCE(?, next_attempt_at), updated_at = ?
       WHERE id = ?`,
    )
    .run(status, error, nextAttemptAt, Date.now(), id);
  return getDb().prepare('SELECT * FROM announcement_deliveries WHERE id = ?').get(id) ?? null;
}

export function listDeliveries(announcementId, limit = 5) {
  return getDb()
    .prepare('SELECT * FROM announcement_deliveries WHERE announcement_id = ? ORDER BY created_at DESC LIMIT ?')
    .all(announcementId, Math.max(1, Math.min(25, Number(limit) || 5)));
}

export function pruneDeliveries(before = Date.now() - 30 * 86_400_000) {
  return getDb()
    .prepare("DELETE FROM announcement_deliveries WHERE status != 'pending' AND updated_at < ?")
    .run(before).changes;
}
