import { getDb, transaction } from '../index.js';
import { getGuildSettings } from './guilds.js';
import { uniqueId } from '../../utils/random.js';
import { ValidationError } from '../../core/errors.js';

export function createPost({ guildId, ownerId, title, description = null, platform = 'any', region = 'any', playersNeeded = 4, tags = [] }) {
  const id = uniqueId('lfg');
  transaction(() => {
    const db = getDb();
    db.prepare(
      `INSERT INTO lfg_posts (id, guild_id, owner_id, title, description, platform, region, players_needed, filled, tags, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, 'open', ?)`,
    ).run(id, guildId, ownerId, title, description, platform, region, playersNeeded, JSON.stringify(tags), Date.now());
    db.prepare('INSERT OR IGNORE INTO lfg_members (post_id, guild_id, user_id, joined_at) VALUES (?, ?, ?, ?)').run(
      id,
      guildId,
      ownerId,
      Date.now(),
    );
  });
  return getPost(id);
}

export function getPost(postId) {
  return getDb().prepare('SELECT * FROM lfg_posts WHERE id = ?').get(postId) ?? null;
}

export function listOpen(guildId, { platform = 'any', limit = 10 } = {}) {
  if (platform === 'any') {
    return getDb()
      .prepare("SELECT * FROM lfg_posts WHERE guild_id = ? AND status = 'open' ORDER BY created_at DESC LIMIT ?")
      .all(guildId, limit);
  }
  return getDb()
    .prepare("SELECT * FROM lfg_posts WHERE guild_id = ? AND status = 'open' AND platform = ? ORDER BY created_at DESC LIMIT ?")
    .all(guildId, platform, limit);
}

export function listOpenGlobal({ limit = 10 } = {}) {
  const rows = getDb()
    .prepare("SELECT * FROM lfg_posts WHERE status = 'open' ORDER BY created_at DESC LIMIT ?")
    .all(Math.max(1, limit) * 4);

  return rows
    .filter((post) => {
      const settings = getGuildSettings(post.guild_id);
      return settings.lfg.enabled !== false && settings.lfg.scope === 'global';
    })
    .slice(0, limit);
}

export function listByOwner(guildId, ownerId) {
  return getDb()
    .prepare("SELECT * FROM lfg_posts WHERE guild_id = ? AND owner_id = ? AND status = 'open' ORDER BY created_at DESC")
    .all(guildId, ownerId);
}

export function countOpenByOwner(guildId, ownerId) {
  const row = getDb()
    .prepare("SELECT COUNT(*) AS count FROM lfg_posts WHERE guild_id = ? AND owner_id = ? AND status = 'open'")
    .get(guildId, ownerId);
  return Number(row?.count ?? 0);
}

export function countMembers(postId) {
  const row = getDb().prepare('SELECT COUNT(*) AS count FROM lfg_members WHERE post_id = ?').get(postId);
  return Number(row?.count ?? 0);
}

export function listMembers(postId) {
  return getDb()
    .prepare('SELECT user_id, joined_at FROM lfg_members WHERE post_id = ? ORDER BY joined_at ASC')
    .all(postId);
}

export function isMember(postId, userId) {
  return Boolean(
    getDb().prepare('SELECT 1 AS ok FROM lfg_members WHERE post_id = ? AND user_id = ?').get(postId, userId),
  );
}

/** Join is idempotent per user and respects the party capacity. */
export function joinPost(postId, userId) {
  return transaction(() => {
    const post = getPost(postId);
    if (!post) throw new ValidationError('That listing no longer exists.');
    if (post.status !== 'open') throw new ValidationError('That listing is closed.');
    if (post.owner_id === userId) throw new ValidationError('You created this listing; the owner is already in the party.');
    if (isMember(postId, userId)) throw new ValidationError('You are already in this party.');

    const filled = countMembers(postId);
    if (filled >= Number(post.players_needed)) throw new ValidationError('That party is already full.');

    getDb()
      .prepare('INSERT INTO lfg_members (post_id, guild_id, user_id, joined_at) VALUES (?, ?, ?, ?)')
      .run(postId, post.guild_id, userId, Date.now());
    refreshFilled(postId);
    return getPost(postId);
  });
}

export function leavePost(postId, userId) {
  return transaction(() => {
    const post = getPost(postId);
    if (!post) throw new ValidationError('That listing no longer exists.');
    if (post.owner_id === userId) throw new ValidationError('The owner cannot leave their own listing. Close it instead.');
    if (!isMember(postId, userId)) throw new ValidationError('You are not in this party.');

    getDb().prepare('DELETE FROM lfg_members WHERE post_id = ? AND user_id = ?').run(postId, userId);
    refreshFilled(postId);
    return getPost(postId);
  });
}

export function updatePost(postId, fields) {
  const allowed = ['title', 'description', 'platform', 'region', 'players_needed', 'filled', 'status', 'channel_id', 'message_id', 'closed_at', 'tags'];
  const entries = Object.entries(fields).filter(([key]) => allowed.includes(key));
  if (entries.length === 0) return getPost(postId);

  getDb()
    .prepare(`UPDATE lfg_posts SET ${entries.map(([key]) => `${key} = ?`).join(', ')} WHERE id = ?`)
    .run(...entries.map(([, value]) => value), postId);
  return getPost(postId);
}

export function closePost(postId) {
  getDb().prepare("UPDATE lfg_posts SET status = 'closed', closed_at = ? WHERE id = ?").run(Date.now(), postId);
  return getPost(postId);
}

export function setPostMessage(postId, channelId, messageId) {
  getDb().prepare('UPDATE lfg_posts SET channel_id = ?, message_id = ? WHERE id = ?').run(channelId, messageId, postId);
}

export function sweepStale(guildId, staleMs) {
  const cutoff = Date.now() - staleMs;
  const stale = getDb()
    .prepare("SELECT id FROM lfg_posts WHERE guild_id = ? AND status = 'open' AND created_at < ?")
    .all(guildId, cutoff);
  for (const post of stale) closePost(post.id);
  return stale.length;
}

function refreshFilled(postId) {
  getDb()
    .prepare('UPDATE lfg_posts SET filled = (SELECT COUNT(*) FROM lfg_members WHERE post_id = ?) WHERE id = ?')
    .run(postId, postId);
}
