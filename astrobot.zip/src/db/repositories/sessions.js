import { getDb } from '../index.js';

/** Player sessions derived from RCON join/leave telemetry. */

export function openSession({ guildId, serverId = null, gamertag, userId = null, startedAt = Date.now() }) {
  if (!gamertag) return null;
  const existing = getDb()
    .prepare(
      `SELECT * FROM player_sessions
       WHERE guild_id = ? AND LOWER(gamertag) = LOWER(?) AND ended_at IS NULL
       ORDER BY started_at DESC LIMIT 1`,
    )
    .get(guildId, gamertag);
  if (existing) return existing;

  const result = getDb()
    .prepare(
      `INSERT INTO player_sessions (guild_id, server_id, gamertag, user_id, started_at)
       VALUES (?, ?, ?, ?, ?)`,
    )
    .run(guildId, serverId, gamertag, userId, startedAt);
  return getDb().prepare('SELECT * FROM player_sessions WHERE id = ?').get(result.lastInsertRowid) ?? null;
}

export function closeSession({ guildId, gamertag, endedAt = Date.now() }) {
  if (!gamertag) return null;
  const row = getDb()
    .prepare(
      `SELECT * FROM player_sessions
       WHERE guild_id = ? AND LOWER(gamertag) = LOWER(?) AND ended_at IS NULL
       ORDER BY started_at DESC LIMIT 1`,
    )
    .get(guildId, gamertag);
  if (!row) return null;

  const duration = Math.max(0, Math.round((endedAt - row.started_at) / 1000));
  getDb()
    .prepare('UPDATE player_sessions SET ended_at = ?, duration_seconds = ? WHERE id = ?')
    .run(endedAt, duration, row.id);
  return getDb().prepare('SELECT * FROM player_sessions WHERE id = ?').get(row.id) ?? null;
}

export function listSessions(guildId, since = 0, limit = 5000) {
  return getDb()
    .prepare('SELECT * FROM player_sessions WHERE guild_id = ? AND started_at >= ? ORDER BY started_at ASC LIMIT ?')
    .all(guildId, since, limit);
}

export function closeStaleSessions(guildId, cutoff = Date.now() - 12 * 3_600_000) {
  const rows = getDb()
    .prepare('SELECT id, started_at FROM player_sessions WHERE guild_id = ? AND ended_at IS NULL AND started_at < ?')
    .all(guildId, cutoff);
  const statement = getDb().prepare('UPDATE player_sessions SET ended_at = ?, duration_seconds = ? WHERE id = ?');
  for (const row of rows) statement.run(cutoff, Math.round((cutoff - row.started_at) / 1000), row.id);
  return rows.length;
}
