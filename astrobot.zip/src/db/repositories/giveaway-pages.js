import { randomUUID } from 'node:crypto';
import { getDb } from '../index.js';
import { uniqueId } from '../../utils/random.js';
import { DEFAULT_PORTAL_CONFIG } from '../../config/giveaway-portal.js';

const USERNAME_RE = /^[a-z0-9](?:[a-z0-9-]{1,28}[a-z0-9])$/;
const RESERVED_USERNAMES = new Set([
  'admin',
  'api',
  'app',
  'astro',
  'dashboard',
  'giveaway',
  'giveaways',
  'help',
  'mail',
  'status',
  'support',
  'www',
]);
const STATUSES = new Set(['active', 'ended', 'cancelled']);
const HEX_COLOR = /^#[0-9a-f]{6}$/i;

export const DEFAULT_GIVEAWAY_THEME = Object.freeze({
  brand: 'Astro',
  colors: {
    bg: '#07070d',
    cyan: '#00f0ff',
    magenta: '#ff2ec4',
    lime: '#c6ff3d',
    ink: '#eef0f8',
  },
});

const themeColor = (value, fallback) => (HEX_COLOR.test(String(value ?? '')) ? String(value) : fallback);
const DEFAULT_BONUS_TASKS = Object.freeze(
  DEFAULT_PORTAL_CONFIG.tasks.slice(1).map((task) => Object.freeze({ ...task, enabled: true })),
);
const DEFAULT_FAQ = DEFAULT_PORTAL_CONFIG.faq;

function taskUrl(value) {
  const text = String(value ?? '').trim().slice(0, 500);
  return /^https?:\/\//i.test(text) ? text : '';
}

/** Per-giveaway bonus tasks. `null`/missing keeps the legacy defaults. */
export function normalizeBonusTasks(value) {
  const source = Array.isArray(value) ? value : DEFAULT_BONUS_TASKS;
  return source
    .filter((task) => task && typeof task === 'object')
    .map((task) => ({
      title: String(task.title ?? '').trim().slice(0, 80),
      subtitle: String(task.subtitle ?? '').trim().slice(0, 120),
      points: Math.max(0, Math.min(25, Math.trunc(Number(task.points) || 0))),
      icon: String(task.icon ?? 'link').trim().slice(0, 20) || 'link',
      url: taskUrl(task.url),
      enabled: task.enabled !== false,
    }))
    .filter((task) => task.title)
    .slice(0, 10);
}

/** Per-giveaway FAQ. `null`/missing keeps the legacy defaults; [] hides it. */
export function normalizeFaq(value) {
  const source = Array.isArray(value) ? value : DEFAULT_FAQ;
  return source
    .filter((item) => item && typeof item === 'object')
    .map((item) => ({
      question: String(item.question ?? '').trim().slice(0, 180),
      answer: String(item.answer ?? '').trim().slice(0, 1200),
    }))
    .filter((item) => item.question && item.answer)
    .slice(0, 12);
}

export function normalizeTheme(value) {
  const source = value && typeof value === 'object' ? value : {};
  const colors = source.colors && typeof source.colors === 'object' ? source.colors : {};
  return {
    brand: String(source.brand ?? DEFAULT_GIVEAWAY_THEME.brand).trim().slice(0, 40) || DEFAULT_GIVEAWAY_THEME.brand,
    colors: {
      bg: themeColor(colors.bg, DEFAULT_GIVEAWAY_THEME.colors.bg),
      cyan: themeColor(colors.cyan, DEFAULT_GIVEAWAY_THEME.colors.cyan),
      magenta: themeColor(colors.magenta, DEFAULT_GIVEAWAY_THEME.colors.magenta),
      lime: themeColor(colors.lime, DEFAULT_GIVEAWAY_THEME.colors.lime),
      ink: themeColor(colors.ink, DEFAULT_GIVEAWAY_THEME.colors.ink),
    },
  };
}

function parseJson(value, fallback) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

export function normalizeUsername(value) {
  return String(value ?? '').trim().toLowerCase().slice(0, 30);
}

export function usernameError(value) {
  const username = normalizeUsername(value);
  if (!USERNAME_RE.test(username)) return 'Use 3-30 lowercase letters, numbers or hyphens.';
  if (RESERVED_USERNAMES.has(username)) return 'That username is reserved.';
  return null;
}

export function normalizeLinkTree(value) {
  if (!Array.isArray(value)) return [];
  return value
    .filter((entry) => entry && typeof entry === 'object')
    .map((entry) => ({
      label: String(entry.label ?? '').trim().slice(0, 60),
      url: String(entry.url ?? '').trim().slice(0, 500),
    }))
    .filter((entry) => entry.label && /^https?:\/\//i.test(entry.url))
    .slice(0, 20);
}

function mapGiveaway(row) {
  if (!row) return null;
  return {
    id: row.id,
    guildId: row.guild_id,
    username: row.username,
    prize: row.prize,
    description: row.description ?? '',
    winners: Number(row.winners) || 1,
    endsAt: Number(row.ends_at) || 0,
    status: row.status,
    createdAt: Number(row.created_at) || 0,
    theme: normalizeTheme(parseJson(row.theme, {})),
    tasks: normalizeBonusTasks(parseJson(row.bonus_tasks, null)),
    faq: normalizeFaq(parseJson(row.faq, null)),
    faqEnabled: row.faq_enabled !== 0,
    links: parseJson(row.link_tree, []),
    views: Number(row.views) || 0,
    linkPageViews: Number(row.link_page_views) || 0,
    linkClicks: Number(row.link_clicks) || 0,
    pageEntries: Number(row.page_entries) || 0,
    discordEntries: Number(row.discord_entries) || 0,
    bonusClaims: Number(row.bonus_claims) || 0,
    entries: (Number(row.page_entries) || 0) + (Number(row.discord_entries) || 0),
  };
}

const COUNT_COLUMNS = `
  (SELECT COUNT(*) FROM giveaway_events e WHERE e.giveaway_id = g.id AND e.kind = 'view') AS views,
  (SELECT COUNT(*) FROM giveaway_events e WHERE e.giveaway_id = g.id AND e.kind = 'links_view') AS link_page_views,
  (SELECT COUNT(*) FROM giveaway_events e WHERE e.giveaway_id = g.id AND e.kind = 'link_click') AS link_clicks,
  (SELECT COUNT(*) FROM giveaway_page_entries p WHERE p.giveaway_id = g.id) AS page_entries,
  (SELECT COUNT(*) FROM giveaway_entries d WHERE d.giveaway_id = g.id) AS discord_entries,
  (SELECT COUNT(*) FROM giveaway_bonus_entries b WHERE b.giveaway_id = g.id)
    + (SELECT COUNT(*) FROM giveaway_page_bonus_entries pb WHERE pb.giveaway_id = g.id) AS bonus_claims`;

export function listManagedGiveaways(guildId) {
  return getDb()
    .prepare(
      `SELECT g.*, ${COUNT_COLUMNS}
       FROM giveaways g
       WHERE g.guild_id = ? AND g.username IS NOT NULL
       ORDER BY g.created_at DESC`,
    )
    .all(guildId)
    .map(mapGiveaway);
}

export function getManagedGiveaway(id, guildId = null) {
  const row = guildId
    ? getDb()
        .prepare(`SELECT g.*, ${COUNT_COLUMNS} FROM giveaways g WHERE g.id = ? AND g.guild_id = ?`)
        .get(id, guildId)
    : getDb().prepare(`SELECT g.*, ${COUNT_COLUMNS} FROM giveaways g WHERE g.id = ?`).get(id);
  return mapGiveaway(row);
}

export function getManagedGiveawayByUsername(username) {
  const row = getDb()
    .prepare(`SELECT g.*, ${COUNT_COLUMNS} FROM giveaways g WHERE g.username = ? COLLATE NOCASE`)
    .get(normalizeUsername(username));
  return mapGiveaway(row);
}

export function usernameTaken(username, exceptId = null) {
  const row = exceptId
    ? getDb()
        .prepare('SELECT 1 FROM giveaways WHERE username = ? COLLATE NOCASE AND id <> ?')
        .get(normalizeUsername(username), exceptId)
    : getDb().prepare('SELECT 1 FROM giveaways WHERE username = ? COLLATE NOCASE').get(normalizeUsername(username));
  return Boolean(row);
}

export function createManagedGiveaway({
  guildId,
  username,
  prize,
  description = '',
  winners = 1,
  endsAt,
  status = 'active',
  links = [],
  theme = null,
  tasks = null,
  faq = null,
  faqEnabled = true,
}) {
  const id = uniqueId('giveaway');
  getDb()
    .prepare(
      `INSERT INTO giveaways
         (id, guild_id, channel_id, host_id, prize, winners, ends_at, status, created_at, username, description, link_tree, theme, bonus_tasks, faq, faq_enabled)
       VALUES (?, ?, 'portal', 'dashboard', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      id,
      guildId,
      prize,
      Math.max(1, Math.trunc(Number(winners) || 1)),
      Number(endsAt),
      STATUSES.has(status) ? status : 'active',
      Date.now(),
      normalizeUsername(username),
      String(description ?? '').trim().slice(0, 1200),
      JSON.stringify(normalizeLinkTree(links)),
      JSON.stringify(normalizeTheme(theme)),
      JSON.stringify(normalizeBonusTasks(tasks)),
      JSON.stringify(normalizeFaq(faq)),
      faqEnabled === false ? 0 : 1,
    );
  return getManagedGiveaway(id, guildId);
}

export function updateManagedGiveaway(id, guildId, patch) {
  const current = getManagedGiveaway(id, guildId);
  if (!current) return null;
  getDb()
    .prepare(
      `UPDATE giveaways SET
         username = ?, prize = ?, description = ?, winners = ?, ends_at = ?, status = ?, link_tree = ?, theme = ?, bonus_tasks = ?, faq = ?, faq_enabled = ?
       WHERE id = ? AND guild_id = ?`,
    )
    .run(
      patch.username === undefined ? current.username : normalizeUsername(patch.username),
      patch.prize === undefined ? current.prize : String(patch.prize).trim().slice(0, 160),
      patch.description === undefined ? current.description : String(patch.description).trim().slice(0, 1200),
      patch.winners === undefined ? current.winners : Math.max(1, Math.trunc(Number(patch.winners) || 1)),
      patch.endsAt === undefined ? current.endsAt : Number(patch.endsAt),
      patch.status === undefined ? current.status : STATUSES.has(patch.status) ? patch.status : current.status,
      patch.links === undefined ? JSON.stringify(current.links) : JSON.stringify(normalizeLinkTree(patch.links)),
      patch.theme === undefined ? JSON.stringify(normalizeTheme(current.theme)) : JSON.stringify(normalizeTheme(patch.theme)),
      patch.tasks === undefined ? JSON.stringify(normalizeBonusTasks(current.tasks)) : JSON.stringify(normalizeBonusTasks(patch.tasks)),
      patch.faq === undefined ? JSON.stringify(normalizeFaq(current.faq)) : JSON.stringify(normalizeFaq(patch.faq)),
      patch.faqEnabled === undefined ? (current.faqEnabled ? 1 : 0) : patch.faqEnabled ? 1 : 0,
      id,
      guildId,
    );
  return getManagedGiveaway(id, guildId);
}

export function deleteManagedGiveaway(id, guildId) {
  const db = getDb();
  const exists = db.prepare('SELECT 1 FROM giveaways WHERE id = ? AND guild_id = ?').get(id, guildId);
  if (!exists) return false;
  db.exec('BEGIN');
  try {
    db.prepare('DELETE FROM giveaway_entries WHERE giveaway_id = ?').run(id);
    db.prepare('DELETE FROM giveaway_bonus_entries WHERE giveaway_id = ?').run(id);
    db.prepare('DELETE FROM giveaway_page_bonus_entries WHERE giveaway_id = ?').run(id);
    db.prepare('DELETE FROM giveaway_page_entries WHERE giveaway_id = ?').run(id);
    db.prepare('DELETE FROM giveaway_events WHERE giveaway_id = ?').run(id);
    db.prepare('DELETE FROM giveaway_entry_tokens WHERE giveaway_id = ?').run(id);
    db.prepare('DELETE FROM giveaway_domain_checks WHERE giveaway_id = ?').run(id);
    db.prepare('DELETE FROM giveaway_domain_alert_acks WHERE giveaway_id = ?').run(id);
    db.prepare('DELETE FROM giveaway_domain_webhook_tests WHERE giveaway_id = ?').run(id);
    db.prepare('DELETE FROM giveaways WHERE id = ? AND guild_id = ?').run(id, guildId);
    db.exec('COMMIT');
    return true;
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}

export function recordGiveawayEvent({ giveawayId, guildId, kind, path = null, referrer = null, linkIndex = null }) {
  try {
    getDb()
      .prepare(
        'INSERT INTO giveaway_events (giveaway_id, guild_id, kind, path, referrer, link_index, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      )
      .run(giveawayId, guildId, kind, path, referrer, linkIndex, Date.now());
  } catch {
    // Analytics is best-effort and must never break the public page.
  }
}

function pageEntrySummary(entryId) {
  const db = getDb();
  const claims = db
    .prepare('SELECT task_index, points FROM giveaway_page_bonus_entries WHERE entry_id = ? ORDER BY task_index ASC')
    .all(entryId);
  const bonusPoints = claims.reduce((sum, claim) => sum + (Number(claim.points) || 0), 0);
  return {
    tickets: Math.min(25, 1 + Math.max(0, bonusPoints)),
    claims: claims.map((claim) => Number(claim.task_index)),
    bonusPoints,
  };
}

export function recordPageEntry({ giveawayId, guildId, displayName, email, region = null }) {
  const db = getDb();
  const normalizedEmail = email.toLowerCase();
  const accessToken = randomUUID().replaceAll('-', '');
  const result = db
    .prepare(
      `INSERT OR IGNORE INTO giveaway_page_entries
         (id, giveaway_id, guild_id, display_name, email, region, access_token, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(randomUUID(), giveawayId, guildId, displayName, normalizedEmail, region, accessToken, Date.now());
  let entry = db
    .prepare('SELECT id, access_token FROM giveaway_page_entries WHERE giveaway_id = ? AND email = ? COLLATE NOCASE')
    .get(giveawayId, normalizedEmail);
  if (entry && !entry.access_token) {
    db.prepare('UPDATE giveaway_page_entries SET access_token = ? WHERE id = ?').run(accessToken, entry.id);
    entry = { ...entry, access_token: accessToken };
  }
  const count = Number(
    db.prepare('SELECT COUNT(*) AS count FROM giveaway_page_entries WHERE giveaway_id = ?').get(giveawayId)?.count ?? 0,
  );
  const summary = entry ? pageEntrySummary(entry.id) : { tickets: 1, claims: [], bonusPoints: 0 };
  return {
    inserted: result.changes > 0,
    count,
    entryId: entry?.id ?? null,
    accessToken: entry?.access_token ?? null,
    ...summary,
  };
}

export function getPageEntryState({ giveawayId, entryId, token }) {
  const entry = getDb()
    .prepare('SELECT id, display_name, access_token FROM giveaway_page_entries WHERE giveaway_id = ? AND id = ? AND access_token = ?')
    .get(giveawayId, String(entryId ?? ''), String(token ?? ''));
  if (!entry) return null;
  return {
    entryId: entry.id,
    displayName: entry.display_name,
    ...pageEntrySummary(entry.id),
  };
}

export function claimPageBonus({ giveawayId, entryId, token, taskIndex, points }) {
  const db = getDb();
  const entry = db
    .prepare('SELECT id, display_name FROM giveaway_page_entries WHERE giveaway_id = ? AND id = ? AND access_token = ?')
    .get(giveawayId, String(entryId ?? ''), String(token ?? ''));
  if (!entry) return null;
  const index = Math.max(1, Math.trunc(Number(taskIndex) || 0));
  const score = Math.max(0, Math.min(25, Math.trunc(Number(points) || 0)));
  const result = db
    .prepare(
      `INSERT OR IGNORE INTO giveaway_page_bonus_entries
         (entry_id, giveaway_id, task_index, points, claimed_at)
       VALUES (?, ?, ?, ?, ?)`,
    )
    .run(entry.id, giveawayId, index, score, Date.now());
  return {
    claimed: result.changes > 0,
    entryId: entry.id,
    displayName: entry.display_name,
    ...pageEntrySummary(entry.id),
  };
}

export function listPageEntries(giveawayId, guildId) {
  return getDb()
    .prepare(
      `SELECT p.id, p.display_name, p.email, p.region, p.created_at,
              1 + COALESCE(SUM(b.points), 0) AS tickets,
              GROUP_CONCAT(b.task_index) AS task_indexes
         FROM giveaway_page_entries p
         LEFT JOIN giveaway_page_bonus_entries b ON b.entry_id = p.id
        WHERE p.giveaway_id = ? AND p.guild_id = ?
        GROUP BY p.id
        ORDER BY p.created_at DESC`,
    )
    .all(giveawayId, guildId)
    .map((row) => ({
      id: row.id,
      displayName: row.display_name,
      email: row.email,
      region: row.region ?? null,
      createdAt: Number(row.created_at) || 0,
      tickets: Math.min(25, Number(row.tickets) || 1),
      taskIndexes: row.task_indexes ? String(row.task_indexes).split(',').map(Number) : [],
    }));
}

/** Public-safe recent-entry feed for the live ticker. Never includes email. */
export function recentPageEntries(giveawayId, limit = 12) {
  const safeLimit = Math.max(1, Math.min(50, Math.trunc(Number(limit) || 12)));
  return getDb()
    .prepare(
      `SELECT display_name, region, created_at
         FROM giveaway_page_entries
        WHERE giveaway_id = ?
        ORDER BY created_at DESC
        LIMIT ?`,
    )
    .all(giveawayId, safeLimit)
    .map((row) => ({
      displayName: row.display_name,
      region: row.region ?? null,
      createdAt: Number(row.created_at) || 0,
    }));
}

export function listDiscordEntries(giveawayId, guildId) {
  return getDb()
    .prepare(
      `SELECT e.user_id, MIN(e.created_at) AS created_at,
              1 + COALESCE(SUM(b.points), 0) AS tickets,
              GROUP_CONCAT(b.task_index) AS task_indexes
         FROM giveaway_entries e
         LEFT JOIN giveaway_bonus_entries b
           ON b.giveaway_id = e.giveaway_id AND b.user_id = e.user_id
        WHERE e.giveaway_id = ? AND e.guild_id = ?
        GROUP BY e.user_id
        ORDER BY created_at DESC`,
    )
    .all(giveawayId, guildId)
    .map((row) => ({
      id: row.user_id,
      displayName: row.user_id,
      email: '',
      source: 'discord',
      createdAt: Number(row.created_at) || 0,
      tickets: Math.min(25, Number(row.tickets) || 1),
      taskIndexes: row.task_indexes ? String(row.task_indexes).split(',').map(Number) : [],
    }));
}

export function recordDomainCheck({ giveawayId, guildId, host, status, checks, checkedAt = new Date().toISOString() }) {
  getDb()
    .prepare(
      `INSERT INTO giveaway_domain_checks (giveaway_id, guild_id, host, status, checks, checked_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
    )
    .run(
      giveawayId,
      guildId,
      host,
      status === 'ok' ? 'ok' : 'fail',
      JSON.stringify(Array.isArray(checks) ? checks : []),
      Number.isFinite(Number(checkedAt)) ? Number(checkedAt) : new Date(checkedAt).getTime() || Date.now(),
    );
  return latestDomainCheck(giveawayId);
}

export function listDomainChecks(giveawayId, guildId, limit = 25) {
  return getDb()
    .prepare(
      `SELECT host, status, checks, checked_at
         FROM giveaway_domain_checks
        WHERE giveaway_id = ? AND guild_id = ?
        ORDER BY checked_at DESC, id DESC
        LIMIT ?`,
    )
    .all(giveawayId, guildId, Math.min(100, Math.max(1, Number(limit) || 25)))
    .map((row) => {
      let checks = [];
      try {
        checks = JSON.parse(row.checks);
      } catch {
        checks = [];
      }
      return {
        host: row.host,
        status: row.status,
        checks,
        checkedAt: new Date(Number(row.checked_at) || 0).toISOString(),
      };
    });
}

export function acknowledgeDomainAlert({ giveawayId, guildId, actorId = null }) {
  const now = Date.now();
  getDb()
    .prepare(
      `INSERT INTO giveaway_domain_alert_acks (giveaway_id, guild_id, acknowledged_at, acknowledged_by)
       VALUES (?, ?, ?, ?)
       ON CONFLICT(giveaway_id) DO UPDATE SET
         acknowledged_at = excluded.acknowledged_at,
         acknowledged_by = excluded.acknowledged_by`,
    )
    .run(giveawayId, guildId, now, actorId);
  return new Date(now).toISOString();
}

export function domainAlertAcknowledgement(giveawayId) {
  const row = getDb()
    .prepare('SELECT acknowledged_at FROM giveaway_domain_alert_acks WHERE giveaway_id = ?')
    .get(giveawayId);
  return row ? new Date(Number(row.acknowledged_at) || 0).toISOString() : null;
}

export function clearDomainAlertAcknowledgement(giveawayId) {
  getDb().prepare('DELETE FROM giveaway_domain_alert_acks WHERE giveaway_id = ?').run(giveawayId);
}

export function recordDomainWebhookTest({ giveawayId, guildId, ok, detail = null }) {
  const testedAt = Date.now();
  getDb()
    .prepare(
      `INSERT INTO giveaway_domain_webhook_tests (giveaway_id, guild_id, tested_at, ok, detail)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(giveaway_id) DO UPDATE SET
         tested_at = excluded.tested_at,
         ok = excluded.ok,
         detail = excluded.detail`,
    )
    .run(giveawayId, guildId, testedAt, ok ? 1 : 0, detail ? String(detail).slice(0, 300) : null);
  return { testedAt: new Date(testedAt).toISOString(), ok: Boolean(ok), detail };
}

export function latestDomainWebhookTest(giveawayId) {
  const row = getDb()
    .prepare('SELECT tested_at, ok, detail FROM giveaway_domain_webhook_tests WHERE giveaway_id = ?')
    .get(giveawayId);
  if (!row) return null;
  return {
    testedAt: new Date(Number(row.tested_at) || 0).toISOString(),
    ok: Boolean(row.ok),
    detail: row.detail ?? null,
  };
}

export function latestDomainCheck(giveawayId) {
  const row = getDb()
    .prepare('SELECT host, status, checks, checked_at FROM giveaway_domain_checks WHERE giveaway_id = ? ORDER BY checked_at DESC, id DESC LIMIT 1')
    .get(giveawayId);
  if (!row) return null;
  let checks = [];
  try {
    checks = JSON.parse(row.checks);
  } catch {
    checks = [];
  }
  return {
    host: row.host,
    status: row.status,
    checks,
    checkedAt: new Date(Number(row.checked_at) || 0).toISOString(),
  };
}

export function giveawayAnalytics(giveawayId) {
  const publicTaskClaims = Object.fromEntries(
    getDb()
      .prepare('SELECT task_index, COUNT(*) AS claims FROM giveaway_page_bonus_entries WHERE giveaway_id = ? GROUP BY task_index')
      .all(giveawayId)
      .map((row) => [String(row.task_index), Number(row.claims) || 0]),
  );
  const counts = getDb()
    .prepare(
      `SELECT
         (SELECT COUNT(*) FROM giveaway_events WHERE giveaway_id = ? AND kind = 'view') AS views,
         (SELECT COUNT(*) FROM giveaway_events WHERE giveaway_id = ? AND kind = 'links_view') AS linkPageViews,
         (SELECT COUNT(*) FROM giveaway_events WHERE giveaway_id = ? AND kind = 'link_click') AS linkClicks,
         (SELECT COUNT(*) FROM giveaway_page_entries WHERE giveaway_id = ?) AS pageEntries,
         (SELECT COUNT(*) FROM giveaway_entries WHERE giveaway_id = ?) AS discordEntries,
         (SELECT COUNT(*) FROM giveaway_bonus_entries WHERE giveaway_id = ?) AS discordBonusClaims,
         (SELECT COUNT(*) FROM giveaway_page_bonus_entries WHERE giveaway_id = ?) AS pageBonusClaims`,
    )
    .get(giveawayId, giveawayId, giveawayId, giveawayId, giveawayId, giveawayId, giveawayId);
  const entries = Number(counts.pageEntries) + Number(counts.discordEntries);
  const daily = getDb()
    .prepare(
      `SELECT day, SUM(views) AS views, SUM(entries) AS entries FROM (
         SELECT strftime('%Y-%m-%d', created_at / 1000, 'unixepoch') AS day, COUNT(*) AS views, 0 AS entries
           FROM giveaway_events WHERE giveaway_id = ? AND kind = 'view'
         UNION ALL
         SELECT strftime('%Y-%m-%d', created_at / 1000, 'unixepoch') AS day, 0 AS views, COUNT(*) AS entries
           FROM giveaway_page_entries WHERE giveaway_id = ?
         UNION ALL
         SELECT strftime('%Y-%m-%d', created_at / 1000, 'unixepoch') AS day, 0 AS views, COUNT(*) AS entries
           FROM giveaway_entries WHERE giveaway_id = ?
       ) WHERE day IS NOT NULL GROUP BY day ORDER BY day ASC`,
    )
    .all(giveawayId, giveawayId, giveawayId)
    .map((row) => ({ day: row.day, views: Number(row.views), entries: Number(row.entries) }));
  return {
    views: Number(counts.views),
    linkPageViews: Number(counts.linkPageViews),
    linkClicks: Number(counts.linkClicks),
    pageEntries: Number(counts.pageEntries),
    discordEntries: Number(counts.discordEntries),
    entries,
    bonusClaims: Number(counts.discordBonusClaims) + Number(counts.pageBonusClaims),
    publicTaskClaims,
    conversion: Number(counts.views) ? Math.round((entries / Number(counts.views)) * 1000) / 10 : 0,
    daily,
  };
}