import { getDb } from '../index.js';

/** Clan ranks, uploaded clan badges and per-player badge awards. */

export function listClanRanks(guildId) {
  return getDb()
    .prepare('SELECT key, label, icon, position FROM clan_ranks WHERE guild_id = ? ORDER BY position, created_at')
    .all(guildId);
}

export function insertClanRank({ guildId, key, label, icon, position = 0 }) {
  getDb()
    .prepare('INSERT INTO clan_ranks (guild_id, key, label, icon, position, created_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(guildId, key, label, icon, position, Date.now());
}

export function updateClanRankRow({ guildId, key, label, icon }) {
  getDb().prepare('UPDATE clan_ranks SET label = ?, icon = ? WHERE guild_id = ? AND key = ?').run(label, icon, guildId, key);
}

export function deleteClanRankRow(guildId, key) {
  return getDb().prepare('DELETE FROM clan_ranks WHERE guild_id = ? AND key = ?').run(guildId, key).changes > 0;
}

export function listClanBadgeRows(guildId) {
  return getDb()
    .prepare('SELECT * FROM clan_badges WHERE guild_id = ? ORDER BY created_at DESC')
    .all(guildId);
}

export function insertClanBadge({ id, guildId, label, file, createdBy }) {
  getDb()
    .prepare('INSERT INTO clan_badges (id, guild_id, label, file, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(id, guildId, label, file, createdBy ?? null, Date.now());
}

export function deleteClanBadgeRow(guildId, id) {
  return getDb().prepare('DELETE FROM clan_badges WHERE guild_id = ? AND id = ?').run(guildId, id).changes > 0;
}

export function getClanBadgeRow(guildId, id) {
  return getDb().prepare('SELECT * FROM clan_badges WHERE guild_id = ? AND id = ?').get(guildId, id) ?? null;
}

export function listAwardedBadges(guildId, userId) {
  return getDb()
    .prepare('SELECT * FROM player_badges WHERE guild_id = ? AND user_id = ? ORDER BY awarded_at DESC')
    .all(guildId, userId);
}

export function insertAwardedBadge({ guildId, userId, badgeId, awardedBy }) {
  return (
    getDb()
      .prepare('INSERT OR IGNORE INTO player_badges (guild_id, user_id, badge_id, awarded_by, awarded_at) VALUES (?, ?, ?, ?, ?)')
      .run(guildId, userId, badgeId, awardedBy ?? null, Date.now()).changes > 0
  );
}

export function deleteAwardedBadgesFor(guildId, badgeId) {
  return getDb().prepare('DELETE FROM player_badges WHERE guild_id = ? AND badge_id = ?').run(guildId, badgeId).changes;
}

export function deleteAwardedBadge(guildId, userId, badgeId) {
  return (
    getDb().prepare('DELETE FROM player_badges WHERE guild_id = ? AND user_id = ? AND badge_id = ?').run(guildId, userId, badgeId)
      .changes > 0
  );
}
