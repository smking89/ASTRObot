import { getDb, transaction } from '../index.js';
import { uniqueId } from '../../utils/random.js';

export function placeBounty({ guildId, targetId, placedBy, amount }) {
  const id = uniqueId('bounty');
  getDb()
    .prepare(
      `INSERT INTO bounties (id, guild_id, target_id, placed_by, amount, status, created_at)
       VALUES (?, ?, ?, ?, ?, 'active', ?)`,
    )
    .run(id, guildId, targetId, placedBy, amount, Date.now());
  return getBounty(id);
}

export function getBounty(id) {
  return getDb().prepare('SELECT * FROM bounties WHERE id = ?').get(id) ?? null;
}

export function activeBountiesFor(guildId, targetId) {
  return getDb()
    .prepare("SELECT * FROM bounties WHERE guild_id = ? AND target_id = ? AND status = 'active' ORDER BY amount DESC")
    .all(guildId, targetId);
}

export function totalBounty(guildId, targetId) {
  const row = getDb()
    .prepare("SELECT COALESCE(SUM(amount), 0) AS total FROM bounties WHERE guild_id = ? AND target_id = ? AND status = 'active'")
    .get(guildId, targetId);
  return Number(row?.total ?? 0);
}

export function bountyBoard(guildId, limit = 10) {
  return getDb()
    .prepare(
      `SELECT target_id, COALESCE(SUM(amount), 0) AS total, COUNT(*) AS backers
       FROM bounties WHERE guild_id = ? AND status = 'active'
       GROUP BY target_id ORDER BY total DESC LIMIT ?`,
    )
    .all(guildId, limit);
}

/**
 * Claims every active bounty on a target. Returns the total owed and closes the
 * rows in one transaction so two killers cannot double-claim.
 */
export function claimBounties({ guildId, targetId, claimedBy }) {
  return transaction((db) => {
    const rows = db
      .prepare("SELECT id, amount FROM bounties WHERE guild_id = ? AND target_id = ? AND status = 'active'")
      .all(guildId, targetId);

    if (rows.length === 0) return { total: 0, count: 0 };

    const statement = db.prepare("UPDATE bounties SET status = 'claimed', claimed_by = ?, claimed_at = ? WHERE id = ?");
    for (const row of rows) statement.run(claimedBy, Date.now(), row.id);

    return { total: rows.reduce((sum, row) => sum + Number(row.amount), 0), count: rows.length };
  });
}
