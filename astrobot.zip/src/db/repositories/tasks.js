import { getDb } from '../index.js';
import { uniqueId } from '../../utils/random.js';

/** Timed console commands, wipe cycles and rotating broadcasts. */

export function listTasks(guildId) {
  return getDb().prepare('SELECT * FROM scheduled_tasks WHERE guild_id = ? ORDER BY created_at ASC').all(guildId);
}

export function dueTasks(now = Date.now()) {
  return getDb()
    .prepare('SELECT * FROM scheduled_tasks WHERE enabled = 1 AND (next_run_at IS NULL OR next_run_at <= ?)')
    .all(now);
}

export function getTask(taskId) {
  return getDb().prepare('SELECT * FROM scheduled_tasks WHERE id = ?').get(taskId) ?? null;
}

export function upsertTask({ id = null, guildId, name, kind = 'command', intervalSeconds, command = null, payload = null, enabled = true }) {
  const taskId = id ?? uniqueId('task');
  const nextRun = Date.now() + intervalSeconds * 1000;

  getDb()
    .prepare(
      `INSERT INTO scheduled_tasks (id, guild_id, name, kind, interval_seconds, command, payload, enabled, next_run_at, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         name = excluded.name,
         kind = excluded.kind,
         interval_seconds = excluded.interval_seconds,
         command = excluded.command,
         payload = excluded.payload,
         enabled = excluded.enabled,
         next_run_at = excluded.next_run_at`,
    )
    .run(taskId, guildId, name, kind, intervalSeconds, command, payload ? JSON.stringify(payload) : null, enabled ? 1 : 0, nextRun, Date.now());

  return getTask(taskId);
}

export function markTaskRun(taskId, intervalSeconds, ranAt = Date.now()) {
  getDb()
    .prepare('UPDATE scheduled_tasks SET last_run_at = ?, next_run_at = ? WHERE id = ?')
    .run(ranAt, ranAt + intervalSeconds * 1000, taskId);
}

export function setTaskEnabled(taskId, enabled) {
  getDb().prepare('UPDATE scheduled_tasks SET enabled = ? WHERE id = ?').run(enabled ? 1 : 0, taskId);
  return getTask(taskId);
}

export function removeTask(taskId) {
  return getDb().prepare('DELETE FROM scheduled_tasks WHERE id = ?').run(taskId).changes > 0;
}
