import { randomUUID } from 'node:crypto';
import { getDb } from '../index.js';

/** Owner-customized giveaway portal configurations. */

export function getPortalConfig(guildId) {
  return getDb().prepare('SELECT * FROM giveaway_portals WHERE guild_id = ?').get(guildId) ?? null;
}

export function savePortalConfig(guildId, config, updatedBy = null) {
  getDb()
    .prepare(
      `INSERT INTO giveaway_portals (guild_id, config, updated_by, updated_at) VALUES (?, ?, ?, ?)
       ON CONFLICT(guild_id) DO UPDATE SET config = excluded.config, updated_by = excluded.updated_by, updated_at = excluded.updated_at`,
    )
    .run(guildId, JSON.stringify(config), updatedBy, Date.now());
  return getPortalConfig(guildId);
}

export function issuePortalToken({ guildId, userId, ttlMs = 86_400_000 }) {
  const db = getDb();
  db.prepare('DELETE FROM giveaway_portal_tokens WHERE expires_at <= ?').run(Date.now());
  const token = randomUUID();
  db.prepare('INSERT INTO giveaway_portal_tokens (token, guild_id, user_id, expires_at, created_at) VALUES (?, ?, ?, ?, ?)').run(
    token,
    guildId,
    userId,
    Date.now() + ttlMs,
    Date.now(),
  );
  return token;
}

/**
 * Personal portal entry links. The bot issues one token per member and open
 * giveaway; the public portal exchanges it for a recorded entry, so a visitor
 * can never enter on someone else's behalf.
 */
export function issueGiveawayEntryToken({ guildId, userId, giveawayId, ttlMs = 7 * 86_400_000 }) {
  const db = getDb();
  db.prepare('DELETE FROM giveaway_entry_tokens WHERE expires_at <= ?').run(Date.now());
  const token = randomUUID();
  db.prepare(
    'INSERT INTO giveaway_entry_tokens (token, guild_id, user_id, giveaway_id, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?)',
  ).run(token, guildId, userId, giveawayId, Date.now() + ttlMs, Date.now());
  return token;
}

export function validateGiveawayEntryToken(token, guildId = null) {
  const trimmed = String(token ?? '').trim();
  if (!trimmed) return null;
  const row = guildId
    ? getDb()
        .prepare('SELECT * FROM giveaway_entry_tokens WHERE token = ? AND guild_id = ? AND expires_at > ?')
        .get(trimmed, guildId, Date.now())
    : getDb().prepare('SELECT * FROM giveaway_entry_tokens WHERE token = ? AND expires_at > ?').get(trimmed, Date.now());
  return row ?? null;
}

/** Single-use for claiming the entry; the token still authorises bonus tasks. */
export function markGiveawayEntryTokenUsed(token) {
  const result = getDb()
    .prepare('UPDATE giveaway_entry_tokens SET used_at = ? WHERE token = ? AND used_at IS NULL')
    .run(Date.now(), String(token ?? '').trim());
  return result.changes > 0;
}

export function validatePortalToken(token, guildId) {
  const trimmed = String(token ?? '').trim();
  if (!trimmed) return null;
  const row = getDb()
    .prepare('SELECT * FROM giveaway_portal_tokens WHERE token = ? AND guild_id = ? AND expires_at > ?')
    .get(trimmed, guildId, Date.now());
  return row ?? null;
}
