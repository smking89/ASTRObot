import { getDb } from '../index.js';
import { uniqueId } from '../../utils/random.js';

/** Per-server wipe schedules. Scoped by guild and server row, never global. */

export function listWipeProfiles(guildId) {
  return getDb()
    .prepare('SELECT * FROM wipe_profiles WHERE guild_id = ? ORDER BY next_wipe_at ASC')
    .all(guildId);
}

export function listAllWipeProfiles() {
  return getDb().prepare('SELECT * FROM wipe_profiles ORDER BY next_wipe_at ASC').all();
}

export function getWipeProfile(id) {
  return getDb().prepare('SELECT * FROM wipe_profiles WHERE id = ?').get(id) ?? null;
}

/** Profiles waiting for their server to finish restarting after a wipe. */
export function listWipeProfilesAwaitingOnline(serverId, now = Date.now()) {
  return getDb()
    .prepare(
      'SELECT * FROM wipe_profiles WHERE server_id = ? AND awaiting_online = 1 AND (online_after IS NULL OR online_after <= ?)',
    )
    .all(serverId, now);
}

export function listAllWipeProfilesAwaitingOnline(now = Date.now()) {
  return getDb()
    .prepare('SELECT * FROM wipe_profiles WHERE awaiting_online = 1 AND (online_after IS NULL OR online_after <= ?)')
    .all(now);
}

export function createWipeProfile({
  guildId,
  serverId,
  name,
  wipeType = 'bp',
  intervalHours = 168,
  nextWipeAt,
  channelId = null,
  autoRestart = true,
  rotateMap = false,
  mapRotation = [],
  countdowns = [60, 30, 10],
  restartCommand = 'restart 300',
  restartDelay = null,
  wipeMessages = null,
  announceInGame = true,
}) {
  const id = uniqueId('wipe');
  getDb()
    .prepare(
      `INSERT INTO wipe_profiles
         (id, guild_id, server_id, name, wipe_type, interval_hours, next_wipe_at, channel_id,
          auto_restart, rotate_map, map_rotation, countdowns, restart_command, restart_delay,
          wipe_messages, announce_in_game, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      id,
      guildId,
      serverId,
      name,
      wipeType,
      intervalHours,
      nextWipeAt,
      channelId,
      autoRestart ? 1 : 0,
      rotateMap ? 1 : 0,
      JSON.stringify(mapRotation),
      countdowns.join(','),
      restartCommand,
      restartDelay == null ? null : Math.max(0, Math.min(3600, Math.trunc(Number(restartDelay) || 0))),
      wipeMessages == null ? null : JSON.stringify(wipeMessages),
      announceInGame ? 1 : 0,
      Date.now(),
    );
  return getWipeProfile(id);
}

const EDITABLE = new Set([
  'name',
  'wipe_type',
  'interval_hours',
  'next_wipe_at',
  'channel_id',
  'auto_restart',
  'rotate_map',
  'map_rotation',
  'countdowns',
  'announced_stages',
  'rotation_index',
  'restart_command',
  'restart_delay',
  'last_wipe_at',
  'wipe_messages',
  'announce_in_game',
  'awaiting_online',
  'online_after',
  'online_announced_at',
]);

export function updateWipeProfile(id, fields) {
  const entries = Object.entries(fields).filter(([key]) => EDITABLE.has(key));
  if (entries.length === 0) return getWipeProfile(id);

  getDb()
    .prepare(`UPDATE wipe_profiles SET ${entries.map(([key]) => `${key} = ?`).join(', ')} WHERE id = ?`)
    .run(...entries.map(([, value]) => value), id);
  return getWipeProfile(id);
}

export function deleteWipeProfile(id) {
  return getDb().prepare('DELETE FROM wipe_profiles WHERE id = ?').run(id).changes > 0;
}
