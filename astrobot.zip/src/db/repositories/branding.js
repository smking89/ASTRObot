import { getDb } from '../index.js';

const HEX = /^#[0-9a-f]{6}$/i;
const ASSET_URL = /^(?:https?:\/\/|\/|data:image\/)/i;

export const DEFAULT_BRANDING = Object.freeze({
  name: 'AstroBot',
  faviconUrl: '',
  wordmarkUrl: '',
  colors: Object.freeze({
    brand: '#e62127',
    accent: '#ff4d4d',
    background: '#07070d',
    text: '#eef0f8',
  }),
});

function color(value, fallback) {
  return HEX.test(String(value ?? '')) ? String(value).toLowerCase() : fallback;
}

function assetUrl(value, fallback = '') {
  if (value == null) return fallback;
  const text = String(value).trim().slice(0, 500);
  // An explicit empty string clears a previously configured asset.
  if (!text) return '';
  return ASSET_URL.test(text) ? text : fallback;
}

export function normalizeBranding(value, base = DEFAULT_BRANDING) {
  const source = value && typeof value === 'object' ? value : {};
  const colors = source.colors && typeof source.colors === 'object' ? source.colors : {};
  return {
    name: String(source.name ?? base.name).trim().slice(0, 40) || base.name,
    faviconUrl: assetUrl(source.faviconUrl, base.faviconUrl),
    wordmarkUrl: assetUrl(source.wordmarkUrl, base.wordmarkUrl),
    colors: {
      brand: color(colors.brand, base.colors.brand),
      accent: color(colors.accent, base.colors.accent),
      background: color(colors.background, base.colors.background),
      text: color(colors.text, base.colors.text),
    },
  };
}

export function getBranding() {
  try {
    const row = getDb().prepare('SELECT brand_name, favicon_url, wordmark_url, colors FROM bot_branding WHERE id = 1').get();
    if (!row) return structuredClone(DEFAULT_BRANDING);
    let colors = {};
    try {
      colors = JSON.parse(row.colors);
    } catch {
      colors = {};
    }
    return normalizeBranding({
      name: row.brand_name,
      faviconUrl: row.favicon_url,
      wordmarkUrl: row.wordmark_url,
      colors,
    });
  } catch {
    // Branding must never stop an embed or dashboard from rendering.
    return structuredClone(DEFAULT_BRANDING);
  }
}

export function saveBranding(patch, actorId = null) {
  const current = getBranding();
  const next = normalizeBranding(
    {
      ...current,
      ...patch,
      colors: { ...current.colors, ...(patch?.colors ?? {}) },
    },
    current,
  );
  getDb()
    .prepare(
      `INSERT INTO bot_branding (id, brand_name, favicon_url, wordmark_url, colors, updated_by, updated_at)
       VALUES (1, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         brand_name = excluded.brand_name,
         favicon_url = excluded.favicon_url,
         wordmark_url = excluded.wordmark_url,
         colors = excluded.colors,
         updated_by = excluded.updated_by,
         updated_at = excluded.updated_at`,
    )
    .run(next.name, next.faviconUrl, next.wordmarkUrl, JSON.stringify(next.colors), actorId, Date.now());
  return next;
}
