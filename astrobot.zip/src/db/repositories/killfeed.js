import { getDb } from '../index.js';
import { uniqueId } from '../../utils/random.js';

/** Durable local kill rows consumed by the five-second global publisher. */

export function recordKillfeedEvent({ guildId, serverId = null, serverLabel = null, event = {} }) {
  if (!guildId || !event?.killer?.name || !event?.victim?.name) return null;

  const coordinates = event.coordinates ?? {};
  const x = coordinates.x == null ? null : Number(coordinates.x);
  const y = coordinates.y == null ? null : Number(coordinates.y);
  const z = coordinates.z == null ? null : Number(coordinates.z);
  const id = uniqueId('kf');
  getDb()
    .prepare(
      `INSERT INTO killfeed_events (
         id, guild_id, server_id, server_label, killer_name, killer_external_id,
         victim_name, victim_external_id, weapon, grid, x, y, z, npc, stolen,
         distance, raw, occurred_at, status, attempts, created_at
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 0, ?)`,
    )
    .run(
      id,
      String(guildId),
      serverId ? String(serverId) : null,
      serverLabel ? String(serverLabel) : null,
      String(event.killer.name).slice(0, 100),
      event.killer.externalId ? String(event.killer.externalId) : null,
      String(event.victim.name).slice(0, 100),
      event.victim.externalId ? String(event.victim.externalId) : null,
      event.weapon ? String(event.weapon).slice(0, 100) : null,
      coordinates.grid ? String(coordinates.grid).slice(0, 40) : null,
      Number.isFinite(x) ? x : null,
      Number.isFinite(y) ? y : null,
      Number.isFinite(z) ? z : null,
      event.npc ? 1 : 0,
      Number.isFinite(Number(event.stolen)) ? Math.max(0, Math.trunc(Number(event.stolen))) : 0,
      Number.isFinite(Number(event.distance)) ? Number(event.distance) : null,
      event.raw ? String(event.raw).slice(0, 2000) : null,
      Number(event.at) || Date.now(),
      Date.now(),
    );
  return id;
}

/**
 * Claims a small batch atomically. Rows left processing by a crash are
 * recovered after staleMs so a restart cannot lose a kill permanently.
 */
export function claimPendingKillfeedEvents({ limit = 50, now = Date.now(), staleMs = 60_000 } = {}) {
  const db = getDb();
  db.prepare(
    `UPDATE killfeed_events
     SET status = 'pending', processing_at = NULL, last_error = COALESCE(last_error, 'stale worker claim')
     WHERE status = 'processing' AND (processing_at IS NULL OR processing_at < ?)`,
  ).run(now - staleMs);

  const rows = db
    .prepare(
      `SELECT * FROM killfeed_events
       WHERE status = 'pending' AND (next_attempt_at IS NULL OR next_attempt_at <= ?)
       ORDER BY occurred_at ASC, created_at ASC LIMIT ?`,
    )
    .all(now, Math.max(1, Math.min(250, Number(limit) || 50)));

  const claim = db.prepare(
    `UPDATE killfeed_events
     SET status = 'processing', processing_at = ?, attempts = attempts + 1
     WHERE id = ? AND status = 'pending'`,
  );
  const claimed = [];
  for (const row of rows) {
    if (claim.run(now, row.id).changes > 0) claimed.push({ ...row, attempts: Number(row.attempts) + 1 });
  }
  return claimed;
}

export function markKillfeedEventPosted(id, now = Date.now()) {
  getDb()
    .prepare("UPDATE killfeed_events SET status = 'posted', posted_at = ?, processing_at = NULL, last_error = NULL WHERE id = ?")
    .run(now, id);
}

export function markKillfeedEventSkipped(id, reason = null) {
  getDb()
    .prepare("UPDATE killfeed_events SET status = 'skipped', processing_at = NULL, last_error = ? WHERE id = ?")
    .run(reason ? String(reason).slice(0, 500) : null, id);
}

export function markKillfeedEventRetry({ id, error = null, nextAttemptAt = Date.now() + 5_000, maxAttempts = 5 }) {
  const row = getDb().prepare('SELECT attempts FROM killfeed_events WHERE id = ?').get(id);
  const status = Number(row?.attempts ?? 0) >= maxAttempts ? 'failed' : 'pending';
  getDb()
    .prepare(
      `UPDATE killfeed_events
       SET status = ?, processing_at = NULL, last_error = ?, next_attempt_at = ?
       WHERE id = ?`,
    )
    .run(status, error ? String(error).slice(0, 500) : null, status === 'pending' ? nextAttemptAt : null, id);
  return status;
}

export function getKillfeedEvent(id) {
  return getDb().prepare('SELECT * FROM killfeed_events WHERE id = ?').get(id) ?? null;
}

export function countKillfeedEvents(status = null) {
  if (status) {
    return Number(getDb().prepare('SELECT COUNT(*) AS count FROM killfeed_events WHERE status = ?').get(status)?.count ?? 0);
  }
  return Number(getDb().prepare('SELECT COUNT(*) AS count FROM killfeed_events').get()?.count ?? 0);
}