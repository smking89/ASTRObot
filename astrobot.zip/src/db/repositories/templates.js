import { getDb } from '../index.js';
import { uniqueId } from '../../utils/random.js';

/** Saved server layouts are guild-scoped; payloads are JSON snapshots. */

function hydrate(row) {
  if (!row) return null;
  let payload;
  try {
    payload = JSON.parse(row.payload);
  } catch {
    payload = { version: 1, roles: [], categories: [], channels: [] };
  }
  return { ...row, payload };
}

export function createTemplate({ guildId, name, payload, createdBy = null }) {
  const id = uniqueId('tpl');
  getDb()
    .prepare(
      `INSERT INTO server_templates (id, guild_id, name, payload, created_by, created_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
    )
    .run(id, guildId, name, JSON.stringify(payload), createdBy, Date.now());
  return getTemplate(guildId, id);
}

export function listTemplates(guildId) {
  return getDb()
    .prepare('SELECT * FROM server_templates WHERE guild_id = ? ORDER BY created_at DESC')
    .all(guildId)
    .map(hydrate);
}

export function getTemplate(guildId, id) {
  return hydrate(
    getDb().prepare('SELECT * FROM server_templates WHERE guild_id = ? AND id = ?').get(guildId, id),
  );
}

export function findTemplateByName(guildId, name) {
  return hydrate(
    getDb()
      .prepare('SELECT * FROM server_templates WHERE guild_id = ? AND lower(name) = lower(?)')
      .get(guildId, name),
  );
}

export function updateTemplate(guildId, id, { name, payload }) {
  const changes = getDb()
    .prepare('UPDATE server_templates SET name = ?, payload = ? WHERE guild_id = ? AND id = ?')
    .run(name, JSON.stringify(payload), guildId, id).changes;
  return changes ? getTemplate(guildId, id) : null;
}

export function deleteTemplate(guildId, id) {
  return getDb().prepare('DELETE FROM server_templates WHERE guild_id = ? AND id = ?').run(guildId, id).changes > 0;
}
