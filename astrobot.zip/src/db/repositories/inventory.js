import { getDb } from '../index.js';

/** Inventory rows back case battles, loot chests and kit deliveries. */

export function addItem({ guildId, userId, itemKey, quantity = 1, metadata = null }) {
  const existing = getDb()
    .prepare('SELECT * FROM inventory WHERE guild_id = ? AND user_id = ? AND item_key = ?')
    .get(guildId, userId, itemKey);

  if (existing) {
    getDb().prepare('UPDATE inventory SET quantity = quantity + ? WHERE id = ?').run(quantity, existing.id);
    return { ...existing, quantity: Number(existing.quantity) + quantity };
  }

  getDb()
    .prepare('INSERT INTO inventory (guild_id, user_id, item_key, quantity, metadata, acquired_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(guildId, userId, itemKey, quantity, metadata ? JSON.stringify(metadata) : null, Date.now());

  return getDb()
    .prepare('SELECT * FROM inventory WHERE guild_id = ? AND user_id = ? AND item_key = ?')
    .get(guildId, userId, itemKey);
}

export function listItems(guildId, userId) {
  return getDb()
    .prepare('SELECT * FROM inventory WHERE guild_id = ? AND user_id = ? AND quantity > 0 ORDER BY acquired_at DESC')
    .all(guildId, userId);
}

export function consumeItem({ guildId, userId, itemKey, quantity = 1 }) {
  const row = getDb()
    .prepare('SELECT * FROM inventory WHERE guild_id = ? AND user_id = ? AND item_key = ? AND quantity >= ?')
    .get(guildId, userId, itemKey, quantity);

  if (!row) return false;
  getDb().prepare('UPDATE inventory SET quantity = quantity - ? WHERE id = ?').run(quantity, row.id);
  return true;
}

/** Weighted loot roll table: [{ itemKey, weight, min, max }] */
export function rollLoot(table) {
  const total = table.reduce((sum, entry) => sum + entry.weight, 0);
  let cursor = Math.random() * total;
  for (const entry of table) {
    cursor -= entry.weight;
    if (cursor <= 0) {
      const quantity = entry.min + Math.floor(Math.random() * (entry.max - entry.min + 1));
      return { itemKey: entry.itemKey, quantity };
    }
  }
  return { itemKey: table[0].itemKey, quantity: table[0].min };
}
