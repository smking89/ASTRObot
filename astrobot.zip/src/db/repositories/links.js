import { getDb } from '../index.js';

/** Xbox / PlayStation identity links used by /link, /unlink and killfeed attribution. */

export function getLink(guildId, userId) {
  return getDb().prepare('SELECT * FROM player_links WHERE guild_id = ? AND user_id = ?').get(guildId, userId) ?? null;
}

export function getLinkByGamertag(guildId, gamertag) {
  return (
    getDb()
      .prepare('SELECT * FROM player_links WHERE guild_id = ? AND LOWER(gamertag) = LOWER(?)')
      .get(guildId, gamertag) ?? null
  );
}

export function upsertLink({ guildId, userId, platform, gamertag, externalId = null }) {
  getDb()
    .prepare(
      `INSERT INTO player_links (guild_id, user_id, platform, gamertag, external_id, verified_at)
       VALUES (?, ?, ?, ?, ?, ?)
       ON CONFLICT(guild_id, user_id) DO UPDATE SET
         platform = excluded.platform,
         gamertag = excluded.gamertag,
         external_id = excluded.external_id,
         verified_at = excluded.verified_at`,
    )
    .run(guildId, userId, platform, gamertag, externalId, Date.now());
  return getLink(guildId, userId);
}

export function removeLink(guildId, userId) {
  const result = getDb().prepare('DELETE FROM player_links WHERE guild_id = ? AND user_id = ?').run(guildId, userId);
  return result.changes > 0;
}

/** All linked players in a guild — used by the playtime coin loop. */
export function listLinks(guildId) {
  return getDb().prepare('SELECT * FROM player_links WHERE guild_id = ?').all(guildId);
}
