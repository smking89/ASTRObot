import { getDb } from '../index.js';
import { uniqueId } from '../../utils/random.js';

/** Marketplace persistence. Money movement stays in marketplace-service. */

export function createListing({
  guildId,
  sellerId,
  kind,
  assetKey,
  assetLabel,
  quantity = 1,
  price,
  vipPrice = null,
  mode = 'buy_now',
  currency,
  feePercent = 0,
  endsAt = null,
  metadata = null,
}) {
  const id = uniqueId('listing');
  getDb()
    .prepare(
      `INSERT INTO marketplace_listings
         (id, guild_id, seller_id, kind, asset_key, asset_label, quantity, price, vip_price,
          mode, status, currency, fee_percent, ends_at, created_at, metadata)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?, ?)`,
    )
    .run(
      id,
      guildId,
      sellerId,
      kind,
      assetKey,
      assetLabel,
      Math.max(1, Math.trunc(quantity)),
      Math.trunc(price),
      vipPrice === null || vipPrice === undefined ? null : Math.trunc(vipPrice),
      mode,
      currency,
      Number(feePercent) || 0,
      endsAt,
      Date.now(),
      metadata ? JSON.stringify(metadata) : null,
    );
  return getListing(id);
}

export function getListing(id) {
  return getDb().prepare('SELECT * FROM marketplace_listings WHERE id = ?').get(id) ?? null;
}

export function listActiveListings(guildId, { includeMine = null, limit = 50 } = {}) {
  const params = [guildId];
  let sql = "SELECT * FROM marketplace_listings WHERE guild_id = ? AND status = 'active'";
  if (includeMine) {
    sql += ' AND seller_id = ?';
    params.push(includeMine);
  }
  sql += ' ORDER BY created_at DESC LIMIT ?';
  params.push(Math.min(100, Math.max(1, Number(limit) || 50)));
  return getDb().prepare(sql).all(...params);
}

export function listSellerListings(guildId, sellerId) {
  return getDb()
    .prepare('SELECT * FROM marketplace_listings WHERE guild_id = ? AND seller_id = ? ORDER BY created_at DESC LIMIT 50')
    .all(guildId, sellerId);
}

export function listDueBidListings(now = Date.now()) {
  return getDb()
    .prepare("SELECT * FROM marketplace_listings WHERE status = 'active' AND mode = 'bid' AND ends_at IS NOT NULL AND ends_at <= ? ORDER BY ends_at ASC LIMIT 25")
    .all(now);
}

export function updateListing(id, fields) {
  const allowed = ['status', 'high_bidder_id', 'high_bid', 'buyer_id', 'sold_at', 'price', 'vip_price', 'ends_at'];
  const entries = Object.entries(fields).filter(([key]) => allowed.includes(key));
  if (entries.length === 0) return getListing(id);
  const assignments = entries.map(([key]) => `${key} = ?`).join(', ');
  getDb()
    .prepare(`UPDATE marketplace_listings SET ${assignments} WHERE id = ?`)
    .run(...entries.map(([, value]) => value), id);
  return getListing(id);
}

export function addBid({ listingId, guildId, bidderId, amount }) {
  const id = uniqueId('bid');
  const db = getDb();
  db.prepare(
    'INSERT INTO marketplace_bids (id, listing_id, guild_id, bidder_id, amount, created_at) VALUES (?, ?, ?, ?, ?, ?)',
  ).run(id, listingId, guildId, bidderId, Math.trunc(amount), Date.now());
  db.prepare(
    `UPDATE marketplace_listings
     SET high_bidder_id = ?, high_bid = ?
     WHERE id = ? AND (high_bid IS NULL OR ? > high_bid)`,
  ).run(bidderId, Math.trunc(amount), listingId, Math.trunc(amount));
  return db.prepare('SELECT * FROM marketplace_bids WHERE id = ?').get(id);
}

export function listBids(listingId) {
  return getDb()
    .prepare('SELECT * FROM marketplace_bids WHERE listing_id = ? ORDER BY amount DESC, created_at ASC')
    .all(listingId);
}

export function recordSale({ listingId, guildId, sellerId, buyerId, kind, assetKey, assetLabel, amount, fee, currency }) {
  const id = uniqueId('sale');
  getDb()
    .prepare(
      `INSERT INTO marketplace_sales
         (id, listing_id, guild_id, seller_id, buyer_id, kind, asset_key, asset_label, amount, fee, currency, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(id, listingId, guildId, sellerId, buyerId, kind, assetKey, assetLabel, Math.trunc(amount), Math.trunc(fee), currency, Date.now());
  return id;
}

export function listSales(guildId, { sellerId = null, limit = 25 } = {}) {
  if (sellerId) {
    return getDb()
      .prepare('SELECT * FROM marketplace_sales WHERE guild_id = ? AND seller_id = ? ORDER BY created_at DESC LIMIT ?')
      .all(guildId, sellerId, Math.min(100, Math.max(1, limit)));
  }
  return getDb()
    .prepare('SELECT * FROM marketplace_sales WHERE guild_id = ? ORDER BY created_at DESC LIMIT ?')
    .all(guildId, Math.min(100, Math.max(1, limit)));
}

export function marketSummary(guildId) {
  const totals = getDb()
    .prepare(
      `SELECT COUNT(*) AS sales, COALESCE(SUM(amount), 0) AS volume, COALESCE(SUM(fee), 0) AS fees
       FROM marketplace_sales WHERE guild_id = ?`,
    )
    .get(guildId) ?? { sales: 0, volume: 0, fees: 0 };
  const active = getDb()
    .prepare("SELECT COUNT(*) AS count FROM marketplace_listings WHERE guild_id = ? AND status = 'active'")
    .get(guildId);
  const topSellers = getDb()
    .prepare(
      `SELECT seller_id, COUNT(*) AS sales, COALESCE(SUM(amount), 0) AS volume
       FROM marketplace_sales WHERE guild_id = ? GROUP BY seller_id ORDER BY volume DESC LIMIT 5`,
    )
    .all(guildId);
  return {
    sales: Number(totals.sales) || 0,
    volume: Number(totals.volume) || 0,
    fees: Number(totals.fees) || 0,
    active: Number(active?.count) || 0,
    topSellers,
  };
}

export function getAssetLock(guildId, userId, assetKey) {
  return getDb()
    .prepare('SELECT * FROM marketplace_locks WHERE guild_id = ? AND user_id = ? AND asset_key = ?')
    .get(guildId, userId, assetKey) ?? null;
}

export function setAssetLock({ guildId, userId, assetKey, kind, unlockAt }) {
  getDb()
    .prepare(
      `INSERT INTO marketplace_locks (guild_id, user_id, asset_key, kind, unlock_at)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(guild_id, user_id, asset_key) DO UPDATE SET kind = excluded.kind, unlock_at = excluded.unlock_at`,
    )
    .run(guildId, userId, assetKey, kind, Math.trunc(unlockAt));
}

export function clearAssetLock(guildId, userId, assetKey) {
  getDb().prepare('DELETE FROM marketplace_locks WHERE guild_id = ? AND user_id = ? AND asset_key = ?').run(guildId, userId, assetKey);
}

export function clearExpiredLocks(now = Date.now()) {
  return getDb().prepare('DELETE FROM marketplace_locks WHERE unlock_at <= ?').run(now).changes ?? 0;
}
