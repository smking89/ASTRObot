import { getDb } from '../index.js';

/**
 * Payment ledger. `beginPayment` claims a transaction id atomically; the unique
 * primary key means concurrent or retried webhooks only deliver once.
 */

export function beginPayment({ transactionId, guildId, userId, productId = null, provider = 'tip4serv' }) {
  if (!transactionId) return true;
  const result = getDb()
    .prepare(
      `INSERT OR IGNORE INTO payment_events
         (transaction_id, guild_id, user_id, product_id, provider, status, created_at)
       VALUES (?, ?, ?, ?, ?, 'pending', ?)`,
    )
    .run(String(transactionId), guildId, userId, productId == null ? null : String(productId), provider, Date.now());
  return result.changes > 0;
}

export function finishPayment(transactionId, { delivered = [], status = 'delivered' } = {}) {
  if (!transactionId) return null;
  getDb()
    .prepare('UPDATE payment_events SET status = ?, delivered = ?, completed_at = ? WHERE transaction_id = ?')
    .run(status, JSON.stringify(delivered), Date.now(), String(transactionId));
  return getPayment(transactionId);
}

/** Drops a pending claim so the provider's retry can attempt delivery again. */
export function abortPayment(transactionId, reason = null) {
  if (!transactionId) return false;
  const result = getDb()
    .prepare("DELETE FROM payment_events WHERE transaction_id = ? AND status = 'pending'")
    .run(String(transactionId));
  if (result.changes > 0) return true;
  getDb()
    .prepare("UPDATE payment_events SET status = 'failed', delivered = ? WHERE transaction_id = ? AND status = 'pending'")
    .run(JSON.stringify(reason ? [reason] : []), String(transactionId));
  return false;
}

export function getPayment(transactionId) {
  return getDb().prepare('SELECT * FROM payment_events WHERE transaction_id = ?').get(String(transactionId)) ?? null;
}

export function listPayments(guildId, limit = 25) {
  return getDb()
    .prepare('SELECT * FROM payment_events WHERE guild_id = ? ORDER BY created_at DESC LIMIT ?')
    .all(guildId, Math.max(1, Math.min(100, Number(limit) || 25)));
}
