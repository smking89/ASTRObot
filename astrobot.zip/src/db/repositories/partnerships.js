import { getDb } from '../index.js';
import { uniqueId } from '../../utils/random.js';

export function createPartnershipRequest({ fromGuildId, toGuildId, requesterId, brandName, duration, description, memberCount }) {
  const id = uniqueId('partner');
  getDb()
    .prepare(
      `INSERT INTO partnerships
         (id, from_guild_id, to_guild_id, requester_id, brand_name, duration, description, member_count, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)`,
    )
    .run(id, fromGuildId, toGuildId, requesterId, brandName, duration, description, Math.trunc(memberCount), Date.now());
  return getPartnership(id);
}

export function getPartnership(id) {
  return getDb().prepare('SELECT * FROM partnerships WHERE id = ?').get(id) ?? null;
}

export function updatePartnership(id, { status, networkId = null, respondedBy = null }) {
  getDb()
    .prepare(
      `UPDATE partnerships
       SET status = ?, network_id = COALESCE(?, network_id), responded_by = ?, responded_at = ?
       WHERE id = ?`,
    )
    .run(status, networkId, respondedBy, Date.now(), id);
  return getPartnership(id);
}

export function listPartnershipsForGuild(guildId, limit = 10) {
  return getDb()
    .prepare(
      `SELECT * FROM partnerships
       WHERE from_guild_id = ? OR to_guild_id = ?
       ORDER BY created_at DESC LIMIT ?`,
    )
    .all(guildId, guildId, Math.min(25, Math.max(1, limit)));
}

export function listIncomingPartnerships(guildId, limit = 10) {
  return getDb()
    .prepare("SELECT * FROM partnerships WHERE to_guild_id = ? AND status = 'pending' ORDER BY created_at DESC LIMIT ?")
    .all(guildId, Math.min(25, Math.max(1, limit)));
}
