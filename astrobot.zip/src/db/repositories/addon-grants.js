import { getDb, transaction } from '../index.js';
import { uniqueId } from '../../utils/random.js';
import { addMembershipSeats } from './memberships.js';

/**
 * Recurring add-ons must be delivered once per subscription, not once per
 * renewal transaction. Tip4Serv sends a stable subscription id on renewals;
 * one-time purchases fall back to their transaction id in the service layer.
 *
 * The unique row is claimed inside the same transaction as the seat grant, so a
 * crash rolls both back and a retry can still deliver the seat.
 */
export function grantSeatAddonOnce({
  provider = 'tip4serv',
  providerRef,
  guildId = null,
  userId,
  productId,
  seats = 1,
  tier = 'pro',
  expiresAt = null,
  grantedBy = 'tip4serv',
}) {
  const ref = String(providerRef ?? '').trim();
  if (!ref) throw new Error('Add-on grant is missing a subscription or transaction reference.');

  return transaction((db) => {
    const id = uniqueId('grant');
    const claimed = db
      .prepare(
        `INSERT OR IGNORE INTO addon_grants
           (id, provider, provider_ref, guild_id, user_id, product_id, kind, seats, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 'seat', ?, ?)`,
      )
      .run(id, String(provider), ref, guildId, String(userId), String(productId), Math.max(1, Math.trunc(Number(seats) || 1)), Date.now());

    if (!claimed.changes) return { granted: false, membership: null };

    const membership = addMembershipSeats({
      userId,
      seats,
      tier,
      expiresAt,
      grantedBy,
    });
    return { granted: true, membership };
  });
}

export function listAddonGrants(userId, limit = 25) {
  return getDb()
    .prepare('SELECT * FROM addon_grants WHERE user_id = ? ORDER BY created_at DESC LIMIT ?')
    .all(String(userId), Math.max(1, Math.min(100, Number(limit) || 25)));
}
