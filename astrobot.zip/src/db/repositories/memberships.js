import { getDb } from '../index.js';
import { PLAN_CATALOG, normalizePlanId } from '../../config/plans.js';

/** Astro Pro/Max membership, including the Discord-server seat allowance. */

export function baseSeatLimit(tier) {
  return PLAN_CATALOG[normalizePlanId(tier)].limits.discordServers;
}

/** Existing rows may predate server_limit; the plan's base allowance is the fallback. */
export function membershipSeatLimit(membership) {
  if (!membership) return 0;
  return Math.max(1, Number(membership.server_limit) || baseSeatLimit(membership.tier));
}

export function getMembership(userId) {
  return getDb().prepare('SELECT * FROM memberships WHERE user_id = ?').get(userId) ?? null;
}

export function grantMembership({ userId, tier = 'pro', grantedBy = 'system', expiresAt = null, serverLimit = null, renew = true }) {
  const now = Date.now();
  const current = getMembership(userId);
  const tierId = normalizePlanId(tier);
  const requestedSeats = Number(serverLimit);
  const sameTier = current && normalizePlanId(current.tier) === tierId;
  const seats =
    Number.isFinite(requestedSeats) && requestedSeats > 0
      ? Math.trunc(requestedSeats)
      : sameTier
        ? membershipSeatLimit(current)
        : baseSeatLimit(tier);

  // Renewing the same tier extends the remaining time instead of throwing it
  // away, so a subscriber never loses unused days at checkout.
  let nextExpiry = expiresAt;
  if (
    renew &&
    expiresAt &&
    current &&
    String(current.tier) === String(tier) &&
    (!current.expires_at || Number(current.expires_at) > now)
  ) {
    // A lifetime membership stays lifetime; a timed membership gets the new
    // days added on top of whatever it had left.
    nextExpiry = current.expires_at ? Number(current.expires_at) + (Number(expiresAt) - now) : null;
  }

  getDb()
    .prepare(
      `INSERT INTO memberships (user_id, tier, granted_by, granted_at, expires_at, server_limit)
       VALUES (?, ?, ?, ?, ?, ?)
       ON CONFLICT(user_id) DO UPDATE SET tier = excluded.tier, granted_by = excluded.granted_by,
         granted_at = excluded.granted_at, expires_at = excluded.expires_at, server_limit = excluded.server_limit`,
    )
    .run(userId, tier, grantedBy, now, nextExpiry, seats);
  return getMembership(userId);
}

/**
 * Adds seats to an active membership without changing its tier or expiry. A
 * purchase made without a membership starts the plan named by `tier` with the
 * plan's base seats plus this add-on.
 */
export function addMembershipSeats({ userId, seats = 1, tier = 'pro', expiresAt = null, grantedBy = 'tip4serv' }) {
  const increment = Math.max(1, Math.trunc(Number(seats) || 1));
  const current = getMembership(userId);
  if (!current) {
    return grantMembership({
      userId,
      tier,
      grantedBy,
      expiresAt,
      serverLimit: baseSeatLimit(tier) + increment,
    });
  }

  const now = Date.now();
  const active = !current.expires_at || Number(current.expires_at) > now;
  const nextTier = active && normalizePlanId(current.tier) !== 'basic' ? current.tier : tier;
  const currentSeats = active ? membershipSeatLimit(current) : baseSeatLimit(tier);

  let nextExpiry;
  if (active) {
    // A lifetime membership stays lifetime. Otherwise keep the later expiry so
    // an add-on never cuts an existing subscription short.
    nextExpiry = current.expires_at ? Math.max(Number(current.expires_at), Number(expiresAt) || 0) : null;
  } else {
    nextExpiry = expiresAt;
  }

  getDb()
    .prepare('UPDATE memberships SET tier = ?, server_limit = ?, expires_at = ? WHERE user_id = ?')
    .run(nextTier, currentSeats + increment, nextExpiry, userId);
  return getMembership(userId);
}

export function revokeMembership(userId) {
  return getDb().prepare('DELETE FROM memberships WHERE user_id = ?').run(userId).changes > 0;
}

export function listMemberships(limit = 25) {
  return getDb().prepare('SELECT * FROM memberships ORDER BY granted_at DESC LIMIT ?').all(limit);
}

export function isActive(userId) {
  const membership = getMembership(userId);
  if (!membership) return false;
  return !membership.expires_at || Number(membership.expires_at) > Date.now();
}
