import { getDb, transaction } from '../index.js';

function mapPoll(row) {
  if (!row) return null;
  let options = [];
  try {
    options = JSON.parse(row.options);
  } catch {
    options = [];
  }
  return {
    ...row,
    options: Array.isArray(options) ? options : [],
    allow_multiple: Boolean(row.allow_multiple),
    anonymous: Boolean(row.anonymous),
  };
}

export function createPoll({ id, guildId, channelId, creatorId, question, options, hours, allowMultiple = false, anonymous = false }) {
  const now = Date.now();
  getDb()
    .prepare(
      `INSERT INTO polls (id, guild_id, channel_id, creator_id, question, options, allow_multiple, anonymous, status, created_at, ends_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', ?, ?)`,
    )
    .run(
      id,
      guildId,
      channelId,
      creatorId,
      question,
      JSON.stringify(options),
      allowMultiple ? 1 : 0,
      anonymous ? 1 : 0,
      now,
      now + hours * 3_600_000,
    );
  return getPollForGuild(id, guildId);
}

export function getPoll(id) {
  return mapPoll(getDb().prepare('SELECT * FROM polls WHERE id = ?').get(id) ?? null);
}

export function getPollForGuild(id, guildId) {
  return mapPoll(getDb().prepare('SELECT * FROM polls WHERE id = ? AND guild_id = ?').get(id, guildId) ?? null);
}

export function listPolls(guildId, limit = 25) {
  return getDb()
    .prepare(
      `SELECT * FROM polls WHERE guild_id = ?
       ORDER BY CASE status WHEN 'open' THEN 0 ELSE 1 END, created_at DESC LIMIT ?`,
    )
    .all(guildId, Math.max(1, Math.min(50, Number(limit) || 25)))
    .map(mapPoll);
}

/** Open polls whose closing time has passed, for the automation loop. */
export function duePolls(now = Date.now(), limit = 50) {
  return getDb()
    .prepare("SELECT * FROM polls WHERE status = 'open' AND ends_at <= ? ORDER BY ends_at ASC LIMIT ?")
    .all(now, Math.max(1, Math.min(200, Number(limit) || 50)))
    .map(mapPoll);
}

export function setPollMessage(id, messageId) {
  getDb().prepare('UPDATE polls SET message_id = ? WHERE id = ?').run(messageId, id);
}

export function closePollRecord(id) {
  getDb().prepare("UPDATE polls SET status = 'ended', ended_at = ? WHERE id = ? AND status = 'open'").run(Date.now(), id);
  return getPoll(id);
}

export function voteCounts(pollId) {
  return getDb()
    .prepare('SELECT option_index, COUNT(*) AS votes FROM poll_votes WHERE poll_id = ? GROUP BY option_index')
    .all(pollId)
    .map((row) => ({ option_index: Number(row.option_index), votes: Number(row.votes) }));
}

export function uniqueVoterCount(pollId) {
  return Number(getDb().prepare('SELECT COUNT(DISTINCT user_id) AS total FROM poll_votes WHERE poll_id = ?').get(pollId)?.total ?? 0);
}

export function voteCount(pollId) {
  return Number(getDb().prepare('SELECT COUNT(*) AS total FROM poll_votes WHERE poll_id = ?').get(pollId)?.total ?? 0);
}

/**
 * Toggles one ballot. In single-choice polls a second click removes the vote;
 * in multi-choice polls each option toggles independently.
 */
export function toggleVote({ pollId, guildId, userId, optionIndex }) {
  const poll = getPollForGuild(pollId, guildId);
  if (!poll) return { poll: null, voted: false };
  if (poll.status !== 'open' || Number(poll.ends_at) <= Date.now()) return { poll, voted: false, closed: true };

  const index = Number(optionIndex);
  if (!Number.isInteger(index) || index < 0 || index >= poll.options.length) return { poll, voted: false, invalid: true };

  const db = getDb();
  const existing = db
    .prepare('SELECT 1 FROM poll_votes WHERE poll_id = ? AND guild_id = ? AND user_id = ? AND option_index = ?')
    .get(pollId, guildId, userId, index);

  transaction((tx) => {
    if (existing) {
      tx.prepare('DELETE FROM poll_votes WHERE poll_id = ? AND guild_id = ? AND user_id = ? AND option_index = ?').run(
        pollId,
        guildId,
        userId,
        index,
      );
      return;
    }

    if (!poll.allow_multiple) {
      tx.prepare('DELETE FROM poll_votes WHERE poll_id = ? AND guild_id = ? AND user_id = ?').run(pollId, guildId, userId);
    }
    tx.prepare('INSERT OR IGNORE INTO poll_votes (poll_id, guild_id, user_id, option_index, created_at) VALUES (?, ?, ?, ?, ?)').run(
      pollId,
      guildId,
      userId,
      index,
      Date.now(),
    );
  });

  return { poll, voted: !existing, removed: Boolean(existing) };
}

/**
 * Voter identity plus the competitive profile the admin panel asks for:
 * gamertag/platform, rival score, team/clan tag and clan rank label.
 */
export function listPollVoters(pollId, guildId) {
  return getDb()
    .prepare(
      `SELECT v.user_id, v.option_index, v.created_at,
              p.astro_score, p.rival_wins, p.kills, p.deaths, p.level,
              l.platform, l.gamertag,
              t.name AS team_name, t.tag AS team_tag,
              tm.rank AS team_rank,
              cr.label AS clan_rank
       FROM poll_votes v
       LEFT JOIN players p ON p.guild_id = v.guild_id AND p.user_id = v.user_id
       LEFT JOIN player_links l ON l.guild_id = v.guild_id AND l.user_id = v.user_id
       LEFT JOIN team_members tm ON tm.guild_id = v.guild_id AND tm.user_id = v.user_id
       LEFT JOIN teams t ON t.id = tm.team_id AND t.guild_id = v.guild_id
       LEFT JOIN clan_ranks cr ON cr.guild_id = v.guild_id AND cr.key = tm.rank
       WHERE v.poll_id = ? AND v.guild_id = ?
       ORDER BY v.option_index ASC, v.created_at ASC`,
    )
    .all(pollId, guildId)
    .map((row) => ({ ...row, option_index: Number(row.option_index) }));
}
