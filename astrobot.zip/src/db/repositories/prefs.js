import { getDb } from '../index.js';

/** Per-user, per-guild preferences such as the selected card back. */

export function getPref(guildId, userId, key, fallback = null) {
  const row = getDb().prepare('SELECT value FROM player_prefs WHERE guild_id = ? AND user_id = ? AND key = ?').get(guildId, userId, key);
  return row ? row.value : fallback;
}

export function setPref(guildId, userId, key, value) {
  getDb()
    .prepare(
      `INSERT INTO player_prefs (guild_id, user_id, key, value, updated_at) VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(guild_id, user_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
    )
    .run(guildId, userId, key, String(value), Date.now());
  return value;
}

export function allPrefs(guildId, userId) {
  return getDb().prepare('SELECT key, value FROM player_prefs WHERE guild_id = ? AND user_id = ?').all(guildId, userId);
}
