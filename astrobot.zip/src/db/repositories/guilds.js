import { getDb, transaction } from '../index.js';
import { DEFAULT_GUILD_SETTINGS } from '../../config/defaults.js';
import { deepMerge, getPath, setPath } from '../../utils/object.js';
import { createLogger } from '../../core/logger.js';
import { normalizePlanId } from '../../config/plans.js';

const log = createLogger('db:guilds');

/** Settings are read on nearly every interaction; cache merged per guild. */
const settingsCache = new Map();

export function ensureGuild({ id, name = null, icon = null }) {
  const db = getDb();
  db.prepare(
    `INSERT INTO guilds (id, name, icon, approved, plan, joined_at)
     VALUES (?, ?, ?, 0, 'basic', ?)
     ON CONFLICT(id) DO UPDATE SET name = COALESCE(excluded.name, guilds.name), icon = COALESCE(excluded.icon, guilds.icon)`,
  ).run(id, name, icon, Date.now());
  return getGuild(id);
}

export function getGuild(guildId) {
  return getDb().prepare('SELECT * FROM guilds WHERE id = ?').get(guildId) ?? null;
}

export function approveGuild(guildId, actorId) {
  getDb()
    .prepare('UPDATE guilds SET approved = 1, approved_at = ?, approved_by = ? WHERE id = ?')
    .run(Date.now(), actorId, guildId);
  return getGuild(guildId);
}

export function revokeGuild(guildId, actorId) {
  getDb()
    .prepare('UPDATE guilds SET approved = 0, approved_at = NULL, approved_by = ? WHERE id = ?')
    .run(actorId, guildId);
  return getGuild(guildId);
}

export function setGuildPlan(guildId, plan, { expiresAt = null, source = 'manual', ownerId = null } = {}) {
  getDb()
    .prepare('UPDATE guilds SET plan = ?, plan_expires_at = ?, plan_source = ?, plan_owner_id = ? WHERE id = ?')
    .run(normalizePlanId(plan), expiresAt, source, ownerId, guildId);
  return getGuild(guildId);
}

export function listGuilds({ approved = null, limit = 50 } = {}) {
  if (approved === null) {
    return getDb().prepare('SELECT * FROM guilds ORDER BY joined_at DESC LIMIT ?').all(limit);
  }
  return getDb()
    .prepare('SELECT * FROM guilds WHERE approved = ? ORDER BY joined_at DESC LIMIT ?')
    .all(approved ? 1 : 0, limit);
}

export function getGuildSettings(guildId) {
  if (!guildId) return deepMerge(DEFAULT_GUILD_SETTINGS, {});

  const cached = settingsCache.get(guildId);
  if (cached) return cached;

  const rows = getDb().prepare('SELECT key, value FROM guild_settings WHERE guild_id = ?').all(guildId);
  let merged = deepMerge(DEFAULT_GUILD_SETTINGS, {});

  for (const row of rows) {
    try {
      merged = { ...merged, [row.key]: deepMerge(DEFAULT_GUILD_SETTINGS[row.key] ?? {}, JSON.parse(row.value)) };
    } catch (error) {
      log.warn(`Ignoring corrupt settings row ${guildId}/${row.key}`, error);
    }
  }

  settingsCache.set(guildId, merged);
  return merged;
}

export function saveGuildSettings(guildId, settings, { actorId = null, audit = true } = {}) {
  const before = getGuildSettings(guildId);
  const db = getDb();

  transaction((tx) => {
    const statement = tx.prepare(
      `INSERT INTO guild_settings (guild_id, key, value, updated_at) VALUES (?, ?, ?, ?)
       ON CONFLICT(guild_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
    );

    for (const [key, value] of Object.entries(settings)) {
      if (!(key in DEFAULT_GUILD_SETTINGS)) continue;
      statement.run(guildId, key, JSON.stringify(value), Date.now());

      if (audit && JSON.stringify(before[key]) !== JSON.stringify(value)) {
        tx.prepare(
          `INSERT INTO settings_audit (guild_id, actor_id, key, old_value, new_value, created_at)
           VALUES (?, ?, ?, ?, ?, ?)`,
        ).run(guildId, actorId, key, JSON.stringify(before[key] ?? null), JSON.stringify(value), Date.now());
      }
    }
  });

  settingsCache.delete(guildId);
  return getGuildSettings(guildId);
}

/**
 * Edits a single dotted path (e.g. "economy.playtimeReward") and persists only
 * the affected root key. Returns { settings, previous }.
 */
export function patchGuildSetting(guildId, path, value, { actorId = null } = {}) {
  const current = getGuildSettings(guildId);
  const rootKey = path.split('.')[0];

  if (!(rootKey in DEFAULT_GUILD_SETTINGS)) throw new Error(`Unknown settings group "${rootKey}".`);

  const previous = getPath(current, path);
  const relativePath = path.slice(rootKey.length + 1);
  const nextRoot = relativePath
    ? setPath(current[rootKey] ?? {}, relativePath, value)
    : value;
  const settings = saveGuildSettings(guildId, { [rootKey]: nextRoot }, { actorId });

  return { settings, previous };
}

export function invalidateSettingsCache(guildId) {
  if (guildId) settingsCache.delete(guildId);
  else settingsCache.clear();
}

export function settingsAuditTrail(guildId, limit = 10) {
  return getDb()
    .prepare('SELECT * FROM settings_audit WHERE guild_id = ? ORDER BY created_at DESC LIMIT ?')
    .all(guildId, limit);
}
