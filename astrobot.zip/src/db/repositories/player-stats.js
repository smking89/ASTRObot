import { getDb } from '../index.js';

/** Persisted message id for a live player/queue stats channel. */
export function getStatsChannelState(channelId) {
  return getDb()
    .prepare('SELECT * FROM stats_channel_messages WHERE channel_id = ?')
    .get(String(channelId)) ?? null;
}

export function saveStatsChannelState({ channelId, guildId, scope, messageId, line = null }) {
  getDb()
    .prepare(
      `INSERT INTO stats_channel_messages (channel_id, guild_id, scope, message_id, last_line, updated_at)
       VALUES (?, ?, ?, ?, ?, ?)
       ON CONFLICT(channel_id) DO UPDATE SET
         guild_id = excluded.guild_id,
         scope = excluded.scope,
         message_id = excluded.message_id,
         last_line = excluded.last_line,
         updated_at = excluded.updated_at`,
    )
    .run(String(channelId), String(guildId), String(scope), String(messageId), line, Date.now());
}

export function clearStatsChannelState(channelId) {
  getDb().prepare('DELETE FROM stats_channel_messages WHERE channel_id = ?').run(String(channelId));
}
