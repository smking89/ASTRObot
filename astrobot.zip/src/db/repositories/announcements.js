import { getDb } from '../index.js';
import { formatTimeZone } from '../../utils/timezone.js';
import { uniqueId } from '../../utils/random.js';

/** Scheduled Discord/in-game announcements with calendar + clock timing. */

const SCHEDULES = new Set(['once', 'daily', 'weekly', 'interval']);

function mapAnnouncement(row) {
  if (!row) return null;
  let weekdays = [];
  try {
    weekdays = row.weekdays ? JSON.parse(row.weekdays) : [];
  } catch {
    weekdays = [];
  }
  return {
    ...row,
    in_game: Boolean(row.in_game),
    enabled: Boolean(row.enabled),
    timezone: row.timezone || 'UTC',
    weekdays: Array.isArray(weekdays) ? weekdays.map(Number).filter((day) => day >= 0 && day <= 6) : [],
  };
}

export function listAnnouncements(guildId, limit = 50) {
  return getDb()
    .prepare('SELECT * FROM announcements WHERE guild_id = ? ORDER BY enabled DESC, next_run_at ASC, created_at DESC LIMIT ?')
    .all(guildId, Math.max(1, Math.min(100, Number(limit) || 50)))
    .map(mapAnnouncement);
}

export function getAnnouncement(id) {
  return mapAnnouncement(getDb().prepare('SELECT * FROM announcements WHERE id = ?').get(id) ?? null);
}

export function setAnnouncementMessage(id, message, rconMessage = null) {
  getDb().prepare('UPDATE announcements SET message = ?, rcon_message = ? WHERE id = ?').run(message, rconMessage, id);
  return getAnnouncement(id);
}

export function setAnnouncementChannel(id, channelId) {
  getDb().prepare('UPDATE announcements SET channel_id = ? WHERE id = ?').run(channelId, id);
  return getAnnouncement(id);
}

/** Changes the zone while keeping the wall-clock time the owner entered. */
export function setAnnouncementTimeZone(id, timezone, runAt, nextRunAt) {
  getDb()
    .prepare('UPDATE announcements SET timezone = ?, run_at = ?, next_run_at = ? WHERE id = ?')
    .run(formatTimeZone(timezone), runAt, nextRunAt, id);
  return getAnnouncement(id);
}

export function createAnnouncement({
  guildId,
  name,
  message,
  channelId = null,
  inGame = false,
  rconMessage = null,
  schedule = 'once',
  runAt,
  intervalSeconds = null,
  weekdays = [],
  timezone = 'UTC',
  createdBy = null,
  nextRunAt = null,
}) {
  const id = uniqueId('ann');
  const kind = SCHEDULES.has(schedule) ? schedule : 'once';
  const firstRun = Number(runAt) || Date.now();
  const next = nextRunAt == null ? firstRun : Number(nextRunAt);
  const days = Array.isArray(weekdays) ? [...new Set(weekdays.map(Number).filter((day) => day >= 0 && day <= 6))] : [];

  getDb()
    .prepare(
      `INSERT INTO announcements
         (id, guild_id, name, message, channel_id, in_game, rcon_message, schedule, run_at,
          interval_seconds, weekdays, timezone, enabled, created_by, next_run_at, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)`,
    )
    .run(
      id,
      guildId,
      name,
      message,
      channelId,
      inGame ? 1 : 0,
      rconMessage,
      kind,
      firstRun,
      intervalSeconds == null ? null : Math.max(60, Number(intervalSeconds) || 3600),
      days.length > 0 ? JSON.stringify(days) : null,
      formatTimeZone(timezone),
      createdBy,
      next,
      Date.now(),
    );

  return getAnnouncement(id);
}

export function setAnnouncementEnabled(id, enabled, nextRunAt = null) {
  const current = getAnnouncement(id);
  if (!current) return null;
  const next = enabled ? nextRunAt ?? current.next_run_at ?? current.run_at : current.next_run_at;
  getDb().prepare('UPDATE announcements SET enabled = ?, next_run_at = ? WHERE id = ?').run(enabled ? 1 : 0, next, id);
  return getAnnouncement(id);
}

export function markAnnouncementRun(id, ranAt = Date.now(), nextRunAt = null) {
  if (nextRunAt == null) {
    getDb().prepare('UPDATE announcements SET last_run_at = ?, next_run_at = NULL, enabled = 0 WHERE id = ?').run(ranAt, id);
    return;
  }
  getDb().prepare('UPDATE announcements SET last_run_at = ?, next_run_at = ? WHERE id = ?').run(ranAt, nextRunAt, id);
}

export function dueAnnouncements(now = Date.now()) {
  return getDb()
    .prepare('SELECT * FROM announcements WHERE enabled = 1 AND next_run_at IS NOT NULL AND next_run_at <= ? ORDER BY next_run_at ASC LIMIT 25')
    .all(now)
    .map(mapAnnouncement);
}

export function removeAnnouncement(id) {
  return getDb().prepare('DELETE FROM announcements WHERE id = ?').run(id).changes > 0;
}
