import { getDb } from '../index.js';

/** Purchase history backs per-member limits and shop analytics. */

export function recordPurchase({ guildId, userId, productId, quantity = 1, price = 0 }) {
  getDb()
    .prepare(
      `INSERT INTO shop_purchases (guild_id, user_id, product_id, quantity, price, created_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
    )
    .run(guildId, userId, String(productId), Math.trunc(quantity), Math.trunc(price), Date.now());
}

export function countPurchasesSince(guildId, userId, productId, since) {
  const row = getDb()
    .prepare(
      `SELECT COUNT(*) AS count FROM shop_purchases
       WHERE guild_id = ? AND user_id = ? AND product_id = ? AND created_at >= ?`,
    )
    .get(guildId, userId, String(productId), Math.trunc(since));

  return Number(row?.count ?? 0);
}

export function recordStockEvent({ guildId, productId, delta = 0, stockAfter = null, kind = 'adjust', actorId = null, note = null }) {
  getDb()
    .prepare(
      `INSERT INTO shop_stock_events (guild_id, product_id, delta, stock_after, kind, actor_id, note, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(guildId, String(productId), Math.trunc(delta), stockAfter === null ? null : Math.trunc(stockAfter), kind, actorId, note, Date.now());
}

export function listStockEvents(guildId, productId, limit = 10) {
  return getDb()
    .prepare('SELECT * FROM shop_stock_events WHERE guild_id = ? AND product_id = ? ORDER BY created_at DESC, id DESC LIMIT ?')
    .all(guildId, String(productId), limit);
}

export function pruneStockEvents(guildId, before) {
  return getDb().prepare('DELETE FROM shop_stock_events WHERE guild_id = ? AND created_at < ?').run(guildId, Math.trunc(before))
    .changes;
}

export function lastStockEventAt(guildId, productId) {
  const row = getDb()
    .prepare('SELECT MAX(created_at) AS last FROM shop_stock_events WHERE guild_id = ? AND product_id = ?')
    .get(guildId, String(productId));
  return row?.last === null || row?.last === undefined ? null : Number(row.last);
}

/** Sales analytics for the staff report, newest window first. */
export function topSellers(guildId, since = 0, limit = 5) {
  return getDb()
    .prepare(
      `SELECT product_id, COUNT(*) AS purchases, COALESCE(SUM(quantity), 0) AS units, COALESCE(SUM(price), 0) AS revenue
       FROM shop_purchases WHERE guild_id = ? AND created_at >= ?
       GROUP BY product_id ORDER BY revenue DESC, purchases DESC LIMIT ?`,
    )
    .all(guildId, Math.trunc(since), limit);
}

export function salesTotals(guildId, since = 0) {
  return getDb()
    .prepare(
      `SELECT COUNT(*) AS purchases, COALESCE(SUM(quantity), 0) AS units, COALESCE(SUM(price), 0) AS revenue
       FROM shop_purchases WHERE guild_id = ? AND created_at >= ?`,
    )
    .get(guildId, Math.trunc(since));
}

export function recentPurchases(guildId, userId, limit = 5) {
  return getDb()
    .prepare('SELECT * FROM shop_purchases WHERE guild_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT ?')
    .all(guildId, userId, limit);
}
