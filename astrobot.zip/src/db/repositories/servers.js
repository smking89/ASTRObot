import { getDb } from '../index.js';
import { uniqueId } from '../../utils/random.js';
import { decryptSecret, encryptSecret } from '../../utils/crypto.js';

/** Connected Rust servers. Passwords are encrypted at rest by utils/crypto. */

export function listServers(guildId) {
  return getDb()
    .prepare('SELECT * FROM servers WHERE guild_id = ? ORDER BY created_at ASC')
    .all(guildId)
    .map((row) => ({ ...row, password: undefined, hasPassword: Boolean(row.password) }));
}

export function listEnabledServers() {
  return getDb().prepare('SELECT * FROM servers WHERE enabled = 1').all();
}

export function getServer(serverId, { withSecret = false } = {}) {
  const row = getDb().prepare('SELECT * FROM servers WHERE id = ?').get(serverId) ?? null;
  if (!row) return null;
  return withSecret ? { ...row, password: decryptSecret(row.password) } : { ...row, password: undefined };
}

export function addServer({ guildId, label, host, port, password, enabled = true }) {
  const id = uniqueId('srv');
  getDb()
    .prepare(
      `INSERT INTO servers (id, guild_id, label, host, port, password, enabled, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(id, guildId, label, host, port, encryptSecret(password), enabled ? 1 : 0, Date.now());
  return getServer(id);
}

export function updateServer(serverId, fields) {
  const allowed = ['label', 'host', 'port', 'enabled'];
  const entries = Object.entries(fields).filter(([key]) => allowed.includes(key));
  if (fields.password !== undefined) entries.push(['password', encryptSecret(fields.password)]);
  if (entries.length === 0) return getServer(serverId);

  getDb()
    .prepare(`UPDATE servers SET ${entries.map(([key]) => `${key} = ?`).join(', ')} WHERE id = ?`)
    .run(...entries.map(([, value]) => value), serverId);
  return getServer(serverId);
}

export function removeServer(serverId) {
  const result = getDb().prepare('DELETE FROM servers WHERE id = ?').run(serverId);
  return result.changes > 0;
}
