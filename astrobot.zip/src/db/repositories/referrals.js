import { getDb, transaction } from '../index.js';
import { uniqueId } from '../../utils/random.js';

export function createReferralCode({ guildId, ownerId, code, maxUses = null }) {
  getDb()
    .prepare(
      `INSERT INTO referrals (code, guild_id, owner_id, uses, max_uses, active, created_at)
       VALUES (?, ?, ?, 0, ?, 1, ?)`,
    )
    .run(code.toUpperCase(), guildId, ownerId, maxUses, Date.now());
  return getReferral(code);
}

export function getReferral(code) {
  return getDb().prepare('SELECT * FROM referrals WHERE code = ?').get(String(code).toUpperCase()) ?? null;
}

export function getReferralForOwner(guildId, ownerId) {
  return (
    getDb()
      .prepare('SELECT * FROM referrals WHERE guild_id = ? AND owner_id = ? ORDER BY created_at DESC LIMIT 1')
      .get(guildId, ownerId) ?? null
  );
}

export function hasClaimed(guildId, invitedId) {
  return Boolean(
    getDb().prepare('SELECT 1 AS claimed FROM referral_claims WHERE guild_id = ? AND invited_id = ?').get(guildId, invitedId),
  );
}

/** Records a redemption atomically so a code can never exceed its use limit. */
export function claimReferral({ guildId, code, invitedId, reward }) {
  return transaction((db) => {
    const referral = getReferral(code);
    if (!referral || referral.guild_id !== guildId || !referral.active) return { ok: false, reason: 'invalid' };
    if (referral.owner_id === invitedId) return { ok: false, reason: 'self' };
    if (referral.max_uses !== null && referral.uses >= referral.max_uses) return { ok: false, reason: 'exhausted' };
    if (hasClaimed(guildId, invitedId)) return { ok: false, reason: 'already_claimed' };

    db.prepare('UPDATE referrals SET uses = uses + 1 WHERE code = ?').run(referral.code);
    db.prepare(
      `INSERT INTO referral_claims (id, guild_id, code, inviter_id, invited_id, reward, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
    ).run(uniqueId('claim'), guildId, referral.code, referral.owner_id, invitedId, reward, Date.now());

    return { ok: true, referral };
  });
}

export function topReferrers(guildId, limit = 15) {
  return getDb()
    .prepare('SELECT * FROM referrals WHERE guild_id = ? ORDER BY uses DESC LIMIT ?')
    .all(guildId, limit);
}

export function referralClaimCount(guildId, ownerId) {
  const row = getDb()
    .prepare('SELECT COUNT(*) AS count FROM referral_claims WHERE guild_id = ? AND inviter_id = ?')
    .get(guildId, ownerId);
  return Number(row?.count ?? 0);
}
