import { getDb } from '../index.js';

export function getProgress(guildId, userId) {
  return getDb().prepare('SELECT * FROM battle_pass WHERE guild_id = ? AND user_id = ?').get(guildId, userId) ?? null;
}

export function ensureProgress(guildId, userId) {
  const existing = getProgress(guildId, userId);
  if (existing) return existing;

  getDb()
    .prepare('INSERT OR IGNORE INTO battle_pass (guild_id, user_id, tier, xp, premium, claimed, updated_at) VALUES (?, ?, 0, 0, 0, ?, ?)')
    .run(guildId, userId, '[]', Date.now());
  return getProgress(guildId, userId);
}

export function addPassXp(guildId, userId, xp, xpPerTier) {
  const current = ensureProgress(guildId, userId);
  const totalXp = Number(current.xp) + xp;
  const tier = Math.floor(totalXp / Math.max(1, xpPerTier));

  getDb()
    .prepare('UPDATE battle_pass SET xp = ?, tier = ?, updated_at = ? WHERE guild_id = ? AND user_id = ?')
    .run(totalXp, tier, Date.now(), guildId, userId);

  return { progress: getProgress(guildId, userId), tierUp: tier > Number(current.tier) };
}

export function setPremium(guildId, userId, premium) {
  ensureProgress(guildId, userId);
  getDb()
    .prepare('UPDATE battle_pass SET premium = ?, updated_at = ? WHERE guild_id = ? AND user_id = ?')
    .run(premium ? 1 : 0, Date.now(), guildId, userId);
  return getProgress(guildId, userId);
}

export function recordClaim(guildId, userId, tier) {
  const current = ensureProgress(guildId, userId);
  const claimed = new Set(JSON.parse(current.claimed || '[]'));
  claimed.add(tier);
  getDb()
    .prepare('UPDATE battle_pass SET claimed = ?, updated_at = ? WHERE guild_id = ? AND user_id = ?')
    .run(JSON.stringify([...claimed]), Date.now(), guildId, userId);
  return getProgress(guildId, userId);
}
