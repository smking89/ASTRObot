-- AstroBot schema. All ids are stored as TEXT (Discord snowflakes exceed int53).
-- Money is stored as INTEGER; the application enforces wallet/bank caps.

CREATE TABLE IF NOT EXISTS guilds (
  id                 TEXT PRIMARY KEY,
  name               TEXT,
  icon               TEXT,
  approved           INTEGER NOT NULL DEFAULT 0,
  approved_at        INTEGER,
  approved_by        TEXT,
  plan               TEXT NOT NULL DEFAULT 'free',
  joined_at          INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS guild_settings (
  guild_id           TEXT NOT NULL,
  key                TEXT NOT NULL,
  value              TEXT NOT NULL,
  updated_at         INTEGER NOT NULL,
  PRIMARY KEY (guild_id, key)
);

CREATE TABLE IF NOT EXISTS settings_audit (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id           TEXT NOT NULL,
  actor_id           TEXT,
  key                TEXT NOT NULL,
  old_value          TEXT,
  new_value          TEXT,
  created_at         INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS players (
  guild_id           TEXT NOT NULL,
  user_id            TEXT NOT NULL,
  wallet             INTEGER NOT NULL DEFAULT 0,
  bank               INTEGER NOT NULL DEFAULT 0,
  xp                 INTEGER NOT NULL DEFAULT 0,
  level              INTEGER NOT NULL DEFAULT 1,
  prestige           INTEGER NOT NULL DEFAULT 0,
  astro_score        INTEGER NOT NULL DEFAULT 0,
  kills              INTEGER NOT NULL DEFAULT 0,
  deaths             INTEGER NOT NULL DEFAULT 0,
  playtime_seconds   INTEGER NOT NULL DEFAULT 0,
  streak             INTEGER NOT NULL DEFAULT 0,
  last_daily         INTEGER,
  last_playtime_at   INTEGER,
  created_at         INTEGER NOT NULL,
  PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS player_links (
  guild_id           TEXT NOT NULL,
  user_id            TEXT NOT NULL,
  platform           TEXT NOT NULL CHECK (platform IN ('xbox', 'playstation')),
  gamertag           TEXT NOT NULL,
  external_id        TEXT,
  verified_at        INTEGER NOT NULL,
  PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS player_prefs (
  guild_id           TEXT NOT NULL,
  user_id            TEXT NOT NULL,
  key                TEXT NOT NULL,
  value              TEXT NOT NULL,
  updated_at         INTEGER NOT NULL,
  PRIMARY KEY (guild_id, user_id, key)
);

CREATE TABLE IF NOT EXISTS transactions (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id           TEXT NOT NULL,
  user_id            TEXT NOT NULL,
  kind               TEXT NOT NULL,
  amount             INTEGER NOT NULL,
  balance_after      INTEGER NOT NULL,
  metadata           TEXT,
  created_at         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_transactions_guild_user ON transactions (guild_id, user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS inventory (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id           TEXT NOT NULL,
  user_id            TEXT NOT NULL,
  item_key           TEXT NOT NULL,
  quantity           INTEGER NOT NULL DEFAULT 1,
  metadata           TEXT,
  acquired_at        INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS teams (
  id                 TEXT PRIMARY KEY,
  guild_id           TEXT NOT NULL,
  name               TEXT NOT NULL,
  tag                TEXT NOT NULL,
  owner_id           TEXT NOT NULL,
  color              INTEGER,
  badge              TEXT,
  role_id            TEXT,
  orp_zone           TEXT,
  raid_channel_id    TEXT,
  created_at         INTEGER NOT NULL,
  UNIQUE (guild_id, name),
  UNIQUE (guild_id, tag)
);

CREATE TABLE IF NOT EXISTS team_members (
  team_id            TEXT NOT NULL,
  guild_id           TEXT NOT NULL,
  user_id            TEXT NOT NULL,
  rank               TEXT NOT NULL DEFAULT 'member',
  joined_at          INTEGER NOT NULL,
  PRIMARY KEY (team_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_team_members_user ON team_members (guild_id, user_id);

CREATE TABLE IF NOT EXISTS team_invites (
  id                 TEXT PRIMARY KEY,
  guild_id           TEXT NOT NULL,
  team_id            TEXT NOT NULL,
  inviter_id         TEXT NOT NULL,
  invitee_id         TEXT NOT NULL,
  status             TEXT NOT NULL DEFAULT 'pending',
  created_at         INTEGER NOT NULL,
  expires_at         INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS team_wars (
  id                 TEXT PRIMARY KEY,
  guild_id           TEXT NOT NULL,
  team_id            TEXT NOT NULL,
  opponent_team_id   TEXT NOT NULL,
  status             TEXT NOT NULL DEFAULT 'active',
  score              TEXT,
  started_at         INTEGER NOT NULL,
  ended_at           INTEGER
);

CREATE TABLE IF NOT EXISTS lfg_posts (
  id                 TEXT PRIMARY KEY,
  guild_id           TEXT NOT NULL,
  channel_id         TEXT,
  message_id         TEXT,
  owner_id           TEXT NOT NULL,
  title              TEXT NOT NULL,
  description        TEXT,
  platform           TEXT NOT NULL DEFAULT 'any',
  region             TEXT NOT NULL DEFAULT 'any',
  players_needed     INTEGER NOT NULL DEFAULT 4,
  filled             INTEGER NOT NULL DEFAULT 1,
  tags               TEXT,
  status             TEXT NOT NULL DEFAULT 'open',
  created_at         INTEGER NOT NULL,
  closed_at          INTEGER
);
CREATE INDEX IF NOT EXISTS idx_lfg_guild_status ON lfg_posts (guild_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS partnerships (
  id                 TEXT PRIMARY KEY,
  from_guild_id      TEXT NOT NULL,
  to_guild_id        TEXT NOT NULL,
  requester_id       TEXT,
  brand_name         TEXT NOT NULL,
  duration           TEXT,
  description        TEXT,
  member_count       INTEGER NOT NULL DEFAULT 0,
  status             TEXT NOT NULL DEFAULT 'pending',
  network_id         TEXT,
  responded_by       TEXT,
  created_at         INTEGER NOT NULL,
  responded_at       INTEGER
);
CREATE INDEX IF NOT EXISTS idx_partnerships_target ON partnerships (to_guild_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_partnerships_source ON partnerships (from_guild_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS referrals (
  code               TEXT PRIMARY KEY,
  guild_id           TEXT NOT NULL,
  owner_id           TEXT NOT NULL,
  uses               INTEGER NOT NULL DEFAULT 0,
  max_uses           INTEGER,
  active             INTEGER NOT NULL DEFAULT 1,
  created_at         INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS referral_claims (
  id                 TEXT PRIMARY KEY,
  guild_id           TEXT NOT NULL,
  code               TEXT NOT NULL,
  inviter_id         TEXT NOT NULL,
  invited_id         TEXT NOT NULL,
  reward             INTEGER NOT NULL DEFAULT 0,
  created_at         INTEGER NOT NULL,
  UNIQUE (guild_id, invited_id)
);

CREATE TABLE IF NOT EXISTS licenses (
  id                 TEXT PRIMARY KEY,
  key                TEXT NOT NULL UNIQUE,
  guild_id           TEXT,
  owner_id           TEXT,
  tier               TEXT NOT NULL DEFAULT 'standard',
  status             TEXT NOT NULL DEFAULT 'unassigned',
  issued_at          INTEGER NOT NULL,
  activated_at       INTEGER,
  expires_at         INTEGER,
  revoked_at         INTEGER,
  revoked_by         TEXT,
  transferred_from   TEXT
);

CREATE TABLE IF NOT EXISTS addon_grants (
  id                 TEXT PRIMARY KEY,
  provider           TEXT NOT NULL,
  provider_ref       TEXT NOT NULL,
  guild_id           TEXT,
  user_id            TEXT NOT NULL,
  product_id         TEXT NOT NULL,
  kind               TEXT NOT NULL,
  seats              INTEGER NOT NULL DEFAULT 1,
  created_at         INTEGER NOT NULL,
  UNIQUE (provider, provider_ref, product_id, kind)
);
CREATE INDEX IF NOT EXISTS idx_addon_grants_user ON addon_grants (user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS bounties (
  id                 TEXT PRIMARY KEY,
  guild_id           TEXT NOT NULL,
  target_id          TEXT NOT NULL,
  placed_by          TEXT NOT NULL,
  amount             INTEGER NOT NULL,
  status             TEXT NOT NULL DEFAULT 'active',
  claimed_by         TEXT,
  created_at         INTEGER NOT NULL,
  claimed_at         INTEGER
);
CREATE INDEX IF NOT EXISTS idx_bounties_target ON bounties (guild_id, target_id, status);

CREATE TABLE IF NOT EXISTS battle_pass (
  guild_id           TEXT NOT NULL,
  user_id            TEXT NOT NULL,
  tier               INTEGER NOT NULL DEFAULT 0,
  xp                 INTEGER NOT NULL DEFAULT 0,
  premium            INTEGER NOT NULL DEFAULT 0,
  claimed            TEXT NOT NULL DEFAULT '[]',
  updated_at         INTEGER NOT NULL,
  PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS servers (
  id                 TEXT PRIMARY KEY,
  guild_id           TEXT NOT NULL,
  label              TEXT NOT NULL,
  host               TEXT NOT NULL,
  port               INTEGER NOT NULL,
  password           TEXT NOT NULL,
  enabled            INTEGER NOT NULL DEFAULT 1,
  created_at         INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS scheduled_tasks (
  id                 TEXT PRIMARY KEY,
  guild_id           TEXT NOT NULL,
  name               TEXT NOT NULL,
  kind               TEXT NOT NULL DEFAULT 'command',
  interval_seconds   INTEGER NOT NULL,
  command            TEXT,
  payload            TEXT,
  enabled            INTEGER NOT NULL DEFAULT 1,
  last_run_at        INTEGER,
  next_run_at        INTEGER,
  created_at         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tasks_due ON scheduled_tasks (enabled, next_run_at);

CREATE TABLE IF NOT EXISTS telemetry_events (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id           TEXT,
  server_id          TEXT,
  kind               TEXT NOT NULL,
  payload            TEXT,
  created_at         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_telemetry_kind ON telemetry_events (guild_id, kind, created_at DESC);

CREATE TABLE IF NOT EXISTS mod_cases (
  id                 TEXT PRIMARY KEY,
  guild_id           TEXT NOT NULL,
  target_id          TEXT NOT NULL,
  moderator_id       TEXT NOT NULL,
  action             TEXT NOT NULL,
  reason             TEXT,
  duration_ms        INTEGER,
  expires_at         INTEGER,
  active             INTEGER NOT NULL DEFAULT 1,
  created_at         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_mod_cases_target ON mod_cases (guild_id, target_id, active);

CREATE TABLE IF NOT EXISTS memberships (
  user_id            TEXT PRIMARY KEY,
  tier               TEXT NOT NULL DEFAULT 'pro',
  granted_by         TEXT,
  granted_at         INTEGER NOT NULL,
  expires_at         INTEGER
);

CREATE TABLE IF NOT EXISTS tickets (
  id                 TEXT PRIMARY KEY,
  guild_id           TEXT NOT NULL,
  channel_id         TEXT,
  owner_id           TEXT NOT NULL,
  subject            TEXT NOT NULL,
  status             TEXT NOT NULL DEFAULT 'open',
  created_at         INTEGER NOT NULL,
  closed_at          INTEGER
);

CREATE TABLE IF NOT EXISTS lfg_members (
  post_id            TEXT NOT NULL,
  guild_id           TEXT NOT NULL,
  user_id            TEXT NOT NULL,
  joined_at          INTEGER NOT NULL,
  PRIMARY KEY (post_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_lfg_members_user ON lfg_members (guild_id, user_id);

-- Existing LFG rows predate membership tracking; the owner is always the
-- first member. Recomputing `filled` keeps capacity checks honest after the
-- migration and on every boot.
INSERT OR IGNORE INTO lfg_members (post_id, guild_id, user_id, joined_at)
  SELECT id, guild_id, owner_id, created_at FROM lfg_posts;
UPDATE lfg_posts
  SET filled = (SELECT COUNT(*) FROM lfg_members WHERE post_id = lfg_posts.id)
  WHERE filled <> (SELECT COUNT(*) FROM lfg_members WHERE post_id = lfg_posts.id);

CREATE TABLE IF NOT EXISTS server_templates (
  id                 TEXT PRIMARY KEY,
  guild_id           TEXT NOT NULL,
  name               TEXT NOT NULL,
  payload            TEXT NOT NULL,
  created_by         TEXT,
  created_at         INTEGER NOT NULL,
  UNIQUE (guild_id, name)
);
CREATE INDEX IF NOT EXISTS idx_server_templates_guild ON server_templates (guild_id, created_at DESC);

CREATE TABLE IF NOT EXISTS shop_purchases (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id           TEXT NOT NULL,
  user_id            TEXT NOT NULL,
  product_id         TEXT NOT NULL,
  quantity           INTEGER NOT NULL DEFAULT 1,
  price              INTEGER NOT NULL DEFAULT 0,
  created_at         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_shop_purchases_member ON shop_purchases (guild_id, user_id, product_id, created_at DESC);

CREATE TABLE IF NOT EXISTS clan_ranks (
  guild_id           TEXT NOT NULL,
  key                TEXT NOT NULL,
  label              TEXT NOT NULL,
  icon               TEXT NOT NULL,
  position           INTEGER NOT NULL DEFAULT 0,
  created_at         INTEGER NOT NULL,
  PRIMARY KEY (guild_id, key)
);

CREATE TABLE IF NOT EXISTS clan_badges (
  id                 TEXT PRIMARY KEY,
  guild_id           TEXT NOT NULL,
  label              TEXT NOT NULL,
  file               TEXT NOT NULL,
  created_by         TEXT,
  created_at         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_clan_badges_guild ON clan_badges (guild_id, created_at DESC);

CREATE TABLE IF NOT EXISTS player_badges (
  guild_id           TEXT NOT NULL,
  user_id            TEXT NOT NULL,
  badge_id           TEXT NOT NULL,
  awarded_by         TEXT,
  awarded_at         INTEGER NOT NULL,
  PRIMARY KEY (guild_id, user_id, badge_id)
);

CREATE TABLE IF NOT EXISTS shop_stock_events (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id           TEXT NOT NULL,
  product_id         TEXT NOT NULL,
  delta              INTEGER NOT NULL DEFAULT 0,
  stock_after        INTEGER,
  kind               TEXT NOT NULL,
  actor_id           TEXT,
  note               TEXT,
  created_at         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_shop_stock_events_product ON shop_stock_events (guild_id, product_id, created_at DESC);
