-- Last manual webhook delivery test for each managed giveaway.
CREATE TABLE IF NOT EXISTS giveaway_domain_webhook_tests (
  giveaway_id TEXT PRIMARY KEY,
  guild_id    TEXT NOT NULL,
  tested_at   INTEGER NOT NULL,
  ok          INTEGER NOT NULL,
  detail      TEXT
);
