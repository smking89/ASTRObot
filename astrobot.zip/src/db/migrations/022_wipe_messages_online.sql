-- Owner-authored wipe warnings. Stored as JSON with first/second/third/online
-- entries so the panel can support plain text and simple HTML.
ALTER TABLE wipe_profiles ADD COLUMN wipe_messages TEXT;
ALTER TABLE wipe_profiles ADD COLUMN announce_in_game INTEGER NOT NULL DEFAULT 1;

-- Back-online detection. `online_after` is the earliest time the server can be
-- considered back after the configured restart delay.
ALTER TABLE wipe_profiles ADD COLUMN awaiting_online INTEGER NOT NULL DEFAULT 0;
ALTER TABLE wipe_profiles ADD COLUMN online_after INTEGER;
ALTER TABLE wipe_profiles ADD COLUMN online_announced_at INTEGER;
