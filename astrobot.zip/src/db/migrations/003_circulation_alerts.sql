-- Remembers whether a guild's economy is currently over its circulation
-- threshold so the crossing alert fires once, survives restarts, and re-arms
-- only after circulation drops back under the hysteresis band.
CREATE TABLE IF NOT EXISTS circulation_state (
  guild_id           TEXT PRIMARY KEY,
  state              TEXT NOT NULL DEFAULT 'below',
  total              INTEGER NOT NULL DEFAULT 0,
  updated_at         INTEGER NOT NULL
);
