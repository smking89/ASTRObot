-- Durable local killfeed queue. Every parsed kill is stored before display so
-- the global publisher can validate and post it independently of RCON timing.
CREATE TABLE IF NOT EXISTS killfeed_events (
  id                 TEXT PRIMARY KEY,
  guild_id           TEXT NOT NULL,
  server_id          TEXT,
  server_label       TEXT,
  killer_name        TEXT NOT NULL,
  killer_external_id TEXT,
  victim_name        TEXT NOT NULL,
  victim_external_id TEXT,
  weapon             TEXT,
  grid               TEXT,
  x                  REAL,
  y                  REAL,
  z                  REAL,
  npc                INTEGER NOT NULL DEFAULT 0,
  raw                TEXT,
  occurred_at        INTEGER NOT NULL,
  status             TEXT NOT NULL DEFAULT 'pending',
  attempts           INTEGER NOT NULL DEFAULT 0,
  next_attempt_at    INTEGER,
  processing_at      INTEGER,
  posted_at          INTEGER,
  last_error         TEXT,
  created_at         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_killfeed_pending ON killfeed_events (status, next_attempt_at, occurred_at);
CREATE INDEX IF NOT EXISTS idx_killfeed_guild ON killfeed_events (guild_id, occurred_at DESC);