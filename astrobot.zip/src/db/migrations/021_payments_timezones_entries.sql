-- Persisted payment ledger. The transaction id is the primary key so a retry
-- from Tip4Serv (or a restart mid-delivery) can never grant the same purchase
-- twice.
CREATE TABLE IF NOT EXISTS payment_events (
  transaction_id TEXT PRIMARY KEY,
  guild_id       TEXT NOT NULL,
  user_id        TEXT NOT NULL,
  product_id     TEXT,
  provider       TEXT NOT NULL DEFAULT 'tip4serv',
  status         TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'delivered', 'failed')),
  delivered      TEXT,
  created_at     INTEGER NOT NULL,
  completed_at   INTEGER
);
CREATE INDEX IF NOT EXISTS idx_payment_events_guild ON payment_events (guild_id, created_at DESC);

-- Scheduled announcements remember the timezone their wall-clock time was
-- entered in, so changing the guild default later never shifts them.
ALTER TABLE announcements ADD COLUMN timezone TEXT;

-- Delivery retries for announcements whose channel or RCON target was offline.
CREATE TABLE IF NOT EXISTS announcement_deliveries (
  id              TEXT PRIMARY KEY,
  announcement_id TEXT NOT NULL,
  guild_id        TEXT NOT NULL,
  need_discord    INTEGER NOT NULL DEFAULT 0,
  need_game       INTEGER NOT NULL DEFAULT 0,
  attempts        INTEGER NOT NULL DEFAULT 0,
  status          TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'failed')),
  error           TEXT,
  next_attempt_at INTEGER NOT NULL,
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_announcement_deliveries_due ON announcement_deliveries (status, next_attempt_at);
CREATE INDEX IF NOT EXISTS idx_announcement_deliveries_announcement ON announcement_deliveries (announcement_id, created_at DESC);

-- Portal entry links are single-use for claiming the entry; the same token
-- still authenticates bonus-task claims until it expires.
ALTER TABLE giveaway_entry_tokens ADD COLUMN used_at INTEGER;

-- Weighted portal entries: each claimed task adds its configured points as
-- extra draw tickets for that member.
CREATE TABLE IF NOT EXISTS giveaway_bonus_entries (
  giveaway_id TEXT NOT NULL,
  guild_id    TEXT NOT NULL,
  user_id     TEXT NOT NULL,
  task_index  INTEGER NOT NULL,
  points      INTEGER NOT NULL,
  created_at  INTEGER NOT NULL,
  PRIMARY KEY (giveaway_id, user_id, task_index)
);
CREATE INDEX IF NOT EXISTS idx_giveaway_bonus_giveaway ON giveaway_bonus_entries (giveaway_id, user_id);
