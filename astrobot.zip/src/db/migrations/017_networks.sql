-- Cross-server partnership requests. A request is stored in the bot database
-- so the target guild can accept it from its own admin panel or DM.
CREATE TABLE IF NOT EXISTS partnerships (
  id                 TEXT PRIMARY KEY,
  from_guild_id      TEXT NOT NULL,
  to_guild_id        TEXT NOT NULL,
  requester_id       TEXT,
  brand_name         TEXT NOT NULL,
  duration           TEXT,
  description        TEXT,
  member_count       INTEGER NOT NULL DEFAULT 0,
  status             TEXT NOT NULL DEFAULT 'pending',
  network_id         TEXT,
  responded_by       TEXT,
  created_at         INTEGER NOT NULL,
  responded_at       INTEGER
);
CREATE INDEX IF NOT EXISTS idx_partnerships_target ON partnerships (to_guild_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_partnerships_source ON partnerships (from_guild_id, status, created_at DESC);
