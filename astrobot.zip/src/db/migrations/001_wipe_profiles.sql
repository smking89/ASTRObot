-- Per-server wipe schedules: BP/full type, countdown stages, map rotation.
CREATE TABLE IF NOT EXISTS wipe_profiles (
  id                 TEXT PRIMARY KEY,
  guild_id           TEXT NOT NULL,
  server_id          TEXT NOT NULL,
  name               TEXT NOT NULL,
  wipe_type          TEXT NOT NULL DEFAULT 'bp',
  interval_hours     INTEGER NOT NULL DEFAULT 168,
  next_wipe_at       INTEGER NOT NULL,
  channel_id         TEXT,
  auto_restart       INTEGER NOT NULL DEFAULT 1,
  rotate_map         INTEGER NOT NULL DEFAULT 0,
  map_rotation       TEXT NOT NULL DEFAULT '[]',
  countdowns         TEXT NOT NULL DEFAULT '60,30,10',
  announced_stages   TEXT NOT NULL DEFAULT '',
  rotation_index     INTEGER NOT NULL DEFAULT 0,
  restart_command    TEXT NOT NULL DEFAULT 'restart 300',
  last_wipe_at       INTEGER,
  created_at         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_wipes_guild ON wipe_profiles (guild_id);
CREATE INDEX IF NOT EXISTS idx_wipes_due ON wipe_profiles (next_wipe_at);
