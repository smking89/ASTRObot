-- Plan expiry, purchase source and the one-time per-guild trial ledger.
ALTER TABLE guilds ADD COLUMN plan_expires_at INTEGER;
ALTER TABLE guilds ADD COLUMN plan_source TEXT;
ALTER TABLE guilds ADD COLUMN plan_owner_id TEXT;

CREATE INDEX IF NOT EXISTS idx_guilds_plan_owner ON guilds (plan_owner_id, plan);

CREATE TABLE IF NOT EXISTS plan_trials (
  guild_id           TEXT PRIMARY KEY,
  started_at         INTEGER NOT NULL,
  ends_at            INTEGER NOT NULL,
  actor_id           TEXT
);
