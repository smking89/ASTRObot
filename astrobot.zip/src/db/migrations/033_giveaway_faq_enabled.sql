-- Per-giveaway Quick FAQ visibility, independent of the saved questions.
ALTER TABLE giveaways ADD COLUMN faq_enabled INTEGER NOT NULL DEFAULT 1;
