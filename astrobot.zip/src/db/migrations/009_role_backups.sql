-- Member role assignments captured immediately before a replacing template apply.
CREATE TABLE IF NOT EXISTS role_backups (
  id            TEXT PRIMARY KEY,
  guild_id      TEXT NOT NULL,
  actor_id      TEXT,
  template_name TEXT,
  member_count  INTEGER NOT NULL DEFAULT 0,
  role_count    INTEGER NOT NULL DEFAULT 0,
  roles_json    TEXT NOT NULL,
  members_json  TEXT NOT NULL,
  created_at    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_role_backups_guild ON role_backups (guild_id, created_at DESC);
