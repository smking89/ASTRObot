-- Live player/queue snapshots for the dashboard and stats channels.
ALTER TABLE servers ADD COLUMN battlemetrics_id TEXT;

CREATE TABLE IF NOT EXISTS server_live_stats (
  server_id    TEXT PRIMARY KEY,
  guild_id     TEXT NOT NULL,
  players      INTEGER NOT NULL DEFAULT 0,
  max_players  INTEGER,
  queue        INTEGER NOT NULL DEFAULT 0,
  updated_at   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_live_stats_guild ON server_live_stats (guild_id);
