-- Progressive jackpot pool. It is funded by a small rake on eligible wagers
-- and resets to the seed after a win. One pool per guild keeps the economy
-- isolated exactly like wallets and casino sessions.
CREATE TABLE IF NOT EXISTS jackpots (
  guild_id      TEXT PRIMARY KEY,
  balance       INTEGER NOT NULL DEFAULT 2500,
  last_won_at   INTEGER,
  last_won_by   TEXT,
  updated_at    INTEGER NOT NULL
);
