-- Durable polls. Native Discord polls do not expose voter identities, so
-- AstroBot stores its own ballots and renders button polls instead.
CREATE TABLE IF NOT EXISTS polls (
  id              TEXT PRIMARY KEY,
  guild_id        TEXT NOT NULL,
  channel_id      TEXT NOT NULL,
  message_id      TEXT,
  creator_id      TEXT NOT NULL,
  question        TEXT NOT NULL,
  options         TEXT NOT NULL,
  allow_multiple  INTEGER NOT NULL DEFAULT 0,
  anonymous       INTEGER NOT NULL DEFAULT 0,
  status          TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'ended')),
  created_at      INTEGER NOT NULL,
  ends_at         INTEGER NOT NULL,
  ended_at        INTEGER
);
CREATE INDEX IF NOT EXISTS idx_polls_guild_status ON polls (guild_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_polls_due ON polls (status, ends_at);

CREATE TABLE IF NOT EXISTS poll_votes (
  poll_id         TEXT NOT NULL,
  guild_id        TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  option_index    INTEGER NOT NULL,
  created_at      INTEGER NOT NULL,
  PRIMARY KEY (poll_id, user_id, option_index)
);
CREATE INDEX IF NOT EXISTS idx_poll_votes_poll ON poll_votes (poll_id, option_index, created_at);
CREATE INDEX IF NOT EXISTS idx_poll_votes_user ON poll_votes (guild_id, user_id, created_at DESC);

-- Owner-customized public giveaway pages. The bot issues short-lived access
-- tokens only to Astro Pro members; the dashboard validates those tokens
-- before returning or saving a portal configuration.
CREATE TABLE IF NOT EXISTS giveaway_portals (
  guild_id        TEXT PRIMARY KEY,
  config          TEXT NOT NULL,
  updated_by      TEXT,
  updated_at      INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS giveaway_portal_tokens (
  token           TEXT PRIMARY KEY,
  guild_id        TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  expires_at      INTEGER NOT NULL,
  created_at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_portal_tokens_expiry ON giveaway_portal_tokens (expires_at);
