-- Per-giveaway public bonus tasks. NULL keeps the original default task list
-- for giveaways created before this migration.
ALTER TABLE giveaways ADD COLUMN bonus_tasks TEXT;

-- One global, operator-managed brand. Values are validated again in the
-- repository so malformed JSON can never break the dashboard.
CREATE TABLE IF NOT EXISTS bot_branding (
  id            INTEGER PRIMARY KEY CHECK (id = 1),
  brand_name    TEXT NOT NULL,
  favicon_url   TEXT NOT NULL DEFAULT '',
  wordmark_url  TEXT NOT NULL DEFAULT '',
  colors        TEXT NOT NULL,
  updated_by    TEXT,
  updated_at    INTEGER NOT NULL
);
INSERT OR IGNORE INTO bot_branding (id, brand_name, colors, updated_at)
VALUES (
  1,
  'AstroBot',
  '{"brand":"#e62127","accent":"#ff4d4d","background":"#07070d","text":"#eef0f8"}',
  0
);

-- Latest domain health snapshots are written by the manual check and by the
-- background monitor, so managers can see a stale/broken domain at a glance.
CREATE TABLE IF NOT EXISTS giveaway_domain_checks (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  giveaway_id  TEXT NOT NULL,
  guild_id     TEXT NOT NULL,
  host         TEXT NOT NULL,
  status       TEXT NOT NULL CHECK (status IN ('ok', 'fail')),
  checks       TEXT NOT NULL,
  checked_at   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_giveaway_domain_checks_giveaway
  ON giveaway_domain_checks (giveaway_id, checked_at DESC);
