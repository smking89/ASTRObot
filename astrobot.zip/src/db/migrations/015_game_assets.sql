-- Admin-uploaded game artwork. Files live under data/game-assets/<guild>/ and
-- this table stores the stable slot mapping used by the game views.
CREATE TABLE IF NOT EXISTS game_assets (
  id         TEXT PRIMARY KEY,
  guild_id   TEXT NOT NULL,
  game_id    TEXT NOT NULL,
  slot       TEXT NOT NULL,
  label      TEXT,
  file       TEXT NOT NULL,
  mime       TEXT NOT NULL,
  created_by TEXT,
  created_at INTEGER NOT NULL,
  UNIQUE (guild_id, game_id, slot)
);
CREATE INDEX IF NOT EXISTS idx_game_assets_guild ON game_assets (guild_id, game_id);
