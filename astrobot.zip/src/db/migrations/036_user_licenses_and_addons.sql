-- Licenses belong to a Discord account, never to a guild. A license carries a
-- plan and a server-seat allowance; servers are attached later through /plan.
ALTER TABLE licenses ADD COLUMN server_limit INTEGER NOT NULL DEFAULT 1;
UPDATE licenses SET guild_id = NULL;
UPDATE licenses
   SET server_limit = CASE LOWER(tier)
     WHEN 'enterprise' THEN 5
     WHEN 'max' THEN 5
     ELSE 1
   END;
CREATE INDEX IF NOT EXISTS idx_licenses_owner ON licenses (owner_id);

-- Recurring add-ons are granted once per provider subscription, not once per
-- monthly renewal transaction. One-time purchases fall back to the transaction
-- id in the service layer.
CREATE TABLE IF NOT EXISTS addon_grants (
  id                 TEXT PRIMARY KEY,
  provider           TEXT NOT NULL,
  provider_ref       TEXT NOT NULL,
  guild_id           TEXT,
  user_id            TEXT NOT NULL,
  product_id         TEXT NOT NULL,
  kind               TEXT NOT NULL,
  seats              INTEGER NOT NULL DEFAULT 1,
  created_at         INTEGER NOT NULL,
  UNIQUE (provider, provider_ref, product_id, kind)
);
CREATE INDEX IF NOT EXISTS idx_addon_grants_user ON addon_grants (user_id, created_at DESC);
