-- Durable state for the live player/queue line. The line is edited in place,
-- so remembering the message id avoids scanning channel history after a
-- restart and keeps the database as the source of truth for each channel.
CREATE TABLE IF NOT EXISTS stats_channel_messages (
  channel_id   TEXT PRIMARY KEY,
  guild_id     TEXT NOT NULL,
  scope        TEXT NOT NULL,
  message_id   TEXT NOT NULL,
  last_line    TEXT,
  updated_at   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_stats_channel_guild ON stats_channel_messages (guild_id, scope);
