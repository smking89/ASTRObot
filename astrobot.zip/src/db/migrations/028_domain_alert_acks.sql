-- Acknowledgements suppress the current domain-failure banner until the
-- domain either recovers or a later failure starts a new incident.
CREATE TABLE IF NOT EXISTS giveaway_domain_alert_acks (
  giveaway_id     TEXT PRIMARY KEY,
  guild_id        TEXT NOT NULL,
  acknowledged_at INTEGER NOT NULL,
  acknowledged_by TEXT
);
