-- Rust Console RCON `serverinfo` supplies queue counts; the PC-only
-- BattleMetrics identifier is no longer used.
ALTER TABLE servers DROP COLUMN battlemetrics_id;
