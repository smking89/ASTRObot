-- Moderation hub v2, ticket operations, retention sessions and uptime events.
ALTER TABLE mod_cases ADD COLUMN scope TEXT NOT NULL DEFAULT 'guild';
ALTER TABLE mod_cases ADD COLUMN server_id TEXT;
ALTER TABLE mod_cases ADD COLUMN evidence TEXT;
ALTER TABLE mod_cases ADD COLUMN appeal_status TEXT NOT NULL DEFAULT 'none';
ALTER TABLE mod_cases ADD COLUMN appeal_ticket_id TEXT;

ALTER TABLE tickets ADD COLUMN category TEXT NOT NULL DEFAULT 'general';
ALTER TABLE tickets ADD COLUMN priority TEXT NOT NULL DEFAULT 'normal';
ALTER TABLE tickets ADD COLUMN assigned_to TEXT;
ALTER TABLE tickets ADD COLUMN sla_due_at INTEGER;
ALTER TABLE tickets ADD COLUMN first_response_at INTEGER;
ALTER TABLE tickets ADD COLUMN closed_by TEXT;
ALTER TABLE tickets ADD COLUMN transcript TEXT;
ALTER TABLE tickets ADD COLUMN rating INTEGER;

CREATE TABLE IF NOT EXISTS player_sessions (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id           TEXT NOT NULL,
  server_id          TEXT,
  gamertag           TEXT NOT NULL,
  user_id            TEXT,
  started_at         INTEGER NOT NULL,
  ended_at           INTEGER,
  duration_seconds   INTEGER
);
CREATE INDEX IF NOT EXISTS idx_sessions_guild ON player_sessions (guild_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_identity ON player_sessions (guild_id, gamertag, started_at DESC);

CREATE TABLE IF NOT EXISTS server_status_events (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id           TEXT NOT NULL,
  server_id          TEXT NOT NULL,
  status             TEXT NOT NULL,
  players            INTEGER,
  created_at         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_status_events_server ON server_status_events (server_id, created_at DESC);
