-- Each Pro/Max membership carries a Discord-server seat allowance. Pro starts
-- at 1, Max at 5; extra seats are sold as add-ons or granted by developers.
ALTER TABLE memberships ADD COLUMN server_limit INTEGER NOT NULL DEFAULT 1;

UPDATE memberships
SET server_limit = CASE
  WHEN lower(tier) IN ('max', 'enterprise') THEN 5
  ELSE 1
END;
