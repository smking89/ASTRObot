-- Player marketplace: listings, bids, completed trades and temporary delivery locks.
CREATE TABLE IF NOT EXISTS marketplace_listings (
  id              TEXT PRIMARY KEY,
  guild_id        TEXT NOT NULL,
  seller_id       TEXT NOT NULL,
  kind            TEXT NOT NULL CHECK (kind IN ('item', 'kit', 'role')),
  asset_key       TEXT NOT NULL,
  asset_label     TEXT NOT NULL,
  quantity        INTEGER NOT NULL DEFAULT 1,
  price           INTEGER NOT NULL,
  vip_price       INTEGER,
  mode            TEXT NOT NULL DEFAULT 'buy_now' CHECK (mode IN ('buy_now', 'bid', 'sale')),
  status          TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'sold', 'cancelled', 'expired')),
  high_bidder_id  TEXT,
  high_bid        INTEGER,
  buyer_id        TEXT,
  currency        TEXT NOT NULL,
  fee_percent     REAL NOT NULL DEFAULT 0,
  ends_at         INTEGER,
  created_at      INTEGER NOT NULL,
  sold_at         INTEGER,
  metadata        TEXT
);
CREATE INDEX IF NOT EXISTS idx_market_active ON marketplace_listings (guild_id, status, mode, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_market_seller ON marketplace_listings (guild_id, seller_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS marketplace_bids (
  id              TEXT PRIMARY KEY,
  listing_id      TEXT NOT NULL,
  guild_id        TEXT NOT NULL,
  bidder_id       TEXT NOT NULL,
  amount          INTEGER NOT NULL,
  created_at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_market_bids_listing ON marketplace_bids (listing_id, amount DESC, created_at ASC);

CREATE TABLE IF NOT EXISTS marketplace_sales (
  id              TEXT PRIMARY KEY,
  listing_id      TEXT NOT NULL,
  guild_id        TEXT NOT NULL,
  seller_id       TEXT NOT NULL,
  buyer_id        TEXT NOT NULL,
  kind            TEXT NOT NULL,
  asset_key       TEXT NOT NULL,
  asset_label     TEXT NOT NULL,
  amount          INTEGER NOT NULL,
  fee             INTEGER NOT NULL DEFAULT 0,
  currency        TEXT NOT NULL,
  created_at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_market_sales_guild ON marketplace_sales (guild_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_market_sales_seller ON marketplace_sales (guild_id, seller_id, created_at DESC);

-- Kit/role delivery locks. Listings clear the seller lock and create a fresh
-- buyer lock when the sale completes.
CREATE TABLE IF NOT EXISTS marketplace_locks (
  guild_id        TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  asset_key       TEXT NOT NULL,
  kind            TEXT NOT NULL,
  unlock_at       INTEGER NOT NULL,
  PRIMARY KEY (guild_id, user_id, asset_key)
);

-- Onboarding: join/leave analytics, verification challenges, giveaways,
-- temp voice channels and time-role grants.
CREATE TABLE IF NOT EXISTS onboarding_events (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id        TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  kind            TEXT NOT NULL CHECK (kind IN ('join', 'leave')),
  created_at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_onboarding_events ON onboarding_events (guild_id, kind, created_at DESC);

CREATE TABLE IF NOT EXISTS onboarding_verifications (
  id              TEXT PRIMARY KEY,
  guild_id        TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  channel_id      TEXT,
  message_id      TEXT,
  expires_at      INTEGER NOT NULL,
  verified_at     INTEGER,
  created_at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_onboarding_verify_user ON onboarding_verifications (guild_id, user_id, verified_at);

CREATE TABLE IF NOT EXISTS giveaways (
  id              TEXT PRIMARY KEY,
  guild_id        TEXT NOT NULL,
  channel_id      TEXT NOT NULL,
  message_id      TEXT,
  host_id         TEXT NOT NULL,
  prize           TEXT NOT NULL,
  winners         INTEGER NOT NULL DEFAULT 1,
  winner_ids      TEXT,
  ends_at         INTEGER NOT NULL,
  status          TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'ended', 'cancelled')),
  created_at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_giveaways_due ON giveaways (status, ends_at);

CREATE TABLE IF NOT EXISTS giveaway_entries (
  giveaway_id     TEXT NOT NULL,
  guild_id        TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  created_at      INTEGER NOT NULL,
  PRIMARY KEY (giveaway_id, user_id)
);

CREATE TABLE IF NOT EXISTS temp_channels (
  channel_id      TEXT PRIMARY KEY,
  guild_id        TEXT NOT NULL,
  owner_id        TEXT NOT NULL,
  category_id     TEXT,
  created_at      INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS time_role_grants (
  guild_id        TEXT NOT NULL,
  user_id         TEXT NOT NULL,
  role_id         TEXT NOT NULL,
  granted_at      INTEGER NOT NULL,
  PRIMARY KEY (guild_id, user_id, role_id)
);
