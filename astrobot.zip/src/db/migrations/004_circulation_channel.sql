-- Remembers which channel the last circulation alert went to, so configuring a
-- channel (or pointing it somewhere new) reports the current overage once
-- instead of staying quiet until the next downward re-arm.
ALTER TABLE circulation_state ADD COLUMN channel_id TEXT;
