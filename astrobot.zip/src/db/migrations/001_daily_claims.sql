-- Lifetime daily claims drive the 10/25/50/100 milestone crates. Deriving them
-- from transaction rows loses claims that paid 0 (wallet already at cap), so the
-- count lives on the player row.
ALTER TABLE players ADD COLUMN daily_claims INTEGER NOT NULL DEFAULT 0;

UPDATE players SET daily_claims = (
  SELECT COUNT(*) FROM transactions t
  WHERE t.guild_id = players.guild_id
    AND t.user_id = players.user_id
    AND t.kind = 'daily_streak'
);
