-- Period state and per-player baselines for automatic leaderboard payouts.
CREATE TABLE IF NOT EXISTS leaderboard_period_state (
  guild_id   TEXT NOT NULL,
  period     TEXT NOT NULL,
  started_at INTEGER NOT NULL,
  PRIMARY KEY (guild_id, period)
);

CREATE TABLE IF NOT EXISTS leaderboard_baselines (
  guild_id TEXT NOT NULL,
  period   TEXT NOT NULL,
  metric   TEXT NOT NULL,
  user_id  TEXT NOT NULL,
  value    REAL NOT NULL,
  PRIMARY KEY (guild_id, period, metric, user_id)
);
