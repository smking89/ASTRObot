-- Public entries need a bearer token so the browser can claim bonus tasks for
-- the correct entry without exposing another visitor's email address.
ALTER TABLE giveaway_page_entries ADD COLUMN access_token TEXT;
UPDATE giveaway_page_entries
   SET access_token = lower(hex(randomblob(16)))
 WHERE access_token IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_giveaway_page_entries_token
  ON giveaway_page_entries (access_token);

CREATE TABLE IF NOT EXISTS giveaway_page_bonus_entries (
  entry_id     TEXT NOT NULL,
  giveaway_id  TEXT NOT NULL,
  task_index   INTEGER NOT NULL,
  points       INTEGER NOT NULL,
  claimed_at   INTEGER NOT NULL,
  PRIMARY KEY (entry_id, task_index)
);
CREATE INDEX IF NOT EXISTS idx_giveaway_page_bonus_giveaway
  ON giveaway_page_bonus_entries (giveaway_id, claimed_at DESC);