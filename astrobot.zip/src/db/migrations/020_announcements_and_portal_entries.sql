-- Scheduled announcements: one message, delivered to Discord and/or the game
-- console on a fixed calendar date and clock time, optionally repeating.
CREATE TABLE IF NOT EXISTS announcements (
  id                TEXT PRIMARY KEY,
  guild_id          TEXT NOT NULL,
  name              TEXT NOT NULL,
  message           TEXT NOT NULL,
  channel_id        TEXT,
  in_game           INTEGER NOT NULL DEFAULT 0,
  rcon_message      TEXT,
  schedule          TEXT NOT NULL DEFAULT 'once' CHECK (schedule IN ('once', 'daily', 'weekly', 'interval')),
  run_at            INTEGER NOT NULL,
  interval_seconds  INTEGER,
  weekdays          TEXT,
  enabled           INTEGER NOT NULL DEFAULT 1,
  created_by        TEXT,
  last_run_at       INTEGER,
  next_run_at       INTEGER,
  created_at        INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_announcements_due ON announcements (enabled, next_run_at);
CREATE INDEX IF NOT EXISTS idx_announcements_guild ON announcements (guild_id, created_at DESC);

-- Personal portal entry links. The bot issues a token to one Discord member for
-- one open giveaway; the public portal can exchange it for a recorded entry.
CREATE TABLE IF NOT EXISTS giveaway_entry_tokens (
  token        TEXT PRIMARY KEY,
  guild_id     TEXT NOT NULL,
  user_id      TEXT NOT NULL,
  giveaway_id  TEXT NOT NULL,
  expires_at   INTEGER NOT NULL,
  created_at   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_giveaway_entry_tokens_expiry ON giveaway_entry_tokens (expires_at);
CREATE INDEX IF NOT EXISTS idx_giveaway_entry_tokens_giveaway ON giveaway_entry_tokens (giveaway_id, user_id);
