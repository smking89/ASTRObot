-- Optional restart delay in seconds. NULL means legacy profiles derive the
-- delay from the trailing number in restart_command (for example `restart 300`).
ALTER TABLE wipe_profiles ADD COLUMN restart_delay INTEGER;
