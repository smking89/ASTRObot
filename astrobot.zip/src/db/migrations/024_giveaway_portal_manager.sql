-- Giveaway pages managed from the dashboard. Bot-created giveaways keep
-- username NULL and continue to work exactly as before.
ALTER TABLE giveaways ADD COLUMN username TEXT;
ALTER TABLE giveaways ADD COLUMN description TEXT;
ALTER TABLE giveaways ADD COLUMN link_tree TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS idx_giveaways_username
  ON giveaways (username COLLATE NOCASE)
  WHERE username IS NOT NULL;

-- Public email/gamertag entries for dashboard-managed giveaways. These are
-- kept separate from Discord member entries so the bot's draw remains
-- authoritative for its own giveaways.
CREATE TABLE IF NOT EXISTS giveaway_page_entries (
  id              TEXT PRIMARY KEY,
  giveaway_id     TEXT NOT NULL,
  guild_id        TEXT NOT NULL,
  display_name    TEXT NOT NULL,
  email           TEXT NOT NULL,
  created_at      INTEGER NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_giveaway_page_entries_email
  ON giveaway_page_entries (giveaway_id, email COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS idx_giveaway_page_entries_giveaway
  ON giveaway_page_entries (giveaway_id, created_at DESC);

-- Lightweight event stream for page views, entries and link-page clicks.
CREATE TABLE IF NOT EXISTS giveaway_events (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  giveaway_id     TEXT NOT NULL,
  guild_id        TEXT NOT NULL,
  kind            TEXT NOT NULL,
  path            TEXT,
  referrer        TEXT,
  link_index      INTEGER,
  created_at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_giveaway_events_giveaway
  ON giveaway_events (giveaway_id, kind, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_giveaway_events_daily
  ON giveaway_events (guild_id, created_at DESC);