-- Per-giveaway Quick FAQ entries managed from the admin screen.
ALTER TABLE giveaways ADD COLUMN faq TEXT;
