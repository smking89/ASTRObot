-- Progressive jackpot winner history. The jackpot pool already stores the
-- latest winner; this keeps a durable feed for the public history panel.
CREATE TABLE IF NOT EXISTS jackpot_wins (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id    TEXT NOT NULL,
  user_id     TEXT NOT NULL,
  game        TEXT NOT NULL,
  amount      INTEGER NOT NULL,
  created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_jackpot_wins_guild ON jackpot_wins (guild_id, created_at DESC);
