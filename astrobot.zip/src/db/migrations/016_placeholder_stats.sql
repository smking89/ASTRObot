-- Helios-style kill placeholders need PvP/PvE splits and kill streaks, plus the
-- wallet amount and distance captured at the moment of the kill. Existing kills
-- and deaths predate the split, so they backfill as PvP.
ALTER TABLE players ADD COLUMN pvp_kills INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN pvp_deaths INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN pve_deaths INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN kill_streak INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN best_kill_streak INTEGER NOT NULL DEFAULT 0;

UPDATE players SET pvp_kills = kills, pvp_deaths = deaths WHERE kills > 0 OR deaths > 0;

ALTER TABLE killfeed_events ADD COLUMN stolen INTEGER NOT NULL DEFAULT 0;
ALTER TABLE killfeed_events ADD COLUMN distance REAL;
