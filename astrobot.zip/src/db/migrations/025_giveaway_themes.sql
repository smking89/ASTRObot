-- Per-giveaway branding for dashboard-managed public pages and Linktree pages.
-- Stored as JSON so new theme tokens can be added without another migration.
ALTER TABLE giveaways ADD COLUMN theme TEXT;