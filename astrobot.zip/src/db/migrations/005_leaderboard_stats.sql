-- Stats used by the picture leaderboards. Existing rows start at zero.
ALTER TABLE players ADD COLUMN pve_kills INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN game_wins INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN rival_wins INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN competition_wins INTEGER NOT NULL DEFAULT 0;
