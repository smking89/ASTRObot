-- Store the entrant's chosen region for public giveaway entries.
ALTER TABLE giveaway_page_entries ADD COLUMN region TEXT;
