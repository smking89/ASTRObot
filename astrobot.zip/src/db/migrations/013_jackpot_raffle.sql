-- Three-place jackpot raffle. Ticket sales fund the raffle pool and tickets
-- remain as weighted entries until an administrator draws the winners.
CREATE TABLE IF NOT EXISTS jackpot_raffle (
  guild_id    TEXT PRIMARY KEY,
  balance     INTEGER NOT NULL DEFAULT 0,
  updated_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS jackpot_tickets (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id    TEXT NOT NULL,
  user_id     TEXT NOT NULL,
  tier_id     TEXT NOT NULL,
  tier_label  TEXT NOT NULL,
  entries     INTEGER NOT NULL,
  cost        INTEGER NOT NULL,
  created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_jackpot_tickets_guild ON jackpot_tickets (guild_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_jackpot_tickets_user ON jackpot_tickets (guild_id, user_id);

CREATE TABLE IF NOT EXISTS jackpot_draws (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id         TEXT NOT NULL,
  actor_id         TEXT,
  pool             INTEGER NOT NULL,
  prize_mode       TEXT NOT NULL,
  first_user_id    TEXT,
  first_amount     INTEGER NOT NULL DEFAULT 0,
  second_user_id   TEXT,
  second_amount    INTEGER NOT NULL DEFAULT 0,
  third_user_id    TEXT,
  third_amount     INTEGER NOT NULL DEFAULT 0,
  participants     INTEGER NOT NULL DEFAULT 0,
  entries          INTEGER NOT NULL DEFAULT 0,
  created_at       INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_jackpot_draws_guild ON jackpot_draws (guild_id, created_at DESC);