-- The stock brand moved from the original purple/blue test palette to the
-- red Astro palette used by the dashboard and public site. Only replace the
-- untouched stock values so an operator's custom branding is preserved.
UPDATE bot_branding
SET colors = '{"brand":"#e62127","accent":"#ff4d4d","background":"#07070d","text":"#eef0f8"}',
    updated_at = CAST(strftime('%s', 'now') AS INTEGER) * 1000
WHERE id = 1
  AND colors LIKE '%#8b5cf6%'
  AND colors LIKE '%#38bdf8%';
