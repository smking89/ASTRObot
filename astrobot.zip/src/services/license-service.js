import {
  activateLicense,
  getLicenseById,
  revokeLicense,
  transferLicense,
} from '../db/repositories/licenses.js';
import { getMembership, grantMembership, membershipSeatLimit, revokeMembership } from '../db/repositories/memberships.js';
import { PLAN_CATALOG, normalizePlanId } from '../config/plans.js';
import { syncOwnedGuildPlans } from './plan-service.js';

/**
 * Licenses follow the Discord account. The license's plan becomes the account
 * membership, and the membership's seats are what /plan attaches to servers.
 * Legacy `standard`/`pro` keys map to Pro; `enterprise`/`max` keys map to Max.
 */
export function licensePlanTier(license) {
  const tier = String(license?.tier ?? '').trim().toLowerCase();
  return tier === 'enterprise' || tier === 'max' ? 'max' : 'pro';
}

export function licensePlanLabel(license) {
  return PLAN_CATALOG[licensePlanTier(license)].label;
}

export function licenseServerLimit(license) {
  const explicit = Number(license?.server_limit);
  if (Number.isFinite(explicit) && explicit > 0) return Math.trunc(explicit);
  return PLAN_CATALOG[licensePlanTier(license)].limits.discordServers;
}

function planRank(tier) {
  const id = normalizePlanId(tier);
  return id === 'max' ? 2 : id === 'pro' ? 1 : 0;
}

function activeMembership(userId) {
  const membership = getMembership(userId);
  if (!membership) return null;
  if (membership.expires_at && Number(membership.expires_at) <= Date.now()) return null;
  return membership;
}

function laterExpiry(left, right) {
  if (left === null || right === null) return null;
  if (!left) return right;
  if (!right) return left;
  return Math.max(Number(left), Number(right));
}

/**
 * Grant the license's plan without shortening a better existing membership.
 * A same-tier license can add seats and extend time, but never downgrade.
 */
function applyLicenseEntitlement(license, userId) {
  const incomingTier = licensePlanTier(license);
  const current = activeMembership(userId);
  const currentTier = current ? normalizePlanId(current.tier) : null;

  if (current && planRank(currentTier) > planRank(incomingTier)) {
    return current;
  }

  const sameTier = current && planRank(currentTier) === planRank(incomingTier);
  const expiresAt = sameTier ? laterExpiry(current.expires_at, license.expires_at) : license.expires_at ?? null;
  const serverLimit = sameTier
    ? Math.max(licenseServerLimit(license), membershipSeatLimit(current))
    : licenseServerLimit(license);

  const membership = grantMembership({
    userId,
    tier: incomingTier,
    grantedBy: `license:${license.id}`,
    expiresAt,
    serverLimit,
    // A license sets its own term; it does not stack the license duration on
    // top of an unrelated paid membership that happens to use the same tier.
    renew: false,
  });

  syncOwnedGuildPlans({
    ownerId: userId,
    tier: membership.tier,
    expiresAt: membership.expires_at,
    seatLimit: membershipSeatLimit(membership),
  });
  return membership;
}

function releaseLicenseEntitlement(license, userId) {
  if (!userId) return;
  const membership = getMembership(userId);
  if (membership?.granted_by !== `license:${license.id}`) return;

  revokeMembership(userId);
  syncOwnedGuildPlans({ ownerId: userId, tier: 'basic', expiresAt: null, seatLimit: 0 });
}

export function activateUserLicense({ key, userId }) {
  const license = activateLicense({ key, ownerId: userId });
  applyLicenseEntitlement(license, userId);
  return getLicenseById(license.id);
}

export function transferUserLicense({ licenseId, newOwnerId, actorId }) {
  const before = getLicenseById(licenseId);
  if (!before) throw new Error('License not found.');
  if (String(before.owner_id) === String(newOwnerId)) {
    throw new Error('That license already belongs to this account.');
  }

  const license = transferLicense({ licenseId, newOwnerId, actorId });
  releaseLicenseEntitlement(before, before.owner_id);
  applyLicenseEntitlement(license, newOwnerId);
  return getLicenseById(license.id);
}

export function revokeUserLicense({ licenseId, actorId }) {
  const before = getLicenseById(licenseId);
  if (!before) throw new Error('License not found.');
  const license = revokeLicense(licenseId, actorId);
  releaseLicenseEntitlement(before, before.owner_id);
  return license;
}
