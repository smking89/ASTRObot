import { getGuild, getGuildSettings, saveGuildSettings } from '../db/repositories/guilds.js';
import { listTeams } from '../db/repositories/teams.js';
import { listServers } from '../db/repositories/servers.js';
import { ValidationError } from '../core/errors.js';

/**
 * Settings backup. Exports guild settings plus non-secret structure metadata
 * (teams, connected server labels). RCON passwords are deliberately excluded.
 */
export function exportGuild(guildId) {
  const guild = getGuild(guildId);
  const settings = getGuildSettings(guildId);

  return {
    format: 'astrobot-config',
    version: 1,
    exportedAt: new Date().toISOString(),
    guild: { id: guildId, name: guild?.name ?? null, plan: guild?.plan ?? 'free' },
    settings,
    structure: {
      teams: listTeams(guildId, 100).map((team) => ({ name: team.name, tag: team.tag, owner_id: team.owner_id })),
      servers: listServers(guildId).map((server) => ({ label: server.label, host: server.host, port: server.port })),
    },
  };
}

export function importGuild(guildId, payload, { actorId = null } = {}) {
  let parsed = payload;

  if (typeof payload === 'string') {
    try {
      parsed = JSON.parse(payload);
    } catch {
      throw new ValidationError('Backup is not valid JSON.');
    }
  }

  if (!parsed || parsed.format !== 'astrobot-config' || typeof parsed.settings !== 'object') {
    throw new ValidationError('That file is not an AstroBot configuration export.');
  }

  const settings = saveGuildSettings(guildId, parsed.settings, { actorId });
  return { settings, guild: parsed.guild ?? null, exportedAt: parsed.exportedAt ?? null };
}
