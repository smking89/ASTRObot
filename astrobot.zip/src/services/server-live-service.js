import { getDb } from '../db/index.js';
import { listEnabledServers } from '../db/repositories/servers.js';

/** Snapshots older than this are not counted in the live player/queue line. */
export const LIVE_STATS_STALE_MS = 120_000;

/** Snapshot written by the bot and read by both the stats channels and dashboard. */
export function recordLiveStats({ serverId, guildId, players = 0, maxPlayers = null, queue = 0, updatedAt = Date.now() }) {
  getDb()
    .prepare(
      `INSERT INTO server_live_stats (server_id, guild_id, players, max_players, queue, updated_at)
       VALUES (?, ?, ?, ?, ?, ?)
       ON CONFLICT(server_id) DO UPDATE SET
         guild_id = excluded.guild_id,
         players = excluded.players,
         max_players = excluded.max_players,
         queue = excluded.queue,
         updated_at = excluded.updated_at`,
    )
    .run(serverId, guildId, players, maxPlayers, queue, updatedAt);
}

export function liveStats(guildId = null) {
  try {
    return guildId
      ? getDb().prepare('SELECT * FROM server_live_stats WHERE guild_id = ?').all(guildId)
      : getDb().prepare('SELECT * FROM server_live_stats').all();
  } catch {
    // The dashboard can start before the bot has applied the migration.
    return [];
  }
}

/**
 * Database-backed aggregate used by the live player/queue lines. Stale server
 * rows are ignored so a disconnected server cannot leave a phantom population
 * in the global count forever.
 */
export function liveTotals({ guildId = null, now = Date.now(), staleMs = LIVE_STATS_STALE_MS } = {}) {
  try {
    const cutoff = now - Math.max(1, Number(staleMs) || LIVE_STATS_STALE_MS);
    const row = guildId
      ? getDb()
          .prepare(
            `SELECT COUNT(*) AS servers,
                    COALESCE(SUM(players), 0) AS players,
                    COALESCE(SUM(queue), 0) AS queue
               FROM server_live_stats WHERE guild_id = ? AND updated_at >= ?`,
          )
          .get(String(guildId), cutoff)
      : getDb()
          .prepare(
            `SELECT COUNT(*) AS servers,
                    COALESCE(SUM(players), 0) AS players,
                    COALESCE(SUM(queue), 0) AS queue
               FROM server_live_stats WHERE updated_at >= ?`,
          )
          .get(cutoff);

    return {
      servers: Number(row?.servers) || 0,
      players: Number(row?.players) || 0,
      queue: Number(row?.queue) || 0,
    };
  } catch {
    return { servers: 0, players: 0, queue: 0 };
  }
}

/**
 * Copies the latest console RCON `serverinfo` counts into the database. Servers
 * that have not answered yet are skipped so a missing poll never zeroes a
 * previously known population.
 */
export function syncLiveStats(rconManager) {
  for (const server of listEnabledServers()) {
    const info = rconManager?.serverInfo?.(server.id);
    if (!info) continue;

    recordLiveStats({
      serverId: server.id,
      guildId: server.guild_id,
      players: Number(info.players) || 0,
      maxPlayers: info.maxPlayers ?? null,
      queue: Number(info.queue) || 0,
    });
  }
}
