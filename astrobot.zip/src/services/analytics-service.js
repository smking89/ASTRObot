/** Pure retention calculations over player session rows. */

const DAY = 86_400_000;

export function summarizeSessions(sessions, now = Date.now(), days = 28) {
  const start = now - days * DAY;
  const rows = (sessions ?? []).filter((row) => Number(row.started_at) >= start);
  const identity = (row) => row.user_id || String(row.gamertag ?? '').toLowerCase();

  const weekAgo = now - 7 * DAY;
  const twoWeeksAgo = now - 14 * DAY;
  const current = new Set();
  const previous = new Set();

  for (const row of rows) {
    const at = Number(row.started_at);
    if (at >= weekAgo) current.add(identity(row));
    else if (at >= twoWeeksAgo) previous.add(identity(row));
  }

  const returning = [...current].filter((id) => previous.has(id)).length;
  const durations = rows.map((row) => Number(row.duration_seconds) || 0).filter((value) => value > 0);
  const averageDurationSeconds = durations.length
    ? Math.round(durations.reduce((total, value) => total + value, 0) / durations.length)
    : 0;

  const daily = new Map();
  for (let offset = days - 1; offset >= 0; offset -= 1) {
    const day = new Date(now - offset * DAY).toISOString().slice(0, 10);
    daily.set(day, { day, sessions: 0, players: new Set() });
  }

  const heatmap = Array.from({ length: 7 }, () => Array(24).fill(0));
  for (const row of rows) {
    const date = new Date(Number(row.started_at));
    const key = date.toISOString().slice(0, 10);
    const bucket = daily.get(key);
    if (bucket) {
      bucket.sessions += 1;
      bucket.players.add(identity(row));
    }
    heatmap[date.getUTCDay()][date.getUTCHours()] += 1;
  }

  return {
    totalSessions: rows.length,
    uniquePlayers: new Set(rows.map(identity)).size,
    averageDurationSeconds,
    currentWeekPlayers: current.size,
    previousWeekPlayers: previous.size,
    returningPlayers: returning,
    newPlayers: Math.max(0, current.size - returning),
    retentionPercent: previous.size ? Math.round((returning / previous.size) * 100) : 0,
    daily: [...daily.values()].map((entry) => ({
      day: entry.day,
      sessions: entry.sessions,
      players: entry.players.size,
    })),
    heatmap,
  };
}

/** Peak hour from a 7x24 session heatmap. */
export function peakHour(heatmap) {
  let best = { day: 0, hour: 0, sessions: 0 };
  (heatmap ?? []).forEach((row, day) => {
    row.forEach((count, hour) => {
      if (count > best.sessions) best = { day, hour, sessions: count };
    });
  });
  return best;
}
