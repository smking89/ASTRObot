import { env } from '../config/env.js';
import { createLogger } from '../core/logger.js';
import { RconManager } from './rcon/manager.js';
import { startScheduler } from './scheduler-service.js';
import { startPlaytimeLoop } from './playtime-service.js';
import { startStatsChannelsLoop } from './stats-channels.js';
import { startQueueWatchdog } from './queue-watchdog.js';
import { startTip4ServWebhook } from './tip4serv-service.js';
import { sweepChallenges } from './games/challenge.js';
import { runShopMaintenance } from './shop-maintenance.js';
import { checkAllCirculation } from './circulation-service.js';
import { announceServerOnline, tickWipes } from './wipe-service.js';
import { refreshLeaderboards } from './leaderboard-feed.js';
import { runLeaderboardPayouts } from './leaderboard-payouts.js';
import { startGlobalKillfeedLoop } from './global-killfeed-service.js';
import { startCrashLoop } from './crash-loop.js';
import { recordStatus } from '../db/repositories/status.js';
import { getDb } from '../db/index.js';
import { invalidateSettingsCache } from '../db/repositories/guilds.js';
import { startOnboardingLoop } from './onboarding-service.js';
import { settleExpiredAuctions } from './marketplace-service.js';
import { closeExpiredPolls } from './poll-service.js';
import { sweepAnnouncementRetries } from './announcement-service.js';

const log = createLogger('jobs');

/**
 * Starts every background loop the bot needs. Returns a controller so index.js
 * can shut everything down cleanly on SIGINT/SIGTERM.
 */
export function startJobs(client) {
  if (!env.runtime.enableBackgroundJobs) {
    log.info('Background jobs disabled by ENABLE_BACKGROUND_JOBS.');
    return { rconManager: null, scheduler: null, stop: async () => {} };
  }

  const rconManager = new RconManager({ client }).start();

  rconManager.on('connected', (connection) => {
    recordStatus({ guildId: connection.guildId, serverId: connection.serverId, status: 'online', players: rconManager.onlineCount(connection.serverId) });
    announceServerOnline({ connection, client }).catch((error) =>
      log.warn(`Back-online wipe announcement failed for ${connection.serverId}`, error),
    );
  });
  rconManager.on('disconnected', (connection) => {
    recordStatus({ guildId: connection.guildId, serverId: connection.serverId, status: 'offline', players: 0 });
  });
  const scheduler = startScheduler(client, { rconManager });
  const stopGlobalKillfeed = startGlobalKillfeedLoop({ client, intervalMs: 5_000 });
  const stopCrashLoop = startCrashLoop();
  const stopPlaytime = startPlaytimeLoop(client);
  const stopStats = startStatsChannelsLoop(client, { rconManager });
  const stopQueueWatchdog = startQueueWatchdog(client, { rconManager });
  const webhook = startTip4ServWebhook({ client, rconManager });
  const stopOnboarding = startOnboardingLoop(client, { rconManager });

  const marketLoop = setInterval(() => {
    settleExpiredAuctions(client).catch((error) => log.warn('Marketplace auction settlement failed', error));
  }, 30_000);
  marketLoop.unref?.();

  const challengeSweeper = setInterval(() => {
    const expired = sweepChallenges();
    if (expired > 0) log.info(`Refunded ${expired} expired challenge(s).`);
  }, 60_000);
  challengeSweeper.unref?.();

  // Poll automation: expire polls on time, refresh their message and post the
  // final tally without waiting for an admin to press End.
  const pollSweeper = setInterval(() => {
    closeExpiredPolls(client).catch((error) => log.warn('Poll automation failed', error));
  }, 60_000);
  pollSweeper.unref?.();

  const firstPollSweep = setTimeout(() => {
    closeExpiredPolls(client).catch((error) => log.warn('Poll automation failed', error));
  }, 15_000);
  firstPollSweep.unref?.();

  // Announcement delivery retries: only the Discord/RCON side that failed is
  // retried, with the backoff stored on the delivery row.
  const deliverySweeper = setInterval(() => {
    sweepAnnouncementRetries({ client, rconManager }).catch((error) => log.warn('Announcement retry failed', error));
  }, 30_000);
  deliverySweeper.unref?.();

  const firstDeliverySweep = setTimeout(() => {
    sweepAnnouncementRetries({ client, rconManager }).catch((error) => log.warn('Announcement retry failed', error));
  }, 20_000);
  firstDeliverySweep.unref?.();

  const shopSweep = setInterval(() => {
    runShopMaintenance({ client }).catch((error) => log.warn('Shop maintenance failed', error));
  }, 6 * 3_600_000);
  shopSweep.unref?.();

  // First sweep runs shortly after boot so retention and stalled timers are
  // handled without waiting six hours.
  const firstShopSweep = setTimeout(() => {
    runShopMaintenance({ client }).catch((error) => log.warn('Shop maintenance failed', error));
  }, 60_000);
  firstShopSweep.unref?.();

  // Economy volume alerts: a cheap aggregate per guild, checked every two
  // minutes so a mint or payout spree reaches staff without waiting on a sweep.
  const circulationLoop = setInterval(() => {
    checkAllCirculation({ client }).catch((error) => log.warn('Circulation check failed', error));
  }, 2 * 60_000);
  circulationLoop.unref?.();

  const firstCirculationCheck = setTimeout(() => {
    checkAllCirculation({ client }).catch((error) => log.warn('Circulation check failed', error));
  }, 45_000);
  firstCirculationCheck.unref?.();

  const wipeLoop = setInterval(() => {
    tickWipes({ client, rconManager }).catch((error) => log.warn('Wipe tick failed', error));
  }, 60_000);
  wipeLoop.unref?.();

  // Keep the picture leaderboard in each guild's leaderboard channel current.
  const leaderboardLoop = setInterval(() => {
    refreshLeaderboards({ client }).catch((error) => log.warn('Leaderboard refresh failed', error));
  }, 60_000);
  leaderboardLoop.unref?.();

  const firstLeaderboardRefresh = setTimeout(() => {
    refreshLeaderboards({ client }).catch((error) => log.warn('Leaderboard refresh failed', error));
  }, 20_000);
  firstLeaderboardRefresh.unref?.();

  // Prize periods: start baselines on first sight, settle once a period elapses.
  const payoutLoop = setInterval(() => {
    runLeaderboardPayouts({ client }).catch((error) => log.warn('Leaderboard payouts failed', error));
  }, 60_000);
  payoutLoop.unref?.();

  const firstPayoutTick = setTimeout(() => {
    runLeaderboardPayouts({ client }).catch((error) => log.warn('Leaderboard payouts failed', error));
  }, 30_000);
  firstPayoutTick.unref?.();

  const firstWipeTick = setTimeout(() => {
    tickWipes({ client, rconManager }).catch((error) => log.warn('Wipe tick failed', error));
  }, 20_000);
  firstWipeTick.unref?.();

  // Snapshot connected player counts so the status dashboard has live samples
  // even when no connect/disconnect event fires.
  const statusLoop = setInterval(() => {
    for (const connection of rconManager.connections.values()) {
      if (!connection.connected) continue;
      recordStatus({
        guildId: connection.guildId,
        serverId: connection.serverId,
        status: 'online',
        players: rconManager.onlineCount(connection.serverId),
      });
    }
  }, 5 * 60_000);
  statusLoop.unref?.();

  // The dashboard writes guild_settings directly. Reload the in-memory settings
  // cache when the newest write timestamp changes so edits apply without a restart.
  let settingsStamp = '';
  const settingsWatch = setInterval(() => {
    const rows = getDb()
      .prepare('SELECT guild_id, MAX(updated_at) AS stamp FROM guild_settings GROUP BY guild_id')
      .all();
    const next = rows.map((row) => `${row.guild_id}:${row.stamp}`).join('|');
    if (settingsStamp && next !== settingsStamp) invalidateSettingsCache();
    settingsStamp = next;
  }, 30_000);
  settingsWatch.unref?.();

  log.info('Background jobs running.');

  return {
    rconManager,
    scheduler,
    stop: async () => {
      clearInterval(challengeSweeper);
      clearInterval(pollSweeper);
      clearTimeout(firstPollSweep);
      clearInterval(shopSweep);
      clearTimeout(firstShopSweep);
      clearInterval(wipeLoop);
      clearTimeout(firstWipeTick);
      clearInterval(leaderboardLoop);
      clearTimeout(firstLeaderboardRefresh);
      clearInterval(circulationLoop);
      clearTimeout(firstCirculationCheck);
      clearInterval(statusLoop);
      clearInterval(settingsWatch);
      clearInterval(marketLoop);
      stopOnboarding();
      stopPlaytime();
      stopStats();
      stopQueueWatchdog();
      stopGlobalKillfeed();
      stopCrashLoop();
      scheduler?.stop();
      rconManager?.shutdown();
      await webhook?.close();
      log.info('Background jobs stopped.');
    },
  };
}
