import { getGuildSettings, saveGuildSettings } from '../db/repositories/guilds.js';

/** The four prize cycles a server can run per leaderboard. */
export const PRIZE_PERIODS = Object.freeze([
  { id: 'daily', label: 'Daily' },
  { id: 'weekly', label: 'Weekly' },
  { id: 'monthly', label: 'Monthly' },
  { id: 'yearly', label: 'Yearly' },
]);

const PERIOD_IDS = new Set(PRIZE_PERIODS.map((entry) => entry.id));

/** Always returns three non-negative integers: [1st, 2nd, 3rd]. */
export function normalizePrizeSet(value) {
  const list = Array.isArray(value) ? value : [];
  return [0, 1, 2].map((index) => Math.max(0, Math.trunc(Number(list[index]) || 0)));
}

export function periodLabel(period) {
  return PRIZE_PERIODS.find((entry) => entry.id === period)?.label ?? 'Weekly';
}

/** The period the boards advertise; never trusts an unknown stored value. */
export function displayPeriodFor(guildId) {
  const settings = getGuildSettings(guildId).leaderboardPrizes ?? {};
  const period = String(settings.displayPeriod ?? '').toLowerCase();
  return PERIOD_IDS.has(period) ? period : 'weekly';
}

export function prizesFor(guildId, period, metric) {
  const settings = getGuildSettings(guildId).leaderboardPrizes ?? {};
  if (settings.enabled === false) return [0, 0, 0];
  return normalizePrizeSet(settings.periods?.[period]?.[metric]);
}

/** Stores one board's three prizes for one period. */
export function savePrizes(guildId, { period, metric, amounts, actorId = null }) {
  if (!PERIOD_IDS.has(period)) throw new Error(`Unknown prize period: ${period}`);

  const settings = getGuildSettings(guildId);
  const config = settings.leaderboardPrizes ?? {};
  const periods = { ...(config.periods ?? {}) };

  periods[period] = {
    ...(periods[period] ?? {}),
    [metric]: normalizePrizeSet(amounts),
  };

  saveGuildSettings(guildId, { leaderboardPrizes: { ...config, periods } }, { actorId });
  return periods[period][metric];
}

/** Prize table for a period: [{ metric, label, amounts }]. */
export function prizeTable(guildId, period, metrics) {
  return metrics.map((entry) => ({
    metric: entry.id,
    label: entry.label,
    amounts: prizesFor(guildId, period, entry.id),
  }));
}
