import { createCanvas, GlobalFonts, loadImage } from '@napi-rs/canvas';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
import { handValue } from './games/cards.js';

/** Blackjack table rendered from the real 52-card asset pack. */

const WIDTH = 1200;
const HEIGHT = 720;
const CARD_ROOT = fileURLToPath(new URL('../../assets/cards/playing/', import.meta.url));
const SUIT_DIR = Object.freeze({ spades: 'spade', hearts: 'heart', diamonds: 'diamond', clubs: 'club' });
const SUIT_FILE = Object.freeze({ spades: 'Spades', hearts: 'Hearts', diamonds: 'Diamonds', clubs: 'Clubs' });

/** Real card-back artwork shipped with the bot. */
export const CARD_BACK_FILES = Object.freeze({
  classic: 'cardBackRed.png',
  astro: 'cardBackBlue.png',
  nebula: 'cardBackGreen.png',
  // Legacy preference keys keep their old artwork.
  carbon: 'cardBackRed.png',
  custom: 'cardBackRed.png',
});

/** A deck's back also picks the matching table artwork. */
export const TABLE_FILES = Object.freeze({
  classic: 'table_red.png',
  astro: 'table_blue.png',
  nebula: 'table_green.png',
  carbon: 'table_red.png',
  custom: 'table_blue.png',
});

/** Absolute path to a card-back PNG for Blackjack, UNO and the panel preview. */
export function cardBackPath(key) {
  return join(CARD_ROOT, 'card back', CARD_BACK_FILES[key] ?? CARD_BACK_FILES.classic);
}

/** Absolute path to the table artwork paired with a deck. */
export function tablePath(key) {
  return fileURLToPath(new URL(`../../assets/cards/${TABLE_FILES[key] ?? TABLE_FILES.classic}`, import.meta.url));
}

const imageCache = new Map();
function cachedImage(path) {
  if (!imageCache.has(path)) imageCache.set(path, loadImage(path).catch(() => null));
  return imageCache.get(path);
}

let fontsReady = false;
function prepareFonts() {
  if (fontsReady) return;
  fontsReady = true;
  try {
    GlobalFonts.registerFromPath('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 'CardSans');
    GlobalFonts.registerFromPath('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 'CardSansBold');
  } catch {
    // System fonts are fine.
  }
}

const fontFamily = (bold) => {
  const wanted = bold ? 'CardSansBold' : 'CardSans';
  return GlobalFonts.families?.some((entry) => entry.family === wanted) ? wanted : 'sans-serif';
};

function roundRect(ctx, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + width, y, x + width, y + height, r);
  ctx.arcTo(x + width, y + height, x, y + height, r);
  ctx.arcTo(x, y + height, x, y, r);
  ctx.arcTo(x, y, x + width, y, r);
  ctx.closePath();
}

function cardPath(card) {
  const suitDir = SUIT_DIR[card.suit];
  const suitFile = SUIT_FILE[card.suit];
  if (!suitDir || !suitFile) return null;
  return join(CARD_ROOT, suitDir, `card${suitFile}_${card.rank}.png`);
}

function drawCard(ctx, image, x, y, width, height) {
  ctx.save();
  ctx.shadowColor = 'rgba(0, 0, 0, 0.42)';
  ctx.shadowBlur = 16;
  ctx.shadowOffsetY = 6;
  if (image) {
    ctx.drawImage(image, x, y, width, height);
  } else {
    ctx.fillStyle = '#ffffff';
    roundRect(ctx, x, y, width, height, width * 0.08);
    ctx.fill();
  }
  ctx.restore();
}

async function drawHand(ctx, cards, { centerX, y, hiddenIndex = null, backImage }) {
  const cardWidth = 116;
  const cardHeight = 184;
  const step = Math.min(126, (960 - cardWidth) / Math.max(1, cards.length - 1));
  const total = cardWidth + step * Math.max(0, cards.length - 1);
  const startX = centerX - total / 2;
  const images = await Promise.all(
    cards.map((card, index) => (index === hiddenIndex ? backImage : cachedImage(cardPath(card) ?? ''))),
  );

  images.forEach((image, index) => {
    drawCard(ctx, image, startX + index * step, y, cardWidth, cardHeight);
  });
}

export async function renderBlackjackImage(state) {
  prepareFonts();

  const table = await loadImage(tablePath(state.deckStyle)).catch(() => null);
  const backImage = await cachedImage(cardBackPath(state.deckStyle));

  const canvas = createCanvas(WIDTH, HEIGHT);
  const ctx = canvas.getContext('2d');

  if (table) {
    const scale = Math.max(WIDTH / table.width, HEIGHT / table.height);
    const drawWidth = table.width * scale;
    const drawHeight = table.height * scale;
    ctx.drawImage(table, (WIDTH - drawWidth) / 2, (HEIGHT - drawHeight) / 2, drawWidth, drawHeight);
  }
  ctx.fillStyle = 'rgba(4, 13, 24, 0.76)';
  ctx.fillRect(0, 0, WIDTH, HEIGHT);

  const glow = ctx.createRadialGradient(WIDTH * 0.5, HEIGHT * 0.46, 20, WIDTH * 0.5, HEIGHT * 0.46, WIDTH * 0.65);
  glow.addColorStop(0, 'rgba(35, 120, 201, 0.22)');
  glow.addColorStop(1, 'rgba(5, 20, 28, 0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, WIDTH, HEIGHT);

  ctx.fillStyle = '#f6fbff';
  ctx.font = `900 34px ${fontFamily(true)}`;
  ctx.fillText('BLACKJACK', 44, 54);
  ctx.fillStyle = '#7f9bbd';
  ctx.font = `600 14px ${fontFamily(false)}`;
  ctx.fillText('ASTRO CASINO', 300, 51);

  const player = handValue(state.player);
  const dealer = handValue(state.dealer);
  const hiddenIndex = state.status === 'player' ? 1 : null;

  await drawHand(ctx, state.dealer, { centerX: WIDTH / 2, y: 146, hiddenIndex, backImage });
  await drawHand(ctx, state.player, { centerX: WIDTH / 2, y: 426, backImage });

  ctx.fillStyle = '#ffffff';
  ctx.font = `700 14px ${fontFamily(true)}`;
  ctx.fillText('DEALER', 44, 112);
  ctx.fillStyle = '#b7c9de';
  ctx.font = `600 14px ${fontFamily(false)}`;
  ctx.fillText(
    state.status === 'player' ? `${dealer.total - state.dealer[1].value}+` : String(dealer.total),
    44,
    134,
  );

  ctx.fillStyle = '#ffffff';
  ctx.font = `700 14px ${fontFamily(true)}`;
  ctx.fillText('YOUR HAND', 44, 400);
  ctx.fillStyle = '#b7c9de';
  ctx.font = `600 14px ${fontFamily(false)}`;
  ctx.fillText(`${player.total}${player.soft ? ' soft' : ''}`, 44, 422);

  const result =
    state.status === 'player'
      ? 'Hit or stand?'
      : state.payout > state.wager
        ? `${state.message ?? 'You win.'} · paid ${state.payout}`
        : state.payout === state.wager
          ? `${state.message ?? 'Push.'} · stake returned`
          : state.payout > 0
            ? `${state.message ?? 'Hand complete.'} · returned ${state.payout}`
            : `${state.message ?? 'Dealer wins.'} · lost ${state.wager}`;

  ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
  roundRect(ctx, 42, 652, WIDTH - 84, 38, 10);
  ctx.fill();
  ctx.fillStyle = state.status === 'ended' && state.payout > state.wager ? '#7df0b2' : '#d7e5f6';
  ctx.font = `600 15px ${fontFamily(false)}`;
  ctx.fillText(result, 62, 677);

  ctx.textAlign = 'right';
  ctx.fillStyle = '#ffffff';
  ctx.font = `700 14px ${fontFamily(true)}`;
  ctx.fillText(`Wager ${state.wager}`, WIDTH - 62, 677);
  ctx.textAlign = 'left';

  return canvas.toBuffer('image/png');
}
