import { ButtonStyle, ChannelType } from 'discord.js';
import { button, customId, row } from '../ui/components.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { normalizeStructureName } from './template-builder.js';
import { hubPayload, staffHubPayload } from '../panels/hub.js';
import { supportPayload } from '../panels/support.js';

/**
 * Builds and posts the interactive panels a template wants in place.
 *
 * Every panel is a static entry card with a button that opens the real panel
 * through the shared `openpanel` component, so the buttons keep working after
 * a restart. Panels are idempotent: each embed carries a footer marker, so
 * re-applying a template repairs a missing panel without stacking duplicates.
 */

const open = (panelId, label, emoji) =>
  button({ id: customId('openpanel', panelId), label, emoji, style: ButtonStyle.Success });

// Older layouts call the ticket panel `tickets`; the deployed panel is the same.
const PANEL_ALIASES = Object.freeze({ tickets: 'support' });
const canonicalPanelType = (type) => PANEL_ALIASES[String(type ?? '').toLowerCase()] ?? String(type ?? '').toLowerCase();

export function featuresPayload() {
  return {
    embeds: [
      buildEmbed({
        title: '✨ AstroBot Features',
        color: COLORS.brand,
        description:
          'Every AstroBot system in one place. Use `/commands` to see what your roles unlock, or open a panel with the button below.',
        fields: [
          { name: '💰 Economy & marketplace', value: 'Wallets, banks, shops, kits, auctions, player trading, marketplace fees and Astro Pro pricing tiers.', inline: false },
          { name: '🎁 Giveaways, pages & polls', value: 'Button-entry giveaways with automatic draws, dashboard-managed public pages on custom username subdomains, Linktree-style link pages, per-page themes, drag-and-drop public task editors with Kick, TikTok, Twitch, Discord, X, YouTube and more, server-backed task claims, public + Discord CSV exports, task-claim analytics with CSV export, DNS/TLS/Host check history, acknowledgeable failures, optional Discord webhook alerts with delivery-test history, view/entry/conversion analytics, email + gamertag/PSN/Steam entrants with region tracking included in the draw, and durable polls.', inline: false },
          { name: '📊 Poll intelligence', value: 'Basic totals and advanced voter profiles: Xbox Gamertag / PSN ID, Astro Score rival rating, clan tag, team tag and clan rank.', inline: false },
          { name: '🎮 Games & progression', value: 'Solo casino games, 1v1 duels, jackpots, battle pass, daily streaks, badges, bounties, leaderboards and referrals.', inline: false },
          { name: '🛡️ Teams & rivals', value: 'Clans, team tags, member ranks, rival wins, team wars, ORP zones and shared clan identity.', inline: false },
          { name: '👋 Onboarding & community', value: 'Welcomer, auto roles, borderwall verification, free roles, reaction roles, temp channels, time roles and join/leave analytics.', inline: false },
          { name: '🖥️ Server operations', value: 'RCON servers, live status, wipe scripts, killfeed, raid alerts, player queue, staff tickets, moderation and backups.', inline: false },
          { name: '🧱 Templates & control panels', value: 'Official layouts, a full template builder, one-click panel deployment and a staff hub for every admin tool.', inline: false },
          { name: '🎨 White-label branding', value: 'Backup-first brand controls from `/white-label` or the dashboard, with a live preview, transparent favicon and wordmark uploads, reusable asset library with ZIP export, reset-to-default and dashboard-wide application.', inline: false },
          { name: '⭐ Astro Pro portal', value: 'Subscribers get a customizable giveaway portal using the Astro palette, with branded pages, prizes, tasks and entry tracking.', inline: false },
        ],
        footer: 'AstroBot panel · astro features',
      }),
    ],
    components: [row(button({ id: customId('openpanel', 'hub'), label: 'Open player hub', emoji: '✨', style: ButtonStyle.Success }))],
  };
}

const FEATURE_CATALOGUE_REQUIREMENTS = Object.freeze([
  { label: 'Giveaways and task editor', tokens: [/giveaway/i, /drag-and-drop/i, /Kick/i, /TikTok/i, /Twitch/i, /Discord/i, /YouTube/i] },
  { label: 'Task analytics', tokens: [/task-claim analytics/i, /CSV export/i] },
  { label: 'Domain operations', tokens: [/DNS\/TLS\/Host check history/i, /acknowledgeable/i, /webhook/i, /delivery-test history/i] },
  { label: 'White-label branding', tokens: [/white-label/i, /transparent favicon/i, /asset library/i, /ZIP export/i] },
  { label: 'Polls', tokens: [/polls/i] },
  { label: 'Economy', tokens: [/economy/i] },
  { label: 'Server operations', tokens: [/RCON/i] },
  { label: 'Templates', tokens: [/template/i] },
  { label: 'Astro Pro', tokens: [/Astro Pro/i] },
  { label: 'Command discovery', tokens: [/\/commands/] },
]);

/**
 * Keeps the advertised feature catalogue honest as the product changes. The
 * check runs in `npm run check`, so a renamed feature or dropped capability
 * fails validation instead of silently disappearing from `/features`.
 */
export function featureCatalogueIssues() {
  const payload = featuresPayload();
  const embed = payload.embeds?.[0]?.data ?? payload.embeds?.[0] ?? {};
  const fields = Array.isArray(embed.fields) ? embed.fields : [];
  const text = [`${embed.description ?? ''}`, ...fields.map((field) => `${field.name}\n${field.value}`)].join('\n');
  const issues = [];

  if (fields.length < 8) issues.push(`Feature catalogue has only ${fields.length} fields.`);
  if (fields.length > 25) issues.push(`Feature catalogue has ${fields.length}/25 fields.`);
  if (new Set(fields.map((field) => field.name)).size !== fields.length) issues.push('Feature catalogue has duplicate field names.');
  for (const field of fields) {
    if (!String(field.name ?? '').trim() || !String(field.value ?? '').trim()) issues.push('Feature catalogue has an empty field.');
    if (String(field.value ?? '').length > 1024) issues.push(`Feature catalogue field "${field.name}" exceeds 1024 characters.`);
  }

  const total = fields.reduce((sum, field) => sum + String(field.value ?? '').length, 0);
  if (total > 6000) issues.push(`Feature catalogue body is ${total}/6000 characters.`);

  for (const requirement of FEATURE_CATALOGUE_REQUIREMENTS) {
    if (!requirement.tokens.every((token) => token.test(text))) {
      issues.push(`Feature catalogue is missing the ${requirement.label} capability.`);
    }
  }
  return issues;
}

export const PANEL_DEFINITIONS = Object.freeze({
  // The hub is the front door: dropdowns for every player and staff panel, so
  // nobody has to remember slash commands.
  hub: {
    marker: 'AstroBot panel · hub',
    payload: () => hubPayload(),
  },
  support: {
    // The ticket intake uses its own privacy footer instead of the generic
    // panel footer; match it so an existing card is never duplicated.
    marker: 'Only you and ASTRO staff can see your ticket.',
    payload: () => supportPayload(),
  },
  // The staff master panel is posted in the staff area, never with the players.
  'staff-hub': {
    marker: 'AstroBot panel · staff hub',
    payload: () => staffHubPayload(),
  },
  shop: {
    marker: 'AstroBot panel · shop',
    payload: () => ({
      embeds: [
        buildEmbed({
          title: '🛒 Server Shop',
          color: COLORS.brand,
          description: 'Browse kits, items and coin packs. Press **Open shop** to see live stock and prices.',
          footer: 'AstroBot panel · shop',
        }),
      ],
      components: [row(button({ id: customId('shop', 'open'), label: 'Open shop', emoji: '🛒', style: ButtonStyle.Success }))],
    }),
  },
  lfg: {
    marker: 'AstroBot panel · lfg',
    payload: () => ({
      embeds: [
        buildEmbed({
          title: '🤝 Looking for Group',
          color: COLORS.brand,
          description: 'Find teammates for your next wipe. Press **Browse listings** to join a squad or create your own.',
          footer: 'AstroBot panel · lfg',
        }),
      ],
      components: [row(button({ id: customId('lfg', 'browse'), label: 'Browse listings', emoji: '🔎', style: ButtonStyle.Success }))],
    }),
  },
  games: {
    marker: 'AstroBot panel · games',
    revision: '3',
    payload: () => ({
      embeds: [
        buildEmbed({
          title: '🎮 Games & Casino',
          color: COLORS.brand,
          description:
            'Pick from the full game catalogue and open a wager prompt in one step. Solo games include Blackjack, UNO, Dice, Treasure Slots, Spin Wheel, Tower, Mines, Crash, Plinko, Roulette and four themed scratch cards; 1v1 challenges are available inside the Games panel.',
          fields: [
            { name: 'Solo games', value: 'Blackjack · UNO · Dice · Slots · Wheel · Tower · Mines · Crash · Plinko · Roulette · Radiation Rush · High-Voltage Grid · The Royal Vault · The Scrap Pile', inline: false },
            { name: 'Open the panel', value: 'Press **Open games** to choose a game, buy jackpot raffle tickets, or configure the casino.', inline: false },
          ],
          footer: 'AstroBot panel · games · v3',
        }),
      ],
      components: [row(open('play', 'Open games', '🎮'))],
    }),
  },
  teams: {
    marker: 'AstroBot panel · teams',
    payload: () => ({
      embeds: [
        buildEmbed({
          title: '🛡️ Teams & Clans',
          color: COLORS.brand,
          description: 'Create a team, invite players and register your ORP zone. Press **Open teams** to manage your clan.',
          footer: 'AstroBot panel · teams',
        }),
      ],
      components: [row(open('team', 'Open teams', '🛡️'))],
    }),
  },
  rewards: {
    marker: 'AstroBot panel · rewards',
    payload: () => ({
      embeds: [
        buildEmbed({
          title: '🎁 Daily Rewards',
          color: COLORS.brand,
          description: 'Claim your daily streak, open crates and see everything waiting for you. Press **Open rewards**.',
          footer: 'AstroBot panel · rewards',
        }),
      ],
      components: [row(open('claim', 'Open rewards', '🎁'))],
    }),
  },
  kits: {
    marker: 'AstroBot panel · kits',
    payload: () => ({
      embeds: [
        buildEmbed({
          title: '🎒 Kit Claim',
          color: COLORS.brand,
          description: 'Claim the kits your roles unlock and have them delivered in game. Press **Open kits**.',
          footer: 'AstroBot panel · kits',
        }),
      ],
      components: [row(open('player-panel', 'Open kits', '🎒'))],
    }),
  },
  battlepass: {
    marker: 'AstroBot panel · battle pass',
    payload: () => ({
      embeds: [
        buildEmbed({
          title: '🎖️ Battle Pass',
          color: COLORS.brand,
          description: 'Track your tier, unlock rewards and claim everything you have earned. Press **Open battle pass**.',
          footer: 'AstroBot panel · battle pass',
        }),
      ],
      components: [row(open('battle-pass', 'Open battle pass', '🎖️'))],
    }),
  },
  leaderboards: {
    marker: 'AstroBot panel · leaderboards',
    payload: () => ({
      embeds: [
        buildEmbed({
          title: '🏆 Leaderboards',
          color: COLORS.brand,
          description: 'See who leads the server in kills, coins, playtime and Astro Score. Press **Open leaderboards**.',
          footer: 'AstroBot panel · leaderboards',
        }),
      ],
      components: [row(open('leaderboards', 'Open leaderboards', '🏆'))],
    }),
  },
  bounties: {
    marker: 'AstroBot panel · bounties',
    payload: () => ({
      embeds: [
        buildEmbed({
          title: '🎯 Bounties',
          color: COLORS.brand,
          description: 'Place a bounty on a rival or check the ones already live. Press **Open bounties**.',
          footer: 'AstroBot panel · bounties',
        }),
      ],
      components: [row(open('bounty', 'Open bounties', '🎯'))],
    }),
  },
  features: {
    marker: 'AstroBot panel · astro features',
    payload: () => featuresPayload(),
  },
});

/** Channel-name rules used when a template does not list panels explicitly. */
const RULES = Object.freeze([
  { type: 'support', pattern: /\bsupport\b|\btickets?\b/i },
  { type: 'shop', pattern: /\bshop\b|\bstore\b/i },
  { type: 'lfg', pattern: /\blfg\b|looking.for.group/i },
  { type: 'games', pattern: /\bgames?\b|\bcasino\b|\barcade\b/i },
  { type: 'teams', pattern: /\bclans?\b|\bteams\b|\bfind-a-team\b/i },
  { type: 'rewards', pattern: /reward|claim|daily|streak/i },
  { type: 'kits', pattern: /\bkit/i },
  { type: 'battlepass', pattern: /battle.?pass/i },
  { type: 'leaderboards', pattern: /leaderboard|ranking|rankings/i },
  { type: 'bounties', pattern: /bount(y|ies)/i },
  { type: 'features', pattern: /astro.?features|bot-features|features/i },
  { type: 'staff-hub', pattern: /astrobot.staff|staff.panel|admin.panel/i },
  { type: 'hub', pattern: /astrobot.panel|control.panel|bot.panel/i },
]);

/** Chooses which panels belong in a template, explicit panels first. */
export function planTemplatePanels(template) {
  const explicit = Array.isArray(template?.panels) ? template.panels : [];
  const plan = explicit
    .map((entry) => ({
      type: canonicalPanelType(entry?.type),
      channelName: String(entry?.channelName ?? entry?.channel ?? ''),
    }))
    .filter((entry) => entry.channelName && PANEL_DEFINITIONS[entry.type]);

  // Templates that list some panels explicitly still get every other panel
  // whose channel they define, so applying a layout never leaves a panel out.
  const channels = (template?.channels ?? []).map((channel) => String(channel.name ?? '')).filter(Boolean);
  for (const rule of RULES) {
    if (plan.some((entry) => entry.type === rule.type)) continue;
    const channelName = channels.find((name) => rule.pattern.test(name));
    if (channelName) plan.push({ type: rule.type, channelName });
  }
  return plan;
}

function isPostable(channel) {
  return channel && (channel.type === ChannelType.GuildText || channel.type === ChannelType.GuildAnnouncement);
}

/** Finds a channel by name in a live guild cache or a fetched collection. */
export function findPanelChannel(guild, channelName, channelIds = new Map()) {
  const key = normalizeStructureName(channelName);
  const cache = guild?.channels?.cache;
  const fromMap = channelIds.get(key) ? cache?.get?.(channelIds.get(key)) : null;
  if (isPostable(fromMap)) return fromMap;

  const pool = [...(cache?.values?.() ?? [])];
  return pool.find((channel) => normalizeStructureName(channel.name) === key && isPostable(channel)) ?? null;
}

/**
 * Reads recent channel history and reports whether the panel exists and still
 * carries buttons. Missing Read Message History is treated as "unknown" so a
 * repair never spams a duplicate panel it simply cannot see.
 */
export async function inspectPanelMessage(channel, definition) {
  if (!isPostable(channel)) return { found: false, hasButtons: false, unknown: false };
  if (typeof channel.messages?.fetch !== 'function') return { found: false, hasButtons: false, unknown: true };

  let recent;
  try {
    recent = await channel.messages.fetch({ limit: 50 });
  } catch {
    return { found: false, hasButtons: false, unknown: true };
  }

  // buildEmbed appends the brand copyright to every footer, so the panel
  // marker is a prefix, never the whole footer text. An exact comparison made
  // the bot blind to its own panels and re-posted them on every repair.
  const message =
    recent?.find?.((entry) => String(entry.embeds?.[0]?.footer?.text ?? '').includes(definition.marker)) ?? null;
  if (!message) return { found: false, hasButtons: false, unknown: false, stale: false };

  const components = message.components;
  const count = Number(components?.size ?? components?.length ?? 0);
  const footer = String(message.embeds?.[0]?.footer?.text ?? '');
  const stale = Boolean(definition.revision && !footer.includes(`v${definition.revision}`));
  return { found: true, hasButtons: count > 0, stale, message };
}

export async function deployTemplatePanels({ guild, template, channelIds = new Map(), actorId = null } = {}) {
  const plan = planTemplatePanels(template);
  const posted = [];
  const errors = [];
  let repaired = 0;

  for (const entry of plan) {
    const definition = PANEL_DEFINITIONS[entry.type];
    if (!definition) continue;

    let channel = findPanelChannel(guild, entry.channelName, channelIds);
    if (!isPostable(channel) && typeof guild?.channels?.fetch === 'function') {
      const id = channelIds.get(normalizeStructureName(entry.channelName));
      if (id) {
        try {
          channel = await guild.channels.fetch(id);
        } catch {
          channel = null;
        }
      }
    }
    if (!isPostable(channel) || typeof channel.send !== 'function') {
      errors.push(`panel ${entry.type}: channel ${entry.channelName} is missing`);
      continue;
    }

    const state = await inspectPanelMessage(channel, definition);
    if (state.found && state.hasButtons && !state.stale) continue;

    try {
      if (state.found && state.message) {
        await state.message.edit({ ...definition.payload(), allowedMentions: { parse: [] } });
        repaired += 1;
        posted.push(`${entry.type} → <#${channel.id}> (buttons restored)`);
      } else if (!state.unknown) {
        await channel.send({ ...definition.payload(), allowedMentions: { parse: [] } });
        posted.push(`${entry.type} → <#${channel.id}>`);
      }
    } catch (error) {
      errors.push(`panel ${entry.type}: ${error.message}`);
    }
  }

  return { posted: posted.length, channels: posted, repaired, errors };
}
