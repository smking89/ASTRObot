import { getGuildSettings } from '../db/repositories/guilds.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { createLogger } from '../core/logger.js';
import { truncate } from '../utils/format.js';

const log = createLogger('giveaway');

export const DEFAULT_WINNER_MESSAGE = '🎉 **{winners}** won **{prize}**!';
export const DEFAULT_GAME_WINNER_MESSAGE = '{winners} won {prize}!';

export function fillWinnerTemplate(template, { prize, winners, winnersText, count, server = '' }) {
  const winnerList = winnersText !== undefined ? winnersText : winners.length ? winners.map((id) => `<@${id}>`).join(', ') : 'nobody';
  return String(template ?? '')
    .replaceAll('{prize}', String(prize ?? 'the prize'))
    .replaceAll('{winners}', winnerList)
    .replaceAll('{count}', String(Number(count) || winners.length || 0))
    .replaceAll('{server}', String(server ?? ''));
}

export function fillGameWinnerTemplate(template, { prize, winnerIds = [], winnerNames = [], count }) {
  const ids = winnerIds.length ? winnerIds.join(', ') : 'nobody';
  const names = winnerNames.length ? winnerNames.join(', ') : ids;
  return String(template ?? '')
    .replaceAll('{prize}', String(prize ?? 'the prize'))
    .replaceAll('{winners}', names)
    .replaceAll('{winner}', names)
    .replaceAll('{ids}', ids)
    .replaceAll('{count}', String(Number(count) || winnerIds.length || 0));
}

/**
 * Posts the winner announcement to the admin-configured channel and optionally
 * the game console. Falls back to the original giveaway channel before giving up.
 */
export async function announceGiveawayWinners({ client, rconManager, giveaway, winners = [], winnerLabels = [] }) {
  const settings = getGuildSettings(giveaway.guild_id);
  const config = settings.onboarding?.giveaways ?? {};
  const result = { discord: false, game: false };
  const winnerText = winners.length
    ? winners
        .map((id, index) => winnerLabels[index] || (String(id).startsWith('web:') ? 'web entrant' : `<@${id}>`))
        .join(', ')
    : '';

  const channelId = config.winnerChannelId || giveaway.channel_id;
  if (channelId) {
    const channel = await client?.channels?.fetch?.(channelId).catch(() => null);
    if (channel?.isTextBased?.()) {
      const description = fillWinnerTemplate(config.winnerMessage || DEFAULT_WINNER_MESSAGE, {
        prize: giveaway.prize,
        winners,
        winnersText: winnerText,
        count: winners.length,
        server: channel.guild?.name ?? '',
      });
      const message = await channel
        .send({
          embeds: [
            buildEmbed({
              title: '🎉 Giveaway results',
              color: winners.length ? COLORS.success : COLORS.neutral,
              description: truncate(
                winners.length ? description : `**${giveaway.prize}**\nNo entries — no winner this time.`,
                3800,
              ),
              fields: [
                { name: 'Prize', value: truncate(giveaway.prize, 250), inline: false },
                { name: 'Winners', value: winnerText || 'None', inline: false },
              ],
              footer: 'Giveaway drawn by AstroBot',
            }),
          ],
          allowedMentions: { users: winners.filter((id) => /^\d{17,20}$/.test(String(id))) },
        })
        .catch((error) => {
          log.warn(`Winner announcement failed for ${giveaway.id}`, error);
          return null;
        });
      result.discord = Boolean(message);
    }
  }

  if (config.announceInGame) {
    const connection = rconManager?.connectionFor?.(giveaway.guild_id);
    if (connection) {
      // The game console has no Discord mention syntax, so resolve display
      // names and keep {ids} available for owners who want the raw ids.
      const guild = await client?.guilds?.fetch?.(giveaway.guild_id).catch(() => null);
      const winnerNames = await Promise.all(
        winners.map(async (userId, index) => {
          if (winnerLabels[index]) return winnerLabels[index];
          const member = await guild?.members?.fetch?.(userId).catch(() => null);
          return member?.displayName ?? member?.user?.username ?? `user ${userId}`;
        }),
      );
      const line = fillGameWinnerTemplate(config.gameWinnerMessage || DEFAULT_GAME_WINNER_MESSAGE, {
        prize: giveaway.prize,
        winnerIds: winners,
        winnerNames,
        count: winners.length,
      })
        .replace(/\s+/g, ' ')
        .replaceAll('"', "'")
        .slice(0, 240);
      if (line) {
        try {
          await connection.send(`say ${line}`);
          result.game = true;
        } catch (error) {
          log.warn(`RCON winner announcement failed for ${giveaway.id}`, error);
        }
      }
    }
  }

  return result;
}
