import { getGuildSettings } from '../db/repositories/guilds.js';
import { addProgress, getAccount, getOrCreateAccount } from '../db/repositories/players.js';
import { addPassXp, ensureProgress } from '../db/repositories/battlepass.js';
import { rankFor } from '../db/repositories/players.js';
import { isStaffMember } from './staff-service.js';

/**
 * XP curve: each level costs more than the last. Level is derived, never trusted
 * from input, so a corrupted XP value cannot grant an impossible level.
 */
export const MAX_LEVEL = 1000;

export function xpForLevel(level) {
  return Math.floor(100 * Math.pow(1.18, Math.max(1, level) - 1));
}

export function levelFromXp(totalXp) {
  let remaining = Math.max(0, Math.trunc(totalXp));
  let level = 1;

  while (level < MAX_LEVEL && remaining >= xpForLevel(level)) {
    remaining -= xpForLevel(level);
    level += 1;
  }

  return { level, intoLevel: remaining, needed: xpForLevel(level) };
}

/**
 * Awards XP, recomputes level, mirrors progress into the battle pass and returns
 * what changed so callers can announce level ups.
 */
export function awardXp({ guildId, userId, xp = 0, astroScore = 0, playtimeSeconds = 0, member = null }) {
  const settings = getGuildSettings(guildId);
  const account = getOrCreateAccount(guildId, userId);

  // Staff roles are support, not players: they never earn XP or Astro Score.
  if (member && isStaffMember(member, guildId)) {
    return { account, level: Number(account.level) || 1, leveledUp: false, levelsGained: 0, skipped: 'staff' };
  }

  const beforeLevel = Number(account.level) || 1;

  const totalXp = Math.max(0, Number(account.xp) + Math.trunc(xp));
  const { level } = levelFromXp(totalXp);

  const updated = addProgress(guildId, userId, {
    xp: Math.trunc(xp),
    astroScore: Math.trunc(astroScore),
    playtimeSeconds: Math.trunc(playtimeSeconds),
    level,
  });

  let pass = null;
  if (settings.battlePass.enabled && xp > 0) {
    pass = addPassXp(guildId, userId, Math.trunc(xp), Number(settings.battlePass.xpPerTier) || 1000);
  }

  return {
    account: updated,
    level,
    leveledUp: level > beforeLevel,
    levelsGained: Math.max(0, level - beforeLevel),
    nextLevelXp: xpForLevel(level),
    battlePass: pass,
  };
}

export function prestige({ guildId, userId }) {
  const account = getOrCreateAccount(guildId, userId);
  if (Number(account.level) < MAX_LEVEL) {
    return { ok: false, reason: 'not_max_level', level: Number(account.level) };
  }

  const updated = addProgress(guildId, userId, { xp: -Number(account.xp), level: 1, prestige: Number(account.prestige) + 1 });
  return { ok: true, account: updated, prestige: Number(updated.prestige) };
}

export function summary(guildId, userId) {
  const account = getOrCreateAccount(guildId, userId);
  const { level, intoLevel, needed } = levelFromXp(Number(account.xp));
  const settings = getGuildSettings(guildId);
  const pass = ensureProgress(guildId, userId);

  return {
    account,
    level,
    intoLevel,
    needed,
    rank: rankFor(guildId, userId, 'level'),
    walletRank: rankFor(guildId, userId, 'wallet'),
    pass,
    premium: Boolean(pass.premium),
    passTiers: Number(settings.battlePass.tiers) || 100,
    xpPerTier: Number(settings.battlePass.xpPerTier) || 1000,
  };
}

export function accountFor(guildId, userId) {
  return getAccount(guildId, userId);
}
