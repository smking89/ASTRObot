import { ValidationError } from '../core/errors.js';
import { getPath } from '../utils/object.js';

/**
 * Central feature-switch map.
 *
 * Settings already own the switch values; this service keeps the command and
 * panel names aligned so a switch cannot be toggled in /config while the
 * feature still opens from another entry point.
 */
const COMMAND_FEATURES = Object.freeze({
  shop: 'shop.enabled',
  market: 'marketplace.enabled',
  freeroles: 'onboarding.freeroles.enabled',
  play: 'games.enabled',
  lfg: 'lfg.enabled',
  partner: 'partnerships.enabled',
  'battle-pass': 'battlePass.enabled',
  claim: 'streak.enabled',
  team: 'clan.enabled',
  bounty: 'bounties.enabled',
  challenge: 'challenges.enabled',
  progression: 'challenges.enabled',
  competition: 'events.enabled',
  referral: 'referrals.enabled',
  leaderboards: 'leaderboards.enabled',
  support: 'tickets.enabled',
  mod: 'moderation.enabled',
});

const PANEL_FEATURES = Object.freeze({
  shop: 'shop.enabled',
  market: 'marketplace.enabled',
  freeroles: 'onboarding.freeroles.enabled',
  play: 'games.enabled',
  lfg: 'lfg.enabled',
  'battle-pass': 'battlePass.enabled',
  claim: 'streak.enabled',
  team: 'clan.enabled',
  bounty: 'bounties.enabled',
  progression: 'challenges.enabled',
  referral: 'referrals.enabled',
  leaderboards: 'leaderboards.enabled',
  support: 'tickets.enabled',
  mod: 'moderation.enabled',
});

const LABELS = Object.freeze({
  'shop.enabled': 'The shop',
  'marketplace.enabled': 'The player marketplace',
  'onboarding.freeroles.enabled': 'Free roles',
  'games.enabled': 'The casino',
  'lfg.enabled': 'Looking for Group',
  'partnerships.enabled': 'Partnership requests',
  'battlePass.enabled': 'The battle pass',
  'streak.enabled': 'Daily rewards',
  'clan.enabled': 'Teams and clans',
  'bounties.enabled': 'Bounties',
  'challenges.enabled': 'Challenges and progression',
  'events.enabled': 'Server events',
  'referrals.enabled': 'Referrals',
  'leaderboards.enabled': 'Leaderboards',
  'tickets.enabled': 'Support tickets',
  'moderation.enabled': 'Moderation commands',
});

export function featureForCommand(commandName) {
  return COMMAND_FEATURES[String(commandName ?? '')] ?? null;
}

export function featureForPanel(panelId) {
  return PANEL_FEATURES[String(panelId ?? '')] ?? null;
}

export function isFeatureEnabled(settings, path) {
  if (!path) return true;
  return getPath(settings, path) !== false;
}

export function assertFeatureEnabled(settings, path) {
  if (isFeatureEnabled(settings, path)) return;
  throw new ValidationError(
    `${LABELS[path] ?? 'That feature'} is switched off. An administrator can turn it back on in /config → Feature switches.`,
  );
}
