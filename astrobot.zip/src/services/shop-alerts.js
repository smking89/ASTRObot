import { getGuildSettings, patchGuildSetting } from '../db/repositories/guilds.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { formatCoins } from '../utils/format.js';

/**
 * Warns staff when a limited product sells out or drops to the configured
 * threshold. The alert is stamped onto the product so a busy shop cannot spam
 * the channel; any restock clears the stamp for the next dip.
 */
export async function maybeAlertLowStock({ client, guildId, product, stock, force = false }) {
  if (!product || stock === null || stock === undefined) return false;
  if (product.alertMuted) return false;

  const settings = getGuildSettings(guildId);
  const channelId = settings.shop.stockAlertChannelId;
  const threshold = Math.max(0, Number(settings.shop.lowStockThreshold ?? 3));
  const soldOut = Number(stock) <= 0;
  // Stock that can run out with no timer quietly stays sold out, so the alert
  // says so explicitly instead of leaving staff to discover it.
  const stalled =
    !(Number(product.restockMinutes) > 0) || !(Number(product.restockAmount) > 0);

  if (!channelId) return false;
  if (!soldOut && Number(stock) > threshold) return false;
  // Manual stock edits pass force so a dip alerts even if this product already
  // warned earlier; a purchase relies on the stamp to avoid alert spam.
  if (!force && product.stockAlertAt) return false;

  let channel = null;
  try {
    channel = await client?.channels?.fetch?.(channelId);
  } catch {
    return false;
  }
  if (!channel?.send) return false;

  const embed = buildEmbed({
    title: soldOut ? 'Sold out' : 'Low stock',
    color: soldOut ? COLORS.danger : COLORS.warning,
    description: soldOut
      ? `**${product.name ?? product.id}** has sold out. Restock it from \`/shop-panel\`.`
      : `**${product.name ?? product.id}** is down to **${stock}** left.`,
    thumbnail: /^https?:\/\//.test(product.image ?? '') ? product.image : null,
    fields: [
      { name: 'Product', value: `\`${product.id}\``, inline: true },
      { name: 'Stock', value: `${stock}`, inline: true },
      { name: 'Price', value: formatCoins(product.price ?? 0), inline: true },
      { name: 'Category', value: String(product.category ?? 'General'), inline: true },
      {
        name: 'Restock',
        value: stalled ? '⚠️ No restock timer — restock manually' : `+${product.restockAmount} every ${product.restockMinutes}m`,
      },
    ],
    footer: stalled
      ? 'No automatic restock is configured for this product'
      : soldOut
        ? 'Restock to resume sales'
        : `Alert threshold: ${threshold}`,
  });

  try {
    await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
  } catch {
    return false;
  }

  const products = getGuildSettings(guildId).shop.products ?? [];
  patchGuildSetting(
    guildId,
    'shop.products',
    products.map((entry) => (String(entry.id) === String(product.id) ? { ...entry, stockAlertAt: Date.now() } : entry)),
  );

  return true;
}
