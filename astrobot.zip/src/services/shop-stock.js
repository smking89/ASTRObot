import { getGuildSettings, patchGuildSetting } from '../db/repositories/guilds.js';
import { recordStockEvent } from '../db/repositories/shop.js';

/**
 * Stock helpers shared by the shop panels and the purchase handler.
 * A null stock means "unlimited"; 0 means sold out.
 */
export function stockOf(product) {
  if (!product || product.stock === null || product.stock === undefined || product.stock === '') return null;

  const value = Math.trunc(Number(product.stock));
  return Number.isFinite(value) ? Math.max(0, value) : null;
}

export function isSoldOut(product) {
  const stock = stockOf(product);
  return stock !== null && stock <= 0;
}

export function stockLabel(product) {
  const stock = stockOf(product);
  return stock === null ? 'unlimited' : `${stock} left`;
}

/** Parses the shop-wide starting stock: null = unlimited, otherwise a count. */
export function defaultStockValue(settings) {
  const raw = settings?.shop?.defaultStock;
  if (raw === null || raw === undefined || String(raw).trim() === '') return null;
  if (['unlimited', 'inf', 'infinite', '∞', '-1'].includes(String(raw).trim().toLowerCase())) return null;

  const value = Math.trunc(Number(raw));
  return Number.isFinite(value) && value >= 0 ? value : null;
}

/** Applies a delta to one product's stock. Returns the new stock, or null when unlimited. */
export function adjustStock(guildId, productId, delta, { kind = 'sale', actorId = null } = {}) {
  const products = getGuildSettings(guildId).shop.products ?? [];
  const index = products.findIndex((product) => String(product.id) === String(productId));
  if (index === -1) return null;

  const current = stockOf(products[index]);
  if (current === null) return null;

  const next = Math.max(0, current + Math.trunc(delta));
  const updated = products.map((product, position) => (position === index ? { ...product, stock: next } : product));
  patchGuildSetting(guildId, 'shop.products', updated);
  recordStockEvent({ guildId, productId, delta: Math.trunc(delta), stockAfter: next, kind, actorId });
  return next;
}

/**
 * Applies any restock ticks that are due. A product with no restock settings,
 * or unlimited stock, is returned untouched.
 */
export function restockProduct(product, now = Date.now()) {
  const minutes = Math.max(0, Math.trunc(Number(product.restockMinutes) || 0));
  const amount = Math.max(0, Math.trunc(Number(product.restockAmount) || 0));
  if (minutes === 0 || amount === 0) return product;

  const stock = stockOf(product);
  if (stock === null) return product;

  const anchor = Number(product.restockAnchorAt) || now;
  const ticks = Math.floor((now - anchor) / (minutes * 60_000));
  if (ticks <= 0) return product;

  const cap =
    product.stockMax === null || product.stockMax === undefined ? null : Math.max(0, Math.trunc(Number(product.stockMax)));
  const next = cap === null ? stock + ticks * amount : Math.min(cap, stock + ticks * amount);

  return { ...product, stock: next, restockAnchorAt: anchor + ticks * minutes * 60_000, stockAlertAt: null };
}

/** Timestamp of the next restock tick, or null when restock is off. */
export function restockAt(product, now = Date.now()) {
  const minutes = Math.max(0, Math.trunc(Number(product?.restockMinutes) || 0));
  const amount = Math.max(0, Math.trunc(Number(product?.restockAmount) || 0));
  if (minutes === 0 || amount === 0) return null;

  const anchor = Number(product.restockAnchorAt) || now;
  return anchor + minutes * 60_000;
}

/** Whole minutes until the next restock tick, or null when restock is off. */
export function restockCountdown(product, now = Date.now()) {
  const minutes = Math.max(0, Math.trunc(Number(product?.restockMinutes) || 0));
  const amount = Math.max(0, Math.trunc(Number(product?.restockAmount) || 0));
  if (minutes === 0 || amount === 0) return null;

  const anchor = Number(product.restockAnchorAt) || now;
  return Math.max(0, Math.ceil((anchor + minutes * 60_000 - now) / 60_000));
}

/** Restocks every product that is due and persists the result once. */
export function applyRestock(guildId, products, now = Date.now()) {
  let changed = false;
  const next = products.map((product) => {
    const updated = restockProduct(product, now);
    if (updated !== product) {
      changed = true;
      recordStockEvent({
        guildId,
        productId: product.id,
        delta: Number(updated.stock) - Number(stockOf(product)),
        stockAfter: updated.stock,
        kind: 'restock',
      });
    }
    return updated;
  });

  if (changed) patchGuildSetting(guildId, 'shop.products', next);
  return changed ? next : products;
}

/** Groups products by their category, keeping catalog order inside each group. */
export function groupByCategory(products) {
  const groups = new Map();

  for (const [index, product] of products.entries()) {
    const category = String(product.category ?? '').trim() || 'General';
    if (!groups.has(category)) groups.set(category, []);
    groups.get(category).push({ product, number: index + 1 });
  }

  return [...groups.entries()].map(([category, entries]) => ({ category, entries }));
}
