import { getGuildSettings } from '../db/repositories/guilds.js';
import { dueAnnouncements, getAnnouncement, markAnnouncementRun } from '../db/repositories/announcements.js';
import { dueDeliveryRetries, enqueueDeliveryRetry, recordDeliveryAttempt } from '../db/repositories/announcement-deliveries.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { createLogger } from '../core/logger.js';
import { truncate } from '../utils/format.js';
import { addZonedDays, formatTimeZone, weekdayOf, zonedParts, zonedTimeToUtc } from '../utils/timezone.js';

const log = createLogger('announcements');
const DAY_MS = 86_400_000;
export const MAX_DELIVERY_ATTEMPTS = 5;

const REPEAT_LABELS = {
  once: 'Once',
  daily: 'Every day',
  weekly: 'Every week',
  interval: 'Every interval',
};

export const REPEAT_CHOICES = Object.freeze([
  { label: 'Once', value: 'once' },
  { label: 'Every day', value: 'daily' },
  { label: 'Every week (same weekday)', value: 'weekly' },
]);

export function scheduleLabel(announcement) {
  if (announcement.schedule === 'weekly') {
    const names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const days = (announcement.weekdays ?? []).map((day) => names[day]).join(', ');
    return `Weekly · ${days || names[weekdayOf(zonedParts(Number(announcement.run_at), announcementTimeZone(announcement)))]}`;
  }
  if (announcement.schedule === 'interval') {
    const minutes = Math.round(Math.max(60, Number(announcement.interval_seconds) || 3600) / 60);
    return `Every ${minutes} min`;
  }
  return REPEAT_LABELS[announcement.schedule] ?? 'Once';
}

/** Stored zone first, then the guild default, then UTC. */
export function announcementTimeZone(announcement) {
  if (announcement?.timezone) return formatTimeZone(announcement.timezone);
  try {
    return formatTimeZone(getGuildSettings(announcement?.guild_id).announcements?.timezone);
  } catch {
    return 'UTC';
  }
}

/** Next delivery time for a repeating announcement, or null for a one-shot. */
export function nextRunAfter(announcement, from = Date.now()) {
  const runAt = Number(announcement.run_at) || from;
  const zone = announcementTimeZone(announcement);

  if (announcement.schedule === 'daily') {
    const anchor = zonedParts(runAt, zone);
    const today = zonedParts(from, zone);
    for (let offset = 0; offset <= 2; offset += 1) {
      const day = addZonedDays(today, offset);
      const candidate = zonedTimeToUtc({ ...day, hour: anchor.hour, minute: anchor.minute }, zone);
      if (candidate > from) return candidate;
    }
    return from + DAY_MS;
  }

  if (announcement.schedule === 'weekly') {
    const anchor = zonedParts(runAt, zone);
    const days = announcement.weekdays?.length ? announcement.weekdays : [weekdayOf(anchor)];
    const today = zonedParts(from, zone);
    for (let offset = 0; offset <= 8; offset += 1) {
      const day = addZonedDays(today, offset);
      if (!days.includes(weekdayOf(day))) continue;
      const candidate = zonedTimeToUtc({ ...day, hour: anchor.hour, minute: anchor.minute }, zone);
      if (candidate > from) return candidate;
    }
    return from + 7 * DAY_MS;
  }

  if (announcement.schedule === 'interval') {
    return from + Math.max(60, Number(announcement.interval_seconds) || 3600) * 1000;
  }

  return null;
}

/** Next run used when an admin re-enables or reschedules an announcement. */
export function nextRunFor(announcement, from = Date.now()) {
  if (announcement.schedule === 'once') {
    return Math.max(Number(announcement.run_at) || from, from + 60_000);
  }
  return nextRunAfter(announcement, from) ?? null;
}

export function announcementEmbed(announcement, { preview = false } = {}) {
  const zone = announcementTimeZone(announcement);
  return buildEmbed({
    title: `📣 ${truncate(announcement.name || 'Announcement', 200)}`,
    color: COLORS.brand,
    description: truncate(announcement.message, 3800),
    fields: [
      { name: 'Schedule', value: scheduleLabel(announcement), inline: true },
      {
        name: 'Next run',
        value: preview ? 'Now' : `<t:${Math.floor(Number(announcement.next_run_at ?? announcement.run_at) / 1000)}:F>`,
        inline: true,
      },
      { name: 'Time zone', value: zone, inline: true },
      { name: 'In game', value: announcement.in_game ? '✅ RCON say' : '—', inline: true },
    ],
    footer: 'AstroBot · scheduled announcement',
  });
}

export function gameAnnouncementLine(announcement) {
  const raw = String(announcement.rcon_message || announcement.message || '').trim();
  if (!raw) return '';
  return raw
    .replace(/\s+/g, ' ')
    .replaceAll('"', "'")
    .slice(0, 240);
}

/**
 * Delivers one announcement to the requested targets. `targets` lets a retry
 * resend only the side that failed. Each channel is best-effort and the result
 * reports what was attempted so failures can be queued.
 */
export async function deliverAnnouncement({ client, rconManager, announcement, preview = false, targets = {} }) {
  const settings = getGuildSettings(announcement.guild_id);
  const wantDiscord = targets.discord !== false;
  const wantGame = targets.game !== false;
  const channelId = announcement.channel_id ?? settings.channels?.broadcasts ?? null;
  const result = { discord: false, game: false, attemptedDiscord: false, attemptedGame: false, error: null };
  const errors = [];

  if (wantDiscord && channelId) {
    result.attemptedDiscord = true;
    const channel = await client?.channels?.fetch?.(channelId).catch(() => null);
    if (!channel?.isTextBased?.()) {
      errors.push(`channel ${channelId} is unavailable`);
    } else {
      const message = await channel
        .send({ embeds: [announcementEmbed(announcement, { preview })], allowedMentions: { parse: [] } })
        .catch((error) => {
          errors.push(`Discord: ${error.message}`);
          return null;
        });
      result.discord = Boolean(message);
    }
  }

  if (wantGame && announcement.in_game) {
    result.attemptedGame = true;
    const connection = rconManager?.connectionFor?.(announcement.guild_id);
    const line = gameAnnouncementLine(announcement);
    if (!connection || !line) {
      errors.push(connection ? 'announcement has no in-game text' : `no RCON connection for ${announcement.guild_id}`);
    } else {
      try {
        await connection.send(`say ${line}`);
        result.game = true;
      } catch (error) {
        errors.push(`RCON: ${error.message}`);
      }
    }
  }

  result.error = errors.length > 0 ? errors.join('; ') : null;
  return result;
}

/** Scheduler tick: delivers due announcements, queues retries and advances runs. */
export async function sweepAnnouncements({ client, rconManager, now = Date.now() }) {
  let delivered = 0;
  for (const announcement of dueAnnouncements(now)) {
    try {
      const result = await deliverAnnouncement({ client, rconManager, announcement });
      const needDiscord = result.attemptedDiscord && !result.discord;
      const needGame = result.attemptedGame && !result.game;
      if (needDiscord || needGame) {
        enqueueDeliveryRetry({
          announcementId: announcement.id,
          guildId: announcement.guild_id,
          needDiscord,
          needGame,
          error: result.error,
          now: now + 60_000,
        });
      }
      const next = nextRunAfter(announcement, Math.max(now, Number(announcement.next_run_at) || now));
      markAnnouncementRun(announcement.id, now, next);
      delivered += 1;
    } catch (error) {
      log.error(`Announcement ${announcement.id} failed`, error);
      enqueueDeliveryRetry({
        announcementId: announcement.id,
        guildId: announcement.guild_id,
        needDiscord: Boolean(announcement.channel_id),
        needGame: Boolean(announcement.in_game),
        error: error.message,
        now: now + 60_000,
      });
      markAnnouncementRun(announcement.id, now, nextRunAfter(announcement, now) ?? null);
    }
  }
  return delivered;
}

/** Retries only the sides that previously failed, with exponential backoff. */
export async function sweepAnnouncementRetries({ client, rconManager, now = Date.now() }) {
  let recovered = 0;
  for (const delivery of dueDeliveryRetries(now)) {
    const announcement = getAnnouncement(delivery.announcement_id);
    if (!announcement) {
      recordDeliveryAttempt(delivery.id, { status: 'failed', error: 'Announcement was deleted' });
      continue;
    }

    const result = await deliverAnnouncement({
      client,
      rconManager,
      announcement,
      targets: { discord: Boolean(delivery.need_discord), game: Boolean(delivery.need_game) },
    });

    const failed = (delivery.need_discord && !result.discord) || (delivery.need_game && !result.game);
    const attempts = Number(delivery.attempts) + 1;

    if (!failed) {
      recordDeliveryAttempt(delivery.id, { status: 'sent', error: null });
      recovered += 1;
    } else if (attempts >= MAX_DELIVERY_ATTEMPTS) {
      recordDeliveryAttempt(delivery.id, { status: 'failed', error: result.error ?? 'Delivery failed' });
      log.warn(`Announcement ${announcement.id} delivery gave up after ${attempts} attempts.`);
    } else {
      recordDeliveryAttempt(delivery.id, {
        status: 'pending',
        error: result.error,
        nextAttemptAt: now + Math.min(3_600_000, 60_000 * 2 ** (attempts - 1)),
      });
    }
  }
  return recovered;
}
