/** Pure uptime maths over RCON online/offline status events. */

export function computeUptime(events, now = Date.now(), windowMs = 7 * 86_400_000) {
  const start = now - windowMs;
  const relevant = (events ?? [])
    .filter((event) => event.status === 'online' || event.status === 'offline')
    .sort((a, b) => Number(a.created_at) - Number(b.created_at));

  let onlineSince = null;
  let onlineMs = 0;
  let incidents = 0;
  let last = null;

  for (const event of relevant) {
    const at = Math.max(Number(event.created_at), start);
    if (event.status === 'online') {
      if (onlineSince === null) onlineSince = at;
    } else {
      if (onlineSince !== null) {
        onlineMs += Math.max(0, at - onlineSince);
        onlineSince = null;
      }
      incidents += 1;
    }
    last = event;
  }

  if (onlineSince !== null) onlineMs += Math.max(0, now - onlineSince);

  return {
    uptimePercent: windowMs > 0 ? Math.round((onlineMs / windowMs) * 1000) / 10 : 100,
    onlineMs,
    incidents,
    current: last?.status ?? 'unknown',
    players: last?.players ?? 0,
  };
}

export function describeUptime(events, now = Date.now(), windowMs = 7 * 86_400_000) {
  const summary = computeUptime(events, now, windowMs);
  return {
    ...summary,
    label: summary.current === 'online' ? '🟢 online' : summary.current === 'offline' ? '🔴 offline' : '⚪ unknown',
  };
}
