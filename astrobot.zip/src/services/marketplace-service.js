import { transaction } from '../db/index.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { addItem, consumeItem, listItems } from '../db/repositories/inventory.js';
import { getTeamForUser } from '../db/repositories/teams.js';
import { balances, credit, debit } from './economy-service.js';
import {
  addBid,
  clearAssetLock,
  createListing as insertListing,
  getAssetLock,
  getListing,
  listActiveListings,
  listBids,
  listDueBidListings,
  listSales,
  marketSummary,
  recordSale,
  setAssetLock,
  updateListing,
} from '../db/repositories/marketplace.js';
import { ValidationError } from '../core/errors.js';
import { createLogger } from '../core/logger.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS, TIME } from '../config/constants.js';

const log = createLogger('marketplace');
export const TREASURY_ID = '__market_treasury__';

export function marketCurrency(settings, { vip = false } = {}) {
  const base = String(settings?.marketplace?.currency ?? '').trim() || settings?.economy?.currency || 'coins';
  if (!vip) return base;
  return String(settings?.marketplace?.vip?.currency ?? '').trim() || base;
}

export function isVipMember(member, settings) {
  if (!settings?.marketplace?.vip?.enabled) return false;
  const roleId = normalizeRoleId(settings.marketplace.vip.roleId);
  return Boolean(roleId && member?.roles?.cache?.has?.(roleId));
}

export function marketPrice(listing, member, settings) {
  const base = Math.max(0, Number(listing?.price) || 0);
  if (listing?.vip_price !== null && listing?.vip_price !== undefined) {
    return isVipMember(member, settings) ? Math.max(0, Number(listing.vip_price) || 0) : base;
  }
  if (!isVipMember(member, settings)) return base;
  const discount = Math.max(0, Math.min(90, Number(settings?.marketplace?.vip?.discountPercent) || 0));
  return Math.max(0, Math.floor(base * (1 - discount / 100)));
}

export function marketFeePercent(listing, member, settings) {
  const vip = isVipMember(member, settings);
  const percent = vip
    ? Number(settings?.marketplace?.vip?.feePercent ?? settings?.marketplace?.feePercent ?? 0)
    : Number(listing?.fee_percent ?? settings?.marketplace?.feePercent ?? 0);
  return Math.max(0, Math.min(50, Number(percent) || 0));
}

export function assertMarketOpen(settings) {
  if (!settings?.marketplace?.enabled) {
    throw new ValidationError('The player marketplace is closed. An administrator can open it in /config → Player Marketplace.');
  }
}

function normalizeRoleId(value) {
  if (Array.isArray(value)) return value[0] ?? null;
  return value ?? null;
}

function modeEnabled(settings, mode) {
  const modes = settings?.marketplace?.modes ?? {};
  if (mode === 'bid') return modes.bid !== false;
  if (mode === 'sale') return modes.sale !== false;
  return modes.buyNow !== false;
}

function assertKindAllowed(settings, kind) {
  if (kind === 'item' && settings?.marketplace?.allowItems === false) throw new ValidationError('Item listings are disabled.');
  if (kind === 'kit' && settings?.marketplace?.allowKits === false) throw new ValidationError('Kit listings are disabled.');
  if (kind === 'role' && settings?.marketplace?.allowRoles === false) throw new ValidationError('Role listings are disabled.');
}

export function assertFairTrade(guildId, sellerId, buyerId) {
  if (!sellerId || !buyerId) throw new ValidationError('Both sides of the trade are required.');
  if (sellerId === buyerId) throw new ValidationError('You cannot buy your own listing.');

  const sellerTeam = getTeamForUser(guildId, sellerId);
  const buyerTeam = getTeamForUser(guildId, buyerId);
  if (sellerTeam && buyerTeam && sellerTeam.id === buyerTeam.id) {
    throw new ValidationError('Fraud protection blocked this trade: the buyer and seller are in the same team or clan.');
  }
}

export function listMarketAssets(guildId, member) {
  if (!member?.id) return [];
  const items = listItems(guildId, member.id).map((row) => {
    const isKit = String(row.item_key).startsWith('kit:');
    const lock = getAssetLock(guildId, member.id, row.item_key);
    return {
      key: row.item_key,
      label: isKit ? `Kit · ${row.item_key.slice(4)}` : row.item_key,
      kind: isKit ? 'kit' : 'item',
      quantity: Number(row.quantity) || 0,
      lockedUntil: lock && Number(lock.unlock_at) > Date.now() ? Number(lock.unlock_at) : null,
    };
  });
  const roles = [...(member.roles?.cache?.values?.() ?? [])]
    .filter((role) => role.id !== member.guild.id && !role.managed)
    .sort((left, right) => right.position - left.position)
    .map((role) => {
      const lock = getAssetLock(guildId, member.id, role.id);
      return {
        key: role.id,
        label: `Role · ${role.name}`,
        kind: 'role',
        quantity: 1,
        lockedUntil: lock && Number(lock.unlock_at) > Date.now() ? Number(lock.unlock_at) : null,
      };
    });
  return [...items, ...roles];
}

export function listMarketplace(guildId, { sellerId = null } = {}) {
  return listActiveListings(guildId, { includeMine: sellerId, limit: 50 });
}

export function marketDashboard(guildId, settings) {
  const summary = marketSummary(guildId);
  return {
    ...summary,
    currency: marketCurrency(settings),
    vipCurrency: marketCurrency(settings, { vip: true }),
    treasury: balances(guildId, TREASURY_ID).wallet,
    recent: listSales(guildId, { limit: 8 }),
  };
}

export function createListing({ guildId, sellerId, member, kind, assetKey, assetLabel, quantity = 1, price, vipPrice = null, mode = 'buy_now' }) {
  const settings = getGuildSettings(guildId);
  assertMarketOpen(settings);
  assertKindAllowed(settings, kind);
  if (!modeEnabled(settings, mode)) throw new ValidationError('That listing type is disabled by an administrator.');

  const numericPrice = Math.trunc(Number(price));
  if (!Number.isFinite(numericPrice) || numericPrice <= 0) throw new ValidationError('Price must be a positive whole number.');
  const numericVip = vipPrice === null || vipPrice === undefined || vipPrice === '' ? null : Math.trunc(Number(vipPrice));
  if (numericVip !== null && (!Number.isFinite(numericVip) || numericVip <= 0)) {
    throw new ValidationError('VIP price must be a positive whole number, or left blank.');
  }

  const lock = getAssetLock(guildId, sellerId, assetKey);
  if (lock && Number(lock.unlock_at) > Date.now()) {
    throw new ValidationError('That asset is locked after a recent marketplace delivery. Try again when the lock expires.');
  }

  const duplicate = listActiveListings(guildId, { includeMine: sellerId }).find((listing) => listing.asset_key === assetKey);
  if (duplicate) throw new ValidationError('You already have an active listing for that asset.');

  if (kind === 'role') {
    const roleId = String(assetKey);
    const role = member?.guild?.roles?.cache?.get?.(roleId);
    if (!role) throw new ValidationError('That role no longer exists.');
    if (role.managed) throw new ValidationError('Bot-managed roles cannot be sold.');
    if (!member.roles.cache.has(roleId)) throw new ValidationError('You do not own that role.');
  } else {
    const item = listItems(guildId, sellerId).find((row) => row.item_key === assetKey);
    const expectedKit = kind === 'kit';
    if (!item) throw new ValidationError('You no longer own that item.');
    if (expectedKit !== String(assetKey).startsWith('kit:')) {
      throw new ValidationError('That inventory item is not the selected listing type.');
    }
    if (Number(item.quantity) < Math.max(1, Math.trunc(quantity))) {
      throw new ValidationError('You do not have enough of that item to list.');
    }
  }

  const endsAt = mode === 'bid' ? Date.now() + Math.max(1, Number(settings.marketplace.listingHours) || 48) * TIME.hour : null;
  return insertListing({
    guildId,
    sellerId,
    kind,
    assetKey,
    assetLabel: String(assetLabel || assetKey).slice(0, 200),
    quantity: Math.max(1, Math.trunc(quantity)),
    price: numericPrice,
    vipPrice: numericVip,
    mode,
    currency: marketCurrency(settings),
    feePercent: Number(settings.marketplace.feePercent) || 0,
    endsAt,
    metadata: { sellerLabel: member?.user?.username ?? null },
  });
}

export function cancelListing({ guildId, userId, listingId }) {
  const listing = getListing(listingId);
  if (!listing || listing.guild_id !== guildId) throw new ValidationError('That listing no longer exists.');
  if (listing.seller_id !== userId) throw new ValidationError('Only the seller can cancel this listing.');
  if (listing.status !== 'active') throw new ValidationError('That listing is no longer active.');
  return updateListing(listing.id, { status: 'cancelled' });
}

export function placeBid({ guildId, userId, listingId, amount }) {
  const settings = getGuildSettings(guildId);
  assertMarketOpen(settings);
  const listing = getListing(listingId);
  if (!listing || listing.guild_id !== guildId) throw new ValidationError('That auction no longer exists.');
  if (listing.status !== 'active' || listing.mode !== 'bid' || !listing.ends_at || Number(listing.ends_at) <= Date.now()) {
    throw new ValidationError('That auction has ended.');
  }
  assertFairTrade(guildId, listing.seller_id, userId);

  const value = Math.trunc(Number(amount));
  const current = Number(listing.high_bid) || Number(listing.price) || 0;
  const minimum = current + Math.max(1, Number(settings.marketplace.minBidIncrement) || 1);
  if (!Number.isFinite(value) || value < minimum) throw new ValidationError(`The minimum bid is ${minimum.toLocaleString('en-US')}.`);
  if (balances(guildId, userId).wallet < value) throw new ValidationError('Your wallet cannot cover that bid.');

  addBid({ listingId, guildId, bidderId: userId, amount: value });
  return getListing(listingId);
}

export async function buyListing({ client, guildId, buyerId, listingId, amount = null, auction = false }) {
  const settings = getGuildSettings(guildId);
  assertMarketOpen(settings);
  const listing = getListing(listingId);
  if (!listing || listing.guild_id !== guildId) throw new ValidationError('That listing no longer exists.');
  if (listing.status !== 'active') throw new ValidationError('That listing is no longer available.');
  if (listing.mode === 'bid' && !auction) throw new ValidationError('This is an auction. Place a bid instead.');
  assertFairTrade(guildId, listing.seller_id, buyerId);

  const guild = client?.guilds?.cache?.get?.(guildId);
  const buyerMember = await guild?.members?.fetch?.(buyerId).catch(() => null);
  const sellerMember = await guild?.members?.fetch?.(listing.seller_id).catch(() => null);
  if (listing.kind === 'role') {
    const role = guild?.roles?.cache?.get?.(listing.asset_key);
    if (!role) throw new ValidationError('The listed role no longer exists.');
    if (!buyerMember) throw new ValidationError('Could not find your member record.');
    if (!sellerMember?.roles?.cache?.has?.(listing.asset_key)) throw new ValidationError('The seller no longer owns that role.');
    if (buyerMember.roles?.cache?.has?.(listing.asset_key)) throw new ValidationError('You already have that role.');
  }

  const value = auction ? Math.max(0, Math.trunc(Number(amount))) : marketPrice(listing, buyerMember, settings);
  if (!Number.isFinite(value) || value <= 0) throw new ValidationError('That listing has no valid price.');
  if (balances(guildId, buyerId).wallet < value) throw new ValidationError('Your wallet cannot cover this purchase.');

  const feePercent = marketFeePercent(listing, buyerMember, settings);
  const fee = Math.floor((value * feePercent) / 100);
  const sellerAmount = value - fee;

  // Add the role before money moves, so a missing Manage Roles permission does
  // not result in a paid but undelivered purchase.
  let roleAdded = false;
  if (listing.kind === 'role' && buyerMember) {
    try {
      await buyerMember.roles.add(listing.asset_key, `Marketplace purchase ${listing.id}`);
      roleAdded = true;
    } catch {
      throw new ValidationError('The bot cannot give that role. Ask an administrator to move the bot role above it.');
    }
  }

  try {
    transaction(() => {
      debit({ guildId, userId: buyerId, amount: value, kind: 'market_purchase' });
      credit({ guildId, userId: listing.seller_id, amount: sellerAmount, kind: 'market_sale', respectCap: false });
      if (fee > 0) credit({ guildId, userId: TREASURY_ID, amount: fee, kind: 'market_fee', respectCap: false });

      if (listing.kind !== 'role') {
        if (!consumeItem({ guildId, userId: listing.seller_id, itemKey: listing.asset_key, quantity: listing.quantity })) {
          throw new ValidationError('The seller no longer has that inventory item.');
        }
        addItem({
          guildId,
          userId: buyerId,
          itemKey: listing.asset_key,
          quantity: listing.quantity,
          metadata: { source: 'marketplace', listingId: listing.id },
        });
      }

      clearAssetLock(guildId, listing.seller_id, listing.asset_key);
      const lockMinutes = Math.max(0, Number(settings.marketplace.lockMinutes) || 0);
      if (lockMinutes > 0 && (listing.kind === 'kit' || listing.kind === 'role')) {
        setAssetLock({
          guildId,
          userId: buyerId,
          assetKey: listing.asset_key,
          kind: listing.kind,
          unlockAt: Date.now() + lockMinutes * TIME.minute,
        });
      }

      updateListing(listing.id, {
        status: 'sold',
        buyer_id: buyerId,
        sold_at: Date.now(),
      });
      recordSale({
        listingId: listing.id,
        guildId,
        sellerId: listing.seller_id,
        buyerId,
        kind: listing.kind,
        assetKey: listing.asset_key,
        assetLabel: listing.asset_label,
        amount: value,
        fee,
        currency: marketCurrency(settings, { vip: isVipMember(buyerMember, settings) }),
      });
    });
  } catch (error) {
    if (roleAdded) await buyerMember?.roles?.remove?.(listing.asset_key, 'Marketplace transaction rolled back').catch(() => null);
    throw error;
  }

  if (listing.kind === 'role') {
    await sellerMember?.roles?.remove?.(listing.asset_key, `Marketplace sale ${listing.id}`).catch((error) => {
      log.warn(`Could not remove sold role ${listing.asset_key} from seller ${listing.seller_id}`, error);
    });
  }

  const announcementChannelId = settings.marketplace.announcementChannelId;
  if (announcementChannelId) {
    const channel = await client?.channels?.fetch?.(announcementChannelId).catch(() => null);
    if (channel?.isTextBased?.()) {
      await channel
        .send({
          embeds: [
            buildEmbed({
              title: '🏪 Marketplace sale',
              description: `<@${buyerId}> bought **${listing.asset_label}** from <@${listing.seller_id}> for ${value.toLocaleString('en-US')} ${marketCurrency(settings)}.`,
              color: COLORS.success,
            }),
          ],
          allowedMentions: { parse: [] },
        })
        .catch(() => null);
    }
  }

  return { listing: getListing(listing.id), amount: value, fee, sellerAmount };
}

export async function settleExpiredAuctions(client) {
  let settled = 0;
  for (const listing of listDueBidListings()) {
    if (!listing.high_bidder_id || !listing.high_bid) {
      updateListing(listing.id, { status: 'expired' });
      continue;
    }
    try {
      await buyListing({
        client,
        guildId: listing.guild_id,
        buyerId: listing.high_bidder_id,
        listingId: listing.id,
        amount: Number(listing.high_bid),
        auction: true,
      });
      settled += 1;
    } catch (error) {
      log.warn(`Auction ${listing.id} could not settle; marking expired.`, error);
      updateListing(listing.id, { status: 'expired' });
    }
  }
  return settled;
}

export function bidsFor(listingId) {
  return listBids(listingId);
}

export { listSales };
