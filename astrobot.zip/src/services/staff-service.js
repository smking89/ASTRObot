import { ButtonStyle, PermissionFlagsBits } from 'discord.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, row } from '../ui/components.js';
import { COLORS } from '../config/constants.js';
import { ValidationError } from '../core/errors.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { env } from '../config/env.js';

/** Publishes the staff "Apply now" card into a channel. */
export async function publishApplyPanel(guild, channelId) {
  if (!channelId) throw new ValidationError('Set a staff panel channel in `/config staff` first.');

  const channel = await guild.channels.fetch(channelId).catch(() => null);
  if (!channel?.isTextBased()) throw new ValidationError('The staff panel channel is not writable.');

  await channel.send({
    embeds: [
      buildEmbed({
        title: 'Apply for staff',
        description: 'We are looking for active, fair-minded players to join the team. Press the button below to apply.',
        color: COLORS.brand,
        footer: 'Applications are reviewed by the staff team',
      }),
    ],
    components: [row(button({ id: customId('staff', 'apply'), label: 'Apply now', emoji: '📝', style: ButtonStyle.Success }))],
  });
}

/** Publishes an open staff position to the cross-server recruitment hub. */
export async function publishRecruitment(client, guild, officialGuildId, channelId) {
  if (!officialGuildId) throw new ValidationError('OFFICIAL_GUILD_ID is not configured.');
  if (!channelId) throw new ValidationError('No recruitment destination channel is configured.');

  const official = await client.guilds.fetch(officialGuildId).catch(() => null);
  const channel = official ? await official.channels.fetch(channelId).catch(() => null) : null;
  if (!channel?.isTextBased()) throw new ValidationError('No recruitment destination channel is configured.');

  await channel.send({
    embeds: [
      buildEmbed({
        title: `Staff opening · ${guild.name}`,
        description: `${guild.name} is recruiting staff. Apply in the server with \`/staff panel\`.`,
        color: COLORS.gold,
        footer: 'AstroBot recruitment hub',
      }),
    ],
  });
}

/**
 * Staff detection shared by progression, playtime rewards and leaderboards.
 *
 * A member counts as staff when they hold a role configured in
 * `access.staffRoleIds` (template setup fills this) or a role whose name is an
 * obvious staff tier. Staff are excluded from XP, Astro Score and every board.
 */
export const STAFF_ROLE_PATTERN = /\b(owner|admin|administrator|moderator|mod|staff|support|manager|producer|stream team)\b/i;

export function staffRoleIds(guildId) {
  return new Set((getGuildSettings(guildId).access?.staffRoleIds ?? []).map(String));
}

export function isStaffMember(member, guildId) {
  if (!member) return false;

  // The server owner and administrators are staff even without a configured
  // role (the owner often has no roles at all), so they never earn XP, Astro
  // Score or a leaderboard position.
  const ownerId = member.guild?.ownerId;
  if (ownerId && String(member.id) === String(ownerId)) return true;
  if (env.discord.developerIds.includes(String(member.id))) return true;
  if (member.permissions?.has?.(PermissionFlagsBits.Administrator)) return true;

  const roles = member.roles?.cache;
  if (!roles) return false;

  const configured = staffRoleIds(guildId);
  if (configured.size > 0 && [...configured].some((id) => roles.has(id))) return true;

  return roles.some?.((role) => role?.name && STAFF_ROLE_PATTERN.test(role.name)) ?? false;
}

export function isStaffUser(guild, guildId, userId) {
  if (!guild?.members?.cache) return false;
  const member = guild.members.cache.get(String(userId));
  return Boolean(member && isStaffMember(member, guildId));
}
