import { getDb, transaction } from '../db/index.js';
import { credit } from './economy-service.js';
import { rollInt } from '../utils/random.js';
import { getGameConfig } from './games/game-config.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { formatCoins } from '../utils/format.js';
import { createLogger } from '../core/logger.js';

const log = createLogger('jackpot');

/**
 * Progressive jackpot: every eligible wager contributes a small rake. The pool
 * lives in SQLite so it survives restarts, and a win pays the whole pool before
 * resetting it to the seed.
 */
export const JACKPOT_GAMES = Object.freeze(['slots', 'wheel', 'crash']);
export const JACKPOT_GAME_LABELS = Object.freeze({
  slots: 'Treasure Slots',
  wheel: 'Spin Wheel',
  crash: 'Astro Crash',
});
export const JACKPOT_RAKE_PERCENT = 2;
export const JACKPOT_SEED = 2_500;
export const JACKPOT_MIN = 2_500;

/**
 * Tuned per-game odds. At a 2% rake these settle around 8k, 6k and 5k pools
 * for a typical 100-coin wager, instead of resetting almost as soon as the
 * seed is reached. Keep this table as the single source for the panel too.
 */
export const JACKPOT_ODDS = Object.freeze({
  slots: 4_000,
  wheel: 3_000,
  crash: 2_500,
});

function ensureRow(guildId, seed = JACKPOT_SEED) {
  getDb()
    .prepare(
      `INSERT INTO jackpots (guild_id, balance, last_won_at, last_won_by, updated_at)
       VALUES (?, ?, NULL, NULL, ?)
       ON CONFLICT(guild_id) DO NOTHING`,
    )
    .run(guildId, seed, Date.now());
  return getDb().prepare('SELECT * FROM jackpots WHERE guild_id = ?').get(guildId);
}

export function getJackpot(guildId) {
  const config = getGameConfig(guildId).jackpot;
  const row = ensureRow(guildId, config.seed);
  return {
    guildId,
    balance: Number(row?.balance) || 0,
    lastWonAt: row?.last_won_at ? Number(row.last_won_at) : null,
    lastWonBy: row?.last_won_by ?? null,
    seed: config.seed,
    minimum: config.min,
    milestoneThreshold: config.milestoneThreshold,
    rakePercent: config.rakePercent,
    odds: config.odds,
  };
}

/** Posts one public alert when the pool crosses the configured milestone. */
export async function announceJackpotMilestone({ client, guildId, threshold, jackpot = null }) {
  const config = getGameConfig(guildId).jackpot;
  const at = Number(threshold ?? config.milestoneThreshold);
  if (!(at > 0)) return { announced: false, reason: 'disabled' };

  const channelId = config.milestoneChannelId;
  if (!channelId) return { announced: false, reason: 'no milestone channel' };

  let channel = null;
  try {
    channel = await client?.channels?.fetch?.(channelId);
  } catch {
    channel = null;
  }
  if (!channel?.send) return { announced: false, reason: 'milestone channel unavailable' };

  const pool = jackpot ?? getJackpot(guildId);
  const embed = buildEmbed({
    title: '💎 Jackpot milestone reached',
    color: COLORS.gold,
    description: `The progressive jackpot just crossed **${formatCoins(at)}**!\n\nCurrent pool: **${formatCoins(pool.balance)}**`,
    fields: [
      { name: 'Milestone', value: formatCoins(at), inline: true },
      { name: 'Current pool', value: formatCoins(pool.balance), inline: true },
      { name: 'Eligible games', value: JACKPOT_GAMES.map((game) => JACKPOT_GAME_LABELS[game]).join(' · '), inline: false },
    ],
    footer: 'Open /play and press Jackpot to see the odds and recent winners',
  });

  try {
    await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
  } catch (error) {
    log.warn(`Jackpot milestone announcement could not be sent in ${guildId}`, error);
    return { announced: false, reason: 'send failed' };
  }

  log.info(`Jackpot milestone announced for ${guildId}: ${pool.balance} crossed ${at}`);
  return { announced: true, channelId, threshold: at, balance: pool.balance };
}

export function contributeJackpot({ guildId, wager, game, client = null }) {
  if (!JACKPOT_GAMES.includes(game)) return getJackpot(guildId);

  const config = getGameConfig(guildId).jackpot;
  const before = getJackpot(guildId);
  const amount = Math.max(0, Math.floor((Number(wager) || 0) * (config.rakePercent / 100)));
  if (amount === 0) return before;
  transaction((db) => {
    ensureRow(guildId, config.seed);
    db.prepare('UPDATE jackpots SET balance = balance + ?, updated_at = ? WHERE guild_id = ?').run(
      amount,
      Date.now(),
      guildId,
    );
  });

  const after = getJackpot(guildId);
  const threshold = config.milestoneThreshold;
  const crossed = threshold > 0 && before.balance < threshold && after.balance >= threshold;
  if (crossed) {
    after.milestone = { threshold, balance: after.balance };
    if (client) {
      after.milestoneAnnouncement = announceJackpotMilestone({
        client,
        guildId,
        threshold,
        jackpot: after,
      });
    }
  }
  return after;
}

/** Pays the whole pool and resets it. Kept separate so tests can force a win. */
export function awardJackpot({ guildId, userId, game = 'manual' }) {
  return transaction((db) => {
    const config = getGameConfig(guildId).jackpot;
    ensureRow(guildId, config.seed);
    const row = db.prepare('SELECT * FROM jackpots WHERE guild_id = ?').get(guildId);
    const amount = Number(row?.balance) || 0;
    if (amount < config.min) return null;

    const now = Date.now();
    db.prepare(
      'UPDATE jackpots SET balance = ?, last_won_at = ?, last_won_by = ?, updated_at = ? WHERE guild_id = ?',
    ).run(config.seed, now, userId, now, guildId);

    db.prepare(
      'INSERT INTO jackpot_wins (guild_id, user_id, game, amount, created_at) VALUES (?, ?, ?, ?, ?)',
    ).run(guildId, userId, String(game), amount, now);

    credit({
      guildId,
      userId,
      amount,
      kind: 'jackpot_win',
      respectCap: false,
    });

    return { amount, balance: config.seed, game, userId, wonAt: now };
  });
}

export function getJackpotHistory(guildId, limit = 10) {
  const rows = getDb()
    .prepare('SELECT * FROM jackpot_wins WHERE guild_id = ? ORDER BY created_at DESC, id DESC LIMIT ?')
    .all(guildId, Math.max(1, Math.min(25, Math.trunc(Number(limit) || 10))));

  return rows.map((row) => ({
    userId: row.user_id,
    game: row.game,
    amount: Number(row.amount) || 0,
    createdAt: Number(row.created_at) || 0,
  }));
}

export function maybeAwardJackpot({ guildId, userId, game }) {
  if (!JACKPOT_GAMES.includes(game)) return null;

  const jackpot = getJackpot(guildId);
  if (jackpot.balance < jackpot.minimum) return null;
  if (rollInt(1, jackpot.odds[game] ?? 5_000) !== 1) return null;

  return awardJackpot({ guildId, userId, game });
}
