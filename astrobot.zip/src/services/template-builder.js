import { PermissionFlagsBits } from 'discord.js';
import { createTemplate, findTemplateByName, getTemplate, updateTemplate } from '../db/repositories/templates.js';
import { ValidationError } from '../core/errors.js';

/**
 * In-bot template builder.
 *
 * Lets an owner author a layout from scratch — roles, categories and channels —
 * without touching code and without needing the structure to exist first. The
 * finished draft is stored as a normal template payload, so it is applied by
 * the same additive engine as built-in presets and captured snapshots.
 *
 * A draft may also be seeded from a saved template (loadTemplateDraft); saving
 * it then updates that template in place instead of creating a new one.
 */

export const TEMPLATE_CHANNEL_TYPES = Object.freeze({ text: 0, voice: 2, announcement: 5, forum: 15 });
const MAX_ENTRIES = 40;
const drafts = new Map();

/**
 * Discord rewrites channel and category names (spaces to hyphens, emoji and
 * punctuation stripped), so duplicate checks compare this canonical form. The
 * same helper is used at apply time to match pre-existing structure.
 */
export function normalizeStructureName(value) {
  return String(value ?? '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^\p{L}\p{N}]+/gu, '-')
    .replace(/^-+|-+$/g, '');
}
const key = (guildId, userId) => `${guildId}:${userId}`;

export function templateDraft(guildId, userId) {
  const id = key(guildId, userId);
  if (!drafts.has(id)) {
    drafts.set(id, {
      name: 'Untitled template',
      description: null,
      editingId: null,
      roles: [],
      categories: [],
      channels: [],
      pendingCategory: null,
      kits: [],
      staffRoles: [],
    });
  }
  return drafts.get(id);
}

export function resetTemplateDraft(guildId, userId) {
  drafts.delete(key(guildId, userId));
}

/** Seeds the draft from a saved template so Save updates it in place. */
export function loadTemplateDraft(guildId, userId, template) {
  resetTemplateDraft(guildId, userId);
  const draft = templateDraft(guildId, userId);
  draft.name = template.name;
  draft.description = template.payload?.description ?? null;
  draft.editingId = template.id;
  draft.roles = (template.payload?.roles ?? []).map((entry) => ({
    name: String(entry.name ?? '').slice(0, 100),
    color: Number(entry.color) || 0,
    hoist: Boolean(entry.hoist),
    mentionable: Boolean(entry.mentionable),
    permissions: String(entry.permissions ?? '0'),
  }));
  draft.categories = (template.payload?.categories ?? []).map((entry) => ({
    name: String(entry.name ?? ''),
    overwrites: (entry.overwrites ?? []).map((overwrite) => ({ ...overwrite })),
  }));
  draft.channels = (template.payload?.channels ?? []).map((entry) => ({
    name: String(entry.name ?? ''),
    type: Number(entry.type ?? 0),
    parentName: entry.parentName ?? null,
    ...(entry.topic ? { topic: String(entry.topic) } : {}),
    ...(entry.overwrites ? { overwrites: entry.overwrites.map((overwrite) => ({ ...overwrite })) } : {}),
  }));
  draft.pendingCategory = null;
  draft.kits = (template.payload?.kits ?? []).map((kit) => ({
    name: String(kit.name ?? '').slice(0, 60),
    price: Math.max(0, Number(kit.price) || 0),
    rconCommand: String(kit.rconCommand ?? ''),
    ...(kit.roleName ? { roleName: String(kit.roleName) } : {}),
  }));
  draft.staffRoles = (template.payload?.staffRoles ?? []).map((entry) => String(entry)).filter(Boolean);
  return draft;
}

export function parsePermissions(value) {
  const raw = String(value ?? '').trim();
  if (!raw) return '0';
  if (/^\d+$/.test(raw)) return raw;

  const normalize = (value) => value.toLowerCase().replace(/[^a-z0-9]/g, '');
  let bits = 0n;
  for (const part of raw.split(/[\s,]+/).filter(Boolean)) {
    const name = Object.keys(PermissionFlagsBits).find((flag) => normalize(flag) === normalize(part));
    if (!name) {
      throw new ValidationError(`Unknown permission "${part}". Use names like ManageMessages, KickMembers or a numeric bitfield.`);
    }
    bits |= PermissionFlagsBits[name];
  }
  return bits.toString();
}

function parseColor(value) {
  const raw = String(value ?? '').trim();
  if (!raw) return 0;
  if (/^#?[0-9a-f]{6}$/i.test(raw)) return parseInt(raw.replace('#', ''), 16);
  if (/^\d+$/.test(raw)) return Math.min(0xffffff, Number(raw));
  throw new ValidationError('Color must be a hex value like #8b5cf6.');
}

function readName(value, label) {
  const name = String(value ?? '').trim();
  if (name.length < 1 || name.length > 100) throw new ValidationError(`${label} names must be 1-100 characters.`);
  return name;
}

function unique(entries, name) {
  return !entries.some((entry) => normalizeStructureName(entry.name) === normalizeStructureName(name));
}

export function addDraftRole(guildId, userId, { name, color, hoist, mentionable, permissions }) {
  const draft = templateDraft(guildId, userId);
  if (draft.roles.length >= MAX_ENTRIES) throw new ValidationError(`A template can hold at most ${MAX_ENTRIES} roles.`);

  const label = readName(name, 'Role');
  if (!unique(draft.roles, label)) throw new ValidationError('That role is already in the template.');

  draft.roles.push({
    name: label,
    color: parseColor(color),
    hoist: String(hoist ?? '').toLowerCase() === 'yes' || String(hoist ?? '').toLowerCase() === 'true',
    mentionable: String(mentionable ?? '').toLowerCase() === 'yes' || String(mentionable ?? '').toLowerCase() === 'true',
    permissions: parsePermissions(permissions),
  });
  return draft;
}

export function addDraftCategory(guildId, userId, { name }) {
  const draft = templateDraft(guildId, userId);
  if (draft.categories.length >= MAX_ENTRIES) throw new ValidationError(`A template can hold at most ${MAX_ENTRIES} categories.`);

  const label = readName(name, 'Category');
  if (!unique(draft.categories, label)) throw new ValidationError('That category is already in the template.');

  draft.categories.push({ name: label, overwrites: [] });
  return draft;
}

export function addDraftChannel(guildId, userId, { name, type, category, topic }) {
  const draft = templateDraft(guildId, userId);
  if (draft.channels.length >= MAX_ENTRIES) throw new ValidationError(`A template can hold at most ${MAX_ENTRIES} channels.`);

  const label = readName(name, 'Channel');
  const kind = String(type ?? 'text').trim().toLowerCase();
  if (!(kind in TEMPLATE_CHANNEL_TYPES)) throw new ValidationError('Channel type must be text, voice, announcement or forum.');

  const parentName = String(category ?? draft.pendingCategory ?? '').trim();
  if (parentName && !draft.categories.some((entry) => entry.name.toLowerCase() === parentName.toLowerCase())) {
    throw new ValidationError(`No category named "${parentName}". Create the category first.`);
  }

  // Channel names are unique server-wide in Discord, so the draft rejects a
  // repeat anywhere — not just inside the same category.
  const duplicate = draft.channels.some(
    (entry) => normalizeStructureName(entry.name) === normalizeStructureName(label),
  );
  if (duplicate) throw new ValidationError(`A channel named "${label}" is already in the template.`);

  draft.channels.push({
    name: label,
    type: TEMPLATE_CHANNEL_TYPES[kind],
    parentName: parentName || null,
    ...(topic ? { topic: String(topic).slice(0, 1024) } : {}),
  });
  return draft;
}

/** Sets which draft category new channels are filed under (empty clears it). */
export function setDraftCategory(guildId, userId, category) {
  const draft = templateDraft(guildId, userId);
  const name = String(category ?? '').trim();
  if (!name || name.toLowerCase() === 'none') {
    draft.pendingCategory = null;
    return draft;
  }

  const canonical = draft.categories.find((entry) => entry.name.toLowerCase() === name.toLowerCase())?.name;
  if (!canonical) throw new ValidationError(`No category named "${name}" in the template.`);
  draft.pendingCategory = canonical;
  return draft;
}

/** Adds a purchasable kit to the template, merged into misc.kits on apply. */
export function addDraftKit(guildId, userId, { name, price, command }) {
  const draft = templateDraft(guildId, userId);
  if ((draft.kits ?? []).length >= MAX_ENTRIES) throw new ValidationError(`A template can hold at most ${MAX_ENTRIES} kits.`);

  const label = readName(name, 'Kit').slice(0, 60);
  if (draft.kits.some((kit) => kit.name.toLowerCase() === label.toLowerCase())) {
    throw new ValidationError('That kit is already in the template.');
  }

  const rawPrice = String(price ?? '').trim();
  if (rawPrice && !/^\d+$/.test(rawPrice)) throw new ValidationError('Kit price must be a whole number of coins.');
  const cost = rawPrice ? Math.max(0, Number(rawPrice)) : 0;

  const rconCommand = String(command ?? '').trim();
  if (rconCommand.length < 1 || rconCommand.length > 4000) {
    throw new ValidationError('Kit RCON command must be 1-4000 characters.');
  }

  draft.kits.push({ name: label, price: cost, rconCommand });
  return draft;
}

export function removeDraftKit(guildId, userId, index) {
  const draft = templateDraft(guildId, userId);
  const position = Math.trunc(Number(index));
  if (!Number.isInteger(position) || position < 0 || position >= (draft.kits ?? []).length) {
    throw new ValidationError('That kit is no longer in the template.');
  }
  const [removed] = draft.kits.splice(position, 1);
  return { draft, removed };
}

/** Flags a draft role as staff; apply merges the created role into access.staffRoleIds. */
export function toggleDraftStaffRole(guildId, userId, roleName) {
  const draft = templateDraft(guildId, userId);
  const canonical = draft.roles.find(
    (entry) => normalizeStructureName(entry.name) === normalizeStructureName(roleName),
  )?.name;
  if (!canonical) throw new ValidationError('Add that role to the template before marking it as staff.');

  draft.staffRoles ??= [];
  const index = draft.staffRoles.findIndex((entry) => normalizeStructureName(entry) === normalizeStructureName(canonical));
  if (index >= 0) draft.staffRoles.splice(index, 1);
  else draft.staffRoles.push(canonical);
  return draft;
}

/** Adds a role overwrite to a channel or category already in the draft. */
export function addDraftOverwrite(guildId, userId, { targetType = 'channel', target, role, allow, deny }) {
  const draft = templateDraft(guildId, userId);
  const kind = String(targetType ?? 'channel').trim().toLowerCase();
  const collection = kind === 'category' ? draft.categories : kind === 'channel' ? draft.channels : null;
  if (!collection) throw new ValidationError('Target type must be channel or category.');

  const name = String(target ?? '').trim();
  const entry = collection.find((item) => item.name.toLowerCase() === name.toLowerCase());
  if (!entry) throw new ValidationError(`No ${kind} named "${name}" in the template.`);

  const roleName = String(role ?? '').trim();
  const canonical =
    roleName.toLowerCase() === '@everyone'
      ? '@everyone'
      : draft.roles.find((item) => item.name.toLowerCase() === roleName.toLowerCase())?.name;
  if (!canonical) throw new ValidationError('Add that role to the template before setting overwrites.');

  entry.overwrites ??= [];
  if (entry.overwrites.some((item) => item.name.toLowerCase() === canonical.toLowerCase())) {
    throw new ValidationError('That role already has an overwrite on this entry.');
  }

  const allowed = parsePermissions(allow);
  const denied = parsePermissions(deny);
  if (allowed === '0' && denied === '0') throw new ValidationError('Set at least one allowed or denied permission.');

  entry.overwrites.push({ type: 'role', name: canonical, allow: allowed, deny: denied });
  return entry;
}

export function removeDraftOverwrite(guildId, userId, targetType, entryIndex, overwriteIndex) {
  const draft = templateDraft(guildId, userId);
  const kind = String(targetType).toLowerCase() === 'category' ? 'category' : 'channel';
  const collection = kind === 'category' ? draft.categories : draft.channels;

  const position = Math.trunc(Number(entryIndex));
  const entry = collection[position];
  if (!entry) throw new ValidationError('That entry is no longer in the template.');

  const index = Math.trunc(Number(overwriteIndex));
  if (!Array.isArray(entry.overwrites) || index < 0 || index >= entry.overwrites.length) {
    throw new ValidationError('That permission overwrite no longer exists.');
  }

  const [removed] = entry.overwrites.splice(index, 1);
  return removed;
}

export function removeDraftEntry(guildId, userId, type, index) {
  const draft = templateDraft(guildId, userId);
  const position = Math.trunc(Number(index));
  const collection = type === 'role' ? draft.roles : type === 'category' ? draft.categories : type === 'channel' ? draft.channels : null;
  if (!collection || !Number.isInteger(position) || position < 0 || position >= collection.length) {
    throw new ValidationError('That entry is no longer in the template.');
  }
  const [removed] = collection.splice(position, 1);
  return { draft, removed };
}

export function buildTemplatePayload(draft) {
  return {
    version: 1,
    capturedAt: null,
    guildName: null,
    description: draft.description ?? null,
    roles: draft.roles.map((role) => ({ ...role })),
    categories: draft.categories.map((category) => ({
      ...category,
      overwrites: (category.overwrites ?? []).map((overwrite) => ({ ...overwrite })),
    })),
    channels: draft.channels.map((channel) => ({
      ...channel,
      ...(channel.overwrites ? { overwrites: channel.overwrites.map((overwrite) => ({ ...overwrite })) } : {}),
    })),
    kits: (draft.kits ?? []).map((kit) => ({
      name: kit.name,
      price: kit.price,
      rconCommand: kit.rconCommand,
      ...(kit.roleName ? { roleName: kit.roleName } : {}),
    })),
    staffRoles: [...(draft.staffRoles ?? [])],
  };
}

/** Persists the draft: updates the template it was seeded from, or creates one. */
export function saveTemplateDraft({ guildId, userId, actorId = null, name, description = null }) {
  const draft = templateDraft(guildId, userId);
  const label = String(name ?? draft.name ?? '').trim();
  if (label.length < 2 || label.length > 60) throw new ValidationError('Template names must be 2-60 characters.');

  const total = draft.roles.length + draft.categories.length + draft.channels.length + (draft.kits ?? []).length;
  if (total === 0) throw new ValidationError('Add at least one role, category or channel before saving.');

  if (draft.editingId && !getTemplate(guildId, draft.editingId)) {
    throw new ValidationError('The template being edited no longer exists.');
  }

  const clash = findTemplateByName(guildId, label);
  if (clash && clash.id !== draft.editingId) {
    throw new ValidationError('A template with that name already exists. Pick another name.');
  }

  draft.name = label;
  draft.description = String(description ?? '').trim() || null;
  const payload = buildTemplatePayload(draft);

  const template = draft.editingId
    ? updateTemplate(guildId, draft.editingId, { name: label, payload })
    : createTemplate({ guildId, name: label, payload, createdBy: actorId });

  resetTemplateDraft(guildId, userId);
  return template;
}
