import { runtime } from '../core/runtime.js';
import { addItem } from '../db/repositories/inventory.js';
import { balances, debit } from './economy-service.js';
import { createLogger } from '../core/logger.js';
import { getGuildSettings } from '../db/repositories/guilds.js';

const log = createLogger('kits');

/**
 * Delivers a registered kit: charges the price, records inventory and fires the
 * RCON command (queued as inventory when the server is offline).
 */
export async function provideKit({ guildId, userId, kit, gamertag = null }) {
  const price = Math.max(0, Number(kit.price) || 0);

  if (price > 0) {
    const account = balances(guildId, userId);
    if (account.wallet < price) throw new Error('Insufficient funds for that kit.');
    debit({ guildId, userId, amount: price, kind: 'kit_purchase' });
  }

  addItem({ guildId, userId, itemKey: `kit:${kit.name}`, quantity: 1, metadata: { price } });

  // Console Edition gifts kits by in-game name, so a player without a link is
  // queued instead of being sent an id the server cannot resolve.
  const connection = runtime.rconManager?.connectionFor(guildId);
  if (!connection || !gamertag) return { delivered: false, queued: true };

  const command = buildKitCommand({ kitName: kit.name, gamertag, template: kit.rconCommand });

  try {
    await connection.send(command);
    return { delivered: true, queued: false };
  } catch (error) {
    log.warn(`Kit delivery failed for ${userId}`, error);
    return { delivered: false, queued: true };
  }
}

/**
 * Console Edition gifts a single kit with `kit givetoplayer "<kit>" "<player>"`
 * (kit name first). {user}, {steamid}, {kit} and {name} are supported so owners
 * can point a kit at a custom command.
 */
export function buildKitCommand({ kitName, gamertag = null, template = null }) {
  const target = String(gamertag ?? '').replaceAll('"', '').trim();
  const name = String(kitName ?? '').replaceAll('"', '').trim();
  const source = String(template ?? '').trim() || 'kit givetoplayer "{kit}" "{user}"';

  return source
    .replaceAll('{user}', target)
    .replaceAll('{steamid}', target)
    .replaceAll('{kit}', name)
    .replaceAll('{name}', name)
    .trim();
}

export function kitsFor(guildId) {
  return getGuildSettings(guildId).misc.kits ?? [];
}
