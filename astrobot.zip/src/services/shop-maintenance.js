import { getGuildSettings, patchGuildSetting } from '../db/repositories/guilds.js';
import { listGuilds } from '../db/repositories/guilds.js';
import { lastStockEventAt, pruneStockEvents } from '../db/repositories/shop.js';
import { stockOf } from './shop-stock.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { createLogger } from '../core/logger.js';
import { formatCoins } from '../utils/format.js';

const log = createLogger('shop:maintenance');

/**
 * Periodic shop housekeeping:
 *  - prunes stock history older than the guild's retention window
 *  - warns staff when a timer-bound product's stock has not moved for too long,
 *    which usually means the timer is too slow or was never really replenishing
 */
export async function runShopMaintenance({ client, now = Date.now(), guildIds = null } = {}) {
  const guilds = guildIds ?? listGuilds({ limit: 1000 }).map((guild) => guild.id);

  let pruned = 0;
  let stalled = 0;
  let alerted = 0;

  for (const guildId of guilds) {
    const settings = getGuildSettings(guildId);

    const days = Math.max(0, Number(settings.shop.stockHistoryDays ?? 30));
    if (days > 0) pruned += pruneStockEvents(guildId, now - days * 86_400_000);

    const threshold = Math.max(0, Number(settings.shop.lowStockThreshold ?? 3));
    const stallHours = Math.max(1, Number(settings.shop.stallAlertHours ?? 72));
    const channelId = settings.shop.stockAlertChannelId;
    const flagged = [];

    for (const product of settings.shop.products ?? []) {
      if (product.alertMuted) continue;
      if (!(Number(product.restockMinutes) > 0) || !(Number(product.restockAmount) > 0)) continue;

      const stock = stockOf(product);
      if (stock === null || stock > threshold) continue;

      const lastEventAt = lastStockEventAt(guildId, product.id);
      const reference = lastEventAt ?? Number(product.restockAnchorAt) ?? now;
      if (now - reference < stallHours * 3_600_000) continue;

      // Already warned for this stall; new movement moves the reference past the stamp.
      if (Number(product.stallAlertAt) >= reference) continue;

      flagged.push({ ...product, lastEventAt: reference });
    }

    stalled += flagged.length;
    if (flagged.length === 0 || !channelId) continue;

    let channel = null;
    try {
      channel = await client?.channels?.fetch?.(channelId);
    } catch {
      continue;
    }
    if (!channel?.send) continue;

    const embed = buildEmbed({
      title: 'Stalled restock timers',
      color: COLORS.warning,
      description:
        'These products have a restock timer but their stock has not moved within the stall window, so they are likely to stay sold out.',
      fields: [
        {
          name: `Products · ${flagged.length}`,
          value: flagged
            .slice(0, 15)
            .map(
              (product) =>
                `**${product.name ?? product.id}** · ${stockOf(product)} left · +${product.restockAmount}/${product.restockMinutes}m · last move <t:${Math.floor(
                  product.lastEventAt / 1000,
                )}:R>`,
            )
            .join('\n'),
        },
      ],
      footer: 'Check the restock amount and interval, or restock manually',
    });

    try {
      await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
    } catch (error) {
      log.warn(`Stalled stock alert failed for ${guildId}`, error);
      continue;
    }

    alerted += flagged.length;
    const products = getGuildSettings(guildId).shop.products ?? [];
    patchGuildSetting(
      guildId,
      'shop.products',
      products.map((product) =>
        flagged.some((entry) => String(entry.id) === String(product.id)) ? { ...product, stallAlertAt: now } : product,
      ),
    );
  }

  if (pruned > 0 || alerted > 0) {
    log.info(`Shop maintenance: pruned ${pruned} stock event(s), flagged ${alerted} stalled product(s).`);
  }

  return { pruned, stalled, alerted };
}

/** Formats a revenue figure with the guild currency, used by the sales report. */
export function revenueLabel(amount, settings) {
  return formatCoins(Number(amount) || 0, settings.economy.currency);
}
