import { getDb } from '../db/index.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { formatCoins } from '../utils/format.js';
import { economyScopeKey } from './economy-service.js';
import { createLogger } from '../core/logger.js';

const log = createLogger('economy:circulation');

/**
 * Alerts fire when total wallet + bank volume reaches the administrator's
 * threshold, not on every check above it. The state lives in its own table so a
 * restart cannot re-announce an economy that was already flagged.
 *
 * Re-arming is deliberately forgiving: circulation has to fall 5% under the
 * threshold before the next crossing counts, so a balance hovering on the line
 * cannot flap alerts back and forth.
 */
export const REARM_RATIO = 0.95;

export function circulationTotals(guildId, scopeKey = guildId) {
  const row = getDb()
    .prepare(
      `SELECT COALESCE(SUM(wallet), 0) AS wallet,
              COALESCE(SUM(bank), 0) AS bank,
              COUNT(*) AS players
         FROM players WHERE guild_id = ?`,
    )
    .get(scopeKey);

  const wallet = Number(row?.wallet ?? 0);
  const bank = Number(row?.bank ?? 0);
  return { wallet, bank, players: Number(row?.players ?? 0), total: wallet + bank };
}

export function getCirculationState(guildId) {
  return (
    getDb()
      .prepare('SELECT state, total, channel_id, updated_at FROM circulation_state WHERE guild_id = ?')
      .get(guildId) ?? null
  );
}

export function nextCirculationState({ total, threshold, previous = null }) {
  if (!(Number(threshold) > 0)) return 'below';
  if (Number(total) >= Number(threshold)) return 'above';
  // Hold "above" until the economy clearly drops, then re-arm.
  if (previous === 'above' && Number(total) > Number(threshold) * REARM_RATIO) return 'above';
  return 'below';
}

function saveState(guildId, state, total, channelId = null) {
  getDb()
    .prepare(
      `INSERT INTO circulation_state (guild_id, state, total, channel_id, updated_at)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(guild_id) DO UPDATE SET
         state = excluded.state,
         total = excluded.total,
         channel_id = COALESCE(excluded.channel_id, circulation_state.channel_id),
         updated_at = excluded.updated_at`,
    )
    .run(guildId, state, Math.trunc(total), channelId, Date.now());
}

export async function checkCirculation({ client, guildId, force = false } = {}) {
  if (!guildId) throw new Error('A guild is required to check circulation.');

  const settings = getGuildSettings(guildId);
  const threshold = Math.max(0, Number(settings.economy.circulationAlert ?? 0));
  const totals = circulationTotals(guildId, economyScopeKey(guildId, settings));
  const previous = getCirculationState(guildId);
  const state = nextCirculationState({ total: totals.total, threshold, previous: previous?.state ?? null });
  const crossed = state === 'above' && previous?.state !== 'above';

  saveState(guildId, state, totals.total);

  const base = { state, totals, threshold };
  if (state !== 'above') return { ...base, alerted: false, reason: 'below threshold' };

  const channelId = settings.economy.circulationAlertChannelId;
  if (!channelId) return { ...base, alerted: false, reason: 'no alert channel' };

  // Pointing the alert at a new channel while the economy is already hot should
  // report the current state once, rather than wait for a re-arm that may never
  // come.
  const newChannel = previous?.channel_id !== channelId;
  if (!crossed && !newChannel && !force) return { ...base, alerted: false, reason: 'already reported' };

  let channel = null;
  try {
    channel = await client?.channels?.fetch?.(channelId);
  } catch {
    channel = null;
  }
  if (!channel?.send) return { ...base, alerted: false, reason: 'alert channel unavailable' };

  const overage = totals.total - threshold;
  const embed = buildEmbed({
    title: 'Economy circulation alert',
    color: COLORS.danger,
    description:
      `Total wallet + vault volume reached **${formatCoins(totals.total)}** against a **${formatCoins(threshold)}** threshold.`,
    fields: [
      { name: 'Circulation', value: formatCoins(totals.total), inline: true },
      { name: 'Threshold', value: formatCoins(threshold), inline: true },
      { name: 'Over by', value: formatCoins(overage), inline: true },
      { name: 'In wallets', value: formatCoins(totals.wallet), inline: true },
      { name: 'In vaults', value: formatCoins(totals.bank), inline: true },
      { name: 'Funded players', value: `${totals.players}`, inline: true },
    ],
    footer: `Re-arms once circulation drops below ${formatCoins(Math.floor(threshold * REARM_RATIO))}`,
  });

  try {
    await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
  } catch (error) {
    log.warn(`Circulation alert could not be sent in ${guildId}`, error);
    return { ...base, alerted: false, reason: 'send failed' };
  }

  saveState(guildId, state, totals.total, channelId);

  log.info(`Circulation alert sent for ${guildId}: ${totals.total} >= ${threshold}`);
  return { ...base, alerted: true };
}

export async function checkAllCirculation({ client } = {}) {
  const guildIds = getDb()
    .prepare('SELECT id FROM guilds')
    .all()
    .map((row) => row.id);

  const results = [];
  for (const guildId of guildIds) {
    try {
      results.push({ guildId, ...(await checkCirculation({ client, guildId })) });
    } catch (error) {
      log.warn(`Circulation check failed for ${guildId}`, error);
    }
  }
  return results;
}
