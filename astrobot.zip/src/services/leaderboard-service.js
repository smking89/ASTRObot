import { AttachmentBuilder } from 'discord.js';
import { globalTopPlayers, topPlayers } from '../db/repositories/players.js';
import { topReferrers } from '../db/repositories/referrals.js';
import { formatNumber } from '../utils/format.js';
import { renderLeaderboardImage } from './leaderboard-image.js';
import { isStaffMember } from './staff-service.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { displayPeriodFor, periodLabel, prizesFor } from './leaderboard-prizes.js';

const EMOJI = /[\p{Extended_Pictographic}\uFE0F\u200D\u20E3]/gu;

/** Fonts on the boards cannot draw emoji, so names drop them instead of boxes. */
const cleanName = (value) =>
  String(value ?? '')
    .normalize('NFKC')
    .replace(EMOJI, '')
    .replace(/\s+/g, ' ')
    .trim();

export const LEADERBOARD_METRICS = Object.freeze([
  { id: 'xp', label: 'XP' },
  { id: 'level', label: 'Rank' },
  { id: 'kills', label: 'PvP kills' },
  { id: 'pve_kills', label: 'PvE kills' },
  { id: 'wallet', label: 'Wealth' },
  { id: 'game_wins', label: 'Game wins' },
  { id: 'rival_wins', label: 'Rival wins' },
  { id: 'competition_wins', label: 'Competition wins' },
  { id: 'astro_score', label: 'Astro Score' },
  { id: 'bank', label: 'Bank balance' },
  { id: 'deaths', label: 'Deaths' },
  { id: 'kd', label: 'K/D ratio' },
  { id: 'referrals', label: 'Referrals' },
  { id: 'playtime', label: 'Playtime' },
]);

export function formatLeaderboardValue(metric, row) {
  switch (metric) {
    case 'wallet':
    case 'bank':
      return `${formatNumber(row[metric] ?? 0)} coins`;
    case 'level':
      return `Level ${formatNumber(row.level ?? 1)}`;
    case 'pve_kills':
      return `${formatNumber(row[metric] ?? 0)} kills`;
    case 'game_wins':
    case 'rival_wins':
    case 'competition_wins':
      return `${formatNumber(row[metric] ?? 0)} wins`;
    case 'kd':
      return (row.kills / Math.max(1, row.deaths)).toFixed(2);
    case 'playtime':
      return `${formatNumber(Math.round(row.playtime_seconds / 3600))}h`;
    default:
      return formatNumber(row[metric] ?? 0);
  }
}

/** Counters where a zero row would just be noise on the board. */
const WIN_METRICS = new Set(['pve_kills', 'game_wins', 'rival_wins', 'competition_wins']);

/** Top rows with readable names, ready for either the image or an embed. */
export async function leaderboardRows({ guildId, guild = null, metric = 'wallet', limit = 15 }) {
  const source =
    metric === 'referrals'
      ? topReferrers(guildId, limit).map((row) => ({ ...row, user_id: row.owner_id, value: row.uses }))
      : topPlayers(guildId, metric, limit + 15);

  const rows = [];
  for (const row of source) {
    if (WIN_METRICS.has(metric) && Number(row[metric] ?? 0) <= 0) continue;
    let name = `Player ${String(row.user_id).slice(-4)}`;
    if (guild?.members?.fetch) {
      try {
        const member = await guild.members.fetch(String(row.user_id));
        // Staff never appear on a board, even if they have stats.
        if (isStaffMember(member, guildId)) continue;
        name = cleanName(member.displayName) || cleanName(member.user?.username) || name;
      } catch {
        // A player who left the server still keeps their board position.
      }
    }
    rows.push({
      name,
      value: metric === 'referrals' ? `${row.uses} referrals` : formatLeaderboardValue(metric, row),
    });
  }
  return rows.slice(0, limit);
}

const GLOBAL_WIN_METRICS = new Set(['pve_kills', 'game_wins', 'rival_wins', 'competition_wins']);

const globalValue = (metric, row) => {
  const value = Number(row.value) || 0;
  if (metric === 'level') return `Level ${formatNumber(value)}`;
  if (metric === 'playtime') return `${formatNumber(Math.round(value / 3600))}h`;
  if (metric === 'kd') return (Number(row.kills || 0) / Math.max(1, Number(row.deaths || 0))).toFixed(2);
  if (metric === 'wallet' || metric === 'bank') return `${formatNumber(value)} coins`;
  if (metric === 'pve_kills') return `${formatNumber(value)} kills`;
  if (metric === 'game_wins' || metric === 'rival_wins' || metric === 'competition_wins') return `${formatNumber(value)} wins`;
  if (metric === 'referrals') return `${formatNumber(value)} referrals`;
  return formatNumber(value);
};

/** Name lookup across every connected guild, cache only (cheap). */
function globalMember(client, userId) {
  for (const guild of client?.guilds?.cache?.values?.() ?? []) {
    const member = guild.members?.cache?.get?.(String(userId));
    if (member) return { member, guildId: guild.id };
  }
  return null;
}

/** Global board: players aggregated across every guild the bot serves. */
export async function globalLeaderboardBoard({ client, metric = 'wallet', limit = 15, title = null, eyebrow = 'ASTROBOT' }) {
  const label = title ?? leaderboardLabel(metric);
  const source = globalTopPlayers(metric, limit + 15);
  const rows = [];

  for (const row of source) {
    if (GLOBAL_WIN_METRICS.has(metric) && (Number(row.value) || 0) <= 0) continue;

    const found = globalMember(client, row.user_id);
    if (found && isStaffMember(found.member, found.guildId)) continue;

    const name =
      cleanName(found?.member?.displayName) || cleanName(found?.member?.user?.username) || `Player ${String(row.user_id).slice(-4)}`;
    rows.push({ name, value: globalValue(metric, row) });
    if (rows.length >= limit) break;
  }

  const updated = new Date().toLocaleString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    day: '2-digit',
    month: 'short',
    timeZone: 'UTC',
  });

  const buffer = await renderLeaderboardImage({
    title: label,
    subtitle: 'All servers',
    eyebrow,
    rows,
    prizes: [0, 0, 0],
    footer: `Global rankings · updated ${updated} UTC · top ${rows.length || limit}`,
  });

  return { label, rows, attachment: new AttachmentBuilder(buffer, { name: 'leaderboard.png' }) };
}

export function leaderboardLabel(metric) {
  return LEADERBOARD_METRICS.find((entry) => entry.id === metric)?.label ?? 'Wealth (wallet)';
}

/** Builds the PNG attachment plus the metadata both the panel and feed use. */
export async function leaderboardBoard({
  guild,
  guildId,
  metric = 'wallet',
  limit = 15,
  theme = 'brand',
  title = null,
  eyebrow = 'ASTROBOT',
  period = null,
}) {
  const label = title ?? leaderboardLabel(metric);
  const rows = await leaderboardRows({ guildId, guild, metric, limit });
  const activePeriod = period ?? displayPeriodFor(guildId);
  const prizeSet = prizesFor(guildId, activePeriod, metric);
  const updated = new Date().toLocaleString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    day: '2-digit',
    month: 'short',
    timeZone: 'UTC',
  });
  const buffer = await renderLeaderboardImage({
    title: label,
    subtitle: cleanName(guild?.name) || 'All servers',
    eyebrow,
    theme,
    rows,
    prizes: prizeSet,
    prizeLabel: prizeSet.some(Boolean) ? `${periodLabel(activePeriod)} prizes` : '',
    footer: `Updated ${updated} UTC · top ${rows.length || limit} · refreshes automatically`,
  });
  return { label, rows, attachment: new AttachmentBuilder(buffer, { name: 'leaderboard.png' }), period: activePeriod, prizes: prizeSet };
}
