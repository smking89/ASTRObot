import { env } from '../config/env.js';
import { createLogger } from '../core/logger.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { listLinks } from '../db/repositories/links.js';
import { credit } from './economy-service.js';
import { awardXp } from './progression-service.js';
import { claimPlaytimeMultiplier } from './voucher-service.js';
import { isStaffMember } from './staff-service.js';

const log = createLogger('playtime');

/**
 * Awards playtime coins on an interval to guild members with a verified console
 * link. Nitro boosters earn settings.economy.boosterMultiplier times the reward.
 */
export function startPlaytimeLoop(client, { intervalMs = env.economy.playtimeIntervalMs } = {}) {
  if (intervalMs < 60_000) {
    log.warn(`Refusing to start playtime loop below 60s (requested ${intervalMs}ms).`);
    return () => {};
  }

  let running = false;

  const tick = async () => {
    if (running) return;
    running = true;

    try {
      for (const guild of client.guilds.cache.values()) {
        const settings = getGuildSettings(guild.id);
        if (!settings.misc.playtimeCoinsEnabled) continue;

        const links = listLinks(guild.id);
        if (links.length === 0) continue;

        const members = await guild.members.fetch().catch(() => guild.members.cache);

        for (const link of links) {
          const member = members.get(link.user_id);
          if (!member || member.user.bot) continue;
          if (isStaffMember(member, guild.id)) continue;

          const booster = member.premiumSince ? Number(settings.economy.boosterMultiplier) || 1 : 1;
          // A held streak boost is consumed on the first payout and doubles it for 2h.
          const boost = claimPlaytimeMultiplier(guild.id, member.id);
          const multiplier = booster * boost;
          const reward = Math.max(0, Math.floor(Number(settings.economy.playtimeReward) * multiplier));
          const seconds = Math.floor(intervalMs / 1000);

          if (reward > 0) {
            credit({
              guildId: guild.id,
              userId: member.id,
              amount: reward,
              kind: 'playtime',
              metadata: { multiplier, intervalMs },
            });
          }

          awardXp({
            guildId: guild.id,
            userId: member.id,
            xp: Math.max(1, Math.floor(seconds / 600)),
            playtimeSeconds: seconds,
            member,
          });
        }
      }
    } catch (error) {
      log.error('Playtime cycle failed', error);
    } finally {
      running = false;
    }
  };

  const timer = setInterval(tick, intervalMs);
  timer.unref?.();
  log.info(`Playtime loop started (every ${Math.round(intervalMs / 1000)}s).`);

  return () => clearInterval(timer);
}
