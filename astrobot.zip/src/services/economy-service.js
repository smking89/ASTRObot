import { transaction } from '../db/index.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { addPlayerStat, adjustBalances, getAccount, getOrCreateAccount, incrementDailyClaims, setBalances, setStreak } from '../db/repositories/players.js';
import { addItem } from '../db/repositories/inventory.js';
import { claimBounties, totalBounty } from '../db/repositories/bounties.js';
import { ValidationError } from '../core/errors.js';
import { awardBadge } from './badge-service.js';
import { TIME } from '../config/constants.js';

/**
 * Economy rules live here, not in commands.
 *
 * Wallet = spendable cash, lost on death per settings.economy.deathPenaltyPercent.
 * Bank  = safe storage, untouched by death penalties.
 */

export function currencyOf(guildId) {
  return getGuildSettings(guildId).economy.currency;
}

/**
 * A wallet scope key is the account bucket a guild reads and writes. Local
 * servers keep their own bucket, global servers share one, and accepted
 * partnerships share a network bucket. The key is stored as the synthetic
 * `guild_id` of a players row so every existing balance path stays atomic.
 */
export function economyScopeKey(guildId, settings = getGuildSettings(guildId)) {
  const scope = settings?.economy?.scope;
  if (scope === 'global') return 'global';
  if (scope === 'partner' && settings?.economy?.partnerNetworkId) return `partner:${settings.economy.partnerNetworkId}`;
  return guildId;
}

export function economyScopeLabel(guildId, settings = getGuildSettings(guildId)) {
  const scope = settings?.economy?.scope;
  if (scope === 'global') return 'Global';
  if (scope === 'partner') return 'Partner network';
  return 'Local';
}

/** Maps a credit kind to the owner-controlled mint source it belongs to. */
export function mintSourceForKind(kind) {
  const value = String(kind ?? '').toLowerCase();
  if (['mint', 'give', 'give_clan', 'set_balance'].includes(value)) return 'manual';
  // Refunds, transfers and marketplace settlements move existing supply; they
  // never mint new currency.
  if (value.includes('refund') || value === 'transfer_in' || value === 'transfer_out') return null;
  if (value.startsWith('market_')) return null;
  if (/^(casino_|game_|challenge_|jackpot|bounty_|wager_)/.test(value)) return 'games';
  if (value.includes('daily')) return 'daily';
  if (value.startsWith('kill')) return 'kills';
  if (value.startsWith('playtime')) return 'playtime';
  if (value.startsWith('shop') || value === 'tip4serv') return 'shop';
  if (/^(referral|battlepass|leaderboard|voucher|event)/.test(value)) return 'events';
  return 'other';
}

function assertMintSource(kind, settings) {
  if (!settings?.economy?.minted) return;
  const source = mintSourceForKind(kind);
  if (source === 'manual') {
    throw new ValidationError('This server uses minted currency, so coins cannot be granted manually. Configure mint sources in /config → Economy.');
  }
  if (source && settings.economy.mintSources?.[source] !== true) {
    throw new ValidationError(`Minted currency is disabled for ${source} on this server.`);
  }
}

export function assertManualMintAllowed(guildId) {
  if (!getGuildSettings(guildId).economy.minted) return;
  throw new ValidationError('This server uses minted currency, so manual minting is disabled. Enable a game or event source in /config → Economy.');
}

/**
 * Moves a guild's local wallet rows into a shared scope. This runs when an
 * owner switches on global/partner currency or accepts a partnership, so
 * existing balances follow players instead of disappearing. Shared-scope rows
 * are never split back automatically: a later switch to local starts fresh.
 */
export function migrateLocalBalances(guildId, targetScopeKey) {
  if (!guildId || !targetScopeKey || guildId === targetScopeKey) return 0;

  return transaction((db) => {
    const rows = db.prepare('SELECT user_id, wallet, bank FROM players WHERE guild_id = ?').all(guildId);
    let moved = 0;

    for (const row of rows) {
      const wallet = Number(row.wallet) || 0;
      const bank = Number(row.bank) || 0;
      if (wallet === 0 && bank === 0) continue;

      db.prepare('INSERT OR IGNORE INTO players (guild_id, user_id, created_at) VALUES (?, ?, ?)')
        .run(targetScopeKey, row.user_id, Date.now());
      db.prepare('UPDATE players SET wallet = wallet + ?, bank = bank + ? WHERE guild_id = ? AND user_id = ?')
        .run(wallet, bank, targetScopeKey, row.user_id);
      db.prepare('UPDATE players SET wallet = 0, bank = 0 WHERE guild_id = ? AND user_id = ?')
        .run(guildId, row.user_id);
      moved += 1;
    }

    return moved;
  });
}

export function balances(guildId, userId) {
  const settings = getGuildSettings(guildId);
  const account = getOrCreateAccount(economyScopeKey(guildId, settings), userId);
  return {
    wallet: Number(account.wallet),
    bank: Number(account.bank),
    total: Number(account.wallet) + Number(account.bank),
    walletCap: settings.economy.walletCap,
    bankCap: settings.economy.bankCap,
    currency: settings.economy.currency,
    scope: settings.economy.scope ?? 'local',
    scopeLabel: economyScopeLabel(guildId, settings),
  };
}

/** Adds funds, clamping to the configured cap unless explicitly uncapped. */
export function credit({ guildId, userId, amount, kind = 'credit', target = 'wallet', respectCap = true, metadata = null }) {
  const value = Math.trunc(amount);
  if (!Number.isFinite(value) || value <= 0) throw new ValidationError('Credit amount must be positive.');

  const settings = getGuildSettings(guildId);
  assertMintSource(kind, settings);
  const scopeKey = economyScopeKey(guildId, settings);
  const account = getOrCreateAccount(scopeKey, userId);
  const cap = target === 'bank' ? settings.economy.bankCap : settings.economy.walletCap;
  const available = Math.max(0, cap - Number(account[target]));
  const credited = respectCap ? Math.min(value, available) : value;

  if (credited <= 0) return { account, credited: 0, overflow: value };

  const updated = adjustBalances(scopeKey, userId, { [target]: credited }, { kind, metadata });
  // Every arcade payout means a game was won, so the lifetime counter follows it.
  if (kind === 'casino_win') addPlayerStat(guildId, userId, 'game_wins', 1);
  return { account: updated, credited, overflow: value - credited };
}

/** Removes funds; throws when the balance cannot cover the amount. */
export function debit({ guildId, userId, amount, kind = 'debit', target = 'wallet', allowBank = false }) {
  const value = Math.trunc(amount);
  if (!Number.isFinite(value) || value <= 0) throw new ValidationError('Debit amount must be positive.');

  return transaction(() => {
    const scopeKey = economyScopeKey(guildId);
    const account = getOrCreateAccount(scopeKey, userId);
    const available = Number(account.wallet) + (allowBank ? Number(account.bank) : 0);

    if (available < value) {
      throw new ValidationError(
        `Insufficient funds — you need ${value - available} more ${currencyOf(guildId)}.`,
      );
    }

    const fromWallet = Math.min(Number(account.wallet), value);
    const fromBank = allowBank ? value - fromWallet : 0;

    return adjustBalances(
      scopeKey,
      userId,
      { wallet: -fromWallet, bank: -fromBank },
      { kind },
    );
  });
}

export function depositToBank(guildId, userId, amount) {
  return transaction(() => {
    const settings = getGuildSettings(guildId);
    const scopeKey = economyScopeKey(guildId, settings);
    const account = getOrCreateAccount(scopeKey, userId);
    const value = Math.trunc(amount);

    if (value <= 0) throw new ValidationError('Deposit must be positive.');
    if (Number(account.wallet) < value) throw new ValidationError('You do not have that much in your wallet.');

    const space = Math.max(0, settings.economy.bankCap - Number(account.bank));
    const moved = Math.min(value, space);
    if (moved <= 0) throw new ValidationError('Your bank is at its cap.');

    return {
      account: adjustBalances(scopeKey, userId, { wallet: -moved, bank: moved }, { kind: 'bank_deposit' }),
      moved,
      rejected: value - moved,
    };
  });
}

export function withdrawFromBank(guildId, userId, amount) {
  return transaction(() => {
    const settings = getGuildSettings(guildId);
    const scopeKey = economyScopeKey(guildId, settings);
    const account = getOrCreateAccount(scopeKey, userId);
    const value = Math.trunc(amount);

    if (value <= 0) throw new ValidationError('Withdrawal must be positive.');
    if (Number(account.bank) < value) throw new ValidationError('You do not have that much in your bank.');

    const space = Math.max(0, settings.economy.walletCap - Number(account.wallet));
    const moved = Math.min(value, space);
    if (moved <= 0) throw new ValidationError('Your wallet is at its cap.');

    return {
      account: adjustBalances(scopeKey, userId, { wallet: moved, bank: -moved }, { kind: 'bank_withdraw' }),
      moved,
      rejected: value - moved,
    };
  });
}

/** Peer-to-peer transfer with an optional percentage fee burned from the amount. */
export function transfer({ guildId, fromId, toId, amount }) {
  if (fromId === toId) throw new ValidationError('You cannot send coins to yourself.');

  return transaction(() => {
    const settings = getGuildSettings(guildId);
    const value = Math.trunc(amount);
    const feePercent = Number(settings.economy.transferFeePercent) || 0;

    const sender = debit({ guildId, userId: fromId, amount: value, kind: 'transfer_out' });

    const fee = Math.floor((value * feePercent) / 100);
    const received = value - fee;
    const { account: recipient, credited } = credit({
      guildId,
      userId: toId,
      amount: received,
      kind: 'transfer_in',
    });

    return { sender, recipient, sent: value, received: credited, fee };
  });
}

/** Admin supply minting — bypasses the cap only when explicitly requested. */
export function mint({ guildId, userId, amount, actorId, respectCap = true }) {
  assertManualMintAllowed(guildId);
  const result = credit({ guildId, userId, amount, kind: 'mint', respectCap });
  return { ...result, actorId };
}

export function burn({ guildId, userId, amount, actorId }) {
  const account = debit({ guildId, userId, amount, kind: 'burn' });
  return { account, actorId };
}

export function setBalance({ guildId, userId, wallet, bank }) {
  assertManualMintAllowed(guildId);
  return setBalances(economyScopeKey(guildId), userId, { wallet, bank });
}

/**
 * Amount a kill will remove from the victim wallet, without applying it. The
 * killfeed renders before settlement, so it snapshots the penalty up front.
 */
export function expectedDeathPenalty({ guildId, victimId, settings = getGuildSettings(guildId) }) {
  const percent = Number(settings.economy.deathPenaltyPercent) || 0;
  if (!victimId || percent <= 0) return 0;

  const victim = getAccount(economyScopeKey(guildId, settings), victimId);
  const wallet = Number(victim?.wallet) || 0;
  if (wallet <= 0) return 0;
  return Math.max(0, Math.min(Math.floor((wallet * percent) / 100), wallet));
}

/**
 * Applies kill economics and bounty payouts.
 * Returns a summary so the killfeed can render the numbers it caused.
 */
export function settleKill({ guildId, killerId, victimId, npc = false, settings = getGuildSettings(guildId) }) {
  if (!killerId || killerId === victimId) return null;

  const reward = npc ? Number(settings.economy.killRewardScientist) : Number(settings.economy.killRewardPlayer);
  const penaltyPercent = Number(settings.economy.deathPenaltyPercent) || 0;

  return transaction(() => {
    let paid = 0;
    if (reward > 0) paid = credit({ guildId, userId: killerId, amount: reward, kind: npc ? 'kill_npc' : 'kill_player' }).credited;

    let penalty = 0;
    if (!npc && penaltyPercent > 0) {
      const scopeKey = economyScopeKey(guildId, settings);
      const victim = getAccount(scopeKey, victimId);
      if (victim && Number(victim.wallet) > 0) {
        const raw = Math.floor((Number(victim.wallet) * penaltyPercent) / 100);
        const amount = Math.max(0, Math.min(raw, Number(victim.wallet)));
        if (amount > 0) {
          adjustBalances(scopeKey, victimId, { wallet: -amount }, { kind: 'death_penalty' });
          penalty = amount;
        }
      }
    }

    const bounty = npc ? { total: 0, count: 0 } : claimBounties({ guildId, targetId: victimId, claimedBy: killerId });
    if (bounty.total > 0) credit({ guildId, userId: killerId, amount: bounty.total, kind: 'bounty_claim' });

    return { reward: paid, penalty, bounty: bounty.total, bountyCount: bounty.count };
  });
}

/**
 * Seven-day streak track. Day 1 pays coins (the base payout below); the other
 * days also drop a voucher into the player's inventory, and the 10/25/50/100
 * lifetime-claim milestones add a crate.
 */
export const STREAK_REWARDS = Object.freeze([
  { day: 1, item: null, label: 'Coins drop' },
  { day: 2, item: 'wager_token', label: 'Wager token' },
  { day: 3, item: 'arcade_insurance', label: 'Arcade insurance pass' },
  { day: 4, item: 'playtime_boost', label: 'Playtime multiplier' },
  { day: 5, item: 'bounty_shield', label: 'Bounty protection' },
  { day: 6, item: 'lucky_key', label: 'Lucky box key' },
  { day: 7, item: 'weekly_chest', label: 'Weekly jackpot box' },
]);

export const CLAIM_MILESTONES = Object.freeze([
  { at: 10, item: 'milestone_10', label: 'Bronze crate' },
  { at: 25, item: 'milestone_25', label: 'Iron crate' },
  { at: 50, item: 'milestone_50', label: 'Gilded chest' },
  { at: 100, item: 'milestone_100', label: 'Elite vault' },
]);

/**
 * Daily login streak. Every server can define its own rules (`settings.streak`):
 * who may claim, what each of the seven days pays, and the badge for a full week.
 * The grace window is configurable too, so a server can be generous or strict.
 */
export function claimDaily(guildId, userId, { member = null } = {}) {
  const settings = getGuildSettings(guildId);
  const config = settings.streak ?? {};
  const account = getOrCreateAccount(guildId, userId);
  const streak = Number(account.streak ?? 0);

  if (config.enabled === false) {
    return { claimed: false, disabled: true, nextAt: null, streak };
  }

  const requiredRoleId = config.requiredRoleId || null;
  if (requiredRoleId && member && !member.roles?.cache?.has?.(requiredRoleId)) {
    return { claimed: false, blocked: 'role', roleId: requiredRoleId, nextAt: null, streak };
  }

  const minLevel = Number(config.minLevel ?? 0);
  if (minLevel > 0 && Number(account.level ?? 0) < minLevel) {
    return { claimed: false, blocked: 'level', minLevel, nextAt: null, streak };
  }

  const now = Date.now();
  const last = account.last_daily ? Number(account.last_daily) : 0;

  if (last && now - last < TIME.day) {
    return { claimed: false, nextAt: last + TIME.day, streak };
  }

  const graceDays = Math.max(1, Math.min(7, Number(config.graceHours ?? 48) / 24));
  const nextStreak = last && now - last <= TIME.day * graceDays ? streak + 1 : 1;
  const day = ((nextStreak - 1) % 7) + 1;
  const rewards = Array.isArray(config.rewards) && config.rewards.length ? config.rewards : STREAK_REWARDS;
  const reward = rewards[day - 1] ?? STREAK_REWARDS[day - 1];
  const base = Number(settings.economy.dailyStreakBase) || 100;
  const coins = Number(reward?.coins);
  const amount = Number.isFinite(coins) && coins > 0 ? Math.trunc(coins) : base + (nextStreak - 1) * 25;
  const bonusXp = 50 * nextStreak;

  const { account: updated, credited } = credit({ guildId, userId, amount, kind: 'daily_streak' });
  setStreak(guildId, userId, { streak: nextStreak, lastDaily: now });

  // The crate vouchers stay attached to the seven day cycle so the crate button
  // keeps working, but coins, kits and roles now come from the server's setup.
  const voucherReward = STREAK_REWARDS[day - 1];
  let voucher = null;
  if (voucherReward.item) {
    addItem({ guildId, userId, itemKey: `streak_${voucherReward.item}`, quantity: 1, metadata: { source: 'daily_streak', day } });
    voucher = `streak_${voucherReward.item}`;
  }

  const lifetime = incrementDailyClaims(guildId, userId);
  const milestone = CLAIM_MILESTONES.find((entry) => entry.at === lifetime) ?? null;
  if (milestone) {
    addItem({ guildId, userId, itemKey: milestone.item, quantity: 1, metadata: { source: 'claim_milestone', at: milestone.at } });
  }

  const badgeId = day === 7 ? config.badgeId || null : null;
  if (badgeId) {
    try {
      awardBadge({ guildId, userId, badgeId, awardedBy: null });
    } catch {
      // A deleted badge should never block the reward that was already paid.
    }
  }

  return {
    claimed: true,
    amount: credited,
    streak: nextStreak,
    bonusXp,
    day,
    voucher,
    kit: reward?.kit ?? null,
    roleId: reward?.roleId ?? null,
    label: reward?.label ?? STREAK_REWARDS[day - 1].label,
    badgeId,
    milestone: milestone?.item ?? null,
    account: updated,
    nextAt: now + TIME.day,
  };
}
