import { getGameConfig } from './games/game-config.js';
import { credit } from './economy-service.js';
import { rollInt } from '../utils/random.js';
import { formatCoins } from '../utils/format.js';

/**
 * Optional per-game prize pools.
 *
 * A pool is a list of prize amounts, not a shared balance. When a game is won
 * and its pool is enabled, the bot picks one amount at random and credits it as
 * a separate `game_prize_pool` transaction. Pools are disabled by default so
 * enabling one never changes the economy of an existing guild by accident.
 */
export function gamePrizePool(guildId, game) {
  const pool = getGameConfig(guildId).prizePools?.[game];
  if (!pool?.enabled || !Array.isArray(pool.prizes) || pool.prizes.length === 0) return null;
  return pool;
}

export function awardGamePrize({ guildId, userId, game, won = true }) {
  if (!won) return null;

  const pool = gamePrizePool(guildId, game);
  if (!pool) return null;

  const amount = pool.prizes[rollInt(0, pool.prizes.length - 1)];
  if (!(amount > 0)) return null;

  credit({
    guildId,
    userId,
    amount,
    kind: 'game_prize_pool',
    respectCap: false,
  });

  return { game, amount };
}

export function prizeLine(prize) {
  return prize ? `\n\n🎁 **Game prize pool:** +${formatCoins(prize.amount)}` : '';
}
