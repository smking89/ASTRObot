import { getTeamForUser } from '../db/repositories/teams.js';
import {
  deleteClanRankRow,
  insertClanRank,
  listClanRanks,
  updateClanRankRow,
} from '../db/repositories/badges.js';
import { CLAN_RANK_ICONS, hasBadgeIcon, iconChoices } from '../ui/badge-assets.js';
import { ValidationError } from '../core/errors.js';
import { titleCase } from '../utils/format.js';

/** Default clan ranks seed the database the first time a leader customises them. */
export const DEFAULT_CLAN_RANKS = Object.freeze([
  { key: 'leader', label: 'Leader', icon: 'leader' },
  { key: 'officer', label: 'Officer', icon: 'officer' },
  { key: 'member', label: 'Member', icon: 'member' },
]);

export const RANK_ICON_CHOICES = Object.freeze(iconChoices(CLAN_RANK_ICONS));

const MAX_RANKS = 20;

function defaults() {
  return DEFAULT_CLAN_RANKS.map((rank, position) => ({ ...rank, position }));
}

/** Ranks for a guild, falling back to the defaults until a leader edits them. */
export function clanRanks(guildId) {
  const rows = listClanRanks(guildId);
  return rows.length > 0 ? rows : defaults();
}

export function clanRank(guildId, key) {
  const ranks = clanRanks(guildId);
  const wanted = String(key ?? '').toLowerCase();
  return ranks.find((rank) => rank.key === wanted) ?? ranks.find((rank) => rank.key === 'member') ?? ranks[0] ?? null;
}

export function clanRankLabel(guildId, key) {
  return clanRank(guildId, key)?.label ?? titleCase(key);
}

/** Persists the default ranks so a custom rank never replaces the whole ladder. */
function ensureRankRows(guildId) {
  const rows = listClanRanks(guildId);
  if (rows.length > 0) return rows;

  for (const [position, rank] of DEFAULT_CLAN_RANKS.entries()) {
    insertClanRank({ guildId, ...rank, position });
  }
  return listClanRanks(guildId);
}

function slugify(label) {
  return String(label)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 20);
}

function cleanLabel(value) {
  const label = String(value ?? '').trim();
  if (label.length < 2 || label.length > 24) throw new ValidationError('Rank names must be 2-24 characters.');
  return label;
}

function cleanIcon(value) {
  const icon = String(value ?? '');
  if (!hasBadgeIcon(icon) || !CLAN_RANK_ICONS.includes(icon)) {
    throw new ValidationError('Pick one of the clan badge icons.');
  }
  return icon;
}

export function createClanRank(guildId, { label, icon }, { actorId = null } = {}) {
  const ranks = ensureRankRows(guildId);
  if (ranks.length >= MAX_RANKS) throw new ValidationError(`A clan can have at most ${MAX_RANKS} ranks.`);

  const name = cleanLabel(label);
  const badge = cleanIcon(icon);
  const base = slugify(name) || 'rank';
  let key = base;
  let suffix = 2;
  while (ranks.some((rank) => rank.key === key)) {
    key = `${base.slice(0, 17)}-${suffix}`;
    suffix += 1;
  }

  insertClanRank({ guildId, key, label: name, icon: badge, position: ranks.length });
  return { key, label: name, icon: badge, position: ranks.length, actorId };
}

export function updateClanRank(guildId, key, { label, icon }, { actorId = null } = {}) {
  const ranks = clanRanks(guildId);
  const rank = ranks.find((entry) => entry.key === String(key ?? '').toLowerCase());
  if (!rank) throw new ValidationError('No clan rank with that key.');

  const name = label === undefined || label === null || label === '' ? rank.label : cleanLabel(label);
  const badge = cleanIcon(icon ?? rank.icon);

  if (listClanRanks(guildId).length === 0) ensureRankRows(guildId);
  updateClanRankRow({ guildId, key: rank.key, label: name, icon: badge });
  return { ...rank, label: name, icon: badge, actorId };
}

export function deleteClanRank(guildId, key, { actorId = null } = {}) {
  const rank = clanRanks(guildId).find((entry) => entry.key === String(key ?? '').toLowerCase());
  if (!rank) throw new ValidationError('No clan rank with that key.');
  if (rank.key === 'leader') throw new ValidationError('The leader rank is required and cannot be deleted.');

  if (listClanRanks(guildId).length === 0) ensureRankRows(guildId);
  deleteClanRankRow(guildId, rank.key);
  return { ...rank, actorId };
}

/** Every clan rank/badge command is restricted to the clan leader. */
export function assertClanLeader(ctx) {
  const team = getTeamForUser(ctx.guildId, ctx.userId);
  if (!team) throw new ValidationError('You are not in a clan.');
  if (team.owner_id !== ctx.userId && team.member_rank !== 'leader') {
    throw new ValidationError('Only the clan leader can manage ranks and badge icons.');
  }
  return team;
}
