import { getGuildSettings } from '../db/repositories/guilds.js';
import {
  claimPendingKillfeedEvents,
  markKillfeedEventPosted,
  markKillfeedEventRetry,
  markKillfeedEventSkipped,
} from '../db/repositories/killfeed.js';
import { formatKillfeed, resolveIdentity } from './rcon/killfeed.js';
import { rankForPlayer } from './rcon/placeholders.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { iconAttachment, iconUrl } from '../ui/badge-assets.js';
import { truncate } from '../utils/format.js';
import { createLogger } from '../core/logger.js';

const log = createLogger('global-killfeed');

export const GLOBAL_KILLFEED_INTERVAL_MS = 5_000;
const MAX_ATTEMPTS = 5;
const MAX_AGE_MS = 24 * 60 * 60 * 1000;

/** Returns a reason when a queued row is not safe to publish. */
export function validateKillfeedEvent(row, { now = Date.now() } = {}) {
  if (!row?.guild_id) return 'missing guild id';
  if (!String(row.killer_name ?? '').trim()) return 'missing killer name';
  if (!String(row.victim_name ?? '').trim()) return 'missing victim name';
  if (String(row.killer_name).toLowerCase() === String(row.victim_name).toLowerCase() && !Number(row.npc)) {
    return 'killer and victim are the same player';
  }

  const occurredAt = Number(row.occurred_at);
  if (!Number.isFinite(occurredAt) || occurredAt > now + 60_000) return 'invalid kill timestamp';
  if (occurredAt < now - MAX_AGE_MS) return 'kill is older than the 24 hour replay window';
  return null;
}

function eventFromRow(row) {
  const coordinates =
    row.grid || row.x != null || row.y != null || row.z != null
      ? {
          x: row.x == null ? 0 : Number(row.x),
          y: row.y == null ? 0 : Number(row.y),
          z: row.z == null ? 0 : Number(row.z),
          grid: row.grid ?? undefined,
        }
      : null;

  return {
    kind: 'kill',
    guildId: row.guild_id,
    serverId: row.server_id,
    killer: { name: row.killer_name, externalId: row.killer_external_id },
    victim: { name: row.victim_name, externalId: row.victim_external_id },
    weapon: row.weapon ?? 'Unknown',
    coordinates,
    npc: Boolean(row.npc),
    stolen: Number(row.stolen) || 0,
    distance: row.distance == null ? null : Number(row.distance),
    raw: row.raw ?? '',
    at: Number(row.occurred_at),
  };
}

async function publishEvent(client, row) {
  const settings = getGuildSettings(row.guild_id);
  if (!settings?.killfeed?.globalEnabled) {
    markKillfeedEventSkipped(row.id, 'global killfeed disabled');
    return { outcome: 'skipped' };
  }

  if (row.npc && !settings.killfeed.showNpc) {
    markKillfeedEventSkipped(row.id, 'NPC kills are hidden');
    return { outcome: 'skipped' };
  }

  const channelId = settings.channels?.globalKillfeed;
  if (!channelId) {
    markKillfeedEventSkipped(row.id, 'no global killfeed channel configured');
    return { outcome: 'skipped' };
  }

  const event = eventFromRow(row);
  const identity = {
    killer: resolveIdentity(row.guild_id, event.killer.name),
    victim: resolveIdentity(row.guild_id, event.victim.name),
  };
  const content = formatKillfeed(event, {
    settings,
    serverLabel: row.server_label || 'server',
    identity,
    layout: settings.killfeed.globalLayout || settings.killfeed.layout,
  });
  if (!content) {
    markKillfeedEventSkipped(row.id, 'empty formatted killfeed');
    return { outcome: 'skipped' };
  }

  const channel = await client.channels.fetch(channelId).catch(() => null);
  if (!channel?.isTextBased?.()) throw new Error('global killfeed channel is missing or not text based');

  const rank = settings.killfeed.embed ? rankForPlayer(row.guild_id, identity.killer?.userId) : null;
  const payload = settings.killfeed.embed
    ? {
        embeds: [
          buildEmbed({
            description: content,
            color: COLORS.brand,
            thumbnail: rank ? iconUrl(rank.icon) : null,
          }),
        ],
        files: rank ? [iconAttachment(rank.icon)] : [],
        allowedMentions: { parse: [] },
      }
    : { content: truncate(content, 2000), allowedMentions: { parse: [] } };

  await channel.send(payload);
  markKillfeedEventPosted(row.id);
  return { outcome: 'posted' };
}

/**
 * Claims, validates and publishes queued local kills. Retries are bounded so a
 * deleted channel cannot create an endless five-second retry loop.
 */
export async function processGlobalKillfeed({ client, limit = 50, now = Date.now() } = {}) {
  const rows = claimPendingKillfeedEvents({ limit, now });
  const summary = { scanned: rows.length, posted: 0, skipped: 0, retried: 0, failed: 0, errors: [] };

  for (const row of rows) {
    const invalid = validateKillfeedEvent(row, { now });
    if (invalid) {
      markKillfeedEventSkipped(row.id, `validation: ${invalid}`);
      summary.skipped += 1;
      continue;
    }

    try {
      const result = await publishEvent(client, row);
      if (result.outcome === 'posted') summary.posted += 1;
      else summary.skipped += 1;
    } catch (error) {
      const delay = Math.min(30_000, 5_000 * Math.max(1, Number(row.attempts) || 1));
      const status = markKillfeedEventRetry({
        id: row.id,
        error: error.message,
        nextAttemptAt: now + delay,
        maxAttempts: MAX_ATTEMPTS,
      });
      if (status === 'failed') summary.failed += 1;
      else summary.retried += 1;
      summary.errors.push(`${row.id}: ${error.message}`);
    }
  }

  return summary;
}

/** Starts the five-second global publisher and returns an idempotent stop(). */
export function startGlobalKillfeedLoop({ client, intervalMs = GLOBAL_KILLFEED_INTERVAL_MS } = {}) {
  if (!client) return () => {};
  let running = false;

  const tick = async () => {
    if (running) return;
    running = true;
    try {
      const summary = await processGlobalKillfeed({ client });
      if (summary.posted > 0 || summary.skipped > 0 || summary.retried > 0 || summary.failed > 0) {
        log.info(
          `Global killfeed tick: ${summary.scanned} scanned, ${summary.posted} posted, ${summary.skipped} skipped, ${summary.retried} retried, ${summary.failed} failed.`,
        );
      }
    } catch (error) {
      log.error('Global killfeed tick failed', error);
    } finally {
      running = false;
    }
  };

  const timer = setInterval(tick, intervalMs);
  timer.unref?.();
  const first = setTimeout(tick, Math.min(1_000, intervalMs));
  first.unref?.();
  log.info(`Global killfeed loop started (every ${intervalMs}ms).`);

  return () => {
    clearInterval(timer);
    clearTimeout(first);
  };
}