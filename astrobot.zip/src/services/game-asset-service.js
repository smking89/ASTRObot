import { AttachmentBuilder } from 'discord.js';
import { existsSync, mkdirSync, unlinkSync, writeFileSync } from 'node:fs';
import { basename, dirname, join } from 'node:path';
import { env } from '../config/env.js';
import { uniqueId } from '../utils/random.js';
import { ValidationError } from '../core/errors.js';
import {
  deleteGameAssetRow,
  getGameAssetRow,
  listGameAssetRows,
  upsertGameAsset,
} from '../db/repositories/game-assets.js';

/**
 * Admin-uploaded game art.
 *
 * Every game can have a cover, win and loss image. UNO additionally accepts a
 * card back and a table background, which are baked into its generated board.
 */

export const GAME_ASSET_GAMES = Object.freeze([
  { id: 'blackjack', label: 'Blackjack' },
  { id: 'uno', label: 'UNO' },
  { id: 'dice', label: 'Dice' },
  { id: 'slots', label: 'Treasure Slots' },
  { id: 'wheel', label: 'Spin Wheel' },
  { id: 'tower', label: 'Tower Climb' },
  { id: 'mines', label: 'Mines' },
  { id: 'crash', label: 'Astro Crash' },
  { id: 'plinko', label: 'Plinko' },
  { id: 'roulette', label: 'Roulette' },
  { id: 'lootbox', label: 'Lootbox' },
  { id: 'defuse', label: 'The Defuse Wire' },
  { id: 'minefield', label: 'The Grid Minefield' },
  { id: 'ticket', label: 'The Ticket Jackpot' },
  { id: 'recycler', label: 'The Recycler Roulette' },
  { id: 'range', label: 'The Target Range' },
  { id: 'scratch-radiation', label: 'Radiation Rush' },
  { id: 'scratch-voltage', label: 'High-Voltage Grid' },
  { id: 'scratch-royal', label: 'The Royal Vault' },
  { id: 'scratch-scrap', label: 'The Scrap Pile' },
]);

export const GAME_ASSET_SLOTS = Object.freeze([
  { id: 'cover', label: 'Game cover' },
  { id: 'win', label: 'Win result art' },
  { id: 'lose', label: 'Loss result art' },
  { id: 'uno_back', label: 'UNO card back' },
  { id: 'uno_table', label: 'UNO table background' },
]);

export const GAME_ASSET_IDS = Object.freeze(GAME_ASSET_GAMES.map((game) => game.id));
export const GAME_ASSET_SLOT_IDS = Object.freeze(GAME_ASSET_SLOTS.map((slot) => slot.id));

const ALLOWED_TYPES = Object.freeze({ 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp' });
const MAX_UPLOAD_BYTES = 4 * 1024 * 1024;

export function gameAssetDirectory(guildId) {
  return join(dirname(env.databasePath), 'game-assets', String(guildId));
}

export function validateGameAssetUpload({ contentType, size } = {}) {
  if (Number(size) > MAX_UPLOAD_BYTES) throw new ValidationError('Game artwork must be 4 MB or smaller.');
  const extension = ALLOWED_TYPES[String(contentType ?? '').toLowerCase()];
  if (!extension) throw new ValidationError('Upload a PNG, JPEG or WebP image.');
  return extension;
}

export function assertGameAssetSlot(gameId, slot) {
  if (!GAME_ASSET_IDS.includes(String(gameId))) throw new ValidationError('Choose a valid game.');
  if (!GAME_ASSET_SLOT_IDS.includes(String(slot))) throw new ValidationError('Choose a valid artwork slot.');
  if (String(slot).startsWith('uno_') && gameId !== 'uno') {
    throw new ValidationError('Card back and table artwork can only be uploaded for UNO.');
  }
}

function publicAsset(row) {
  if (!row) return null;
  return {
    id: row.id,
    gameId: row.game_id,
    slot: row.slot,
    label: row.label,
    file: row.file,
    mime: row.mime,
    createdBy: row.created_by,
    createdAt: Number(row.created_at) || null,
    exists: existsSync(row.file),
  };
}

export function listGameAssets(guildId, gameId = null) {
  return listGameAssetRows(guildId)
    .filter((row) => !gameId || row.game_id === gameId)
    .map(publicAsset)
    .filter(Boolean);
}

export function getGameAsset(guildId, gameId, slot) {
  if (!guildId || !gameId || !slot) return null;
  const asset = publicAsset(getGameAssetRow(guildId, gameId, slot));
  return asset?.exists ? asset : null;
}

export function gameAssetPath(guildId, gameId, slot) {
  return getGameAsset(guildId, gameId, slot)?.file ?? null;
}

export function assetAttachment(asset) {
  if (!asset?.file) return null;
  return new AttachmentBuilder(asset.file, { name: basename(asset.file) });
}

export function assetUrl(asset) {
  return asset?.file ? `attachment://${basename(asset.file)}` : null;
}

export function saveGameAsset({ guildId, gameId, slot, label = null, buffer, contentType, actorId = null }) {
  assertGameAssetSlot(gameId, slot);
  const extension = validateGameAssetUpload({ contentType, size: buffer?.length });
  const previous = getGameAssetRow(guildId, gameId, slot);
  const id = uniqueId('gameasset');
  const directory = gameAssetDirectory(guildId);
  mkdirSync(directory, { recursive: true });

  const file = join(directory, `${id}.${extension}`);
  writeFileSync(file, buffer);
  const row = upsertGameAsset({
    id,
    guildId,
    gameId,
    slot,
    label: String(label ?? '').trim().slice(0, 80) || null,
    file,
    mime: String(contentType).toLowerCase(),
    createdBy: actorId,
  });

  if (previous?.file && previous.file !== file && existsSync(previous.file)) {
    try {
      unlinkSync(previous.file);
    } catch {
      // The replacement already succeeded; a stale file can be cleaned later.
    }
  }

  return publicAsset(row);
}

export function removeGameAsset({ guildId, gameId, slot }) {
  assertGameAssetSlot(gameId, slot);
  const row = getGameAssetRow(guildId, gameId, slot);
  if (!row) throw new ValidationError('No artwork is uploaded in that slot.');

  deleteGameAssetRow(guildId, gameId, slot);
  if (row.file && existsSync(row.file)) {
    try {
      unlinkSync(row.file);
    } catch {
      // The row is already gone; never fail a delete because of a stale file.
    }
  }
  return publicAsset(row);
}
