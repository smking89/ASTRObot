import { ButtonStyle } from 'discord.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { button, customId, row } from '../ui/components.js';
import { uniqueId } from '../utils/random.js';
import { truncate } from '../utils/format.js';
import { ValidationError } from '../core/errors.js';
import {
  closePollRecord,
  createPoll,
  duePolls,
  getPoll,
  getPollForGuild,
  listPollVoters,
  setPollMessage,
  toggleVote,
  uniqueVoterCount,
  voteCount,
  voteCounts,
} from '../db/repositories/polls.js';

export const MIN_POLL_OPTIONS = 2;
export const MAX_POLL_OPTIONS = 10;

export function parsePollOptions(input) {
  const options = String(input ?? '')
    .split(/[\n,]+/)
    .map((entry) => entry.trim())
    .filter(Boolean);
  if (options.length < MIN_POLL_OPTIONS || options.length > MAX_POLL_OPTIONS) {
    throw new ValidationError(`A poll needs between ${MIN_POLL_OPTIONS} and ${MAX_POLL_OPTIONS} answers.`);
  }
  if (options.some((entry) => entry.length > 80)) throw new ValidationError('Each poll answer must be 80 characters or fewer.');
  return options;
}

export function pollIsOpen(poll) {
  return Boolean(poll && poll.status === 'open' && Number(poll.ends_at) > Date.now());
}

function countMap(poll) {
  const map = new Map(voteCounts(poll.id).map((entry) => [entry.option_index, entry.votes]));
  return poll.options.map((_, index) => map.get(index) ?? 0);
}

function percent(votes, total) {
  return total > 0 ? Math.round((votes / total) * 100) : 0;
}

function bar(value, total) {
  const filled = total > 0 ? Math.round((value / total) * 12) : 0;
  return `${'█'.repeat(filled)}${'░'.repeat(12 - filled)}`;
}

function pollStatus(poll) {
  return pollIsOpen(poll) ? '🟢 Open' : '🔴 Closed';
}

function platformLabel(platform) {
  if (platform === 'playstation') return 'PSN';
  if (platform === 'xbox') return 'Xbox';
  return null;
}

/** One compact line per voter for the advanced admin view. */
export function voterLine(voter) {
  const platform = platformLabel(voter.platform);
  const handle = voter.gamertag ? `${voter.gamertag}${platform ? ` (${platform})` : ''}` : 'No linked gamertag';
  const team = voter.team_tag ? `[${voter.team_tag}] ${voter.team_name ?? 'Team'}` : 'No clan';
  const rank = voter.clan_rank ?? voter.team_rank ?? 'member';
  const rival = Number(voter.astro_score ?? 0).toLocaleString('en-US');
  return `<@${voter.user_id}> · ${handle} · Rival **${rival}** · ${team} · Rank **${rank}**`;
}

/** Public poll card. Identity data never appears here. */
export function pollEmbed(poll) {
  const counts = countMap(poll);
  const total = counts.reduce((sum, value) => sum + value, 0);
  const fields = poll.options.map((option, index) => ({
    name: `${index + 1}. ${truncate(option, 90)}`,
    value: `\`${bar(counts[index], total)}\` **${counts[index]}** · ${percent(counts[index], total)}%`,
    inline: false,
  }));

  fields.push(
    { name: 'Status', value: pollStatus(poll), inline: true },
    { name: 'Closes', value: pollIsOpen(poll) ? `<t:${Math.floor(Number(poll.ends_at) / 1000)}:R>` : 'Closed', inline: true },
    { name: 'Votes', value: String(total), inline: true },
    { name: 'Mode', value: poll.allow_multiple ? 'Multiple choices' : 'Single choice', inline: true },
  );

  return buildEmbed({
    title: pollIsOpen(poll) ? '📊 Live poll' : '📊 Poll closed',
    color: pollIsOpen(poll) ? COLORS.brand : COLORS.neutral,
    description: `## ${truncate(poll.question, 240)}\n${pollIsOpen(poll) ? 'Click an answer below to vote. Click it again to remove your vote.' : 'Voting is closed. Results are final.'}`,
    fields,
    footer: `Poll ${poll.id} · votes are saved by AstroBot`,
  });
}

/** Admin view; advanced adds one voter block per answer. */
export function pollAdminEmbed(poll, { advanced = false, notice = null } = {}) {
  const counts = countMap(poll);
  const ballots = voteCount(poll.id);
  const voters = listPollVoters(poll.id, poll.guild_id);
  const unique = uniqueVoterCount(poll.id);

  const fields = [
    { name: 'Status', value: pollStatus(poll), inline: true },
    { name: 'Closes', value: pollIsOpen(poll) ? `<t:${Math.floor(Number(poll.ends_at) / 1000)}:R>` : 'Closed', inline: true },
    { name: 'Ballots', value: `${ballots} · ${unique} unique voter(s)`, inline: true },
    { name: 'Mode', value: poll.allow_multiple ? 'Multiple choices' : 'Single choice', inline: true },
  ];

  for (const [index, option] of poll.options.entries()) {
    const optionVoters = voters.filter((voter) => voter.option_index === index);
    const value = advanced
      ? poll.anonymous
        ? 'Anonymous poll — identities are hidden.'
        : optionVoters.length
          ? truncate(optionVoters.map(voterLine).join('\n'), 500)
          : 'No votes yet.'
      : `**${counts[index]}** vote(s) · ${percent(counts[index], ballots)}%`;
    fields.push({
      name: `${index + 1}. ${truncate(option, 90)}${advanced ? ` · ${optionVoters.length}` : ''}`,
      value,
      inline: false,
    });
  }

  return buildEmbed({
    title: `📊 ${poll.question}`,
    color: pollIsOpen(poll) ? COLORS.brand : COLORS.neutral,
    description:
      notice ??
      (advanced
        ? 'Advanced analytics: voter identity, platform handle, rival score, clan tag, team tag and clan rank.'
        : 'Basic analytics: vote totals and percentages. Switch to **Advanced** for voter profiles.'),
    fields,
    footer: `Poll ${poll.id} · ${advanced ? 'advanced' : 'basic'} analytics`,
  });
}

export function pollActionRows(poll) {
  if (!pollIsOpen(poll)) return [];
  const rows = [];
  for (let start = 0; start < poll.options.length; start += 5) {
    rows.push(
      row(
        ...poll.options.slice(start, start + 5).map((option, offset) => {
          const index = start + offset;
          return button({
            id: customId('polls', 'vote', poll.id, index),
            label: `${index + 1}. ${truncate(option, 70)}`,
            style: ButtonStyle.Secondary,
          });
        }),
      ),
    );
  }
  rows.push(row(button({ id: customId('polls', 'results', poll.id), label: 'Results', emoji: '📊', style: ButtonStyle.Primary })));
  return rows;
}

export async function createPollMessage({
  client,
  guildId,
  channelId,
  creatorId,
  question,
  options,
  hours,
  allowMultiple = false,
  anonymous = false,
}) {
  const cleanQuestion = String(question ?? '').trim();
  if (!cleanQuestion) throw new ValidationError('A poll question is required.');
  if (cleanQuestion.length > 300) throw new ValidationError('Poll questions must be 300 characters or fewer.');
  const cleanOptions = parsePollOptions(options);
  const cleanHours = Number(hours);
  if (!Number.isFinite(cleanHours) || cleanHours < 1 || cleanHours > 768) {
    throw new ValidationError('Poll duration must be between 1 and 768 hours.');
  }

  const channel = await client?.channels?.fetch?.(channelId).catch(() => null);
  if (!channel?.isTextBased?.()) throw new ValidationError('That channel cannot receive a poll.');

  const poll = createPoll({
    id: uniqueId('poll'),
    guildId,
    channelId: channel.id,
    creatorId,
    question: cleanQuestion,
    options: cleanOptions,
    hours: cleanHours,
    allowMultiple,
    anonymous,
  });

  const message = await channel.send({
    embeds: [pollEmbed(poll)],
    components: pollActionRows(poll),
    allowedMentions: { parse: [] },
  });
  setPollMessage(poll.id, message.id);
  return { ...poll, message_id: message.id };
}

export async function refreshPollMessage(client, pollId) {
  const poll = getPoll(pollId);
  if (!poll) return null;
  if (!poll.message_id) return poll;

  const channel = await client?.channels?.fetch?.(poll.channel_id).catch(() => null);
  if (!channel?.messages?.fetch) return poll;
  const message = await channel.messages.fetch(poll.message_id).catch(() => null);
  if (!message) return poll;

  await message
    .edit({
      embeds: [pollEmbed(poll)],
      components: pollActionRows(poll),
      allowedMentions: { parse: [] },
    })
    .catch(() => null);
  return poll;
}

export async function voteOnPoll({ client, guildId, pollId, userId, optionIndex }) {
  const result = toggleVote({ pollId, guildId, userId, optionIndex });
  if (!result.poll) throw new ValidationError('That poll no longer exists.');
  if (result.invalid) throw new ValidationError('That answer is not part of this poll.');
  if (result.closed) {
    await refreshPollMessage(client, pollId);
    throw new ValidationError('That poll has closed.');
  }

  await refreshPollMessage(client, pollId);
  return result;
}

/**
 * Poll automation: closes every expired poll, refreshes its live message and
 * posts the final results so nobody has to press End.
 */
let closingPolls = false;

export async function closeExpiredPolls(client, now = Date.now()) {
  if (closingPolls) return 0;
  closingPolls = true;
  try {
    let closed = 0;
    for (const poll of duePolls(now)) {
      const ended = closePollRecord(poll.id);
      await refreshPollMessage(client, poll.id);
      const channel = await client?.channels?.fetch?.(poll.channel_id).catch(() => null);
      if (channel?.isTextBased?.() && ended) {
        await channel.send({ embeds: [pollEmbed(ended)], allowedMentions: { parse: [] } }).catch(() => null);
      }
      closed += 1;
    }
    return closed;
  } finally {
    closingPolls = false;
  }
}

export async function endPoll({ client, guildId, pollId }) {
  const poll = getPollForGuild(pollId, guildId);
  if (!poll) throw new ValidationError('That poll no longer exists.');
  if (!pollIsOpen(poll)) throw new ValidationError('That poll is already closed.');
  const closed = closePollRecord(pollId);
  await refreshPollMessage(client, pollId);
  return closed;
}
