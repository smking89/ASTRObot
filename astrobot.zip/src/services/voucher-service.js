import { ValidationError } from '../core/errors.js';
import { getDb } from '../db/index.js';
import { addItem, consumeItem, rollLoot } from '../db/repositories/inventory.js';
import { getLink } from '../db/repositories/links.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { runtime } from '../core/runtime.js';
import { buildItemCommand } from './rust-items.js';
import { getPref, setPref } from '../db/repositories/prefs.js';
import { credit } from './economy-service.js';

/**
 * Streak vouchers.
 *
 * Every voucher is a real inventory row (`streak_*`) that is consumed at the
 * moment its effect fires — never at claim time — so a player can hold one
 * until they want it. Times are stored in player_prefs, so they survive a
 * restart.
 */

export const VOUCHER_ITEMS = Object.freeze({
  wagerToken: 'streak_wager_token',
  insurance: 'streak_arcade_insurance',
  playtimeBoost: 'streak_playtime_boost',
  bountyShield: 'streak_bounty_shield',
  luckyKey: 'streak_lucky_key',
  weeklyChest: 'streak_weekly_chest',
});

export const CRATE_ITEMS = Object.freeze([
  VOUCHER_ITEMS.luckyKey,
  VOUCHER_ITEMS.weeklyChest,
  'milestone_10',
  'milestone_25',
  'milestone_50',
  'milestone_100',
]);

export const PLAYTIME_BOOST_MS = 2 * 3_600_000;
export const BOUNTY_SHIELD_MS = 24 * 3_600_000;

/** Tokens pay a bonus on the next challenge win; there is no house fee to waive. */
export const WAGER_BONUS_RATE = 0.1;

export function voucherCount(guildId, userId, itemKey) {
  const row = getDb()
    .prepare('SELECT quantity FROM inventory WHERE guild_id = ? AND user_id = ? AND item_key = ?')
    .get(guildId, userId, itemKey);
  return Number(row?.quantity ?? 0);
}

export function hasVoucher(guildId, userId, itemKey) {
  return voucherCount(guildId, userId, itemKey) > 0;
}

/** Removes one voucher. Returns false when the player does not hold it. */
export function consumeVoucher(guildId, userId, itemKey) {
  return consumeItem({ guildId, userId, itemKey, quantity: 1 });
}

/**
 * Wager token: adds WAGER_BONUS_RATE to the winner's pot. Consumed on settle.
 * (The challenge system pays the full pot, so there is no commission to waive;
 * the token pays the equivalent bonus instead.)
 */
export function applyWagerBonus(guildId, userId, pot) {
  if (!consumeVoucher(guildId, userId, VOUCHER_ITEMS.wagerToken)) return { pot, bonus: 0 };
  const bonus = Math.floor(Number(pot) * WAGER_BONUS_RATE);
  if (bonus <= 0) return { pot, bonus: 0 };
  credit({ guildId, userId, amount: bonus, kind: 'voucher_wager_bonus', respectCap: false });
  return { pot: pot + bonus, bonus };
}

/** Arcade insurance: refunds the stake when a Tower Climb round collapses. */
export function applyArcadeInsurance(guildId, userId, wager) {
  if (!consumeVoucher(guildId, userId, VOUCHER_ITEMS.insurance)) return 0;
  const refund = Math.max(0, Math.trunc(Number(wager) || 0));
  if (refund > 0) credit({ guildId, userId, amount: refund, kind: 'voucher_insurance_refund', respectCap: false });
  return refund;
}

/** Remaining playtime boost, in ms. */
export function playtimeBoostRemaining(guildId, userId, now = Date.now()) {
  const until = Number(getPref(guildId, userId, 'playtimeBoostUntil', 0)) || 0;
  return Math.max(0, until - now);
}

/**
 * Playtime multiplier for the next payout. A boost already running stays at 2x;
 * otherwise the first payout after a claim consumes the voucher and starts the
 * two-hour window.
 */
export function claimPlaytimeMultiplier(guildId, userId, now = Date.now()) {
  if (playtimeBoostRemaining(guildId, userId, now) > 0) return 2;
  if (!consumeVoucher(guildId, userId, VOUCHER_ITEMS.playtimeBoost)) return 1;
  setPref(guildId, userId, 'playtimeBoostUntil', now + PLAYTIME_BOOST_MS);
  return 2;
}

export function bountyShieldRemaining(guildId, userId, now = Date.now()) {
  const until = Number(getPref(guildId, userId, 'bountyShieldUntil', 0)) || 0;
  return Math.max(0, until - now);
}

/**
 * Bounty shield: a shielded target cannot be bountied. The first attempt after a
 * claim consumes the voucher and starts the 24 hour window, so the shield is
 * spent only when it actually protects someone.
 */
export function assertBountyAllowed(guildId, targetId, now = Date.now()) {
  const remaining = bountyShieldRemaining(guildId, targetId, now);
  if (remaining > 0) {
    throw new ValidationError(`That player is shielded for another ${Math.ceil(remaining / 3_600_000)}h.`);
  }

  if (consumeVoucher(guildId, targetId, VOUCHER_ITEMS.bountyShield)) {
    setPref(guildId, targetId, 'bountyShieldUntil', now + BOUNTY_SHIELD_MS);
    throw new ValidationError('Their bounty shield absorbed the hit — no bounty was placed.');
  }
}

const CRATE_TABLE = Object.freeze([
  { itemKey: 'kit:medkit', weight: 26, min: 1, max: 2 },
  { itemKey: 'kit:rifle.ak', weight: 18, min: 1, max: 1 },
  { itemKey: 'kit:metal.fragments', weight: 26, min: 100, max: 400 },
  { itemKey: 'kit:lowgrade.fuel', weight: 14, min: 50, max: 150 },
  { itemKey: 'coins', weight: 16, min: 250, max: 750 },
]);

/**
 * Opens a held crate. The lucky key yields one roll, the weekly chest three
 * rolls plus a coin payload, and milestone crates scale with their tier.
 */
export function openCrate(guildId, userId, itemKey = VOUCHER_ITEMS.luckyKey) {
  if (!CRATE_ITEMS.includes(itemKey)) throw new ValidationError('That item is not a crate.');
  if (!consumeVoucher(guildId, userId, itemKey)) throw new ValidationError('You do not hold that crate.');

  const rolls = itemKey === VOUCHER_ITEMS.weeklyChest ? 3 : 1;
  const rewards = [];
  let coins = itemKey === VOUCHER_ITEMS.weeklyChest ? 1_000 : 0;

  for (let index = 0; index < rolls; index += 1) {
    const roll = rollLoot(CRATE_TABLE);
    if (roll.itemKey === 'coins') {
      coins += roll.quantity;
      rewards.push({ kind: 'coins', quantity: roll.quantity });
    } else {
      addItem({ guildId, userId, itemKey: roll.itemKey, quantity: roll.quantity, metadata: { source: 'crate', crate: itemKey } });
      rewards.push({ kind: 'item', itemKey: roll.itemKey, quantity: roll.quantity });
    }
  }

  if (coins > 0) credit({ guildId, userId, amount: coins, kind: 'voucher_crate', respectCap: false });

  return { crate: itemKey, coins, rewards };
}

/**
 * Crate loot is more than an inventory row: kit items are pushed to the linked
 * gamertag over RCON, and anything that cannot be sent stays held in inventory
 * so nothing is silently lost.
 */
export async function deliverCrateLoot({ guildId, userId, rewards }) {
  const items = (rewards ?? []).filter((reward) => reward.kind === 'item');
  if (!items.length) return { delivered: 0, queued: 0, reason: 'coin-only crate' };

  const link = getLink(guildId, userId);
  const connection = runtime.rconManager?.connectionFor(guildId);
  if (!link?.gamertag || !connection) {
    return { delivered: 0, queued: items.length, reason: 'no linked gamertag or server offline' };
  }

  const template = getGuildSettings(guildId).shop.itemCommand;
  let delivered = 0;

  for (const item of items) {
    const shortname = String(item.itemKey).replace(/^kit:/, '');
    const command = buildItemCommand({
      gamertag: link.gamertag,
      shortname,
      name: shortname,
      quantity: Math.max(1, Math.trunc(Number(item.quantity) || 1)),
      template,
    });
    try {
      await connection.send(command);
      delivered += 1;
    } catch {
      // Left in inventory; the owner can deliver it by hand.
    }
  }

  return { delivered, queued: items.length - delivered };
}
