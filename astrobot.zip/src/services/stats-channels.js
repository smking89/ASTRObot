import { createLogger } from '../core/logger.js';
import { LIVE_STATS_STALE_MS, liveTotals, syncLiveStats } from './server-live-service.js';
import { clearStatsChannelState, getStatsChannelState, saveStatsChannelState } from '../db/repositories/player-stats.js';

const log = createLogger('stats');

/** The live line shown in the players/queue channels. */
const LINE = /^🌐\s*\d+\s*｜\s*⏰\s*\d+$/u;

export function statsLine(players, queue) {
  return `🌐 ${Math.max(0, Math.floor(players))}｜⏰ ${Math.max(0, Math.floor(queue))}`;
}

function statsChannel(guild, scope) {
  return [...guild.channels.cache.values()].find((channel) => {
    if (!channel?.isTextBased?.()) return false;
    const name = channel.name ?? '';
    if (!/player/i.test(name) || !/queue/i.test(name)) return false;
    const global = /global|network/i.test(name);
    return scope === 'global' ? global : !global;
  });
}

async function writeLine(client, channel, text, { guildId, scope }) {
  const saved = getStatsChannelState(channel.id);
  if (saved?.message_id) {
    const message = await channel.messages.fetch(saved.message_id).catch(() => null);
    if (message) {
      if (message.content !== text) await message.edit(text);
      saveStatsChannelState({ channelId: channel.id, guildId, scope, messageId: message.id, line: text });
      return;
    }
    clearStatsChannelState(channel.id);
  }

  const recent = await channel.messages.fetch({ limit: 20 }).catch(() => null);
  const existing = recent?.find?.(
    (message) => message.author?.id === client.user?.id && LINE.test(String(message.content ?? '').trim()),
  );

  if (existing) {
    if (existing.content !== text) await existing.edit(text);
    saveStatsChannelState({ channelId: channel.id, guildId, scope, messageId: existing.id, line: text });
    return;
  }

  const sent = await channel.send(text);
  saveStatsChannelState({ channelId: channel.id, guildId, scope, messageId: sent.id, line: text });
}

/**
 * Live population line for the global and server players/queue channels.
 *
 * The line is database-backed: RCON `serverinfo` snapshots are written to
 * `server_live_stats`, then the global and per-guild totals are read from that
 * table. Stale rows are excluded, and the message id for each channel is kept
 * in SQLite so restarts edit the existing message instead of posting another.
 */
export function startStatsChannelsLoop(
  client,
  { rconManager = null, intervalMs = 5000, staleMs = LIVE_STATS_STALE_MS } = {},
) {
  if (!client) return () => {};

  let running = false;

  const tick = async () => {
    if (running) return;
    running = true;

    try {
      if (rconManager) {
        try {
          syncLiveStats(rconManager);
        } catch (error) {
          log.warn('Live stats sync failed', error);
        }
      }

      const globalTotals = liveTotals({ staleMs });
      for (const guild of client.guilds.cache.values()) {
        const regional = statsChannel(guild, 'regional');
        const global = statsChannel(guild, 'global');
        if (!regional && !global) continue;

        if (regional) {
          const regionalTotals = liveTotals({ guildId: guild.id, staleMs });
          await writeLine(client, regional, statsLine(regionalTotals.players, regionalTotals.queue), {
            guildId: guild.id,
            scope: 'regional',
          });
        }
        if (global) {
          await writeLine(client, global, statsLine(globalTotals.players, globalTotals.queue), {
            guildId: guild.id,
            scope: 'global',
          });
        }
      }
    } catch (error) {
      log.warn('Stats channel update failed', error);
    } finally {
      running = false;
    }
  };

  const timer = setInterval(tick, intervalMs);
  timer.unref?.();
  tick().catch(() => null);
  log.info(`Live player stats updating from the database every ${Math.round(intervalMs / 1000)}s.`);

  return () => clearInterval(timer);
}
