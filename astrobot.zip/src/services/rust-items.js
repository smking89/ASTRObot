import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

/**
 * Rust Console Edition item catalog.
 *
 * The catalog is a 1,200+ item dump of the game's item definitions (display
 * name, shortname, ItemID, description, stack size and a rendered image). Shop
 * owners pick items by display name, so nobody ever has to remember a
 * shortname such as `rifle.ak`.
 */

const CATALOG_PATH = fileURLToPath(new URL('../data/rust-items.json', import.meta.url));

/** `inventory.giveto` is the Mod-tier command that hands an item to a player. */
export const DEFAULT_ITEM_COMMAND = 'inventory.giveto "{user}" "{shortname}" {quantity}';

let catalog = null;

function normalize(raw) {
  const name = String(raw.Name ?? '').trim();
  const shortname = String(raw['Short Name'] ?? '').trim();
  if (!name || !shortname) return null;

  const stackSize = Number.parseInt(String(raw['Default Stacksize'] ?? '1'), 10);
  const image = typeof raw.image === 'string' && raw.image.startsWith('http') ? raw.image : null;
  const category = String(raw.Category ?? '').trim() || 'Misc';

  return {
    name,
    shortname,
    itemId: raw.ItemID ? String(raw.ItemID) : null,
    description: String(raw['Item Description'] ?? '').trim() || null,
    stackSize: Number.isFinite(stackSize) && stackSize > 0 ? stackSize : 1,
    image,
    category,
    categoryLower: category.toLowerCase(),
    nameLower: name.toLowerCase(),
    shortnameLower: shortname.toLowerCase(),
  };
}

function load() {
  if (catalog) return catalog;

  const parsed = JSON.parse(readFileSync(CATALOG_PATH, 'utf8'));
  catalog = (parsed.items ?? []).map(normalize).filter(Boolean).sort((a, b) => a.name.localeCompare(b.name));
  return catalog;
}

/** Every catalog entry, sorted by display name. */
export function allRustItems() {
  return load();
}

/** Category names in catalog order, each with its item count. */
export function rustItemCategories() {
  const counts = new Map();
  for (const item of load()) counts.set(item.category, (counts.get(item.category) ?? 0) + 1);
  return [...counts.entries()]
    .map(([category, count]) => ({ category, count }))
    .sort((a, b) => b.count - a.count || a.category.localeCompare(b.category));
}

export function getRustItem(identifier) {
  const key = String(identifier ?? '').trim().toLowerCase();
  if (!key) return null;

  return load().find((item) => item.shortnameLower === key || item.nameLower === key) ?? null;
}

function scoreItem(item, query) {
  if (item.nameLower === query || item.shortnameLower === query) return 100;
  if (item.nameLower.startsWith(query)) return 80;
  if (item.shortnameLower.startsWith(query)) return 70;
  if (item.nameLower.includes(` ${query}`)) return 60;
  if (item.nameLower.includes(query)) return 50;
  if (item.shortnameLower.includes(query)) return 40;
  return 0;
}

/**
 * Ranked search by display name (and shortname as a fallback), best matches
 * first. Owners search "assault rifle" or "ak" — both find `rifle.ak`.
 */
export function searchRustItems(query, { limit = 25 } = {}) {
  const needle = String(query ?? '').trim().toLowerCase();
  if (needle.length === 0) return [];

  const scored = [];
  for (const item of load()) {
    const score = scoreItem(item, needle);
    if (score > 0) scored.push({ item, score });
  }

  scored.sort((a, b) => b.score - a.score || a.item.name.localeCompare(b.item.name));
  return scored.slice(0, Math.max(1, limit)).map((entry) => entry.item);
}

function sanitizeGamertag(value) {
  return String(value ?? '')
    .replaceAll('"', '')
    .replaceAll(/[\r\n]/g, ' ')
    .replaceAll(/\s+/g, ' ')
    .trim();
}

/**
 * Builds the RCON command that delivers a purchased item. Owners can override
 * the template in `/shop-panel` → Advanced, so other server forks (and the
 * `inventory.give` self-target variant) still work.
 */
export function buildItemCommand({ gamertag, shortname, quantity = 1, name = null, template = DEFAULT_ITEM_COMMAND }) {
  const amount = Math.max(1, Math.trunc(Number(quantity) || 1));
  const player = sanitizeGamertag(gamertag);
  if (!player) throw new Error('A linked gamertag is required to deliver items.');
  if (!shortname) throw new Error('An item shortname is required to deliver items.');

  return String(template ?? DEFAULT_ITEM_COMMAND)
    .replaceAll('{user}', player)
    .replaceAll('{player}', player)
    .replaceAll('{shortname}', String(shortname).replaceAll('"', ''))
    .replaceAll('{name}', String(name ?? shortname).replaceAll('"', ''))
    .replaceAll('{quantity}', String(amount))
    .trim();
}
