import { rollInt, chance } from '../../utils/random.js';

/**
 * Progressive Tower Climb.
 *
 * Each floor raises the multiplier but lowers the survival chance. The player
 * chooses to climb or cash out; cashing out pays floor multiplier * stake.
 */
export const TOWER_FLOORS = Object.freeze([
  { floor: 1, multiplier: 1.25, survival: 88 },
  { floor: 2, multiplier: 1.7, survival: 78 },
  { floor: 3, multiplier: 2.5, survival: 68 },
  { floor: 4, multiplier: 3.8, survival: 58 },
  { floor: 5, multiplier: 6, survival: 48 },
  { floor: 6, multiplier: 10, survival: 38 },
  { floor: 7, multiplier: 18, survival: 30 },
  { floor: 8, multiplier: 35, survival: 22 },
]);

export function startTower({ wager }) {
  return {
    game: 'tower',
    wager: Math.trunc(wager),
    floor: 0,
    status: 'climbing',
    payout: 0,
    trail: [],
    hazard: rollInt(1, 8),
  };
}

export function climb(state) {
  if (state.status !== 'climbing') return state;

  const next = TOWER_FLOORS[state.floor];
  const survived = chance(next.survival);

  state.trail.push({ floor: next.floor, survived, survival: next.survival });

  if (!survived) {
    state.status = 'fell';
    state.payout = 0;
    return state;
  }

  state.floor = next.floor;

  if (state.floor >= TOWER_FLOORS.length) {
    state.status = 'summit';
    state.payout = Math.floor(state.wager * TOWER_FLOORS.at(-1).multiplier);
  }

  return state;
}

export function cashOut(state) {
  if (state.status !== 'climbing' || state.floor === 0) return state;

  state.status = 'cashed_out';
  state.payout = Math.floor(state.wager * TOWER_FLOORS[state.floor - 1].multiplier);
  return state;
}

export function currentMultiplier(state) {
  if (state.floor === 0) return 1;
  return TOWER_FLOORS[state.floor - 1].multiplier;
}

export function nextFloor(state) {
  return TOWER_FLOORS[state.floor] ?? null;
}
