import { rollInt } from '../../utils/random.js';

/** Single-zero European roulette. Outside bets lose when the wheel lands on 0. */
export const ROULETTE_NUMBERS = Object.freeze([...Array(37).keys()]);
export const RED_NUMBERS = Object.freeze(
  new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]),
);

export function rouletteColor(number) {
  if (number === 0) return 'green';
  return RED_NUMBERS.has(number) ? 'red' : 'black';
}

function outsideBet(type, label, multiplier = 2) {
  return { type, label, multiplier };
}

/**
 * Accepts readable aliases so the modal stays simple:
 *   red, black, odd, even, low, high, dozen1, dozen2, dozen3, 0-36
 */
export function parseRouletteBet(raw) {
  const key = String(raw ?? '').trim().toLowerCase().replaceAll(/[\s_-]+/g, '');
  if (!key) throw new Error('Choose a roulette bet.');

  if (/^\d{1,2}$/.test(key)) {
    const number = Number(key);
    if (number >= 0 && number <= 36) {
      return { type: 'number', value: number, label: `Number ${number}`, multiplier: 36 };
    }
  }

  if (['red', 'black', 'odd', 'even', 'low', 'high'].includes(key)) {
    return outsideBet(key, key[0].toUpperCase() + key.slice(1), 2);
  }

  if (['zero', 'green'].includes(key)) {
    return { type: 'number', value: 0, label: 'Number 0', multiplier: 36 };
  }

  const dozen = /^(?:dozen)?([123])$|^(?:dozen)?(first|second|third)12$|^(?:dozen)?(1|2|3)(?:st|nd|rd)12$/.exec(key);
  if (dozen) {
    const index = Number(dozen[1] ?? (dozen[2] === 'first' ? 1 : dozen[2] === 'second' ? 2 : 3) ?? dozen[3]);
    const labels = ['1st dozen (1–12)', '2nd dozen (13–24)', '3rd dozen (25–36)'];
    return { type: 'dozen', value: index, label: labels[index - 1], multiplier: 3 };
  }

  if (/^(?:1-?12|first12|1st12)$/.test(key)) return { type: 'dozen', value: 1, label: '1st dozen (1–12)', multiplier: 3 };
  if (/^(?:13-?24|second12|2nd12)$/.test(key)) return { type: 'dozen', value: 2, label: '2nd dozen (13–24)', multiplier: 3 };
  if (/^(?:25-?36|third12|3rd12)$/.test(key)) return { type: 'dozen', value: 3, label: '3rd dozen (25–36)', multiplier: 3 };

  throw new Error('Bet must be red, black, odd, even, low, high, dozen1-3, or a number from 0 to 36.');
}

export function spinRoulette({ wager, bet }) {
  const option = parseRouletteBet(bet);
  const number = rollInt(0, 36);
  const color = rouletteColor(number);

  let won = false;
  if (option.type === 'number') {
    won = number === option.value;
  } else if (number !== 0) {
    if (option.type === 'red') won = color === 'red';
    else if (option.type === 'black') won = color === 'black';
    else if (option.type === 'odd') won = number % 2 === 1;
    else if (option.type === 'even') won = number % 2 === 0;
    else if (option.type === 'low') won = number >= 1 && number <= 18;
    else if (option.type === 'high') won = number >= 19 && number <= 36;
    else if (option.type === 'dozen') {
      const start = (option.value - 1) * 12 + 1;
      won = number >= start && number <= start + 11;
    }
  }

  return {
    game: 'roulette',
    wager: Math.trunc(wager),
    bet: option,
    betLabel: option.label,
    number,
    color,
    won,
    multiplier: option.multiplier,
    payout: won ? Math.trunc(wager) * option.multiplier : 0,
  };
}
