import { shuffle } from '../../utils/random.js';

/**
 * Mines: a 4x5 board. Players reveal tiles while the multiplier rises; hitting
 * a mine loses the stake, and cashing out locks the current multiplier.
 *
 * The grid is 20 tiles rather than 25 so Discord can render four button rows
 * plus a dedicated cash-out row within the five-action-row limit.
 */
export const MINES_TILES = 20;
export const MINES_COLUMNS = 5;
export const MINES_CHOICES = Object.freeze([3, 5, 10]);
export const MINES_MAX_MULTIPLIER = 100;
export const MINES_HOUSE_EDGE = 0.97;

function combination(n, k) {
  if (k < 0 || k > n) return 0;
  const size = Math.min(k, n - k);
  let result = 1;
  for (let index = 1; index <= size; index += 1) {
    result = (result * (n - size + index)) / index;
  }
  return result;
}

/** Fair survival multiplier with a 3% house edge, capped for the payout table. */
export function minesMultiplier(safeRevealed, mineCount) {
  const safe = Math.max(0, Math.trunc(Number(safeRevealed) || 0));
  if (safe === 0) return 1;

  const available = MINES_TILES - mineCount;
  if (safe > available) return MINES_MAX_MULTIPLIER;

  const fair = combination(MINES_TILES, safe) / combination(available, safe);
  return Math.max(1, Math.min(MINES_MAX_MULTIPLIER, Math.floor(fair * MINES_HOUSE_EDGE * 100) / 100));
}

export function startMines({ wager, mines = 3 }) {
  const mineCount = Math.trunc(Number(mines) || 3);
  if (!MINES_CHOICES.includes(mineCount)) {
    throw new Error(`Mines must be one of ${MINES_CHOICES.join(', ')}.`);
  }

  const minePositions = shuffle([...Array(MINES_TILES).keys()]).slice(0, mineCount);

  return {
    game: 'mines',
    wager: Math.trunc(wager),
    mineCount,
    minePositions,
    revealed: [],
    safeRevealed: 0,
    status: 'playing',
    multiplier: 1,
    payout: 0,
    hitIndex: null,
  };
}

export function revealMine(state, index) {
  if (state.status !== 'playing') return state;
  const tile = Number(index);
  if (!Number.isInteger(tile) || tile < 0 || tile >= MINES_TILES) return state;
  if (state.revealed.includes(tile)) return state;

  state.revealed.push(tile);

  if (state.minePositions.includes(tile)) {
    state.status = 'lost';
    state.hitIndex = tile;
    state.payout = 0;
    return state;
  }

  state.safeRevealed += 1;
  state.multiplier = minesMultiplier(state.safeRevealed, state.mineCount);

  if (state.safeRevealed >= MINES_TILES - state.mineCount) {
    state.status = 'cleared';
    state.payout = Math.floor(state.wager * state.multiplier);
  }

  return state;
}

export function cashOutMines(state) {
  if (state.status !== 'playing' || state.safeRevealed === 0) return state;

  state.status = 'cashed_out';
  state.payout = Math.floor(state.wager * state.multiplier);
  return state;
}
