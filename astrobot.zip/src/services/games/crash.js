import { rollInt } from '../../utils/random.js';

/**
 * Astro Crash: a rocket multiplier rises until it reaches a randomly generated
 * crash point. The player can cash out at any time; waiting too long loses the
 * stake. The round is driven by the shared crash loop so Discord can update the
 * message without a button press.
 */
export const CRASH_TICK_MS = 1_500;
export const CRASH_MAX_MS = 30_000;
export const CRASH_MAX_MULTIPLIER = 100;
export const CRASH_HOUSE_EDGE = 0.97;

const history = new Map();
const HISTORY_LIMIT = 12;

/** Smooth, accelerating curve: 1x at launch, roughly 28x after 30 seconds. */
export function crashMultiplierAt(elapsedMs) {
  const seconds = Math.max(0, Number(elapsedMs) || 0) / 1000;
  const raw = 1 + seconds * 0.55 + seconds * seconds * 0.012;
  return Math.floor(Math.min(CRASH_MAX_MULTIPLIER, raw) * 100) / 100;
}

function makeCrashPoint() {
  // P(crash >= x) = edge / x. This puts roughly a 3% chance on an immediate
  // 1.00x bust while keeping the long-tail multipliers possible.
  const roll = rollInt(0, 999_999) / 1_000_000;
  const point = CRASH_HOUSE_EDGE / (1 - roll);
  return Math.min(CRASH_MAX_MULTIPLIER, Math.max(1, Math.floor(point * 100) / 100));
}

export function startCrash({ wager, autoCashout = null, now = Date.now() }) {
  const target = autoCashout == null ? null : Math.round(Number(autoCashout) * 100) / 100;
  return {
    game: 'crash',
    wager: Math.trunc(wager),
    startedAt: now,
    status: 'running',
    crashPoint: makeCrashPoint(),
    multiplier: 1,
    cashoutMultiplier: null,
    autoCashout: Number.isFinite(target) && target > 1 ? target : null,
    payout: 0,
    endedAt: null,
  };
}

export function tickCrash(state, now = Date.now()) {
  if (state.status !== 'running') return state;

  const elapsed = Math.max(0, now - state.startedAt);
  const raw = crashMultiplierAt(elapsed);

  // The crash check comes before auto-cashout: a target above the crash point
  // must lose rather than pay out.
  if (elapsed >= CRASH_MAX_MS) {
    // A round that reaches the time limit is forced down at the multiplier it
    // actually reached, rather than showing a crash point it never touched.
    state.crashPoint = raw;
    state.status = 'crashed';
    state.multiplier = raw;
    state.payout = 0;
    state.endedAt = now;
    return state;
  }

  if (raw >= state.crashPoint) {
    state.status = 'crashed';
    state.multiplier = Math.min(raw, state.crashPoint);
    state.payout = 0;
    state.endedAt = now;
    return state;
  }

  state.multiplier = raw;

  if (state.autoCashout && raw >= state.autoCashout) {
    state.status = 'cashed_out';
    state.cashoutMultiplier = state.autoCashout;
    state.payout = Math.floor(state.wager * state.autoCashout);
    state.endedAt = now;
  }

  return state;
}

export function cashOutCrash(state, now = Date.now()) {
  if (state.status !== 'running') return state;

  const elapsed = Math.max(0, now - state.startedAt);
  const raw = crashMultiplierAt(elapsed);

  if (elapsed >= CRASH_MAX_MS || raw >= state.crashPoint) {
    return tickCrash(state, now);
  }

  state.multiplier = raw;
  state.status = 'cashed_out';
  state.cashoutMultiplier = raw;
  state.payout = Math.floor(state.wager * raw);
  state.endedAt = now;
  return state;
}

export function addCrashResult(guildId, { crashPoint, status = 'crashed', at = Date.now() }) {
  const entries = history.get(guildId) ?? [];
  entries.unshift({ crashPoint: Number(crashPoint), status, at });
  history.set(guildId, entries.slice(0, HISTORY_LIMIT));
  return history.get(guildId);
}

export function getCrashHistory(guildId) {
  return [...(history.get(guildId) ?? [])];
}
