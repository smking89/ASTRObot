import { rollInt } from '../../utils/random.js';

/** Spin wheel segments with house-edge weighted landing chances. */
export const WHEEL_SEGMENTS = Object.freeze([
  { multiplier: 0, weight: 26, label: '0x' },
  { multiplier: 0.5, weight: 20, label: '0.5x' },
  { multiplier: 1, weight: 20, label: '1x' },
  { multiplier: 1.5, weight: 14, label: '1.5x' },
  { multiplier: 2, weight: 10, label: '2x' },
  { multiplier: 3, weight: 6, label: '3x' },
  { multiplier: 5, weight: 3, label: '5x' },
  { multiplier: 10, weight: 1, label: '10x' },
]);

const totalWeight = WHEEL_SEGMENTS.reduce((sum, segment) => sum + segment.weight, 0);

export function spinWheel({ wager }) {
  let cursor = rollInt(1, totalWeight);
  let segment = WHEEL_SEGMENTS[0];

  for (const entry of WHEEL_SEGMENTS) {
    cursor -= entry.weight;
    if (cursor <= 0) {
      segment = entry;
      break;
    }
  }

  return {
    game: 'wheel',
    wager: Math.trunc(wager),
    segment: segment.label,
    multiplier: segment.multiplier,
    won: segment.multiplier > 1,
    payout: Math.floor(Math.trunc(wager) * segment.multiplier),
  };
}
