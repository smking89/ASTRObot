import { shuffle } from '../../utils/random.js';

/**
 * Scratch Cards: a 3x3 card generated server-side with exactly three target
 * symbols. Each scratch reveals one cell; the round ends as soon as the third
 * target is found. The earlier that happens, the higher the multiplier, which
 * keeps the nine-click card a real wager instead of a guaranteed full payout.
 *
 * The payout ladders are ordered by the click that completed the card, from
 * three scratches through nine. They intentionally return less than the stake
 * on late matches, so the house edge lives in the ladder rather than in a
 * hidden chance of losing after all three targets have been found.
 */
export const SCRATCH_SIZE = 9;
export const SCRATCH_COLUMNS = 3;
export const SCRATCH_TARGETS = 3;
export const SCRATCH_MAX_CLICKS = SCRATCH_SIZE;

export const SCRATCH_THEMES = Object.freeze({
  'scratch-radiation': Object.freeze({
    id: 'scratch-radiation',
    label: 'Radiation Rush',
    emoji: '☢️',
    setting: 'Vault-13',
    target: '💚',
    targetLabel: 'Hazmat tokens',
    junk: Object.freeze(['⚙️', '🛢️', '🔋', '🔩']),
    multipliers: Object.freeze([25, 7, 2, 1, 0.3, 0.1, 0.05]),
  }),
  'scratch-voltage': Object.freeze({
    id: 'scratch-voltage',
    label: 'High-Voltage Grid',
    emoji: '⚡',
    setting: 'Neon Syndicate',
    target: '🔋',
    targetLabel: 'Overclock cores',
    junk: Object.freeze(['🖲️', '🔌', '📼', '📟']),
    multipliers: Object.freeze([10, 5, 3, 1.5, 0.6, 0.2, 0.05]),
  }),
  'scratch-royal': Object.freeze({
    id: 'scratch-royal',
    label: 'The Royal Vault',
    emoji: '🏛️',
    setting: 'Crown Palace',
    target: '👑',
    targetLabel: 'Imperial crown marks',
    junk: Object.freeze(['🪙', '🔑', '📜', '🔒']),
    multipliers: Object.freeze([45, 5, 1.5, 0.5, 0.1, 0.05, 0.05]),
  }),
  'scratch-scrap': Object.freeze({
    id: 'scratch-scrap',
    label: 'The Scrap Pile',
    emoji: '🌲',
    setting: 'Outpost Saloon',
    target: '⛏️',
    targetLabel: 'Salvaged pickaxes',
    junk: Object.freeze(['🧱', '🪵', '🦴', '🧵']),
    multipliers: Object.freeze([30, 8, 2, 0.8, 0.2, 0.05, 0.05]),
  }),
});

export function getScratchTheme(themeId) {
  return SCRATCH_THEMES[String(themeId ?? '')] ?? null;
}

export function isScratchGame(gameId) {
  return Boolean(getScratchTheme(gameId));
}

/** Payout for a card completed on a given scratch number (3 through 9). */
export function scratchMultiplier(theme, clickCount) {
  const index = Math.max(0, Math.min(theme.multipliers.length - 1, Math.trunc(Number(clickCount) || SCRATCH_TARGETS) - SCRATCH_TARGETS));
  return theme.multipliers[index];
}

function buildGrid(theme) {
  const targets = new Set(shuffle([...Array(SCRATCH_SIZE).keys()]).slice(0, SCRATCH_TARGETS));
  const junk = shuffle([...theme.junk, ...theme.junk, ...theme.junk]);
  let cursor = 0;

  return {
    grid: Array.from({ length: SCRATCH_SIZE }, (_, index) => {
      if (targets.has(index)) return theme.target;
      const symbol = junk[cursor % junk.length];
      cursor += 1;
      return symbol;
    }),
    targetPositions: [...targets].sort((left, right) => left - right),
  };
}

export function startScratch({ wager, themeId }) {
  const theme = getScratchTheme(themeId);
  if (!theme) throw new Error(`Unknown scratch card "${themeId}".`);

  const stake = Math.trunc(Number(wager));
  if (!Number.isFinite(stake) || stake <= 0) throw new Error('A scratch card needs a positive wager.');

  const { grid, targetPositions } = buildGrid(theme);

  return {
    game: theme.id,
    themeId: theme.id,
    wager: stake,
    grid,
    targetPositions,
    revealed: Array(SCRATCH_SIZE).fill(false),
    clickCount: 0,
    targetsFound: 0,
    maxClicks: SCRATCH_MAX_CLICKS,
    status: 'playing',
    multiplier: 0,
    payout: 0,
    won: false,
  };
}

export function scratchCell(state, index) {
  if (state.status !== 'playing') return state;

  const theme = getScratchTheme(state.themeId);
  const cell = Number(index);
  if (!theme || !Number.isInteger(cell) || cell < 0 || cell >= SCRATCH_SIZE) return state;
  if (state.revealed[cell]) return state;

  state.revealed[cell] = true;
  state.clickCount += 1;

  if (state.grid[cell] === theme.target) state.targetsFound += 1;

  if (state.targetsFound >= SCRATCH_TARGETS) {
    state.status = 'matched';
    state.multiplier = scratchMultiplier(theme, state.clickCount);
    state.payout = Math.floor(state.wager * state.multiplier);
    state.won = state.payout > state.wager;
    return state;
  }

  // Defensive: every generated card has three targets, so this should never
  // fire. It keeps a corrupted session from staying clickable forever.
  if (state.clickCount >= SCRATCH_MAX_CLICKS) {
    state.status = 'lost';
    state.payout = 0;
    state.won = false;
  }

  return state;
}
