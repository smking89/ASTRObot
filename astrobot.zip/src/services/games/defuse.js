import { rollInt } from '../../utils/random.js';

/**
 * The Defuse Wire: six wires, one bomb. Every safe cut raises the multiplier;
 * the player may cash out after any safe cut. Cutting the live wire loses.
 */
export const DEFUSE_WIRES = 6;
export const DEFUSE_SAFE_WIRES = DEFUSE_WIRES - 1;
export const DEFUSE_HOUSE_EDGE = 0.97;
export const DEFUSE_MAX_MULTIPLIER = 100;

function combination(n, k) {
  if (k < 0 || k > n) return 0;
  const size = Math.min(k, n - k);
  let result = 1;
  for (let index = 1; index <= size; index += 1) {
    result = (result * (n - size + index)) / index;
  }
  return result;
}

/** Fair survival multiplier for one bomb, with a 3% house edge. */
export function defuseMultiplier(safeCuts) {
  const safe = Math.max(0, Math.trunc(Number(safeCuts) || 0));
  if (safe === 0) return 1;
  if (safe > DEFUSE_SAFE_WIRES) return DEFUSE_MAX_MULTIPLIER;

  const fair = combination(DEFUSE_WIRES, safe) / combination(DEFUSE_SAFE_WIRES, safe);
  return Math.max(1, Math.min(DEFUSE_MAX_MULTIPLIER, Math.floor(fair * DEFUSE_HOUSE_EDGE * 100) / 100));
}

export function startDefuse({ wager }) {
  return {
    game: 'defuse',
    wager: Math.trunc(wager),
    bombIndex: rollInt(0, DEFUSE_WIRES - 1),
    cuts: [],
    safeCuts: 0,
    status: 'live',
    multiplier: 1,
    payout: 0,
    explodedIndex: null,
  };
}

export function cutWire(state, index) {
  if (state.status !== 'live') return state;

  const wire = Number(index);
  if (!Number.isInteger(wire) || wire < 0 || wire >= DEFUSE_WIRES) return state;
  if (state.cuts.includes(wire)) return state;

  state.cuts.push(wire);

  if (wire === state.bombIndex) {
    state.status = 'exploded';
    state.explodedIndex = wire;
    state.payout = 0;
    return state;
  }

  state.safeCuts += 1;
  state.multiplier = defuseMultiplier(state.safeCuts);

  if (state.safeCuts >= DEFUSE_SAFE_WIRES) {
    state.status = 'cleared';
    state.payout = Math.floor(state.wager * state.multiplier);
  }

  return state;
}

export function cashOutDefuse(state) {
  if (state.status !== 'live' || state.safeCuts === 0) return state;
  state.status = 'cashed_out';
  state.payout = Math.floor(state.wager * state.multiplier);
  return state;
}
