import { rollInt } from '../../utils/random.js';

/** Three-reel recycler with weighted scrap and a 100x core jackpot. */
export const RECYCLER_SYMBOLS = Object.freeze([
  { key: 'scrap', label: '♻️', weight: 30, pair: 1, triple: 2 },
  { key: 'bolt', label: '🔩', weight: 25, pair: 1.2, triple: 3 },
  { key: 'gear', label: '⚙️', weight: 18, pair: 1.5, triple: 5 },
  { key: 'battery', label: '🔋', weight: 14, pair: 2, triple: 8 },
  { key: 'gem', label: '💎', weight: 8, pair: 4, triple: 20 },
  { key: 'core', label: '☢️', weight: 5, pair: 12, triple: 100 },
]);

const TOTAL_WEIGHT = RECYCLER_SYMBOLS.reduce((sum, symbol) => sum + symbol.weight, 0);

function spinReel() {
  let cursor = rollInt(1, TOTAL_WEIGHT);
  for (const symbol of RECYCLER_SYMBOLS) {
    cursor -= symbol.weight;
    if (cursor <= 0) return symbol;
  }
  return RECYCLER_SYMBOLS[0];
}

export function spinRecycler({ wager }) {
  const reels = [spinReel(), spinReel(), spinReel()];
  const counts = reels.reduce((map, symbol) => map.set(symbol.key, (map.get(symbol.key) ?? 0) + 1), new Map());
  const [topKey, topCount] = [...counts.entries()].sort((a, b) => b[1] - a[1])[0];
  const top = RECYCLER_SYMBOLS.find((symbol) => symbol.key === topKey) ?? RECYCLER_SYMBOLS[0];

  const multiplier = topCount === 3 ? top.triple : topCount === 2 ? top.pair : 0;
  const stake = Math.trunc(wager);

  return {
    game: 'recycler',
    wager: stake,
    reels: reels.map((symbol) => symbol.label),
    symbols: reels.map((symbol) => symbol.key),
    kind: topCount === 3 ? 'triple' : topCount === 2 ? 'pair' : 'none',
    multiplier,
    won: multiplier > 1,
    payout: Math.floor(stake * multiplier),
  };
}
