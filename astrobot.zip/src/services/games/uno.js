import { pick, rollInt, shuffle } from '../../utils/random.js';

/**
 * Two-player UNO (player vs. house bot).
 *
 * Simplified rules: no stacking, no scoring across rounds. Wild cards choose a
 * color on play (the bot picks its most common color). Function cards behave as
 * skip/reverse-equivalent (bot loses its turn) plus a forced draw for +2/+4.
 */
export const UNO_COLORS = Object.freeze(['red', 'yellow', 'green', 'blue']);
export const UNO_VALUES = Object.freeze(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'skip', 'reverse', 'draw2']);

export function createUnoDeck() {
  const cards = [];
  for (const color of UNO_COLORS) {
    for (const value of UNO_VALUES) {
      cards.push({ color, value, wild: false });
      if (value !== '0') cards.push({ color, value, wild: false });
    }
    cards.push({ color: 'wild', value: 'wild', wild: true });
    cards.push({ color: 'wild', value: 'draw4', wild: true });
  }
  return shuffle(cards);
}

export function startUno({ wager }) {
  const deck = createUnoDeck();
  const player = deck.splice(0, 7);
  const bot = deck.splice(0, 7);

  let top = deck.pop();
  while (top.wild) {
    deck.unshift(top);
    top = deck.pop();
  }

  return {
    game: 'uno',
    wager: Math.trunc(wager),
    deck,
    player,
    bot,
    discard: [top],
    activeColor: top.color,
    turn: 'player',
    status: 'playing',
    payout: 0,
    pendingWildIndex: null,
    message: 'Play a matching card or draw.',
  };
}

export function topCard(state) {
  return state.discard.at(-1);
}

export function canPlay(card, state) {
  const top = topCard(state);
  if (card.wild) return true;
  return card.color === state.activeColor || card.value === top.value;
}

export function playableIndexes(state) {
  return state.player.map((card, index) => (canPlay(card, state) ? index : -1)).filter((index) => index >= 0);
}

export function playCard(state, index, chosenColor = null) {
  if (state.status !== 'playing') return state;
  if (state.turn !== 'player') return state;

  const card = state.player[index];
  if (!card || !canPlay(card, state)) {
    state.message = 'That card does not match the pile.';
    return state;
  }

  state.player.splice(index, 1);
  state.pendingWildIndex = null;
  state.discard.push(card);
  state.activeColor = card.wild ? chosenColor ?? pick(UNO_COLORS) : card.color;

  if (state.player.length === 0) return finishUno(state, 'player');

  if (card.value === 'draw2' || card.value === 'draw4') {
    const drawCount = card.value === 'draw2' ? 2 : 4;
    state.bot.push(...state.deck.splice(0, drawCount));
    state.message = `Bot draws ${drawCount}.`;
    return state;
  }

  if (card.value === 'skip' || card.value === 'reverse') {
    state.message = 'Bot is skipped.';
    return state;
  }

  state.turn = 'bot';
  return botTurn(state);
}

export function drawForPlayer(state) {
  if (state.status !== 'playing' || state.turn !== 'player') return state;

  const card = state.deck.pop();
  if (!card) return finishUno(state, 'bot');

  state.pendingWildIndex = null;
  state.player.push(card);
  state.message = `You drew ${card.wild ? 'a wild card' : `${card.color} ${card.value}`}.`;
  state.turn = 'bot';
  return botTurn(state);
}

export function botTurn(state) {
  if (state.status !== 'playing') return state;

  let guard = 0;
  while (state.turn === 'bot' && guard < 20) {
    guard += 1;

    const playable = state.bot.findIndex((card) => canPlay(card, state));

    if (playable === -1) {
      const card = state.deck.pop();
      if (card) state.bot.push(card);
      state.turn = 'player';
      state.message = 'Bot drew a card. Your turn.';
      return state;
    }

    const [card] = state.bot.splice(playable, 1);
    state.discard.push(card);
    state.activeColor = card.wild ? dominantColor(state.bot) : card.color;

    if (state.bot.length === 0) return finishUno(state, 'bot');

    if (card.value === 'draw2' || card.value === 'draw4') {
      state.player.push(...state.deck.splice(0, card.value === 'draw2' ? 2 : 4));
      state.turn = 'player';
      state.message = `Bot played ${card.value}. You draw and your turn is lost.`;
      return state;
    }

    if (card.value === 'skip' || card.value === 'reverse') {
      state.turn = 'player';
      state.message = 'Bot played a skip. Your turn.';
      return state;
    }

    state.turn = 'player';
    state.message = `Bot played ${card.wild ? 'a wild card' : `${card.color} ${card.value}`}.`;
  }

  return state;
}

function dominantColor(hand) {
  const counts = new Map();
  for (const card of hand) {
    if (card.wild) continue;
    counts.set(card.color, (counts.get(card.color) ?? 0) + 1);
  }
  const sorted = [...counts.entries()].sort((a, b) => b[1] - a[1]);
  return sorted[0]?.[0] ?? UNO_COLORS[rollInt(0, 3)];
}

function finishUno(state, winner) {
  state.status = 'ended';
  state.winner = winner;
  state.payout = winner === 'player' ? Math.trunc(state.wager) * 2 : 0;
  state.message = winner === 'player' ? 'You played your last card and won!' : 'The bot went out first.';
  return state;
}
