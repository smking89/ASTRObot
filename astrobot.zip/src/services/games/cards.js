import { rollInt, shuffle } from '../../utils/random.js';

export const SUITS = Object.freeze([
  { key: 'spades', symbol: '♠', color: 'black' },
  { key: 'hearts', symbol: '♥', color: 'red' },
  { key: 'diamonds', symbol: '♦', color: 'red' },
  { key: 'clubs', symbol: '♣', color: 'black' },
]);

export const RANKS = Object.freeze([
  { key: 'A', value: 11, softValue: 1 },
  { key: '2', value: 2 },
  { key: '3', value: 3 },
  { key: '4', value: 4 },
  { key: '5', value: 5 },
  { key: '6', value: 6 },
  { key: '7', value: 7 },
  { key: '8', value: 8 },
  { key: '9', value: 9 },
  { key: '10', value: 10 },
  { key: 'J', value: 10 },
  { key: 'Q', value: 10 },
  { key: 'K', value: 10 },
]);

export function createDeck({ decks = 1 } = {}) {
  const cards = [];
  for (let deck = 0; deck < decks; deck += 1) {
    for (const suit of SUITS) {
      for (const rank of RANKS) {
        cards.push({ rank: rank.key, suit: suit.key, symbol: suit.symbol, color: suit.color, value: rank.value, softValue: rank.softValue });
      }
    }
  }
  return shuffle(cards);
}

/** Ace-aware hand total: 11 counts as 1 when the hand would bust. */
export function handValue(hand) {
  let total = hand.reduce((sum, card) => sum + card.value, 0);
  let aces = hand.filter((card) => card.rank === 'A').length;

  while (total > 21 && aces > 0) {
    total -= 10;
    aces -= 1;
  }

  return { total, soft: aces > 0 };
}

export function isBlackjack(hand) {
  return hand.length === 2 && handValue(hand).total === 21;
}

export function cardLabel(card) {
  return `${card.rank}${card.symbol}`;
}

export function handLabel(hand) {
  return hand.map(cardLabel).join(' ');
}

/** Card back variants selectable with /card-style (real artwork in assets/cards). */
export const CARD_BACKS = Object.freeze({
  classic: '🎴',
  astro: '🌌',
  nebula: '✨',
  custom: '🖼️',
});

export function draw(shoe, count = 1) {
  const drawn = [];
  for (let index = 0; index < count; index += 1) {
    if (shoe.length === 0) shoe.push(...createDeck());
    drawn.push(shoe.pop());
  }
  return drawn;
}

export function randomSuit() {
  return SUITS[rollInt(0, SUITS.length - 1)];
}
