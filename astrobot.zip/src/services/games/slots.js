import { rollInt } from '../../utils/random.js';

/** Weighted reels: rarer symbols pay more for three of a kind. */
export const SLOT_SYMBOLS = Object.freeze([
  { key: 'coin', label: '🪙', weight: 30, triple: 4, pair: 1.2 },
  { key: 'gem', label: '💎', weight: 20, triple: 6, pair: 1.5 },
  { key: 'chest', label: '🧰', weight: 15, triple: 10, pair: 2 },
  { key: 'rocket', label: '🚀', weight: 10, triple: 15, pair: 2.5 },
  { key: 'crown', label: '👑', weight: 5, triple: 25, pair: 4 },
  { key: 'astro', label: '🌟', weight: 2, triple: 100, pair: 10 },
]);

const totalWeight = SLOT_SYMBOLS.reduce((sum, symbol) => sum + symbol.weight, 0);

function spinReel() {
  let cursor = rollInt(1, totalWeight);
  for (const symbol of SLOT_SYMBOLS) {
    cursor -= symbol.weight;
    if (cursor <= 0) return symbol;
  }
  return SLOT_SYMBOLS[0];
}

export function spinSlots({ wager }) {
  const reels = [spinReel(), spinReel(), spinReel()];
  const counts = reels.reduce((map, symbol) => map.set(symbol.key, (map.get(symbol.key) ?? 0) + 1), new Map());

  let multiplier = 0;
  let kind = 'none';

  const [topKey, topCount] = [...counts.entries()].sort((a, b) => b[1] - a[1])[0];

  if (topCount === 3) {
    const symbol = SLOT_SYMBOLS.find((entry) => entry.key === topKey);
    multiplier = symbol.triple;
    kind = 'triple';
  } else if (topCount === 2) {
    const symbol = SLOT_SYMBOLS.find((entry) => entry.key === topKey);
    multiplier = symbol.pair;
    kind = 'pair';
  }

  return {
    game: 'slots',
    wager: Math.trunc(wager),
    reels: reels.map((symbol) => symbol.label),
    symbols: reels.map((symbol) => symbol.key),
    kind,
    multiplier,
    won: multiplier > 0,
    payout: Math.floor(Math.trunc(wager) * multiplier),
  };
}
