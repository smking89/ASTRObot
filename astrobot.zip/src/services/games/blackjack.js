import { createDeck, draw, handValue, isBlackjack } from './cards.js';

/**
 * Blackjack state machine. The engine never touches the database: it reports
 * `payout` (total return including stake) and the caller credits the winner.
 *
 * payout: 0 = loss, wager = push, wager * 2 = win, wager * 2.5 = natural.
 */
export function startRound({ wager, deckStyle = 'classic', shoe = createDeck({ decks: 4 }) }) {
  const player = draw(shoe, 2);
  const dealer = draw(shoe, 2);

  const state = {
    game: 'blackjack',
    wager: Math.trunc(wager),
    deckStyle,
    shoe,
    player,
    dealer,
    status: 'player',
    result: null,
    payout: 0,
    doubled: false,
    message: null,
    startedAt: Date.now(),
  };

  if (isBlackjack(player)) {
    if (isBlackjack(dealer)) return finish(state, 'push', 'Both had blackjack.');
    return finish(state, 'blackjack', 'Natural blackjack!');
  }

  if (isBlackjack(dealer)) return finish(state, 'dealer_blackjack', 'Dealer had blackjack.');

  return state;
}

export function hit(state) {
  if (state.status !== 'player') return state;

  state.player.push(...draw(state.shoe, 1));
  const total = handValue(state.player).total;

  if (total > 21) return finish(state, 'bust', 'Bust — over 21.');
  if (total === 21) return stand(state);

  return state;
}

export function stand(state) {
  if (state.status !== 'player') return state;

  let dealerTotal = handValue(state.dealer).total;
  while (dealerTotal < 17) {
    state.dealer.push(...draw(state.shoe, 1));
    dealerTotal = handValue(state.dealer).total;
  }

  const playerTotal = handValue(state.player).total;

  if (dealerTotal > 21) return finish(state, 'dealer_bust', 'Dealer busted.');
  if (playerTotal > dealerTotal) return finish(state, 'win', 'You beat the dealer.');
  if (playerTotal < dealerTotal) return finish(state, 'loss', 'Dealer wins.');
  return finish(state, 'push', 'Push — stake returned.');
}

export function double(state) {
  if (state.status !== 'player' || state.player.length !== 2) return state;

  state.wager *= 2;
  state.doubled = true;
  state.player.push(...draw(state.shoe, 1));

  if (handValue(state.player).total > 21) return finish(state, 'bust', 'Bust after doubling.');
  return stand(state);
}

function finish(state, result, message) {
  state.status = 'ended';
  state.result = result;
  state.message = message;

  switch (result) {
    case 'blackjack':
      state.payout = Math.floor(state.wager * 2.5);
      break;
    case 'win':
    case 'dealer_bust':
      state.payout = state.wager * 2;
      break;
    case 'push':
      state.payout = state.wager;
      break;
    default:
      state.payout = 0;
  }

  return state;
}

export function renderState(state) {
  const player = handValue(state.player);
  const dealer = handValue(state.dealer);

  return {
    player: state.player.map((card) => `${card.rank}${card.symbol}`),
    dealer:
      state.status === 'player'
        ? [`${state.dealer[0].rank}${state.dealer[0].symbol}`, '🎴']
        : state.dealer.map((card) => `${card.rank}${card.symbol}`),
    playerTotal: player.total,
    dealerTotal: state.status === 'player' ? `${dealer.total - state.dealer[1].value}+` : dealer.total,
    result: state.result,
    payout: state.payout,
    wager: state.wager,
    message: state.message,
  };
}
