import { getGuildSettings } from '../../db/repositories/guilds.js';
import { ValidationError } from '../../core/errors.js';

/** Games that can be played solo against the house. */
export const SOLO_GAME_IDS = Object.freeze([
  'blackjack',
  'uno',
  'dice',
  'slots',
  'wheel',
  'tower',
  'mines',
  'crash',
  'plinko',
  'roulette',
  'lootbox',
  'defuse',
  'minefield',
  'ticket',
  'recycler',
  'range',
  'scratch-radiation',
  'scratch-voltage',
  'scratch-royal',
  'scratch-scrap',
]);

/** Games that can be played as a 1v1 wager through the challenge system. */
export const MULTIPLAYER_GAME_IDS = Object.freeze(['dice', 'coinflip']);

export const DEFAULT_SOLO_GAMES = Object.freeze({
  blackjack: true,
  uno: true,
  dice: true,
  slots: true,
  wheel: true,
  tower: true,
  mines: true,
  crash: true,
  plinko: true,
  roulette: true,
  lootbox: true,
  defuse: true,
  minefield: true,
  ticket: true,
  recycler: true,
  range: true,
  'scratch-radiation': true,
  'scratch-voltage': true,
  'scratch-royal': true,
  'scratch-scrap': true,
});

export const DEFAULT_MULTIPLAYER_GAMES = Object.freeze({
  dice: true,
  coinflip: true,
});

export const PRIZE_POOL_GAME_IDS = Object.freeze([...SOLO_GAME_IDS, ...MULTIPLAYER_GAME_IDS]);

export const DEFAULT_PRIZE_POOLS = Object.freeze(
  Object.fromEntries(
    PRIZE_POOL_GAME_IDS.map((id) => [id, Object.freeze({ enabled: false, prizes: Object.freeze([]) })]),
  ),
);

export const DEFAULT_JACKPOT_TIERS = Object.freeze([
  { id: 'bronze', label: 'Bronze', cost: 100, entries: 1 },
  { id: 'silver', label: 'Silver', cost: 250, entries: 3 },
  { id: 'gold', label: 'Gold', cost: 500, entries: 7 },
]);

export const DEFAULT_JACKPOT_CONFIG = Object.freeze({
  seed: 2_500,
  min: 2_500,
  rakePercent: 2,
  milestoneThreshold: 10_000,
  milestoneChannelId: null,
  odds: Object.freeze({ slots: 4_000, wheel: 3_000, crash: 2_500 }),
  raffle: Object.freeze({
    enabled: true,
    prizeMode: 'pool',
    prizes: Object.freeze({ first: 5_000, second: 2_500, third: 1_000 }),
    poolShares: Object.freeze({ first: 50, second: 30, third: 20 }),
    tiers: DEFAULT_JACKPOT_TIERS,
  }),
});

export const MAX_WAGER = 100_000_000;

function integer(value, fallback, min, max) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, Math.trunc(parsed)));
}

function boolean(value, fallback) {
  return typeof value === 'boolean' ? value : fallback;
}

function gameMap(defaults, raw) {
  return Object.fromEntries(
    Object.entries(defaults).map(([id, fallback]) => [id, boolean(raw?.[id], fallback)]),
  );
}

function jackpotTiers(raw) {
  const source = Array.isArray(raw) && raw.length > 0 ? raw : DEFAULT_JACKPOT_TIERS;
  const seen = new Set();
  const tiers = [];

  for (const entry of source.slice(0, 25)) {
    const id = String(entry?.id ?? '').trim().toLowerCase();
    if (!/^[a-z0-9-]{1,20}$/.test(id) || seen.has(id)) continue;
    seen.add(id);
    const label = String(entry?.label ?? id).trim().slice(0, 40) || id;
    tiers.push({
      id,
      label,
      cost: integer(entry?.cost, 100, 1, MAX_WAGER),
      entries: integer(entry?.entries, 1, 1, 100_000),
    });
  }

  return tiers.length > 0 ? tiers : [...DEFAULT_JACKPOT_TIERS];
}

/**
 * Returns a normalized view of the per-guild casino settings. Stored values are
 * always merged over defaults so older guilds keep working after a deploy.
 */
export function getGameConfig(guildId) {
  const raw = getGuildSettings(guildId).games ?? {};
  const minWager = integer(raw.minWager, 1, 1, MAX_WAGER);
  const maxWager = integer(raw.maxWager, 100_000, minWager, MAX_WAGER);
  const jackpot = raw.jackpot ?? {};
  const jackpotOdds = jackpot.odds ?? {};
  const raffle = jackpot.raffle ?? {};
  const rafflePrizes = raffle.prizes ?? {};
  const raffleShares = raffle.poolShares ?? {};
  const prizePools = raw.prizePools ?? {};

  return {
    enabled: boolean(raw.enabled, true),
    minWager,
    maxWager,
    soloEnabled: boolean(raw.soloEnabled, true),
    multiplayerEnabled: boolean(raw.multiplayerEnabled, true),
    jackpot: {
      seed: integer(jackpot.seed, DEFAULT_JACKPOT_CONFIG.seed, 1, MAX_WAGER),
      min: integer(jackpot.min, DEFAULT_JACKPOT_CONFIG.min, 1, MAX_WAGER),
      rakePercent: integer(jackpot.rakePercent, DEFAULT_JACKPOT_CONFIG.rakePercent, 0, 25),
      milestoneThreshold: integer(jackpot.milestoneThreshold, DEFAULT_JACKPOT_CONFIG.milestoneThreshold, 0, MAX_WAGER),
      milestoneChannelId:
        typeof jackpot.milestoneChannelId === 'string' && /^\d{17,20}$/.test(jackpot.milestoneChannelId)
          ? jackpot.milestoneChannelId
          : null,
      odds: Object.fromEntries(
        Object.entries(DEFAULT_JACKPOT_CONFIG.odds).map(([game, fallback]) => [
          game,
          integer(jackpotOdds[game], fallback, 1, 100_000_000),
        ]),
      ),
      raffle: {
        enabled: boolean(raffle.enabled, DEFAULT_JACKPOT_CONFIG.raffle.enabled),
        prizeMode: raffle.prizeMode === 'fixed' ? 'fixed' : 'pool',
        prizes: {
          first: integer(rafflePrizes.first, DEFAULT_JACKPOT_CONFIG.raffle.prizes.first, 0, MAX_WAGER),
          second: integer(rafflePrizes.second, DEFAULT_JACKPOT_CONFIG.raffle.prizes.second, 0, MAX_WAGER),
          third: integer(rafflePrizes.third, DEFAULT_JACKPOT_CONFIG.raffle.prizes.third, 0, MAX_WAGER),
        },
        poolShares: {
          first: integer(raffleShares.first, DEFAULT_JACKPOT_CONFIG.raffle.poolShares.first, 0, 100),
          second: integer(raffleShares.second, DEFAULT_JACKPOT_CONFIG.raffle.poolShares.second, 0, 100),
          third: integer(raffleShares.third, DEFAULT_JACKPOT_CONFIG.raffle.poolShares.third, 0, 100),
        },
        tiers: jackpotTiers(raffle.tiers),
      },
    },
    prizePools: Object.fromEntries(
      PRIZE_POOL_GAME_IDS.map((id) => {
        const entry = prizePools[id] ?? {};
        const prizes = Array.isArray(entry.prizes)
          ? entry.prizes
              .slice(0, 20)
              .map((value) => integer(value, 0, 0, MAX_WAGER))
              .filter((value) => value > 0)
          : [];
        return [id, { enabled: boolean(entry.enabled, false) && prizes.length > 0, prizes }];
      }),
    ),
    solo: gameMap(DEFAULT_SOLO_GAMES, raw.solo),
    multiplayer: gameMap(DEFAULT_MULTIPLAYER_GAMES, raw.multiplayer),
  };
}

export function assertCasinoOpen(config) {
  if (!config.enabled) throw new ValidationError('The casino is closed right now. An administrator can reopen it from `/play` → Game Setup.');
}

export function assertSoloGame(config, gameId) {
  assertCasinoOpen(config);
  if (!config.soloEnabled) throw new ValidationError('Solo casino games are disabled by an administrator.');
  if (config.solo[gameId] === false) throw new ValidationError('That game is disabled by an administrator.');
}

export function assertMultiplayerGame(config, gameId) {
  assertCasinoOpen(config);
  if (!config.multiplayerEnabled) throw new ValidationError('1v1 challenges are disabled by an administrator.');
  if (config.multiplayer[gameId] === false) throw new ValidationError('That 1v1 game is disabled by an administrator.');
}

/**
 * Wager bounds for a player. `max` never exceeds their wallet, and a wallet
 * below the configured minimum is rejected before a modal is shown.
 */
export function wagerBounds(config, wallet) {
  const available = Math.max(0, Math.trunc(Number(wallet) || 0));
  if (available < config.minWager) {
    throw new ValidationError(`You need at least ${config.minWager} coins to play. Your wallet has ${available}.`);
  }

  return { min: config.minWager, max: Math.min(config.maxWager, available) };
}

export function wagerInRange(config, wager) {
  return Number.isInteger(wager) && wager >= config.minWager && wager <= config.maxWager;
}
