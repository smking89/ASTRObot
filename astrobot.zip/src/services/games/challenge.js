import { uniqueId } from '../../utils/random.js';
import { credit, debit } from '../economy-service.js';
import { addPlayerStat } from '../../db/repositories/players.js';
import { applyWagerBonus } from '../voucher-service.js';
import { ValidationError } from '../../core/errors.js';
import { createLogger } from '../../core/logger.js';

const log = createLogger('challenge');

/**
 * 1v1 wager escrow. The challenger's stake is debited immediately; the wager is
 * returned if the challenge expires, is declined or cancelled. Settlement pays
 * the winner the combined pot exactly once.
 */
const challenges = new Map();
const TTL_MS = 15 * 60 * 1000;

export function createChallenge({ guildId, channelId, challengerId, opponentId, wager, game = 'dice' }) {
  // Normalise at the service boundary. Commands pass Discord snowflakes as
  // strings, but buttons and older callers can carry numbers; a raw === check
  // let a self-challenge through when the two IDs had different types.
  challengerId = String(challengerId ?? '');
  opponentId = String(opponentId ?? '');
  if (!challengerId || !opponentId) throw new ValidationError('Both players are required.');
  if (challengerId === opponentId) throw new ValidationError('You cannot challenge yourself.');
  const amount = Math.trunc(wager);
  if (amount <= 0) throw new ValidationError('Wager must be positive.');

  const active = [...challenges.values()].find(
    (entry) =>
      entry.guildId === guildId &&
      entry.status === 'pending' &&
      (entry.challengerId === challengerId || entry.opponentId === challengerId),
  );
  if (active) throw new ValidationError('You already have an open challenge.');

  debit({ guildId, userId: challengerId, amount, kind: 'challenge_escrow' });

  const id = uniqueId('duel');
  const challenge = {
    id,
    guildId,
    channelId,
    challengerId,
    opponentId,
    wager: amount,
    game,
    status: 'pending',
    createdAt: Date.now(),
    expiresAt: Date.now() + TTL_MS,
    messageId: null,
  };

  challenges.set(id, challenge);
  return challenge;
}

export function getChallenge(id) {
  const challenge = challenges.get(id);
  if (!challenge) return null;
  if (challenge.status === 'pending' && challenge.expiresAt < Date.now()) {
    refundChallenge(challenge, 'expired');
    return challenges.get(id);
  }
  return challenge;
}

export function acceptChallenge(id, userId) {
  userId = String(userId ?? '');
  const challenge = getChallenge(id);
  if (!challenge) throw new ValidationError('That challenge no longer exists.');
  if (challenge.opponentId !== userId) throw new ValidationError('This challenge is not addressed to you.');
  if (challenge.challengerId === userId) throw new ValidationError('You cannot accept your own challenge.');
  if (challenge.status !== 'pending') throw new ValidationError(`That challenge is already ${challenge.status}.`);

  debit({ guildId: challenge.guildId, userId, amount: challenge.wager, kind: 'challenge_escrow' });
  challenge.status = 'accepted';
  challenge.acceptedAt = Date.now();

  return challenge;
}

export function declineChallenge(id, userId) {
  userId = String(userId ?? '');
  const challenge = getChallenge(id);
  if (!challenge) throw new ValidationError('That challenge no longer exists.');
  if (challenge.opponentId !== userId && challenge.challengerId !== userId) {
    throw new ValidationError('This challenge is not yours.');
  }
  if (challenge.status !== 'pending') throw new ValidationError(`That challenge is already ${challenge.status}.`);

  refundChallenge(challenge, 'declined');
  return challenge;
}

export function settleChallenge(id, winnerId) {
  winnerId = String(winnerId ?? '');
  const challenge = getChallenge(id);
  if (!challenge) throw new ValidationError('That challenge no longer exists.');
  if (challenge.status !== 'accepted') throw new ValidationError('That challenge has not been accepted yet.');
  if (winnerId !== challenge.challengerId && winnerId !== challenge.opponentId) {
    throw new ValidationError('The winner must be one of the two challenge players.');
  }

  const pot = challenge.wager * 2;
  challenge.status = 'settled';
  challenge.winnerId = winnerId;
  challenge.settledAt = Date.now();

  credit({ guildId: challenge.guildId, userId: winnerId, amount: pot, kind: 'challenge_win', respectCap: false });
  addPlayerStat(challenge.guildId, winnerId, 'rival_wins', 1);

  // A held wager token pays a bonus on the win and is consumed here.
  const { pot: total, bonus } = applyWagerBonus(challenge.guildId, winnerId, pot);
  challenge.bonus = bonus;

  log.info(`Challenge ${id} settled: ${winnerId} won ${total}${bonus ? ` (token bonus ${bonus})` : ''}.`);

  return { challenge, pot: total, bonus };
}

function refundChallenge(challenge, status) {
  challenge.status = status;
  challenge.closedAt = Date.now();
  credit({ guildId: challenge.guildId, userId: challenge.challengerId, amount: challenge.wager, kind: 'challenge_refund' });
}

/** Called by the housekeeping loop. */
export function sweepChallenges() {
  let expired = 0;
  for (const challenge of challenges.values()) {
    if (challenge.status === 'pending' && challenge.expiresAt < Date.now()) {
      refundChallenge(challenge, 'expired');
      expired += 1;
    }
  }
  for (const [id, challenge] of challenges) {
    if (challenge.status !== 'pending' && challenge.status !== 'accepted' && Date.now() - challenge.closedAt > 3_600_000) {
      challenges.delete(id);
    }
  }
  return expired;
}
