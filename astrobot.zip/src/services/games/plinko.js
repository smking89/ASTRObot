import { rollInt } from '../../utils/random.js';

/**
 * Plinko: eight rows produce nine buckets. The multiplier table is symmetric
 * and tuned to about a 2% house edge on a uniform left/right drop.
 */
export const PLINKO_ROWS = 8;
export const PLINKO_MULTIPLIERS = Object.freeze([18, 4.5, 1.5, 0.4, 0.2, 0.4, 1.5, 4.5, 18]);

export function dropPlinko({ wager }) {
  const path = [];
  let bucket = 0;

  for (let row = 0; row < PLINKO_ROWS; row += 1) {
    const right = rollInt(0, 1);
    path.push(right);
    bucket += right;
  }

  const multiplier = PLINKO_MULTIPLIERS[bucket];
  return {
    game: 'plinko',
    wager: Math.trunc(wager),
    path,
    bucket,
    multiplier,
    won: multiplier > 1,
    payout: Math.floor(Math.trunc(wager) * multiplier),
  };
}
