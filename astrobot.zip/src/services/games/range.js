import { chance, shuffle } from '../../utils/random.js';

/**
 * The Target Range: choose a weapon and fire five shots at a 5x5 target. Each
 * hit adds that weapon's score multiplier; a clean miss loses the stake.
 */
export const RANGE_SHOTS = 5;
export const RANGE_WEAPONS = Object.freeze({
  pistol: { label: 'Pistol', accuracy: 45, multiplier: 0.38, emoji: '🔫' },
  smg: { label: 'SMG', accuracy: 58, multiplier: 0.28, emoji: '🔫' },
  rifle: { label: 'Rifle', accuracy: 70, multiplier: 0.21, emoji: '🎯' },
  sniper: { label: 'Sniper', accuracy: 82, multiplier: 0.15, emoji: '🔭' },
});

export const RANGE_WEAPON_CHOICES = Object.freeze(
  Object.entries(RANGE_WEAPONS).map(([key, weapon]) => ({ key, ...weapon })),
);

export function fireRange({ wager, weapon }) {
  const key = String(weapon ?? '').trim().toLowerCase();
  const selected = RANGE_WEAPONS[key];
  if (!selected) throw new Error(`Unknown weapon "${weapon}".`);

  const shots = Array.from({ length: RANGE_SHOTS }, () => chance(selected.accuracy));
  const hitCount = shots.filter(Boolean).length;
  const multiplier = Math.round(hitCount * selected.multiplier * 100) / 100;
  const impacts = shuffle([...Array(25).keys()]).slice(0, hitCount);
  const stake = Math.trunc(wager);

  return {
    game: 'range',
    wager: stake,
    weapon: key,
    weaponLabel: selected.label,
    accuracy: selected.accuracy,
    shots,
    impacts,
    hits: hitCount,
    multiplier,
    won: hitCount > 0,
    payout: Math.floor(stake * multiplier),
  };
}
