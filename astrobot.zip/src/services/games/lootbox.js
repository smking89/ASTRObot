import { rollInt } from '../../utils/random.js';

/**
 * Lootbox: open a weighted crate for coins.
 *
 * Weights are in thousandths. The table is tuned to a ~3% house edge while
 * leaving a tiny mythic tail so a lucky crate can still pay 100x.
 */
export const LOOTBOX_TABLE = Object.freeze([
  { key: 'empty', label: 'Empty crate', emoji: '📭', multiplier: 0, weight: 190 },
  { key: 'common', label: 'Scrap cache', emoji: '📦', multiplier: 0.5, weight: 300 },
  { key: 'uncommon', label: 'Salvage crate', emoji: '🧰', multiplier: 1, weight: 360 },
  { key: 'rare', label: 'Rare cache', emoji: '💎', multiplier: 1.5, weight: 100 },
  { key: 'epic', label: 'Epic crate', emoji: '🏆', multiplier: 3, weight: 40 },
  { key: 'legendary', label: 'Legendary crate', emoji: '👑', multiplier: 10, weight: 9 },
  { key: 'mythic', label: 'Mythic drop', emoji: '🌟', multiplier: 100, weight: 1 },
]);

const TOTAL_WEIGHT = LOOTBOX_TABLE.reduce((sum, entry) => sum + entry.weight, 0);

export function openLootbox({ wager }) {
  const stake = Math.trunc(wager);
  let cursor = rollInt(1, TOTAL_WEIGHT);
  let reward = LOOTBOX_TABLE[0];

  for (const entry of LOOTBOX_TABLE) {
    cursor -= entry.weight;
    if (cursor <= 0) {
      reward = entry;
      break;
    }
  }

  return {
    game: 'lootbox',
    wager: stake,
    loot: reward,
    multiplier: reward.multiplier,
    won: reward.multiplier > 0,
    payout: Math.floor(stake * reward.multiplier),
  };
}
