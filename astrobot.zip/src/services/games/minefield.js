import { shuffle } from '../../utils/random.js';

/**
 * The Grid Minefield: a 6x6 board with three hidden traps. Every safe reveal
 * raises the multiplier; cash out before a trap ends the round.
 */
export const MINEFIELD_SIZE = 36;
export const MINEFIELD_COLUMNS = 6;
export const MINEFIELD_MINES = 3;
export const MINEFIELD_HOUSE_EDGE = 0.97;
export const MINEFIELD_MAX_MULTIPLIER = 100;

function combination(n, k) {
  if (k < 0 || k > n) return 0;
  const size = Math.min(k, n - k);
  let result = 1;
  for (let index = 1; index <= size; index += 1) {
    result = (result * (n - size + index)) / index;
  }
  return result;
}

export function minefieldMultiplier(safeRevealed, mineCount = MINEFIELD_MINES) {
  const safe = Math.max(0, Math.trunc(Number(safeRevealed) || 0));
  if (safe === 0) return 1;

  const available = MINEFIELD_SIZE - mineCount;
  if (safe > available) return MINEFIELD_MAX_MULTIPLIER;

  const fair = combination(MINEFIELD_SIZE, safe) / combination(available, safe);
  return Math.max(1, Math.min(MINEFIELD_MAX_MULTIPLIER, Math.floor(fair * MINEFIELD_HOUSE_EDGE * 100) / 100));
}

export function startMinefield({ wager, mines = MINEFIELD_MINES }) {
  const mineCount = Math.max(1, Math.min(MINEFIELD_SIZE - 1, Math.trunc(Number(mines) || MINEFIELD_MINES)));
  const positions = shuffle([...Array(MINEFIELD_SIZE).keys()]).slice(0, mineCount);

  return {
    game: 'minefield',
    wager: Math.trunc(wager),
    mineCount,
    minePositions: positions,
    revealed: [],
    safeRevealed: 0,
    status: 'playing',
    multiplier: 1,
    payout: 0,
    hitIndex: null,
  };
}

export function revealMinefield(state, index) {
  if (state.status !== 'playing') return state;

  const cell = Number(index);
  if (!Number.isInteger(cell) || cell < 0 || cell >= MINEFIELD_SIZE) return state;
  if (state.revealed.includes(cell)) return state;

  state.revealed.push(cell);

  if (state.minePositions.includes(cell)) {
    state.status = 'blown';
    state.hitIndex = cell;
    state.payout = 0;
    return state;
  }

  state.safeRevealed += 1;
  state.multiplier = minefieldMultiplier(state.safeRevealed, state.mineCount);

  if (state.safeRevealed >= MINEFIELD_SIZE - state.mineCount) {
    state.status = 'cleared';
    state.payout = Math.floor(state.wager * state.multiplier);
  }

  return state;
}

export function cashOutMinefield(state) {
  if (state.status !== 'playing' || state.safeRevealed === 0) return state;
  state.status = 'cashed_out';
  state.payout = Math.floor(state.wager * state.multiplier);
  return state;
}
