import { rollDie } from '../../utils/random.js';

/**
 * Two dice, high/low or exact seven.
 * Payouts are tuned to the true odds of 2d6.
 */
export const DICE_CHOICES = Object.freeze({
  low: { label: 'Under 7', payout: 2, condition: (total) => total < 7 },
  seven: { label: 'Exactly 7', payout: 5, condition: (total) => total === 7 },
  high: { label: 'Over 7', payout: 2, condition: (total) => total > 7 },
});

export function rollDice({ wager, choice }) {
  const option = DICE_CHOICES[choice];
  if (!option) throw new Error(`Unknown dice choice "${choice}".`);

  const dice = [rollDie(6), rollDie(6)];
  const total = dice[0] + dice[1];
  const won = option.condition(total);

  return {
    game: 'dice',
    wager: Math.trunc(wager),
    choice,
    choiceLabel: option.label,
    dice,
    total,
    won,
    payout: won ? Math.trunc(wager) * option.payout : 0,
    multiplier: option.payout,
  };
}
