import { createLogger } from '../core/logger.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { dueTasks, listTasks, markTaskRun, upsertTask, setTaskEnabled, removeTask } from '../db/repositories/tasks.js';
import { sweepExpiredCases } from '../db/repositories/moderation.js';
import { sweepStale } from '../db/repositories/lfg.js';
import { sweepSessions } from '../core/registry.js';
import { sweepLimits } from '../core/rate-limit.js';
import { sweepAnnouncements } from './announcement-service.js';

const log = createLogger('scheduler');

/**
 * Background loops:
 *  - due scheduled_tasks rows (console commands, broadcasts, wipes, night vote)
 *  - rotating messages per guild
 *  - housekeeping (expired punishments, stale LFG posts, session/rate-limit maps)
 */
export function startScheduler(client, { rconManager, tickMs = 15_000 } = {}) {
  let running = false;
  let lastHousekeeping = 0;

  const executeTask = async (task) => {
    try {
      if (task.kind === 'command') {
        const server = rconManager?.connectionFor(task.guild_id);
        if (!server) {
          log.warn(`Task ${task.name} skipped: no connected RCON server for ${task.guild_id}.`);
          return;
        }
        await server.send(task.command);
      } else if (task.kind === 'broadcast') {
        const payload = task.payload ? JSON.parse(task.payload) : {};
        const channelId = payload.channelId ?? getGuildSettings(task.guild_id).channels.broadcasts;
        const channel = channelId ? await client.channels.fetch(channelId).catch(() => null) : null;
        if (channel?.isTextBased()) await channel.send(payload.content ?? task.command ?? '').catch(() => null);
      } else if (task.kind === 'log') {
        log.info(`[task:${task.guild_id}] ${task.command}`);
      }
    } catch (error) {
      log.error(`Task "${task.name}" failed`, error);
    } finally {
      markTaskRun(task.id, Number(task.interval_seconds));
    }
  };

  const tick = async () => {
    if (running) return;
    running = true;

    try {
      for (const task of dueTasks()) {
        await executeTask(task);
      }

      const announced = await sweepAnnouncements({ client, rconManager });
      if (announced > 0) log.info(`Delivered ${announced} scheduled announcement(s).`);

      if (Date.now() - lastHousekeeping > 60_000) {
        lastHousekeeping = Date.now();
        const expiredCases = sweepExpiredCases();
        if (expiredCases > 0) log.info(`Expired ${expiredCases} moderation case(s).`);

        for (const guild of client.guilds.cache.values()) {
          const settings = getGuildSettings(guild.id);
          sweepStale(guild.id, Number(settings.lfg.staleHours) * 3_600_000);
        }

        sweepSessions();
        sweepLimits();
      }
    } catch (error) {
      log.error('Scheduler tick failed', error);
    } finally {
      running = false;
    }
  };

  const timer = setInterval(tick, tickMs);
  timer.unref?.();
  log.info(`Scheduler started (tick ${tickMs}ms).`);

  return {
    stop: () => clearInterval(timer),
    executeTask,
    listTasks,
    upsertTask,
    setTaskEnabled,
    removeTask,
  };
}

/**
 * Night skip voting: RCON chat lines containing "!night" count as a vote.
 * Returns true when the guild crosses its threshold and the command was sent.
 */
export function createNightVoteTracker({ thresholdPercent = 0.6, minVotes = 3 } = {}) {
  const votes = new Map();

  return {
    addVote(guildId, userId) {
      const set = votes.get(guildId) ?? new Set();
      const isNew = !set.has(userId);
      set.add(userId);
      votes.set(guildId, set);
      return { votes: set.size, isNew };
    },
    reset(guildId) {
      votes.delete(guildId);
    },
    shouldSkip(guildId, onlineCount) {
      const count = votes.get(guildId)?.size ?? 0;
      if (count < minVotes) return false;
      return count >= Math.ceil(Math.max(1, onlineCount) * thresholdPercent);
    },
    snapshot(guildId) {
      return votes.get(guildId)?.size ?? 0;
    },
  };
}
