import { createCanvas, GlobalFonts, loadImage } from '@napi-rs/canvas';
import { fileURLToPath } from 'node:url';
import { canPlay } from './games/uno.js';

/**
 * Renders a real UNO table from the Card Asset pack. The sheet contains a
 * 13-column value grid across four color rows, plus back, wild and draw-four
 * cards in the top row. Admin uploads can replace the card back and table.
 */

const WIDTH = 1200;
const HEIGHT = 730;
const UNO_SHEET_PATH = fileURLToPath(new URL('../../assets/cards/uno_cards.png', import.meta.url));
const DEFAULT_TABLE_PATH = fileURLToPath(new URL('../../assets/cards/table_green.png', import.meta.url));

const COL_X = Object.freeze([17, 199, 381, 564, 746, 928, 1110, 1292, 1474, 1656, 1838, 2020, 2205]);
const COL_W = Object.freeze([170, 171, 171, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170]);
const ROW_Y = Object.freeze([19, 298, 574, 854, 1134]);
const ROW_H = 261;

const VALUE_COL = Object.freeze({
  1: 0,
  2: 1,
  3: 2,
  4: 3,
  5: 4,
  6: 5,
  7: 6,
  8: 7,
  9: 8,
  0: 9,
  draw2: 10,
  skip: 11,
  reverse: 12,
});
const COLOR_ROW = Object.freeze({ yellow: 1, blue: 2, red: 3, green: 4 });

let fontsReady = false;
function prepareFonts() {
  if (fontsReady) return;
  fontsReady = true;
  try {
    GlobalFonts.registerFromPath('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 'UnoSans');
    GlobalFonts.registerFromPath('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 'UnoSansBold');
  } catch {
    // Fall back to the system font when the optional font is missing.
  }
}

const fontFamily = (bold) => {
  const wanted = bold ? 'UnoSansBold' : 'UnoSans';
  return GlobalFonts.families?.some((entry) => entry.family === wanted) ? wanted : 'sans-serif';
};

let sheetPromise = null;
function loadUnoSheet() {
  if (!sheetPromise) sheetPromise = loadImage(UNO_SHEET_PATH).catch(() => null);
  return sheetPromise;
}

function roundRect(ctx, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + width, y, x + width, y + height, r);
  ctx.arcTo(x + width, y + height, x, y + height, r);
  ctx.arcTo(x, y + height, x, y, r);
  ctx.arcTo(x, y, x + width, y, r);
  ctx.closePath();
}

function cardLabel(card) {
  if (card.value === 'wild') return 'WILD';
  if (card.value === 'draw4') return '+4';
  if (card.value === 'draw2') return '+2';
  if (card.value === 'skip') return '⊘';
  if (card.value === 'reverse') return '↺';
  return String(card.value);
}

function sheetPosition(card) {
  if (card.wild) return { col: card.value === 'draw4' ? 2 : 1, row: 0 };
  const row = COLOR_ROW[card.color];
  const col = VALUE_COL[card.value];
  if (row === undefined || col === undefined) return null;
  return { col, row };
}

function drawCrop(ctx, sheet, col, row, x, y, width, height) {
  ctx.save();
  roundRect(ctx, x, y, width, height, width * 0.1);
  ctx.clip();
  ctx.drawImage(sheet, COL_X[col], ROW_Y[row], COL_W[col], ROW_H, x, y, width, height);
  ctx.restore();
}

function drawFallbackFace(ctx, card, x, y, width, height) {
  const colors = { red: '#e53b44', yellow: '#f4c542', green: '#35b56a', blue: '#2378c9', wild: '#191919' };
  const color = colors[card.color] ?? colors.wild;
  ctx.save();
  roundRect(ctx, x, y, width, height, width * 0.1);
  ctx.fillStyle = '#f7f7f7';
  ctx.fill();
  ctx.fillStyle = card.wild ? '#191919' : color;
  roundRect(ctx, x + 6, y + 6, width - 12, height - 12, width * 0.08);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.ellipse(x + width / 2, y + height / 2, width * 0.42, height * 0.35, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = color;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = `900 ${Math.round(width * 0.26)}px ${fontFamily(true)}`;
  ctx.fillText(cardLabel(card), x + width / 2, y + height / 2);
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
  ctx.restore();
}

function drawFaceCard(ctx, card, x, y, width, height, sheet) {
  const position = sheetPosition(card);
  if (sheet && position) {
    drawCrop(ctx, sheet, position.col, position.row, x, y, width, height);
  } else {
    drawFallbackFace(ctx, card, x, y, width, height);
  }

  ctx.lineWidth = Math.max(2, Math.round(width * 0.025));
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.92)';
  roundRect(ctx, x, y, width, height, width * 0.1);
  ctx.stroke();
}

function drawCardBack(ctx, x, y, width, height, backImage, sheet) {
  ctx.save();
  roundRect(ctx, x, y, width, height, width * 0.1);
  ctx.clip();
  if (backImage) {
    ctx.drawImage(backImage, x, y, width, height);
  } else if (sheet) {
    ctx.drawImage(sheet, COL_X[0], ROW_Y[0], COL_W[0], ROW_H, x, y, width, height);
  } else {
    ctx.fillStyle = '#121212';
    ctx.fillRect(x, y, width, height);
    ctx.fillStyle = '#e53b44';
    ctx.beginPath();
    ctx.ellipse(x + width / 2, y + height / 2, width * 0.42, height * 0.35, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = `900 ${Math.round(width * 0.17)}px ${fontFamily(true)}`;
    ctx.fillText('UNO', x + width / 2, y + height / 2 + 2);
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
  }
  ctx.restore();

  ctx.strokeStyle = 'rgba(255, 255, 255, 0.92)';
  ctx.lineWidth = Math.max(2, Math.round(width * 0.025));
  roundRect(ctx, x, y, width, height, width * 0.1);
  ctx.stroke();
}

function drawStatus(ctx, state, top, playableCount) {
  const colors = { red: '#e53b44', yellow: '#f4c542', green: '#35b56a', blue: '#2378c9', wild: '#191919' };
  ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
  roundRect(ctx, 42, 664, WIDTH - 84, 36, 10);
  ctx.fill();

  ctx.fillStyle = colors[state.activeColor] ?? colors.wild;
  ctx.beginPath();
  ctx.arc(66, 682, 9, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#d7e5f6';
  ctx.font = `600 15px ${fontFamily(false)}`;
  const message = state.status === 'ended'
    ? state.winner === 'player' ? 'You won the hand.' : 'The house won the hand.'
    : state.pendingWildIndex != null
      ? 'Choose a color for your wild card.'
      : state.turn === 'player'
        ? `${playableCount} playable card${playableCount === 1 ? '' : 's'} · your turn`
        : 'House turn';
  ctx.fillText(message, 84, 688);

  ctx.textAlign = 'right';
  ctx.fillStyle = '#ffffff';
  ctx.font = `700 14px ${fontFamily(true)}`;
  ctx.fillText(`Pile: ${top.wild ? 'WILD' : `${top.color} ${cardLabel(top)}`}`, WIDTH - 60, 688);
  ctx.textAlign = 'left';
}

function drawBackground(ctx, table) {
  if (table) {
    const scale = Math.max(WIDTH / table.width, HEIGHT / table.height);
    const drawWidth = table.width * scale;
    const drawHeight = table.height * scale;
    ctx.drawImage(table, (WIDTH - drawWidth) / 2, (HEIGHT - drawHeight) / 2, drawWidth, drawHeight);
  }
  ctx.fillStyle = 'rgba(4, 15, 24, 0.72)';
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
  const glow = ctx.createRadialGradient(WIDTH * 0.45, HEIGHT * 0.45, 30, WIDTH * 0.45, HEIGHT * 0.45, WIDTH * 0.72);
  glow.addColorStop(0, 'rgba(35, 120, 201, 0.24)');
  glow.addColorStop(1, 'rgba(5, 20, 28, 0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
}

export async function renderUnoImage(state, { cardBackPath = null, tablePath = null } = {}) {
  prepareFonts();
  const sheet = await loadUnoSheet();

  let table = null;
  try {
    table = await loadImage(tablePath || DEFAULT_TABLE_PATH);
  } catch {
    table = null;
  }

  const canvas = createCanvas(WIDTH, HEIGHT);
  const ctx = canvas.getContext('2d');
  drawBackground(ctx, table);

  ctx.fillStyle = '#f6fbff';
  ctx.font = `900 31px ${fontFamily(true)}`;
  ctx.fillText('UNO', 44, 50);
  ctx.fillStyle = '#7f9bbd';
  ctx.font = `600 14px ${fontFamily(false)}`;
  ctx.fillText('ASTRO CASINO', 160, 48);

  ctx.fillStyle = '#ffffff';
  ctx.font = `700 14px ${fontFamily(true)}`;
  ctx.fillText('HOUSE HAND', 44, 88);
  ctx.fillText(`YOUR HAND · ${state.player.length} CARDS`, 44, 452);

  let backImage = null;
  if (cardBackPath) {
    try {
      backImage = await loadImage(cardBackPath);
    } catch {
      backImage = null;
    }
  }

  const botVisible = state.bot.slice(0, 10);
  const botWidth = Math.min(64, Math.floor(560 / Math.max(1, botVisible.length)));
  const botHeight = Math.round(botWidth * 1.45);
  botVisible.forEach((_, index) => {
    drawCardBack(ctx, 44 + index * (botWidth + 8), 104, botWidth, botHeight, backImage, sheet);
  });
  if (state.bot.length > botVisible.length) {
    ctx.fillStyle = '#ffffff';
    ctx.font = `800 17px ${fontFamily(true)}`;
    ctx.fillText(`+${state.bot.length - botVisible.length}`, 44 + botVisible.length * (botWidth + 8) + 4, 150);
  }

  const pileWidth = 116;
  const pileHeight = 168;
  drawCardBack(ctx, 44, 230, pileWidth, pileHeight, backImage, sheet);
  ctx.fillStyle = '#b7c9de';
  ctx.font = `600 13px ${fontFamily(false)}`;
  ctx.fillText(`${state.deck.length} left`, 60, 424);

  const top = state.discard.at(-1);
  if (top) drawFaceCard(ctx, top, 205, 206, 140, 202, sheet);

  const hand = state.player.slice(0, 10);
  const gap = 10;
  const maxWidth = WIDTH - 88;
  const cardWidth = Math.min(124, Math.floor((maxWidth - gap * (hand.length - 1)) / Math.max(1, hand.length)));
  const cardHeight = Math.round(cardWidth * 1.45);
  const handY = 470;
  const playableIndexes = new Set(
    state.player
      .map((card, index) => (state.turn === 'player' && state.status === 'playing' && canPlay(card, state) ? index : -1))
      .filter((index) => index >= 0),
  );

  hand.forEach((card, index) => {
    const x = 44 + index * (cardWidth + gap);
    if (playableIndexes.has(index) || index === state.pendingWildIndex) {
      ctx.save();
      ctx.shadowColor = index === state.pendingWildIndex ? 'rgba(229, 59, 68, 0.98)' : 'rgba(246, 196, 83, 0.9)';
      ctx.shadowBlur = 18;
      roundRect(ctx, x - 2, handY - 2, cardWidth + 4, cardHeight + 4, cardWidth * 0.11);
      ctx.fillStyle = index === state.pendingWildIndex ? 'rgba(229, 59, 68, 0.22)' : 'rgba(246, 196, 83, 0.16)';
      ctx.fill();
      ctx.restore();
    }
    drawFaceCard(ctx, card, x, handY, cardWidth, cardHeight, sheet);
  });

  if (state.player.length > hand.length) {
    ctx.fillStyle = '#ffffff';
    ctx.font = `800 18px ${fontFamily(true)}`;
    ctx.fillText(`+${state.player.length - hand.length}`, 44 + hand.length * (cardWidth + gap) + 4, handY + 54);
  }

  drawStatus(ctx, state, top ?? { wild: true, value: 'wild' }, playableIndexes.size);
  return canvas.toBuffer('image/png');
}
