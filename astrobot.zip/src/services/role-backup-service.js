import { randomUUID } from 'node:crypto';
import { ValidationError } from '../core/errors.js';
import { getDb } from '../db/index.js';
import { normalizeStructureName } from './template-builder.js';

/**
 * Member role backups taken before a replacing template apply.
 *
 * A confirmed template apply deletes every role below the bot and recreates the
 * layout, which would otherwise erase every member's role assignments. The
 * backup records both the old role definitions and who held them, so the apply
 * can rebuild the layout and then put members back into the matching roles.
 */

const KEEP_BACKUPS = 10;
const keyOf = (value) => normalizeStructureName(value);

/** Newest backups first, without loading the potentially large JSON blobs. */
export function listRoleBackups(guildId, limit = KEEP_BACKUPS) {
  if (!guildId) return [];
  const size = Math.max(1, Math.min(KEEP_BACKUPS, Math.trunc(Number(limit) || KEEP_BACKUPS)));
  return getDb()
    .prepare(
      `SELECT id, actor_id, template_name, member_count, role_count, created_at
       FROM role_backups
       WHERE guild_id = ?
       ORDER BY created_at DESC, rowid DESC
       LIMIT ?`,
    )
    .all(guildId, size);
}

/** Loads one backup (or the newest) with its role definitions and members. */
export function getRoleBackup(guildId, id = 'latest') {
  if (!guildId) return null;

  const wanted = String(id ?? '').trim();
  const row =
    !wanted || wanted === 'latest'
      ? getDb()
          .prepare(
            `SELECT * FROM role_backups WHERE guild_id = ? ORDER BY created_at DESC, rowid DESC LIMIT 1`,
          )
          .get(guildId)
      : getDb().prepare('SELECT * FROM role_backups WHERE guild_id = ? AND id = ?').get(guildId, wanted);

  if (!row) return null;

  try {
    return {
      ...row,
      roles: JSON.parse(row.roles_json),
      members: JSON.parse(row.members_json),
    };
  } catch {
    return null;
  }
}

export async function captureRoleBackup(guild, { actorId = null, templateName = null } = {}) {
  if (!guild?.id) throw new ValidationError('This action must be used inside a server.');

  let members;
  let roles;
  try {
    [members, roles] = await Promise.all([guild.members.fetch(), guild.roles.fetch()]);
  } catch (error) {
    throw new ValidationError(
      `Could not back up member roles (${error.message}). Template apply was cancelled so no roles are lost.`,
    );
  }

  const roleEntries = [...roles.values()]
    .filter((role) => role.id !== guild.id && !role.managed)
    .map((role) => ({
      id: role.id,
      name: role.name,
      color: Number(role.color) || 0,
      hoist: Boolean(role.hoist),
      mentionable: Boolean(role.mentionable),
      permissions: String(role.permissions?.bitfield ?? role.permissions ?? '0'),
    }));

  const memberEntries = [...members.values()]
    .filter((member) => !member.user?.bot)
    .map((member) => ({
      userId: member.id,
      roles: [...member.roles.cache.values()]
        .filter((role) => role.id !== guild.id && !role.managed)
        .map((role) => ({ id: role.id, name: role.name })),
    }))
    .filter((entry) => entry.roles.length > 0);

  const id = `RB-${Date.now().toString(36).toUpperCase()}-${randomUUID().slice(0, 6).toUpperCase()}`;
  const createdAt = Date.now();

  getDb()
    .prepare(
      `INSERT INTO role_backups
         (id, guild_id, actor_id, template_name, member_count, role_count, roles_json, members_json, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      id,
      guild.id,
      actorId,
      templateName,
      memberEntries.length,
      roleEntries.length,
      JSON.stringify(roleEntries),
      JSON.stringify(memberEntries),
      createdAt,
    );

  // Keep a short history; the newest backup is the one the apply restores.
  getDb()
    .prepare(
      `DELETE FROM role_backups
       WHERE guild_id = ?
         AND id NOT IN (
           SELECT id FROM role_backups WHERE guild_id = ? ORDER BY created_at DESC, rowid DESC LIMIT ?
         )`,
    )
    .run(guild.id, guild.id, KEEP_BACKUPS);

  return { id, memberCount: memberEntries.length, roleCount: roleEntries.length, createdAt };
}

/**
 * Restores every member to the roles recorded in a backup.
 *
 * Roles are matched by normalized name because the layout deletes and recreates
 * them with new snowflakes. Any role that was held by a member but is missing
 * after the rebuild is recreated from the backup, so an apply cannot silently
 * strip a member's roles. Restoration is additive: existing roles are kept.
 */
export async function restoreRoleBackup(guild, backupId, { reason = 'Restore member roles after template apply' } = {}) {
  if (!guild?.id) throw new ValidationError('This action must be used inside a server.');

  const row = getDb()
    .prepare('SELECT * FROM role_backups WHERE id = ? AND guild_id = ?')
    .get(backupId, guild.id);
  if (!row) throw new ValidationError('That role backup no longer exists.');

  let backupRoles;
  let backupMembers;
  try {
    backupRoles = JSON.parse(row.roles_json);
    backupMembers = JSON.parse(row.members_json);
  } catch {
    throw new ValidationError('That role backup is unreadable.');
  }

  const currentRoles = [...(await guild.roles.fetch()).values()].filter(
    (role) => role.id !== guild.id && !role.managed,
  );
  const roleById = new Map(currentRoles.map((role) => [role.id, role]));
  const roleByKey = new Map(currentRoles.map((role) => [keyOf(role.name), role]).filter(([key]) => key));

  const heldKeys = new Set();
  for (const entry of backupMembers) {
    for (const role of entry.roles) heldKeys.add(keyOf(role.name));
  }

  const errors = [];
  let rolesRecreated = 0;

  for (const entry of backupRoles) {
    const key = keyOf(entry.name);
    if (!key || key === keyOf('@everyone') || roleByKey.has(key) || !heldKeys.has(key)) continue;

    try {
      const role = await guild.roles.create({
        name: entry.name,
        color: Number(entry.color) || 0,
        hoist: Boolean(entry.hoist),
        mentionable: Boolean(entry.mentionable),
        permissions: BigInt(entry.permissions ?? '0'),
        reason,
      });
      roleByKey.set(key, role);
      roleById.set(role.id, role);
      rolesRecreated += 1;
    } catch (error) {
      errors.push(`recreate role ${entry.name}: ${error.message}`);
    }
  }

  const fetchedMembers = await guild.members.fetch().catch(() => null);
  const memberFor = (userId) =>
    fetchedMembers?.get?.(userId) ?? guild.members.cache.get(userId) ?? null;

  let restoredMembers = 0;
  let restoredAssignments = 0;
  let missingMembers = 0;

  for (const entry of backupMembers) {
    const member = memberFor(entry.userId);
    if (!member) {
      missingMembers += 1;
      continue;
    }

    const targetIds = [
      ...new Set(
        entry.roles
          .map((role) => roleByKey.get(keyOf(role.name))?.id ?? roleById.get(role.id)?.id)
          .filter(Boolean),
      ),
    ];
    const currentIds = new Set(member.roles.cache.keys());
    const missing = targetIds.filter((roleId) => !currentIds.has(roleId));
    if (missing.length === 0) continue;

    try {
      await member.roles.add(missing, reason);
      restoredMembers += 1;
      restoredAssignments += missing.length;
    } catch (error) {
      errors.push(`member ${entry.userId}: ${error.message}`);
    }
  }

  return { restoredMembers, restoredAssignments, rolesRecreated, missingMembers, errors };
}
