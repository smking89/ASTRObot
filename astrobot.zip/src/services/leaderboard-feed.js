import { getGuildSettings } from '../db/repositories/guilds.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { createLogger } from '../core/logger.js';
import {
  LEADERBOARD_METRICS,
  globalLeaderboardBoard,
  leaderboardBoard,
  leaderboardLabel,
} from './leaderboard-service.js';

const log = createLogger('leaderboard');
const MARKER = 'AstroBot live leaderboard';
const GLOBAL_MARKER = 'AstroBot global leaderboard';

const lastRun = new Map();

function leaderboardChannel(guild) {
  return [...guild.channels.cache.values()].find(
    (channel) =>
      channel?.isTextBased?.() &&
      /leaderboard/i.test(channel.name ?? '') &&
      // The server board belongs in the server's own channel, never the
      // network-wide #global-leaderboard.
      !/global|network/i.test(channel.name ?? ''),
  );
}

function globalLeaderboardChannel(guild) {
  return [...guild.channels.cache.values()].find(
    (channel) => channel?.isTextBased?.() && /leaderboard/i.test(channel.name ?? '') && /global|network/i.test(channel.name ?? ''),
  );
}

const footerOf = (message) => String(message.embeds?.[0]?.footer?.text ?? '');

/**
 * Keeps one picture board per metric in a channel. Regional boards use the
 * guild's prizes; global boards aggregate every connected server.
 */
async function publishBoards({ client, channel, guild, scope }) {
  const markerBase = scope === 'global' ? GLOBAL_MARKER : MARKER;
  const recent = await channel.messages.fetch({ limit: 100 });
  const ownMessages = [...recent.values()].filter(
    (message) => message.author?.id === client.user.id && footerOf(message).includes(markerBase),
  );

  for (const metric of LEADERBOARD_METRICS) {
    const marker = `${markerBase} · ${metric.id}`;
    const { label, attachment } =
      scope === 'global'
        ? await globalLeaderboardBoard({ client, metric: metric.id, limit: 15, eyebrow: 'ASTROBOT' })
        : await leaderboardBoard({
            guild,
            guildId: guild.id,
            metric: metric.id,
            limit: 15,
            theme: 'brand',
            eyebrow: 'ASTROBOT',
          });

    const embed = buildEmbed({
      title: `🏆 ${label}`,
      color: COLORS.gold,
      description:
        scope === 'global'
          ? 'Global rankings across every AstroBot server. Refreshes automatically.'
          : 'Updated automatically — play, earn and climb. The picture refreshes every few minutes.',
      footer: `${marker} · auto-refreshes`,
    }).setImage('attachment://leaderboard.png');

    const payload = { embeds: [embed], files: [attachment], components: [], allowedMentions: { parse: [] } };
    const existing = ownMessages.find((message) => footerOf(message).includes(marker));

    if (existing) await existing.edit(payload);
    else await channel.send(payload);
  }

  // Remove any pre-per-metric board left in this channel.
  for (const message of ownMessages) {
    if (LEADERBOARD_METRICS.some((entry) => footerOf(message).includes(`${markerBase} · ${entry.id}`))) continue;
    await message.delete().catch(() => null);
  }
}

/**
 * Refreshes both scopes: regional boards in the server's leaderboard channel
 * and global boards in the network/global leaderboard channel.
 */
export async function refreshLeaderboards({ client, force = false } = {}) {
  for (const guild of client.guilds.cache.values()) {
    try {
      const settings = getGuildSettings(guild.id);
      const seconds = Math.max(60, Number(settings.misc?.leaderboardRefreshSeconds) || 300);
      if (!force && Date.now() - (lastRun.get(guild.id) ?? 0) < seconds * 1000) continue;

      const regional = leaderboardChannel(guild);
      const global = globalLeaderboardChannel(guild);

      if (regional) await publishBoards({ client, channel: regional, guild, scope: 'regional' });
      if (global) await publishBoards({ client, channel: global, guild, scope: 'global' });

      if (regional || global) lastRun.set(guild.id, Date.now());
    } catch (error) {
      log.warn(`Leaderboard refresh failed for guild ${guild.id}`, error);
    }
  }
}

export const LEADERBOARD_MARKER = MARKER;
export const GLOBAL_LEADERBOARD_MARKER = GLOBAL_MARKER;
export { leaderboardLabel };
