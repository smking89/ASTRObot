import { COLORS } from '../config/constants.js';
import { createLogger } from '../core/logger.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { buildEmbed } from '../ui/embeds.js';

const log = createLogger('queue-watchdog');

/**
 * Reports connected servers whose `serverinfo` queue data is absent, has no
 * queue field, or has stopped refreshing. Pure so it can be tested without a
 * live gateway connection.
 */
export function queueIssues({ connections, rconManager, now = Date.now(), staleMs = 120_000 }) {
  return connections
    .filter((connection) => connection.connected)
    .map((connection) => {
      const info = rconManager.serverInfo(connection.serverId);
      if (!info) {
        const since = Number(connection.connectedAt) || now;
        return now - since > staleMs ? { connection, reason: 'no serverinfo reply' } : null;
      }
      if (info.queue == null) return { connection, reason: 'serverinfo has no queue count' };
      const age = now - Number(info.at ?? 0);
      if (age > staleMs) return { connection, reason: `stale for ${Math.round(age / 1000)}s` };
      return null;
    })
    .filter(Boolean);
}

function alertChannel(guild, settings) {
  const named = [...guild.channels.cache.values()].find(
    (channel) => channel.isTextBased?.() && /system.?alerts|queue.?alert|bot.?alert/i.test(channel.name ?? ''),
  );
  if (named) return named;

  const id = settings.channels?.telemetry;
  return id ? guild.channels.cache.get(id) : null;
}

/**
 * Warns staff once when queue telemetry drops for a connected console server,
 * and posts a recovery notice when `serverinfo` starts answering again.
 */
export function startQueueWatchdog(client, { rconManager, intervalMs = 60_000, staleMs = 120_000 } = {}) {
  if (!rconManager) return () => {};

  const state = new Map();
  let running = false;

  const tick = async () => {
    if (running) return;
    running = true;

    try {
      for (const guild of client.guilds.cache.values()) {
        const issues = queueIssues({
          connections: rconManager.connectionsFor(guild.id),
          rconManager,
          staleMs,
        });
        const signature = issues
          .map(({ connection, reason }) => `${connection.serverId}:${reason}`)
          .sort()
          .join('|');
        const previous = state.get(guild.id) ?? '';
        if (signature === previous) continue;
        state.set(guild.id, signature);

        const channel = alertChannel(guild, getGuildSettings(guild.id));
        if (!channel) {
          if (signature) log.warn(`Queue watchdog: no alert channel for guild ${guild.id}.`);
          continue;
        }

        if (signature) {
          const details = issues
            .map(({ connection, reason }) => `**${connection.label}** — ${reason}`)
            .join('\n');
          await channel
            .send({
              embeds: [
                buildEmbed({
                  title: '⚠️ Queue data missing',
                  description: `${details}\n\nCheck the console RCON connection; \`serverinfo\` drives the live queue counter.`,
                  color: COLORS.warning,
                  footer: 'AstroBot · queue watchdog',
                }),
              ],
              allowedMentions: { parse: [] },
            })
            .catch(() => null);
        } else if (previous) {
          await channel
            .send({
              embeds: [
                buildEmbed({
                  title: '✅ Queue data restored',
                  description: 'All connected console servers are returning `serverinfo` queue counts again.',
                  color: COLORS.success,
                  footer: 'AstroBot · queue watchdog',
                }),
              ],
              allowedMentions: { parse: [] },
            })
            .catch(() => null);
        }
      }
    } finally {
      running = false;
    }
  };

  const timer = setInterval(tick, intervalMs);
  timer.unref?.();
  tick().catch(() => null);
  log.info(`Queue watchdog running (stale after ${Math.round(staleMs / 1000)}s).`);

  return () => clearInterval(timer);
}
