import { ChannelType } from 'discord.js';
import { env } from '../config/env.js';
import { OFFICIAL_STAFF_ROLES, TEMPLATE_PRESETS, getPresetTemplate } from '../config/server-templates.js';
import { listTemplates } from '../db/repositories/templates.js';
import { normalizeStructureName } from './template-builder.js';
import { applyGuildTemplate } from './template-service.js';
import { PANEL_DEFINITIONS, findPanelChannel, inspectPanelMessage, planTemplatePanels } from './panel-deploy.js';

/**
 * Guild layout repair.
 *
 * A repair is a scan plus the same additive apply used by templates: roles,
 * categories and channels are matched by Discord-normalised name, and panels
 * are matched by their footer marker in the mapped channel. Nothing is ever
 * deleted, renamed or duplicated.
 */

const keyOf = (value) => normalizeStructureName(value);

export function resolveRepairLayout(guildId, value) {
  const needle = String(value ?? '').trim();
  if (!needle) return null;

  const preset = getPresetTemplate(needle);
  if (preset) return { id: preset.id, name: preset.name, kind: 'built-in', template: preset };

  const saved = listTemplates(guildId).find(
    (entry) => entry.id === needle || keyOf(entry.name) === keyOf(needle),
  );
  if (saved) return { id: saved.id, name: saved.name, kind: 'saved', template: saved };

  return null;
}

/** Every layout a guild can repair against, for command help and pickers. */
export function repairLayoutChoices(guildId) {
  const presets = TEMPLATE_PRESETS.map((entry) => ({
    id: entry.id,
    name: entry.name,
    kind: 'built-in',
    summary: `${entry.payload.roles?.length ?? 0} roles · ${entry.payload.channels?.length ?? 0} channels`,
  }));
  const saved = listTemplates(guildId).map((entry) => ({
    id: entry.id,
    name: entry.name,
    kind: 'saved',
    summary: `${entry.payload?.roles?.length ?? 0} roles · ${entry.payload?.channels?.length ?? 0} channels`,
  }));
  return [...presets, ...saved];
}

/** Scans a live guild against a template without changing anything. */
export async function scanGuildLayout(guild, template) {
  if (!guild) throw new Error('A guild is required.');
  const payload = template?.payload ?? template ?? {};

  const [channels, roles] = await Promise.all([
    guild.channels.fetch ? guild.channels.fetch() : guild.channels.cache,
    guild.roles.fetch ? guild.roles.fetch() : guild.roles.cache,
  ]);
  const channelList = [...(channels?.values?.() ?? [])];
  const roleList = [...(roles?.values?.() ?? [])];

  const officialGuild = Boolean(env.discord.officialGuildId) && guild.id === env.discord.officialGuildId;
  const officialKeys = new Set(OFFICIAL_STAFF_ROLES.map(keyOf));
  const roleKeys = new Set(roleList.map((role) => keyOf(role.name)));
  const categoryByName = new Map(
    channelList
      .filter((channel) => channel.type === ChannelType.GuildCategory)
      .map((channel) => [keyOf(channel.name), channel]),
  );

  const missingRoles = (payload.roles ?? [])
    .filter((entry) => {
      const key = keyOf(entry.name);
      return key && key !== keyOf('@everyone') && !roleKeys.has(key) && (officialGuild || !officialKeys.has(key));
    })
    .map((entry) => entry.name);

  const missingCategories = (payload.categories ?? [])
    .filter((entry) => keyOf(entry.name) && !categoryByName.has(keyOf(entry.name)))
    .map((entry) => entry.name);

  const missingChannels = [];
  for (const entry of payload.channels ?? []) {
    const key = keyOf(entry.name);
    if (!key) continue;
    // Match by name and type only. Discord channel names are unique guild-wide;
    // ignoring the parent prevents a second copy of a category from making
    // every channel beneath it look missing and triggering another duplicate
    // layout.
    const exists = channelList.some(
      (channel) =>
        (channel.type === entry.type ||
          // Guilds without the NEWS feature get a text channel instead of an
          // announcement channel, so either type satisfies the layout.
          (entry.type === ChannelType.GuildAnnouncement && channel.type === ChannelType.GuildText)) &&
        keyOf(channel.name) === key,
    );
    if (!exists) missingChannels.push({ name: entry.name, parentName: entry.parentName ?? null });
  }

  const missingPanels = [];
  for (const entry of planTemplatePanels(payload)) {
    const definition = PANEL_DEFINITIONS[entry.type];
    if (!definition) continue;
    const channel = findPanelChannel(guild, entry.channelName);
    if (!channel) {
      missingPanels.push({ type: entry.type, channelName: entry.channelName, issue: 'channel missing' });
      continue;
    }
    const state = await inspectPanelMessage(channel, definition);
    if (!state.found) missingPanels.push({ type: entry.type, channelName: entry.channelName, issue: 'panel not posted' });
    else if (!state.hasButtons) missingPanels.push({ type: entry.type, channelName: entry.channelName, issue: 'buttons missing' });
  }

  return {
    roles: missingRoles,
    categories: missingCategories,
    channels: missingChannels,
    panels: missingPanels,
    missing: missingRoles.length + missingCategories.length + missingChannels.length + missingPanels.length,
  };
}

/**
 * Applies the additive template and scans again. `result` is the normal
 * template apply result, so the command can report created counts and errors.
 */
export async function repairGuildLayout({ guild, template, actorId = null }) {
  const before = await scanGuildLayout(guild, template);
  const result = await applyGuildTemplate(guild, template.payload ?? template, { actorId });
  const after = await scanGuildLayout(guild, template);
  return { before, after, result };
}
