import { getDb, transaction } from '../db/index.js';
import { credit, debit } from './economy-service.js';
import { getGameConfig } from './games/game-config.js';
import { ValidationError } from '../core/errors.js';
import { rollInt } from '../utils/random.js';

export const JACKPOT_PLACES = Object.freeze(['first', 'second', 'third']);
export const JACKPOT_PLACE_LABELS = Object.freeze({
  first: '1st',
  second: '2nd',
  third: '3rd',
});

function ensureRaffle(guildId) {
  getDb()
    .prepare(
      `INSERT INTO jackpot_raffle (guild_id, balance, updated_at)
       VALUES (?, 0, ?)
       ON CONFLICT(guild_id) DO NOTHING`,
    )
    .run(guildId, Date.now());

  return getDb().prepare('SELECT * FROM jackpot_raffle WHERE guild_id = ?').get(guildId);
}

function raffleConfig(guildId) {
  return getGameConfig(guildId).jackpot.raffle;
}

function weightedWinners(participants, count) {
  const pool = participants
    .map((entry) => ({ userId: entry.user_id, entries: Math.max(0, Number(entry.entries) || 0) }))
    .filter((entry) => entry.entries > 0);
  const winners = [];

  while (winners.length < count && pool.length > 0) {
    const total = pool.reduce((sum, entry) => sum + entry.entries, 0);
    let roll = rollInt(1, total);
    let index = 0;

    for (; index < pool.length; index += 1) {
      roll -= pool[index].entries;
      if (roll <= 0) break;
    }

    winners.push(pool.splice(index, 1)[0]);
  }

  return winners;
}

function prizeAmounts(config, pool) {
  if (config.prizes && config.prizeMode === 'fixed') {
    const amounts = {
      first: Math.max(0, Number(config.prizes.first) || 0),
      second: Math.max(0, Number(config.prizes.second) || 0),
      third: Math.max(0, Number(config.prizes.third) || 0),
    };
    const total = amounts.first + amounts.second + amounts.third;
    if (total <= 0) throw new ValidationError('Configure at least one fixed raffle prize before drawing.');
    if (pool < total) {
      throw new ValidationError(`The raffle pool has ${pool} but the fixed prizes need ${total}. Add more ticket sales first.`);
    }
    return amounts;
  }

  const shares = config.poolShares ?? {};
  const totalShare = Math.max(0, Number(shares.first) || 0) + Math.max(0, Number(shares.second) || 0) + Math.max(0, Number(shares.third) || 0);
  if (totalShare <= 0) throw new ValidationError('Configure at least one raffle pool share before drawing.');

  const first = Math.floor((pool * Math.max(0, Number(shares.first) || 0)) / totalShare);
  const second = Math.floor((pool * Math.max(0, Number(shares.second) || 0)) / totalShare);
  return { first, second, third: Math.max(0, pool - first - second) };
}

export function getJackpotRaffle(guildId) {
  const row = ensureRaffle(guildId);
  return {
    balance: Number(row?.balance) || 0,
    updatedAt: Number(row?.updated_at) || 0,
  };
}

export function getJackpotDrawHistory(guildId, limit = 5) {
  const rows = getDb()
    .prepare('SELECT * FROM jackpot_draws WHERE guild_id = ? ORDER BY created_at DESC, id DESC LIMIT ?')
    .all(guildId, Math.max(1, Math.min(25, Math.trunc(Number(limit) || 5))));

  return rows.map((row) => ({
    id: Number(row.id),
    actorId: row.actor_id ?? null,
    pool: Number(row.pool) || 0,
    prizeMode: row.prize_mode,
    participants: Number(row.participants) || 0,
    entries: Number(row.entries) || 0,
    createdAt: Number(row.created_at) || 0,
    winners: JACKPOT_PLACES.map((place) => ({
      place,
      userId: row[`${place}_user_id`] ?? null,
      amount: Number(row[`${place}_amount`]) || 0,
    })).filter((winner) => winner.userId),
  }));
}

export function getJackpotDrawState(guildId, userId = null) {
  const raffle = getJackpotRaffle(guildId);
  const totals = getDb()
    .prepare(
      `SELECT COUNT(*) AS tickets,
              COALESCE(SUM(entries), 0) AS entries,
              COUNT(DISTINCT user_id) AS participants
         FROM jackpot_tickets WHERE guild_id = ?`,
    )
    .get(guildId);
  const byTier = getDb()
    .prepare(
      `SELECT tier_id, tier_label,
              COUNT(*) AS tickets,
              COALESCE(SUM(entries), 0) AS entries,
              COALESCE(SUM(cost), 0) AS spent
         FROM jackpot_tickets WHERE guild_id = ?
         GROUP BY tier_id, tier_label ORDER BY entries DESC`,
    )
    .all(guildId);
  const user = userId
    ? getDb()
        .prepare('SELECT COALESCE(SUM(entries), 0) AS entries FROM jackpot_tickets WHERE guild_id = ? AND user_id = ?')
        .get(guildId, userId)
    : null;

  return {
    balance: raffle.balance,
    tickets: Number(totals?.tickets) || 0,
    entries: Number(totals?.entries) || 0,
    participants: Number(totals?.participants) || 0,
    userEntries: Number(user?.entries) || 0,
    byTier: byTier.map((row) => ({
      id: row.tier_id,
      label: row.tier_label,
      tickets: Number(row.tickets) || 0,
      entries: Number(row.entries) || 0,
      spent: Number(row.spent) || 0,
    })),
    latest: getJackpotDrawHistory(guildId, 1)[0] ?? null,
  };
}

export function buyJackpotTicket({ guildId, userId, tierId }) {
  const config = raffleConfig(guildId);
  if (!config.enabled) throw new ValidationError('The jackpot raffle is closed right now.');

  const tier = config.tiers.find((entry) => entry.id === String(tierId));
  if (!tier) throw new ValidationError('That ticket tier is not available.');

  transaction((db) => {
    ensureRaffle(guildId);
    debit({ guildId, userId, amount: tier.cost, kind: 'jackpot_ticket' });
    db.prepare(
      `INSERT INTO jackpot_tickets (guild_id, user_id, tier_id, tier_label, entries, cost, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
    ).run(guildId, userId, tier.id, tier.label, tier.entries, tier.cost, Date.now());
    db.prepare('UPDATE jackpot_raffle SET balance = balance + ?, updated_at = ? WHERE guild_id = ?').run(
      tier.cost,
      Date.now(),
      guildId,
    );
  });

  return { tier, state: getJackpotDrawState(guildId, userId) };
}

export function drawJackpot({ guildId, actorId = null }) {
  return transaction((db) => {
    const config = raffleConfig(guildId);
    if (!config.enabled) throw new ValidationError('The jackpot raffle is disabled.');

    const raffle = ensureRaffle(guildId);
    const pool = Number(raffle?.balance) || 0;
    const tickets = db
      .prepare('SELECT user_id, entries FROM jackpot_tickets WHERE guild_id = ?')
      .all(guildId);
    if (tickets.length === 0) throw new ValidationError('No raffle tickets have been sold yet.');

    const participants = db
      .prepare(
        'SELECT user_id, COALESCE(SUM(entries), 0) AS entries FROM jackpot_tickets WHERE guild_id = ? GROUP BY user_id',
      )
      .all(guildId);
    if (participants.length < 3) {
      throw new ValidationError('At least three different players need tickets before a 3-place draw.');
    }

    const winners = weightedWinners(participants, 3);
    const amounts = prizeAmounts(config, pool);
    const totalEntries = Number(tickets.reduce((sum, ticket) => sum + (Number(ticket.entries) || 0), 0));
    const now = Date.now();
    const paid = winners.map((winner, index) => {
      const place = JACKPOT_PLACES[index];
      const amount = amounts[place] || 0;
      if (amount > 0) {
        credit({
          guildId,
          userId: winner.userId,
          amount,
          kind: 'jackpot_prize',
          respectCap: false,
        });
      }
      return { place, userId: winner.userId, amount };
    });
    const paidTotal = paid.reduce((sum, winner) => sum + winner.amount, 0);
    const remaining = Math.max(0, pool - paidTotal);
    const result = db.prepare(
      `INSERT INTO jackpot_draws (
         guild_id, actor_id, pool, prize_mode,
         first_user_id, first_amount, second_user_id, second_amount, third_user_id, third_amount,
         participants, entries, created_at
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    ).run(
      guildId,
      actorId,
      pool,
      config.prizeMode,
      paid[0]?.userId ?? null,
      paid[0]?.amount ?? 0,
      paid[1]?.userId ?? null,
      paid[1]?.amount ?? 0,
      paid[2]?.userId ?? null,
      paid[2]?.amount ?? 0,
      participants.length,
      totalEntries,
      now,
    );

    db.prepare('UPDATE jackpot_raffle SET balance = ?, updated_at = ? WHERE guild_id = ?').run(
      remaining,
      now,
      guildId,
    );
    db.prepare('DELETE FROM jackpot_tickets WHERE guild_id = ?').run(guildId);

    return {
      id: Number(result.lastInsertRowid),
      actorId,
      pool,
      prizeMode: config.prizeMode,
      participants: participants.length,
      entries: totalEntries,
      winners: paid,
      remaining,
      createdAt: now,
    };
  });
}

export { weightedWinners, prizeAmounts };