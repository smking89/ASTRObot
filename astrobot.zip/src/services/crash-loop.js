import { endSession, registry } from '../core/registry.js';
import { createLogger } from '../core/logger.js';
import { CRASH_TICK_MS, getCrashHistory, tickCrash } from './games/crash.js';
import { crashView } from '../ui/game-views.js';
import { settleCrashSession } from './crash-settlement.js';

const log = createLogger('crash');

/**
 * The engine is time-based, so the loop is what makes the visible multiplier
 * climb. Updates are deliberately slower than one second to stay comfortably
 * inside Discord's message-edit budget.
 */
export function startCrashLoop({ intervalMs = CRASH_TICK_MS } = {}) {
  const timer = setInterval(() => {
    advanceCrashes().catch((error) => log.warn('Crash loop failed', error));
  }, intervalMs);
  timer.unref?.();
  return () => clearInterval(timer);
}

export async function advanceCrashes(now = Date.now()) {
  for (const [sessionId, session] of registry.sessions) {
    if (session.game !== 'crash' || session.settled || session.finalized) continue;

    try {
      const state = tickCrash(session.state, now);
      const ended = ['crashed', 'cashed_out'].includes(state.status);

      if (ended) {
        settleCrashSession(session);
        session.finalized = true;
      }

      const payload = crashView(state, sessionId, {
        history: getCrashHistory(session.guildId),
        jackpot: session.jackpotWin,
      });

      if (typeof session.editResponse === 'function') {
        await session.editResponse(payload).catch(() => {
          session.finalized = true;
          endSession(sessionId);
        });
      } else if (session.message?.edit) {
        await session.message.edit(payload).catch(() => {
          session.finalized = true;
          endSession(sessionId);
        });
      } else if (ended) {
        session.finalized = true;
      }
    } catch (error) {
      session.finalized = true;
      log.warn(`Could not advance crash session ${sessionId}`, error);
    }
  }
}
