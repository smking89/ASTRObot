import { getDb, transaction } from '../db/index.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { metricValues } from '../db/repositories/players.js';
import { LEADERBOARD_METRICS } from './leaderboard-service.js';
import { PRIZE_PERIODS, prizesFor } from './leaderboard-prizes.js';
import { credit } from './economy-service.js';
import { isStaffMember } from './staff-service.js';
import { createLogger } from '../core/logger.js';

const log = createLogger('leaderboard-payouts');

/** Period lengths used to decide when a board's prizes are due. */
export const PERIOD_MS = Object.freeze({
  daily: 86_400_000,
  weekly: 604_800_000,
  monthly: 2_592_000_000,
  yearly: 31_536_000_000,
});

function stateFor(guildId, period) {
  return (
    getDb()
      .prepare('SELECT * FROM leaderboard_period_state WHERE guild_id = ? AND period = ?')
      .get(guildId, period) ?? null
  );
}

/** Stores the current metric values as the baseline for the next period. */
function snapshotBaselines(guildId, period) {
  const rows = [];
  for (const metric of LEADERBOARD_METRICS) {
    for (const entry of metricValues(guildId, metric.id)) {
      rows.push({ metric: metric.id, userId: String(entry.user_id), value: Number(entry.value) || 0 });
    }
  }

  transaction((db) => {
    db.prepare('DELETE FROM leaderboard_baselines WHERE guild_id = ? AND period = ?').run(guildId, period);
    const insert = db.prepare(
      `INSERT OR REPLACE INTO leaderboard_baselines (guild_id, period, metric, user_id, value)
       VALUES (?, ?, ?, ?, ?)`,
    );
    for (const row of rows) insert.run(guildId, period, row.metric, row.userId, row.value);
  });
}

function startPeriod(guildId, period, now = Date.now()) {
  getDb()
    .prepare('INSERT OR IGNORE INTO leaderboard_period_state (guild_id, period, started_at) VALUES (?, ?, ?)')
    .run(guildId, period, now);
  snapshotBaselines(guildId, period);
}

function baselineFor(guildId, period, metric) {
  const rows = getDb()
    .prepare('SELECT user_id, value FROM leaderboard_baselines WHERE guild_id = ? AND period = ? AND metric = ?')
    .all(guildId, period, metric);
  return new Map(rows.map((row) => [String(row.user_id), Number(row.value) || 0]));
}

/**
 * Pays one elapsed period: each metric with a prize gets its top three by the
 * gain since the period opened, then the baseline rolls forward.
 */
export function settleLeaderboardPeriod(guildId, period, guild = null, now = Date.now()) {
  const state = stateFor(guildId, period);
  if (!state) {
    startPeriod(guildId, period, now);
    return { paid: [], period };
  }

  const credits = [];

  for (const metric of LEADERBOARD_METRICS) {
    const amounts = prizesFor(guildId, period, metric.id);
    if (!amounts.some((amount) => amount > 0)) continue;

    const baseline = baselineFor(guildId, period, metric.id);
    const gains = [];

    for (const entry of metricValues(guildId, metric.id)) {
      const userId = String(entry.user_id);
      const member = guild?.members?.cache?.get?.(userId) ?? null;
      if (member && isStaffMember(member, guildId)) continue;

      const gain = (Number(entry.value) || 0) - (baseline.get(userId) ?? 0);
      if (gain > 0) gains.push({ userId, gain });
    }

    gains.sort((a, b) => b.gain - a.gain);

    gains.slice(0, 3).forEach((entry, index) => {
      const amount = amounts[index] ?? 0;
      if (amount <= 0) return;
      credits.push({ userId: entry.userId, amount, metric: metric.id, place: index + 1, gain: entry.gain });
    });
  }

  // Roll the period forward before paying so a crash can never double-pay.
  transaction((db) => {
    db.prepare('UPDATE leaderboard_period_state SET started_at = ? WHERE guild_id = ? AND period = ?').run(now, guildId, period);
  });
  snapshotBaselines(guildId, period);

  for (const entry of credits) {
    try {
      credit({
        guildId,
        userId: entry.userId,
        amount: entry.amount,
        kind: 'leaderboard_prize',
        metadata: { period, metric: entry.metric, place: entry.place },
      });
    } catch (error) {
      log.warn(`Prize credit failed for ${guildId}/${entry.userId}`, error);
    }
  }

  if (credits.length > 0) {
    log.info(`Paid ${credits.length} ${period} leaderboard prize(s) in ${guildId}.`);
  }

  return { paid: credits, period };
}

/** Called by the background loop: starts new periods and settles elapsed ones. */
export async function runLeaderboardPayouts({ client } = {}) {
  if (!client?.guilds?.cache) return;

  const now = Date.now();
  for (const guild of client.guilds.cache.values()) {
    try {
      const settings = getGuildSettings(guild.id);
      if (settings.leaderboardPrizes?.enabled === false) continue;

      for (const period of PRIZE_PERIODS) {
        const state = stateFor(guild.id, period.id);
        if (!state) {
          startPeriod(guild.id, period.id, now);
          continue;
        }
        if (now - Number(state.started_at) < PERIOD_MS[period.id]) continue;
        settleLeaderboardPeriod(guild.id, period.id, guild, now);
      }
    } catch (error) {
      log.warn(`Leaderboard payout failed for guild ${guild.id}`, error);
    }
  }
}
