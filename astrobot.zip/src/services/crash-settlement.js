import { credit } from './economy-service.js';
import { addCrashResult } from './games/crash.js';
import { maybeAwardJackpot } from './jackpot-service.js';
import { awardGamePrize } from './game-prize-service.js';

/** Credits a finished crash round exactly once and records its public result. */
export function settleCrashSession(session) {
  if (!session || session.settled) return session;

  const state = session.state;
  if (!state || !['cashed_out', 'crashed'].includes(state.status)) return session;

  session.settled = true;

  if (state.payout > 0) {
    credit({
      guildId: session.guildId,
      userId: session.userId,
      amount: state.payout,
      kind: 'casino_win',
      respectCap: false,
    });
  }

  addCrashResult(session.guildId, {
    crashPoint: state.crashPoint,
    status: state.status,
    at: state.endedAt ?? Date.now(),
  });

  if (state.status === 'cashed_out') {
    session.jackpotWin = maybeAwardJackpot({
      guildId: session.guildId,
      userId: session.userId,
      game: 'crash',
    });
    state.prize = awardGamePrize({
      guildId: session.guildId,
      userId: session.userId,
      game: 'crash',
      won: true,
    });
  }

  return session;
}
