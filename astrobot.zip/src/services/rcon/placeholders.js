import { getGuildSettings } from '../../db/repositories/guilds.js';
import { getAccount } from '../../db/repositories/players.js';
import { formatNumber, gridRef, truncate } from '../../utils/format.js';
import { personalRank } from '../../ui/rank-icons.js';

/**
 * Helios-style game feed placeholders.
 *
 * Templates may mix the legacy lowercase tokens ({killer}, {weapon}, ...) with
 * the CamelCase stat tokens built here. Unknown tokens are left untouched so a
 * typo stays visible in the template instead of silently disappearing.
 */

export const GENERAL_PLACEHOLDERS = Object.freeze([
  '{KillerPlayerName}',
  '{VictimPlayerName}',
  '{KillerKills}',
  '{KillerDeaths}',
  '{KillerCurrentStreak}',
  '{KillerBestStreak}',
  '{KillerKD}',
  '{KillerStreak}',
  '{VictimKills}',
  '{VictimDeaths}',
  '{VictimCurrentStreak}',
  '{VictimBestStreak}',
  '{VictimKD}',
  '{VictimStreak}',
  '{KillerWallet}',
  '{VictimWallet}',
  '{KillerXP}',
  '{VictimXP}',
  '{KillerLevel}',
  '{VictimLevel}',
  '{KillerRank}',
  '{VictimRank}',
  '{KillerRivalPoints}',
  '{VictimRivalPoints}',
  '{KillerClanTag}',
  '{VictimClanTag}',
  '{KillerTeamTag}',
  '{VictimTeamTag}',
  '{KillerTeamName}',
  '{VictimTeamName}',
  '{Currency}',
  '{Stolen}',
  '{Distance}',
]);

export const PVP_PLACEHOLDERS = Object.freeze([
  '{KillerPvPKills}',
  '{KillerPvPDeaths}',
  '{KillerPvPKD}',
  '{VictimPvPKills}',
  '{VictimPvPDeaths}',
  '{VictimPvPKD}',
]);

export const PVE_PLACEHOLDERS = Object.freeze([
  '{KillerPvEKills}',
  '{KillerPvEDeaths}',
  '{KillerPvEKD}',
  '{VictimPvEKills}',
  '{VictimPvEDeaths}',
  '{VictimPvEKD}',
]);

/** True when a template asks for a PvE statistic, used to route PvE events. */
export function usesPvePlaceholder(template) {
  return PVE_PLACEHOLDERS.some((token) => String(template ?? '').includes(token));
}

/** K/D rounded to two decimals; zero deaths never divide by zero. */
export function playerRatio(kills, deaths) {
  const value = Math.max(0, Number(kills) || 0) / Math.max(1, Math.max(0, Number(deaths) || 0));
  return value.toFixed(2);
}

export function playerStatFields(account) {
  const kills = Math.max(0, Number(account?.kills) || 0);
  const deaths = Math.max(0, Number(account?.deaths) || 0);
  const pvpKills = Math.max(0, Number(account?.pvp_kills) || 0);
  const pvpDeaths = Math.max(0, Number(account?.pvp_deaths) || 0);
  const pveKills = Math.max(0, Number(account?.pve_kills) || 0);
  const pveDeaths = Math.max(0, Number(account?.pve_deaths) || 0);
  const currentStreak = Math.max(0, Number(account?.kill_streak) || 0);
  const level = Math.max(1, Number(account?.level) || 1);
  const rank = personalRank(level);

  return {
    kills,
    deaths,
    xp: Math.max(0, Number(account?.xp) || 0),
    level,
    // Game chat can only carry the rank name; embeds can attach rankIcon.
    rank: rank.label,
    rankIcon: rank.icon,
    rivalPoints: Math.max(0, Number(account?.rival_wins) || 0),
    currentStreak,
    bestStreak: Math.max(currentStreak, Number(account?.best_kill_streak) || 0),
    kd: playerRatio(kills, deaths),
    pvpKills,
    pvpDeaths,
    pvpKd: playerRatio(pvpKills, pvpDeaths),
    pveKills,
    pveDeaths,
    pveKd: playerRatio(pveKills, pveDeaths),
    wallet: Math.max(0, Number(account?.wallet) || 0),
  };
}

/** `123m` when a distance was tracked, otherwise the Helios fallback label. */
export function distanceLabel(meters) {
  const value = Number(meters);
  return Number.isFinite(value) && value >= 0 ? `${Math.round(value)}m` : 'Mystery Box';
}

export function gridLabel(coordinates) {
  if (!coordinates) return '--';
  return coordinates.grid ?? gridRef(coordinates.x, coordinates.z);
}

/**
 * Resolves every placeholder for one kill event. Linked players are read from
 * the players table, so the numbers match the leaderboards exactly. Callers pass
 * identity from resolveIdentity() and, when known, the killer's last coordinates.
 */
export function buildPlaceholders({ guildId, event, settings = null, identity = {}, killerCoords = null }) {
  const config = settings ?? getGuildSettings(guildId);
  const killer = playerStatFields(identity?.killer?.userId ? getAccount(guildId, identity.killer.userId) : null);
  const victim = playerStatFields(identity?.victim?.userId ? getAccount(guildId, identity.victim.userId) : null);

  const coords = event?.coordinates ?? null;
  const storedDistance = event?.distance === null || event?.distance === undefined ? NaN : Number(event.distance);
  const measuredDistance =
    Number.isFinite(storedDistance)
      ? storedDistance
      : killerCoords && coords
        ? Math.hypot(killerCoords.x - coords.x, killerCoords.y - coords.y, killerCoords.z - coords.z)
        : NaN;

  const stolen = Number.isFinite(Number(event?.stolen)) ? Math.max(0, Math.trunc(Number(event.stolen))) : 0;

  const values = {
    KillerPlayerName: truncate(event?.killer?.name ?? 'Unknown', 40),
    VictimPlayerName: truncate(event?.victim?.name ?? 'Unknown', 40),
    KillerWallet: formatNumber(killer.wallet),
    VictimWallet: formatNumber(victim.wallet),
    Currency: config?.economy?.currency ?? 'coins',
    Stolen: formatNumber(stolen),
    Distance: distanceLabel(measuredDistance),
    Grid: gridLabel(coords),
    Server: event?.serverLabel ?? null,
  };

  const killerTeamTag = String(identity?.killer?.teamTag ?? '').trim();
  const victimTeamTag = String(identity?.victim?.teamTag ?? '').trim();

  for (const [side, stats, person, teamTag] of [
    ['Killer', killer, identity?.killer, killerTeamTag],
    ['Victim', victim, identity?.victim, victimTeamTag],
  ]) {
    values[`${side}Kills`] = formatNumber(stats.kills);
    values[`${side}XP`] = formatNumber(stats.xp);
    values[`${side}Level`] = formatNumber(stats.level);
    values[`${side}Rank`] = stats.rank;
    values[`${side}RankIcon`] = stats.rankIcon;
    values[`${side}RivalPoints`] = formatNumber(stats.rivalPoints);
    values[`${side}RivalWins`] = formatNumber(stats.rivalPoints);
    values[`${side}ClanTag`] = teamTag ? `[${teamTag}]` : '';
    values[`${side}TeamTag`] = teamTag;
    values[`${side}TeamName`] = String(person?.teamName ?? '').trim();
    values[`${side}Deaths`] = formatNumber(stats.deaths);
    values[`${side}CurrentStreak`] = formatNumber(stats.currentStreak);
    values[`${side}BestStreak`] = formatNumber(stats.bestStreak);
    values[`${side}KD`] = stats.kd;
    // Helios also exposes {KillerStreak}; it is the current streak.
    values[`${side}Streak`] = formatNumber(stats.currentStreak);
    values[`${side}PvPKills`] = formatNumber(stats.pvpKills);
    values[`${side}PvPDeaths`] = formatNumber(stats.pvpDeaths);
    values[`${side}PvPKD`] = stats.pvpKd;
    values[`${side}PvEKills`] = formatNumber(stats.pveKills);
    values[`${side}PvEDeaths`] = formatNumber(stats.pveDeaths);
    values[`${side}PvEKD`] = stats.pveKd;
  }

  return values;
}

/** Rank and badge icon for an embed caller; text templates use {KillerRank}. */
export function rankForPlayer(guildId, userId) {
  if (!userId) return null;
  return personalRank(getAccount(guildId, userId)?.level ?? 1);
}

/** Replaces known tokens and leaves unknown ones in place. */
export function applyPlaceholders(template, values) {
  return String(template ?? '').replaceAll(/\{(\w+)\}/g, (match, key) => (key in values ? String(values[key]) : match));
}
