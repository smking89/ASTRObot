import { getGuildSettings } from '../../db/repositories/guilds.js';
import { createLogger } from '../../core/logger.js';
import { truncate } from '../../utils/format.js';
import { COLORS } from '../../config/constants.js';
import { buildEmbed } from '../../ui/embeds.js';
import { dispatchKillfeed, distanceBetween, resolveIdentity } from './killfeed.js';
import { evaluateProtection, formatRaidAlert, parseZone } from './protection.js';
import { expectedDeathPenalty, settleKill } from '../economy-service.js';
import { awardXp } from '../progression-service.js';
import { recordKillStats, recordPveDeath, recordPveKill } from '../../db/repositories/players.js';
import { isNpc } from './parser.js';
import { isStaffMember } from '../staff-service.js';
import { closeSession, openSession } from '../../db/repositories/sessions.js';
import { recordKillfeedEvent } from '../../db/repositories/killfeed.js';

const log = createLogger('telemetry');

/**
 * Routes parsed RCON events to Discord channels and economy hooks.
 * Every send is individually guarded: a deleted channel must never drop the rest
 * of the stream or kill the RCON connection.
 */
export class TelemetryRouter {
  constructor({ client, rconManager, nightVotes = null }) {
    this.client = client;
    this.rconManager = rconManager;
    this.nightVotes = nightVotes;
    this.raidBuckets = new Map();
    // Last position seen for a gamertag, used for the {Distance} placeholder.
    this.playerCoords = new Map();
  }

  async handle(server, event) {
    if (!event?.guildId) return;

    try {
      switch (event.kind) {
        case 'kill':
          await this.handleKill(server, event);
          break;
        case 'suicide':
          await this.handleSuicide(server, event);
          break;
        case 'damage':
          await this.handleDamage(server, event);
          break;
        case 'join':
        case 'leave':
          await this.handlePresence(server, event);
          break;
        case 'chat':
          await this.handleChat(server, event);
          break;
        case 'pve':
          await this.handlePve(server, event);
          break;
        case 'admin':
          await this.handleAdmin(server, event);
          break;
        default:
          break;
      }
    } catch (error) {
      log.error(`Telemetry handler failed for ${event.kind}`, error);
    }
  }

  async handleKill(server, event) {
    const settings = getGuildSettings(event.guildId);
    const killer = resolveIdentity(event.guildId, event.killer?.name);
    const victim = resolveIdentity(event.guildId, event.victim?.name);
    const killerMember = killer?.userId ? await this.resolveMember(event.guildId, killer.userId) : null;
    const killerIsStaff = isStaffMember(killerMember, event.guildId);

    // Kill coordinates belong to the victim, so the killer's last known spot is
    // used for {Distance}. Without one the placeholder says "Mystery Box".
    const coords = event.coordinates ?? null;
    const killerCoords = this.trackedCoords(event.guildId, event.killer?.name);
    if (coords) this.rememberCoords(event.guildId, event.victim?.name, coords);

    // The feed renders before settlement, so snapshot the wallet amount this
    // kill is about to take and persist it for the delayed global feed.
    event.stolen =
      !event.npc && killer?.userId && victim?.userId && !killerIsStaff
        ? expectedDeathPenalty({ guildId: event.guildId, victimId: victim.userId, settings })
        : 0;
    if (Number.isFinite(event.distance)) event.distance = Number(event.distance);
    else if (coords && killerCoords) event.distance = Math.round(distanceBetween(killerCoords, coords));

    // Persist every parsed local kill before display filters. The global feed
    // publisher consumes this queue independently of channel availability.
    try {
      recordKillfeedEvent({
        guildId: event.guildId,
        serverId: server.id,
        serverLabel: server.label,
        event,
      });
    } catch (error) {
      log.warn(`Could not persist killfeed event for ${event.guildId}`, error);
    }

    if (event.npc && !settings.killfeed.showNpc) {
      // NPC kills still award the scientist reward to linked players, and a
      // player killed by an NPC still records a PvE death.
      if (killer?.userId && !killerIsStaff) {
        recordPveKill(event.guildId, killer.userId);
        settleKill({ guildId: event.guildId, killerId: killer.userId, victimId: null, npc: true, settings });
      } else if (victim?.userId && isNpc(event.killer?.name)) {
        recordPveDeath(event.guildId, victim.userId);
      }
      return;
    }

    // Stats are written before the feed is formatted so placeholders show the
    // state after this kill (kills, PvP/PvE totals and streaks).
    if (killer?.userId && !killerIsStaff) {
      if (event.npc) recordPveKill(event.guildId, killer.userId);
      else recordKillStats({ guildId: event.guildId, killerId: killer.userId, victimId: victim?.userId ?? null });
    } else if (victim?.userId && isNpc(event.killer?.name)) {
      recordPveDeath(event.guildId, victim.userId);
    }

    await dispatchKillfeed({ client: this.client, event, serverLabel: server.label, killerCoords });

    if (killer?.userId) {
      // Staff play support, not the game: no kills, PvE, score or XP for them.
      if (killerIsStaff) return;
      settleKill({
        guildId: event.guildId,
        killerId: killer.userId,
        victimId: victim?.userId ?? null,
        npc: Boolean(event.npc),
        settings,
      });

      awardXp({
        guildId: event.guildId,
        userId: killer.userId,
        xp: event.npc ? 10 : 25,
        astroScore: event.npc ? 2 : 5,
        member: killerMember,
      });
    }
  }

  coordKey(guildId, gamertag) {
    return `${guildId}:${String(gamertag ?? '').toLowerCase()}`;
  }

  trackedCoords(guildId, gamertag) {
    if (!gamertag) return null;
    return this.playerCoords.get(this.coordKey(guildId, gamertag)) ?? null;
  }

  rememberCoords(guildId, gamertag, coordinates) {
    if (!gamertag || !coordinates) return;
    this.playerCoords.set(this.coordKey(guildId, gamertag), coordinates);
    if (this.playerCoords.size > 1000) {
      const oldest = this.playerCoords.keys().next().value;
      if (oldest !== undefined) this.playerCoords.delete(oldest);
    }
  }

  /** Staff detection needs the live member, not just the linked player row. */
  async resolveMember(guildId, userId) {
    const guild = this.client?.guilds?.cache?.get(guildId);
    if (!guild?.members) return null;
    return guild.members.cache.get(String(userId)) ?? (await guild.members.fetch(String(userId)).catch(() => null));
  }

  async handleSuicide(server, event) {
    const settings = getGuildSettings(event.guildId);
    if (!settings.telemetry.deaths) return;

    const victim = resolveIdentity(event.guildId, event.victim?.name);
    const channel = await this.resolveChannel(event.guildId, settings.channels.telemetry);
    if (!channel) return;

    await channel
      .send({
        embeds: [
          buildEmbed({
            title: 'Player died',
            description: `**${event.victim?.name ?? 'Unknown'}** died${event.coordinates ? ` at grid ${event.coordinates.grid}` : ''}.`,
            color: COLORS.neutral,
          }),
        ],
        allowedMentions: { parse: [] },
      })
      .catch(() => null);

    if (victim?.userId) {
      const member = await this.resolveMember(event.guildId, victim.userId);
      awardXp({ guildId: event.guildId, userId: victim.userId, xp: 2, member });
    }
  }

  async handleDamage(server, event) {
    const settings = getGuildSettings(event.guildId);
    if (!settings.orp.raidLinkEnabled) return;
    if (Number(event.damage) < Number(settings.orp.raidLinkMinDamage)) return;

    // RaidLink targets the defending team, so the log must name the structure
    // owner ("... owned by Alice"). Without that, no alert is sent.
    const owner = resolveIdentity(event.guildId, event.owner?.name ?? '');
    const team = owner?.teamId ? this.rconManager.getTeam(owner.teamId) : null;
    if (!team) return;

    const protection = evaluateProtection({
      settings,
      team,
      onlineMembers: this.rconManager.onlineCountFor(team.id),
      zone: parseZone(team.orp_zone),
      damage: Number(event.damage),
      point: event.coordinates,
    });

    const bucket = this.bucketFor(team.id, event, protection);
    if (!bucket) return;

    const channelId = this.rconManager.raidChannelFor(team.id);
    const channel = await this.resolveChannel(event.guildId, channelId);
    if (!channel) return;

    await channel
      .send({
        content: truncate(
          formatRaidAlert({
            team,
            damage: bucket.damage,
            attacker: event.attacker,
            structure: event.structure,
            coordinates: event.coordinates,
            serverLabel: server.label,
          }) + (protection.blocked ? `\n🛡️ Damage blocked: ${protection.reason}` : protection.reductionPercent ? `\n🛡️ ${protection.reason}` : ''),
          1900,
        ),
        allowedMentions: { parse: [] },
      })
      .catch(() => null);
  }

  /** Coalesces raid damage per team into 10 second windows to avoid channel spam. */
  bucketFor(teamId, event, protection) {
    const now = Date.now();
    const existing = this.raidBuckets.get(teamId);

    if (existing && now - existing.startedAt < 10_000) {
      existing.damage += Number(event.damage) || 0;
      existing.structure = event.structure;
      existing.coordinates = event.coordinates;
      return null;
    }

    const bucket = {
      startedAt: now,
      damage: Number(event.damage) || 0,
      structure: event.structure,
      coordinates: event.coordinates,
      protection,
    };
    this.raidBuckets.set(teamId, bucket);

    if (this.raidBuckets.size > 500) {
      for (const [key, value] of this.raidBuckets) {
        if (now - value.startedAt > 60_000) this.raidBuckets.delete(key);
      }
    }

    return bucket;
  }

  async handlePresence(server, event) {
    const settings = getGuildSettings(event.guildId);
    const isJoin = event.kind === 'join';

    if (isJoin) this.rconManager.markOnline(server.id, event.player?.name, true);
    else this.rconManager.markOnline(server.id, event.player?.name, false);

    const gamertag = event.player?.name;
    const identity = resolveIdentity(event.guildId, gamertag);
    if (isJoin) {
      openSession({ guildId: event.guildId, serverId: server.id, gamertag, userId: identity?.userId ?? null });
    } else {
      closeSession({ guildId: event.guildId, gamertag });
    }

    if (isJoin ? !settings.telemetry.joins : !settings.telemetry.leaves) return;

    const online = this.rconManager.onlineCount(server.id);
    const channel = await this.resolveChannel(event.guildId, settings.channels.joins);
    if (!channel) return;

    await channel
      .send({
        embeds: [
          buildEmbed({
            description: `${isJoin ? '🟢' : '🔴'} **${event.player?.name ?? 'Unknown'}** ${isJoin ? 'joined' : 'left'} ${server.label} · ${online} online`,
            color: isJoin ? COLORS.success : COLORS.neutral,
          }),
        ],
        allowedMentions: { parse: [] },
      })
      .catch(() => null);
  }

  async handleChat(server, event) {
    if (!event.message) return;

    if (/^!night\b/i.test(event.message)) {
      const identity = resolveIdentity(event.guildId, event.player?.name);
      const result = this.nightVotes?.addVote(event.guildId, identity?.userId ?? event.player?.name);
      if (result?.isNew) {
        log.info(`Night vote from ${event.player?.name} on ${server.label} (${result.votes} total).`);
      }
    }

    // Frank answers FAQ keywords in Discord channels (see events/message-create).
    // In-game chat is only used for !night voting above.
  }

  async handlePve(server, event) {
    const settings = getGuildSettings(event.guildId);
    if (!settings.telemetry.pveEvents) return;

    const channel = await this.resolveChannel(event.guildId, settings.channels.telemetry);
    if (!channel) return;

    await channel
      .send({
        embeds: [
          buildEmbed({
            title: 'PvE event',
            description: `**${event.subject}** activity detected on ${server.label}.`,
            color: COLORS.info,
          }),
        ],
      })
      .catch(() => null);
  }

  async handleAdmin(server, event) {
    const settings = getGuildSettings(event.guildId);
    if (!settings.telemetry.adminOverrides) return;

    const channel = await this.resolveChannel(event.guildId, settings.channels.modLog);
    if (!channel) return;

    await channel
      .send({
        embeds: [buildEmbed({ title: 'Admin action', description: truncate(event.raw, 1900), color: COLORS.warning })],
      })
      .catch(() => null);
  }

  async resolveChannel(guildId, channelId) {
    if (!channelId) return null;
    const guild = await this.client.guilds.fetch(guildId).catch(() => null);
    if (!guild) return null;
    const channel = await guild.channels.fetch(channelId).catch(() => null);
    return channel?.isTextBased() ? channel : null;
  }
}
