import { EventEmitter } from 'node:events';
import { env } from '../../config/env.js';
import { createLogger } from '../../core/logger.js';
import { listEnabledServers } from '../../db/repositories/servers.js';
import { getTeam, listMembers } from '../../db/repositories/teams.js';
import { getLink } from '../../db/repositories/links.js';
import { decryptSecret } from '../../utils/crypto.js';
import { parseLine, parsePlayerList, parseServerInfo } from './parser.js';
import { RconConnection } from './client.js';
import { TelemetryRouter } from './telemetry.js';
import { createNightVoteTracker } from '../scheduler-service.js';

const log = createLogger('rcon:manager');

/**
 * Owns one RconConnection per enabled server row, tracks online players per
 * server, and feeds parsed events into the telemetry router.
 */
export class RconManager extends EventEmitter {
  constructor({ client }) {
    super();
    this.client = client;
    this.connections = new Map();
    this.teamCache = new Map();
    this.online = new Map();
    this.info = new Map();
    this.nightVotes = createNightVoteTracker();
    this.router = new TelemetryRouter({ client, rconManager: this, nightVotes: this.nightVotes });
    this.refreshTimer = null;
    this.infoTimer = null;
  }

  start() {
    this.syncServers();
    this.refreshTimer = setInterval(() => this.syncServers(), 60_000);
    this.refreshTimer.unref?.();

    // `serverinfo` is the console RCON source for player and queue counts.
    const firstPoll = setTimeout(() => this.pollServerInfo(), 3000);
    firstPoll.unref?.();
    this.infoTimer = setInterval(() => this.pollServerInfo(), 5000);
    this.infoTimer.unref?.();
    return this;
  }

  async pollServerInfo() {
    const connections = [...this.connections.values()].filter((connection) => connection.connected);
    await Promise.allSettled(
      connections.map(async (connection) => {
        const message = await connection.request('serverinfo', 4000);
        const info = parseServerInfo(message);
        if (info) this.info.set(connection.serverId, { ...info, at: Date.now() });
      }),
    );
  }

  serverInfo(serverId) {
    return this.info.get(serverId) ?? null;
  }

  queueCount(serverId) {
    return Number(this.info.get(serverId)?.queue) || 0;
  }

  syncServers() {
    const rows = listEnabledServers();
    const seen = new Set();
    // Team settings (ORP zones, RaidLink channels) are edited in Discord, so the
    // cache is refreshed on every sync pass.
    this.teamCache.clear();

    for (const row of rows) {
      seen.add(row.id);
      if (this.connections.has(row.id)) continue;

      let password;
      try {
        password = decryptSecret(row.password);
      } catch (error) {
        log.error(`Cannot decrypt RCON password for server ${row.id}.`, error);
        continue;
      }

      const connection = new RconConnection({
        guildId: row.guild_id,
        serverId: row.id,
        label: row.label,
        host: row.host,
        port: row.port,
        password,
        reconnectMs: env.rcon.reconnectMs,
      });

      connection.on('connected', () => this.emit('connected', connection));
      connection.on('disconnected', (info) => this.emit('disconnected', connection, info));
      connection.on('message', (frame) => this.handleFrame(connection, frame));
      connection.connect();

      this.connections.set(row.id, connection);
      log.info(`Connecting "${row.label}" (${row.host}:${row.port}) for guild ${row.guild_id}.`);
    }

    for (const [id, connection] of this.connections) {
      if (seen.has(id)) continue;
      connection.destroy();
      this.connections.delete(id);
      this.online.delete(id);
      this.teamCache.clear();
    }
  }

  handleFrame(connection, frame) {
    if (frame.type === 'chat') {
      const event = parseLine(frame.message, { guildId: connection.guildId, serverId: connection.serverId });
      if (event) this.router.handle(connection, event);
      return;
    }

    // Fallback for builds that do not echo the identifier: ingest JSON that
    // looks like a serverinfo payload instead of dropping it.
    if (String(frame.message ?? '').trim().startsWith('{')) {
      const info = parseServerInfo(frame.message);
      if (info) {
        this.info.set(connection.serverId, { ...info, at: Date.now() });
        return;
      }
    }

    const lines = String(frame.message ?? '').split(/\r?\n/).filter(Boolean);

    // A `playerlist` response is a multi-line "name  id  ping" table.
    if (lines.length > 1 && lines.every((line) => /^\S.*?\s{2,}\d{6,20}\s{2,}\d+/.test(line))) {
      this.ingestPlayerList(connection.serverId, frame.message);
      return;
    }

    for (const line of lines) {
      const event = parseLine(line, { guildId: connection.guildId, serverId: connection.serverId });
      if (event) this.router.handle(connection, event);
    }
  }

  ingestPlayerList(serverId, message) {
    const players = parsePlayerList(message);
    const set = new Set(players.map((player) => player.name.toLowerCase()));
    this.online.set(serverId, set);
    log.debug(`playerlist updated (${set.size} online) for ${serverId}.`);
  }

  markOnline(serverId, name, online) {
    if (!name) return;
    const set = this.online.get(serverId) ?? new Set();
    const key = String(name).toLowerCase();
    if (online) set.add(key);
    else set.delete(key);
    this.online.set(serverId, set);
  }

  onlineCount(serverId) {
    return this.online.get(serverId)?.size ?? 0;
  }

  /** Counts a team's players currently online, matched by linked gamertag. */
  onlineCountFor(teamId) {
    const team = this.getTeam(teamId);
    if (!team) return 0;

    const gamertags = new Set();
    for (const member of listMembers(teamId)) {
      const link = getLink(team.guild_id, member.user_id);
      if (link) gamertags.add(link.gamertag.toLowerCase());
    }

    let count = 0;
    for (const connection of this.connections.values()) {
      if (connection.guildId !== team.guild_id) continue;
      const names = this.online.get(connection.serverId);
      if (!names) continue;
      for (const gamertag of gamertags) {
        if (names.has(gamertag)) count += 1;
      }
    }

    return count;
  }

  connectionFor(guildId) {
    for (const connection of this.connections.values()) {
      if (connection.guildId === guildId && connection.connected) return connection;
    }
    return null;
  }

  connectionsFor(guildId) {
    return [...this.connections.values()].filter((connection) => connection.guildId === guildId);
  }

  getTeam(teamId) {
    if (this.teamCache.has(teamId)) return this.teamCache.get(teamId);
    const team = getTeam(teamId);
    if (team) this.teamCache.set(teamId, team);
    return team;
  }

  raidChannelFor(teamId) {
    const team = this.getTeam(teamId);
    return team?.raid_channel_id ?? null;
  }

  async send(guildId, command) {
    const connection = this.connectionFor(guildId);
    if (!connection) throw new Error('No connected server for this guild.');
    return connection.send(command);
  }

  shutdown() {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
    if (this.infoTimer) clearInterval(this.infoTimer);
    for (const connection of this.connections.values()) connection.destroy();
    this.connections.clear();
  }
}
