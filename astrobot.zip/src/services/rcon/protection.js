/**
 * Base protection rules.
 *
 * ZORP  - zoned offline raid protection: registered team boundaries negate or
 *         reduce damage while every team member is offline.
 * SRP   - server wide scheduled raid windows: raiding is only damage-effective
 *         inside configured day/hour windows.
 * RaidLink - pushes a damage alert to a team's private channel.
 */

/** Zone shapes: { type: 'circle', x, z, radius } or { type: 'polygon', points: [{x,z}] } */
export function withinZone(zone, point) {
  if (!zone || !point) return false;

  if (zone.type === 'circle') {
    return Math.hypot(point.x - zone.x, point.z - zone.z) <= Number(zone.radius ?? 0);
  }

  if (zone.type === 'polygon' && Array.isArray(zone.points) && zone.points.length >= 3) {
    let inside = false;
    const { points } = zone;

    for (let index = 0, previous = points.length - 1; index < points.length; previous = index, index += 1) {
      const a = points[index];
      const b = points[previous];
      const intersects =
        a.z > point.z !== b.z > point.z && point.x < ((b.x - a.x) * (point.z - a.z)) / (b.z - a.z) + a.x;
      if (intersects) inside = !inside;
    }

    return inside;
  }

  return false;
}

/** Handles windows that cross midnight (startHour > endHour). UTC only. */
export function isSrpActive(settings, date = new Date()) {
  const orp = settings.orp ?? {};
  if (!orp.srpEnabled) return false;

  const windows = Array.isArray(orp.srpWindows) ? orp.srpWindows : [];
  if (windows.length === 0) return true;

  const day = date.getUTCDay();
  const hour = date.getUTCHours();

  return windows.some((window) => {
    const days = Array.isArray(window.days) && window.days.length > 0 ? window.days : [0, 1, 2, 3, 4, 5, 6];
    if (!days.includes(day)) return false;

    const start = Number(window.startHour ?? 0);
    const end = Number(window.endHour ?? 24);
    if (start === end) return true;
    if (start < end) return hour >= start && hour < end;
    return hour >= start || hour < end;
  });
}

/**
 * @returns {{ blocked: boolean, reductionPercent: number, appliedDamage: number, reason: string }}
 */
export function evaluateProtection({ settings, team, onlineMembers = 0, zone = null, damage, point = null }) {
  const orp = settings.orp ?? {};

  if (orp.srpEnabled && !isSrpActive(settings)) {
    return { blocked: true, reductionPercent: 100, appliedDamage: 0, reason: 'Outside the SRP raid window' };
  }

  if (orp.zorpEnabled && team) {
    const activeZone = zone ?? parseZone(team.orp_zone);
    const inZone = activeZone ? (point ? withinZone(activeZone, point) : true) : false;

    if (inZone && onlineMembers === 0) {
      const reduction = Math.min(100, Math.max(0, Number(orp.zorpDamageReduction) || 0));
      const applied = Math.floor(Number(damage) * (1 - reduction / 100));
      return {
        blocked: reduction >= 100,
        reductionPercent: reduction,
        appliedDamage: applied,
        reason: `ZORP active (${reduction}% reduction, team offline)`,
      };
    }
  }

  return { blocked: false, reductionPercent: 0, appliedDamage: Number(damage) || 0, reason: 'No protection active' };
}

export function parseZone(raw) {
  if (!raw) return null;
  if (typeof raw === 'object') return raw;

  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function describeZone(zone) {
  if (!zone) return 'Not registered';
  if (zone.type === 'circle') return `Circle @ ${zone.x}, ${zone.z} · radius ${zone.radius}`;
  if (zone.type === 'polygon') return `Polygon · ${zone.points?.length ?? 0} vertices`;
  return 'Unknown zone';
}

/** RaidLink alert text. Kept compact for private team channels. */
export function formatRaidAlert({ team, damage, attacker, structure, coordinates, serverLabel = 'server' }) {
  const attackerName = attacker?.name ? `**${attacker.name}**` : 'Unknown attacker';
  const location = coordinates ? `Grid ${coordinates.grid}` : 'unknown location';
  return [
    `🛡️ **RaidLink** · ${serverLabel}`,
    `${attackerName} hit **${structure}** for **${Math.round(damage)}** damage (${location}).`,
    team ? `Team: **${team.name}** [${team.tag}]` : null,
  ]
    .filter(Boolean)
    .join('\n');
}
