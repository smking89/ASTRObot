import { gridRef } from '../../utils/format.js';

/**
 * Parses WebRCON console lines into typed telemetry events.
 *
 * Supported shapes (Rust and Rust Console Edition differ):
 *   "Alice[76561198000000000] was killed by Bob[76561...] using AssaultRifle"
 *   "Bob killed Alice with AssaultRifle at (120.4, 3.0, -890.2)"
 *   "Alice committed suicide"
 *   "Alice joined the server" / "Alice left the server"
 *   "[CHAT] Alice: hello"
 *   "Wall took 250 damage from Alice[7656...]"
 *   "Cargo Ship spawned" / "Supply Drop inbound"
 */
export const NPC_PATTERN = /\b(scientist|bear|wolf|boar|stag|chicken|helicopter|patrol|bradley|tank|npc)\b/i;
export const STRUCTURE_PATTERN = /\b(wall|door|foundation|roof|floor|gate|turret|tc|cupboard|box|furnace|sleeping bag|bed)\b/i;

const COORD_PATTERN = /\(?\s*(-?\d{1,4}(?:\.\d+)?)\s*,\s*(-?\d{1,4}(?:\.\d+)?)\s*,\s*(-?\d{1,4}(?:\.\d+)?)\s*\)?/;

const ID_SUFFIX = /^(?<name>.+?)\s*\[(?<externalId>\d{6,20})\]$/;

export function splitPlayer(raw) {
  const cleaned = String(raw ?? '')
    .trim()
    .replace(/^["']|["']$/g, '')
    .replace(/\s+/g, ' ');

  const match = ID_SUFFIX.exec(cleaned);
  if (match) return { name: match.groups.name.trim(), externalId: match.groups.externalId };
  return { name: cleaned, externalId: null };
}

export function extractCoordinates(line) {
  const match = COORD_PATTERN.exec(String(line ?? ''));
  if (!match) return null;
  const [x, y, z] = [Number(match[1]), Number(match[2]), Number(match[3])];
  if (![x, y, z].every(Number.isFinite)) return null;
  return { x, y, z, grid: gridRef(x, z) };
}

export function prettyWeapon(raw) {
  const value = String(raw ?? '').trim();
  if (!value) return 'Unknown';
  const cleaned = value
    .replace(/^.*\./, '')
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replaceAll('_', ' ')
    .trim();
  const aliases = {
    'Assault Rifle': 'Assault Rifle',
    AssaultRifle: 'Assault Rifle',
    BoltActionRifle: 'Bolt Action Rifle',
    SemiAutomaticRifle: 'Semi-Automatic Rifle',
    HuntingBow: 'Hunting Bow',
    Crossbow: 'Crossbow',
    Rock: 'Rock',
    SalvagedSword: 'Salvaged Sword',
  };
  return aliases[cleaned] ?? cleaned;
}

export function isNpc(name) {
  return NPC_PATTERN.test(String(name ?? ''));
}

const KILL_PATTERNS = [
  // victim-first (Rust dedicated)
  {
    regex:
      /^(?<victim>.+?)\s+was killed by\s+(?<killer>.+?)(?:\s+using\s+(?<weapon>[^()\[]+?))?(?:\s+at\s+\(?-?\d.*)?$/i,
    build: (groups, line) => ({
      kind: 'kill',
      victim: splitPlayer(groups.victim),
      killer: splitPlayer(groups.killer),
      weapon: prettyWeapon(groups.weapon),
      coordinates: extractCoordinates(line),
    }),
  },
  // killer-first (console builds / plugins)
  {
    regex: /^(?<killer>.+?)\s+killed\s+(?<victim>.+?)(?:\s+with\s+(?<weapon>[^()\[]+?))?(?:\s+at\s+\(?-?\d.*)?$/i,
    build: (groups, line) => ({
      kind: 'kill',
      victim: splitPlayer(groups.victim),
      killer: splitPlayer(groups.killer),
      weapon: prettyWeapon(groups.weapon),
      coordinates: extractCoordinates(line),
    }),
  },
  {
    regex: /^(?<victim>.+?)\s+(?:committed suicide|died|was found dead)(?:\s+at\s+\(?-?\d.*)?$/i,
    build: (groups, line) => ({
      kind: 'suicide',
      victim: splitPlayer(groups.victim),
      coordinates: extractCoordinates(line),
    }),
  },
];

const DAMAGE_PATTERN = /^(?<structure>.+?)\s+took\s+(?<damage>\d+(?:\.\d+)?)\s+damage\s+from\s+(?<attacker>.+?)(?:\s+at\s+\(?-?\d.*)?$/i;

const JOIN_PATTERNS = [
  /^(?<name>.+?)\s+joined the (?:server|game)$/i,
  /^(?<name>.+?)\s+has joined$/i,
  /^Client connected:\s*(?<name>.+)$/i,
];

const LEAVE_PATTERNS = [
  /^(?<name>.+?)\s+left the (?:server|game)$/i,
  /^(?<name>.+?)\s+disconnected(?:\s*\((?<reason>.*)\))?$/i,
  /^Client disconnected:\s*(?<name>.+)$/i,
];

const CHAT_PATTERNS = [
  /^\[CHAT\]\s*(?<name>[^:]+):\s*(?<message>.+)$/i,
  /^CHAT:\s*(?<name>[^:]+):\s*(?<message>.+)$/i,
  /^(?<name>[A-Za-z0-9_ .\-[\]]{2,32}):\s*(?<message>.+)$/,
];

const PVE_PATTERN = /\b(cargo ship|supply drop|patrol helicopter|chinook|bradley|apc|airstrike|meteor|easter egg)\b/i;
const ADMIN_PATTERN = /^(?:ADMIN|OWNER|MOD)\b|\b(?:banned|kicked|muted|teleported|granted|spawned)\b/i;

export function parseLine(rawLine, context = {}) {
  const line = String(rawLine ?? '').replaceAll(/\u0000/g, '').trim();
  if (!line) return null;

  for (const pattern of KILL_PATTERNS) {
    const match = pattern.regex.exec(line);
    if (match?.groups) {
      const event = pattern.build(match.groups, line);
      const victim = event.victim?.name ?? '';
      const killer = event.killer?.name ?? '';
      event.npc = isNpc(victim) || isNpc(killer);
      event.suicide = event.kind === 'suicide';
      event.serverId = context.serverId ?? null;
      event.guildId = context.guildId ?? null;
      event.raw = line;
      event.at = Date.now();
      return event;
    }
  }

  const damage = DAMAGE_PATTERN.exec(line);
  if (damage?.groups) {
    // Some server plugins append "owned by <player>"; RaidLink needs the defender.
    const ownerMatch = /owned by\s+(?<owner>[^()\[\]]+)/i.exec(line);
    return {
      kind: 'damage',
      structure: damage.groups.structure.trim(),
      damage: Number(damage.groups.damage),
      attacker: splitPlayer(damage.groups.attacker),
      owner: ownerMatch?.groups?.owner ? splitPlayer(ownerMatch.groups.owner) : null,
      coordinates: extractCoordinates(line),
      serverId: context.serverId ?? null,
      guildId: context.guildId ?? null,
      raw: line,
      at: Date.now(),
    };
  }

  for (const regex of JOIN_PATTERNS) {
    const match = regex.exec(line);
    if (match?.groups?.name) {
      return { kind: 'join', player: splitPlayer(match.groups.name), raw: line, at: Date.now(), ...context };
    }
  }

  for (const regex of LEAVE_PATTERNS) {
    const match = regex.exec(line);
    if (match?.groups?.name) {
      return {
        kind: 'leave',
        player: splitPlayer(match.groups.name),
        reason: match.groups.reason ?? null,
        raw: line,
        at: Date.now(),
        ...context,
      };
    }
  }

  for (const regex of CHAT_PATTERNS) {
    const match = regex.exec(line);
    if (match?.groups?.name && match.groups.message) {
      return {
        kind: 'chat',
        player: splitPlayer(match.groups.name),
        message: match.groups.message.trim(),
        raw: line,
        at: Date.now(),
        ...context,
      };
    }
  }

  if (PVE_PATTERN.test(line) && /\b(spawn|inbound|approaching|incoming|landed|destroyed)\b/i.test(line)) {
    return { kind: 'pve', subject: PVE_PATTERN.exec(line)[0], raw: line, at: Date.now(), ...context };
  }

  if (ADMIN_PATTERN.test(line)) {
    return { kind: 'admin', raw: line, at: Date.now(), ...context };
  }

  if (/^server\.(?:worldsize|seed|hostname)|^playerlist$/i.test(line) || /^\d+ players? (?:online|connected)/i.test(line)) {
    return { kind: 'server_status', raw: line, at: Date.now(), ...context };
  }

  return null;
}

/** Parses a `playerlist` response into names. */
export function parsePlayerList(message) {
  return String(message ?? '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line.length > 0 && !/^players?$/i.test(line))
    .map((line) => {
      const [name, id, ping, ...rest] = line.split(/\s{2,}|\t/);
      return { name: splitPlayer(name).name, externalId: /^\d{6,20}$/.test(id ?? '') ? id : null, ping: Number(ping) || null, extra: rest.join(' ') };
    });
}

/**
 * Parses the Rust Console `serverinfo` response. The payload is JSON with
 * player, max-player and queue counts; key names have varied across builds, so
 * every numeric field is matched case-insensitively and deeply.
 */
export function parseServerInfo(message) {
  const text = String(message ?? '').trim();
  if (!text) return null;

  let parsed = null;
  try {
    parsed = JSON.parse(text);
  } catch {
    parsed = null;
  }

  const found = {};
  const walk = (node) => {
    if (!node || typeof node !== 'object') return;
    for (const [key, value] of Object.entries(node)) {
      const normalized = key.toLowerCase().replace(/[^a-z]/g, '');
      const numeric = Number(value);
      if (Number.isFinite(numeric)) {
        if (['players', 'playercount', 'onlineplayers', 'activeplayers'].includes(normalized)) found.players ??= numeric;
        if (['maxplayers', 'maxplayercount', 'slots', 'maxslots'].includes(normalized)) found.maxPlayers ??= numeric;
        if (['queue', 'queued', 'queuedplayers', 'queuecount', 'inqueue', 'playersinqueue'].includes(normalized)) found.queue ??= numeric;
      }
      walk(value);
    }
  };
  walk(parsed);

  if (found.players == null && found.queue == null) {
    const pair = /(\d+)\s*(?:\/|of)\s*(\d+)\s*players?/i.exec(text);
    const players = pair ?? /players?\D{0,12}(\d+)/i.exec(text);
    const queue = /queu\w*\D{0,12}(\d+)/i.exec(text);
    if (players) {
      found.players = Number(players[1]);
      if (pair) found.maxPlayers = Number(pair[2]);
    }
    if (queue) found.queue = Number(queue[1]);
  }

  if (found.players == null && found.queue == null) return null;
  return { players: found.players ?? 0, maxPlayers: found.maxPlayers ?? null, queue: found.queue ?? null };
}
