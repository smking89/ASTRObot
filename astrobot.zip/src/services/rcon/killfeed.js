import { getGuildSettings } from '../../db/repositories/guilds.js';
import { getLinkByGamertag } from '../../db/repositories/links.js';
import { getTeamForUser } from '../../db/repositories/teams.js';
import { gridRef, truncate } from '../../utils/format.js';
import { COLORS } from '../../config/constants.js';
import { buildEmbed } from '../../ui/embeds.js';
import { iconAttachment, iconUrl } from '../../ui/badge-assets.js';
import { createLogger } from '../../core/logger.js';
import { applyPlaceholders, buildPlaceholders, rankForPlayer } from './placeholders.js';

const log = createLogger('killfeed');

/**
 * Advanced killfeed layout with placeholders.
 *
 * Legacy tokens:
 *   {killer} {victim} {weapon} {distance} {grid} {killer_clan} {victim_clan}
 *   {killer_id} {victim_id} {server} {time}
 *
 * Helios stat tokens (see placeholders.js):
 *   {KillerPlayerName} {KillerKills} {KillerDeaths} {KillerKD}
 *   {KillerCurrentStreak} {KillerBestStreak} {KillerStreak}
 *   {KillerWallet} {VictimWallet} {Currency} {Stolen} {Distance}
 *   {KillerPvPKills} {KillerPvPDeaths} {KillerPvPKD} and victim equivalents
 *   {KillerPvEKills} {KillerPvEDeaths} {KillerPvEKD} and victim equivalents
 */
export function formatKillfeed(event, { settings, serverLabel = 'server', identity = {}, layout = null, killerCoords = null }) {
  const config = settings ?? getGuildSettings(event.guildId);
  const killerClan = identity.killer?.teamTag ? `[${identity.killer.teamTag}]` : '';
  const victimClan = identity.victim?.teamTag ? `[${identity.victim.teamTag}]` : '';

  const coords = event.coordinates;
  const tracked = killerCoords ?? identity.killer?.lastCoords ?? null;
  const distance = coords && tracked ? Math.round(distanceBetween(tracked, coords)) : null;

  const replacements = {
    ...buildPlaceholders({ guildId: event.guildId, event, settings: config, identity, killerCoords: tracked }),
    killer: truncate(event.killer?.name ?? 'Unknown', 40),
    victim: truncate(event.victim?.name ?? 'Unknown', 40),
    weapon: event.weapon ?? 'Unknown',
    distance: distance ?? '?',
    grid: coords?.grid ?? gridRef(coords?.x, coords?.z),
    killer_clan: killerClan,
    victim_clan: victimClan,
    killer_id: event.killer?.externalId ?? '',
    victim_id: event.victim?.externalId ?? '',
    server: serverLabel,
    time: `<t:${Math.floor((event.at ?? Date.now()) / 1000)}:t>`,
  };

  let template = layout ?? config.killfeed.layout ?? '{killer} killed {victim}';

  // Accept {clan}, [clan] and [{clan}] styles, but never leave an empty "[]"
  // behind when a player has no team.
  template = template.replaceAll('[{killer_clan}]', '{killer_clan}').replaceAll('[{victim_clan}]', '{victim_clan}');
  if (!killerClan) template = template.replaceAll('[killer_clan]', '');
  if (!victimClan) template = template.replaceAll('[victim_clan]', '');

  return applyPlaceholders(template, replacements)
    // A player without a clan must never leave a stray "[]" behind, whichever
    // token style the template used.
    .replaceAll('[]', '')
    .replaceAll(/\s{2,}/g, ' ')
    .trim();
}

export function distanceBetween(a, b) {
  if (!a || !b) return 0;
  return Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
}

/**
 * Resolves a gamertag to { userId, teamTag, teamId } using the link table, so
 * killfeeds can show clan tags without trusting in-game names.
 */
export function resolveIdentity(guildId, gamertag) {
  try {
    const link = getLinkByGamertag(guildId, gamertag);
    if (!link) return null;
    const team = getTeamForUser(guildId, link.user_id);
    return {
      userId: link.user_id,
      gamertag: link.gamertag,
      platform: link.platform,
      teamId: team?.id ?? null,
      teamTag: team?.tag ?? null,
      teamName: team?.name ?? null,
    };
  } catch (error) {
    log.warn(`Identity lookup failed for ${gamertag}`, error);
    return null;
  }
}

/** Sends the formatted line, tolerating deleted or unwritable channels. */
export async function dispatchKillfeed({ client, event, serverLabel, killerCoords = null }) {
  const settings = getGuildSettings(event.guildId);
  if (!settings.killfeed.enabled) return null;

  const channelId = settings.channels.killfeed;
  if (!channelId) return null;

  const identity = {
    killer: resolveIdentity(event.guildId, event.killer?.name),
    victim: resolveIdentity(event.guildId, event.victim?.name),
  };

  const content = formatKillfeed(event, { settings, serverLabel, identity, killerCoords });
  if (!content) return null;

  const channel = await client.channels.fetch(channelId).catch(() => null);
  if (!channel?.isTextBased()) return null;

  // Embeds can show the real rank badge icon; plain content cannot.
  const rank = settings.killfeed.embed ? rankForPlayer(event.guildId, identity.killer?.userId) : null;
  const payload = settings.killfeed.embed
    ? {
        embeds: [
          buildEmbed({
            description: content,
            color: COLORS.brand,
            thumbnail: rank ? iconUrl(rank.icon) : null,
          }),
        ],
        files: rank ? [iconAttachment(rank.icon)] : [],
        allowedMentions: { parse: [] },
      }
    : { content: truncate(content, 2000), allowedMentions: { parse: [] } };

  return channel.send(payload).catch((error) => {
    log.warn(`Killfeed send failed for ${event.guildId}`, error);
    return null;
  });
}
