import { EventEmitter } from 'node:events';
import WebSocket from 'ws';
import { createLogger } from '../../core/logger.js';

/**
 * WebRCON client (Rust / Rust Console Edition).
 *
 * Protocol: wss://host:port/<password>, JSON frames
 *   -> { Identifier, Message, Name: "WebRcon" }
 *   <- { Identifier, Message, Type: "Welcome" | "Generic" | "Chat" }
 */
export class RconConnection extends EventEmitter {
  constructor({ guildId, serverId, label, host, port, password, secure = false, reconnectMs = 15_000 }) {
    super();
    this.guildId = guildId;
    this.serverId = serverId;
    this.label = label;
    this.host = host;
    this.port = port;
    this.password = password;
    this.secure = secure || String(host).startsWith('wss://');
    this.reconnectMs = reconnectMs;
    this.log = createLogger(`rcon:${label}`);

    this.socket = null;
    this.identifier = 0;
    this.connected = false;
    this.connectedAt = null;
    this.closedByUser = false;
    this.attempts = 0;
    this.reconnectTimer = null;
    this.keepaliveTimer = null;
    this.pending = new Map();
  }

  get url() {
    const host = String(this.host).replace(/^wss?:\/\//, '');
    return `${this.secure ? 'wss' : 'ws'}://${host}:${this.port}/${encodeURIComponent(this.password)}`;
  }

  connect() {
    if (this.socket && (this.connected || this.socket.readyState === WebSocket.OPEN)) return this;
    this.closedByUser = false;

    const socket = new WebSocket(this.url, { handshakeTimeout: 10_000 });
    this.socket = socket;

    socket.on('open', () => {
      // WebRCON sends a Welcome frame; treat open as connected for command
      // purposes but surface the handshake separately.
      this.log.info('socket open, awaiting handshake');
    });

    socket.on('message', (raw) => this.handleFrame(raw));

    socket.on('close', (code, reason) => {
      this.connected = false;
      this.connectedAt = null;
      this.stopKeepalive();
      this.emit('disconnected', { code, reason: reason?.toString?.() ?? '' });
      if (!this.closedByUser) this.scheduleReconnect();
    });

    socket.on('error', (error) => {
      this.log.error(`socket error: ${error.message}`);
      this.emit('error', error);
    });

    socket.on('pong', () => {
      this.lastPong = Date.now();
    });

    return this;
  }

  handleFrame(raw) {
    let frame;
    try {
      frame = JSON.parse(raw.toString());
    } catch {
      this.emit('raw', raw.toString());
      return;
    }

    if (frame.Type === 'Welcome') {
      this.connected = true;
      this.connectedAt = Date.now();
      this.attempts = 0;
      this.startKeepalive();
      this.log.info('connected');
      this.emit('connected', frame);
      return;
    }

    if (frame.Type === 'Chat') {
      this.emit('message', { type: 'chat', message: String(frame.Message ?? ''), raw: frame });
      return;
    }

    // Console responses echo the request identifier, so a `serverinfo` reply can
    // be matched without confusing it with unsolicited console output.
    const identifier = frame.Identifier ?? frame.identifier;
    const pending = identifier != null ? this.pending.get(identifier) : null;
    if (pending) {
      this.pending.delete(identifier);
      pending.resolve(String(frame.Message ?? ''));
      return;
    }

    this.emit('message', { type: 'console', message: String(frame.Message ?? ''), raw: frame });
  }

  /** Sends a command and resolves with the matching response message. */
  request(command, timeoutMs = 5000) {
    if (!this.connected || this.socket?.readyState !== WebSocket.OPEN) {
      return Promise.reject(new Error(`RCON ${this.label} is not connected.`));
    }

    const identifier = (this.identifier += 1);
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(identifier);
        reject(new Error(`RCON ${this.label} did not answer ${command}.`));
      }, timeoutMs);

      this.pending.set(identifier, {
        resolve: (value) => {
          clearTimeout(timer);
          resolve(value);
        },
        reject: (error) => {
          clearTimeout(timer);
          reject(error);
        },
      });

      const payload = JSON.stringify({ Identifier: identifier, Message: String(command), Name: 'WebRcon' });
      this.socket.send(payload, (error) => {
        if (!error) return;
        clearTimeout(timer);
        this.pending.delete(identifier);
        reject(error);
      });
    });
  }

  /** Sends a console command. Resolves once the frame is flushed. */
  send(command) {
    if (!this.connected || this.socket?.readyState !== WebSocket.OPEN) {
      return Promise.reject(new Error(`RCON ${this.label} is not connected.`));
    }

    const payload = JSON.stringify({
      Identifier: (this.identifier += 1),
      Message: String(command),
      Name: 'WebRcon',
    });

    return new Promise((resolve, reject) => {
      this.socket.send(payload, (error) => (error ? reject(error) : resolve(true)));
    });
  }

  startKeepalive() {
    this.stopKeepalive();
    this.keepaliveTimer = setInterval(() => {
      if (this.socket?.readyState === WebSocket.OPEN) this.socket.ping();
    }, 30_000);
    this.keepaliveTimer.unref?.();
  }

  stopKeepalive() {
    if (this.keepaliveTimer) clearInterval(this.keepaliveTimer);
    this.keepaliveTimer = null;
  }

  scheduleReconnect() {
    if (this.reconnectTimer || this.closedByUser) return;

    this.attempts += 1;
    const backoff = Math.min(this.reconnectMs * 2 ** Math.min(5, this.attempts - 1), 5 * 60_000);
    const delay = backoff + Math.floor(Math.random() * 2000);

    this.log.warn(`reconnecting in ${Math.round(delay / 1000)}s (attempt ${this.attempts})`);
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.connect();
    }, delay);
    this.reconnectTimer.unref?.();
  }

  destroy() {
    this.closedByUser = true;
    this.connected = false;
    this.stopKeepalive();
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.socket?.removeAllListeners();
    this.socket?.close();
    this.socket = null;
  }
}
