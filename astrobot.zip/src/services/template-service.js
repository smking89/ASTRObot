import { ChannelType, OverwriteType, PermissionFlagsBits } from 'discord.js';
import { ValidationError } from '../core/errors.js';
import { env } from '../config/env.js';
import { KIT_ROLE_NAMES, OFFICIAL_STAFF_ROLES, STAFF_ROLE_NAMES } from '../config/server-templates.js';
import { getGuildSettings, patchGuildSetting } from '../db/repositories/guilds.js';
import { normalizeStructureName } from './template-builder.js';
import { deployTemplatePanels, planTemplatePanels } from './panel-deploy.js';
import { captureRoleBackup, restoreRoleBackup } from './role-backup-service.js';

/**
 * Server templates are additive snapshots. Capturing records role names,
 * categories, channels, role-based permission overwrites, staff roles and kits.
 * Applying creates missing structure and reuses anything that already matches
 * after Discord's name sanitisation; it never deletes or renames server
 * structure. Roles/categories/channels duplicated inside a template are skipped.
 */

const CLONED_CHANNEL_TYPES = new Set([
  ChannelType.GuildText,
  ChannelType.GuildVoice,
  ChannelType.GuildAnnouncement,
  ChannelType.GuildForum,
]);

const keyOf = (value) => normalizeStructureName(value);

const BOLD_UPPER = new Map(
  [...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'].map((letter, index) => [letter, String.fromCodePoint(0x1d400 + index)]),
);

/**
 * Category headings use Unicode mathematical bold. Discord has no markdown in
 * channel names, and normalizeStructureName() NFKD-folds these back to ASCII,
 * so a bold heading still matches the same template entry.
 */
export function boldCategoryName(name) {
  return String(name ?? '').replace(/[A-Za-z]/g, (letter) => BOLD_UPPER.get(letter.toUpperCase()) ?? letter);
}

export async function captureGuildTemplate(guild) {
  if (!guild) throw new ValidationError('This command must be used inside a server.');

  const [channels, roles] = await Promise.all([guild.channels.fetch(), guild.roles.fetch()]);
  const roleById = new Map([...roles.values()].map((role) => [role.id, role]));
  const categoryById = new Map(
    [...channels.values()]
      .filter((channel) => channel.type === ChannelType.GuildCategory)
      .map((channel) => [channel.id, channel]),
  );

  const categories = [...channels.values()]
    .filter((channel) => channel.type === ChannelType.GuildCategory)
    .sort((a, b) => a.position - b.position)
    .map((channel) => ({
      name: channel.name,
      position: channel.position,
      overwrites: serializeOverwrites(channel, roleById, guild.id),
    }));

  const serializedChannels = [...channels.values()]
    .filter((channel) => CLONED_CHANNEL_TYPES.has(channel.type))
    .sort((a, b) => a.position - b.position)
    .map((channel) => {
      const parent = channel.parentId ? categoryById.get(channel.parentId) : null;
      return {
        name: channel.name,
        type: channel.type,
        position: channel.position,
        parentName: parent?.name ?? null,
        topic: 'topic' in channel ? channel.topic ?? null : null,
        nsfw: 'nsfw' in channel ? Boolean(channel.nsfw) : false,
        rateLimitPerUser: 'rateLimitPerUser' in channel ? Number(channel.rateLimitPerUser ?? 0) : 0,
        bitrate: 'bitrate' in channel ? Number(channel.bitrate ?? 0) : null,
        userLimit: 'userLimit' in channel ? Number(channel.userLimit ?? 0) : null,
        overwrites: serializeOverwrites(channel, roleById, guild.id),
      };
    });

  const serializedRoles = [...roles.values()]
    .filter((role) => role.id !== guild.id && !role.managed)
    .sort((a, b) => a.position - b.position)
    .map((role) => ({
      name: role.name,
      color: role.color,
      hoist: role.hoist,
      mentionable: role.mentionable,
      permissions: role.permissions.bitfield.toString(),
      position: role.position,
    }));

  const settings = getGuildSettings(guild.id) ?? {};
  const staffRoleIds = new Set(settings.access?.staffRoleIds ?? []);
  const staffRoles = [...roles.values()]
    .filter((entry) => staffRoleIds.has(entry.id))
    .map((entry) => entry.name);

  const kits = (settings.misc?.kits ?? []).map((kit) => {
    const { roleId, ...rest } = kit;
    const roleName = roleId ? roleById.get(roleId)?.name : null;
    return { ...rest, ...(roleName ? { roleName } : {}) };
  });

  return {
    version: 1,
    capturedAt: new Date().toISOString(),
    guildName: guild.name,
    roles: serializedRoles,
    categories,
    channels: serializedChannels,
    kits,
    staffRoles,
  };
}

/** Sections an admin can include or exclude before a template is applied. */
export const TEMPLATE_SECTIONS = Object.freeze([
  { id: 'roles', code: 'r', label: 'Base roles', description: 'Admin, Moderator, Staff, Member and other layout roles.' },
  { id: 'staffRoles', code: 's', label: 'Staff roles', description: 'Server Owner, Server Admin, Server Moderator and official staff roles.' },
  { id: 'kitRoles', code: 'k', label: 'Kit roles', description: 'FreeKit, FreeKit2 and EliteKit1-44 access roles.' },
  { id: 'categories', code: 'c', label: 'Categories', description: 'Category folders for the layout.' },
  { id: 'channels', code: 'h', label: 'Channels', description: 'Text, voice and announcement channels.' },
  { id: 'panels', code: 'p', label: 'Panels', description: 'Ticket, shop, LFG and the other panel messages.' },
  { id: 'kits', code: 't', label: 'Shop kits', description: 'Kit products registered in the shop.' },
]);

const ALL_SECTION_IDS = TEMPLATE_SECTIONS.map((entry) => entry.id);

/** `rskchpt`-style encoding keeps the confirm button custom id short. */
export function encodeTemplateSections(ids) {
  const wanted = new Set(Array.isArray(ids) && ids.length > 0 ? ids : ALL_SECTION_IDS);
  return TEMPLATE_SECTIONS.filter((entry) => wanted.has(entry.id))
    .map((entry) => entry.code)
    .join('');
}

export function decodeTemplateSections(code) {
  const text = String(code ?? '').trim();
  if (!text) return [...ALL_SECTION_IDS];
  const wanted = new Set(TEMPLATE_SECTIONS.filter((entry) => text.includes(entry.code)).map((entry) => entry.id));
  return wanted.size > 0 ? [...wanted] : [...ALL_SECTION_IDS];
}

const kitRoleKeys = new Set(KIT_ROLE_NAMES.map(keyOf));
const staffRoleKeys = new Set(STAFF_ROLE_NAMES.map(keyOf));

/**
 * Keeps only the sections the admin ticked. Channels always keep their
 * categories, because a channel without its parent cannot be created.
 */
export function filterTemplateParts(template, parts) {
  const chosen = new Set(Array.isArray(parts) && parts.length > 0 ? parts : ALL_SECTION_IDS);
  const roles = (template.roles ?? []).filter((entry) => {
    const key = keyOf(entry.name);
    if (kitRoleKeys.has(key)) return chosen.has('kitRoles');
    if (staffRoleKeys.has(key)) return chosen.has('staffRoles');
    return chosen.has('roles');
  });

  return {
    ...template,
    roles,
    categories: chosen.has('categories') || chosen.has('channels') ? template.categories ?? [] : [],
    channels: chosen.has('channels') ? template.channels ?? [] : [],
    panels: chosen.has('panels') ? template.panels ?? [] : [],
    kits: chosen.has('kits') ? template.kits ?? [] : [],
    staffRoles: chosen.has('staffRoles') ? template.staffRoles ?? [] : [],
  };
}

/**
 * Deletes every channel, category and role the bot is allowed to remove, so a
 * confirmed apply replaces the layout instead of adding to it.
 *
 * @everyone, managed (bot/integration) roles and roles above the bot stay: the
 * bot cannot delete them, and removing its own role would cut the apply short.
 */
export async function wipeGuildStructure(guild, { reason = 'Template reinstall' } = {}) {
  if (!guild?.id) throw new ValidationError('This command must be used inside a server.');
  const me = guild.members?.me ?? (await guild.members.fetch(guild.client.user.id));
  const highest = Number(me?.roles?.highest?.position ?? 0);
  const errors = [];
  let channelsDeleted = 0;
  let rolesDeleted = 0;
  let skipped = 0;

  const channels = [...(await guild.channels.fetch()).values()];
  const ordered = [
    ...channels.filter((channel) => channel.type !== ChannelType.GuildCategory),
    ...channels.filter((channel) => channel.type === ChannelType.GuildCategory),
  ];
  for (const channel of ordered) {
    try {
      await channel.delete(reason);
      channelsDeleted += 1;
    } catch (error) {
      errors.push(`delete #${channel.name}: ${error.message}`);
    }
  }

  const roles = [...(await guild.roles.fetch()).values()];
  for (const entry of roles) {
    if (entry.id === guild.id || entry.managed) continue;
    if (Number(entry.position) >= highest) {
      skipped += 1;
      continue;
    }
    try {
      await entry.delete(reason);
      rolesDeleted += 1;
    } catch (error) {
      errors.push(`delete role ${entry.name}: ${error.message}`);
    }
  }

  return { channelsDeleted, rolesDeleted, skipped, errors };
}

const applyLocks = new Map();

export async function applyGuildTemplate(guild, template, options = {}) {
  if (!guild?.id) return applyGuildTemplateUnlocked(guild, template, options);

  // Serialize applies per guild. Two clicks or a repair racing an apply would
  // otherwise both snapshot the same empty structure and create every channel
  // twice.
  const previous = applyLocks.get(guild.id) ?? Promise.resolve();
  const run = previous.then(
    () => applyGuildTemplateUnlocked(guild, template, options),
    () => applyGuildTemplateUnlocked(guild, template, options),
  );
  const guarded = run.catch(() => {});
  applyLocks.set(guild.id, guarded);
  return run.finally(() => {
    if (applyLocks.get(guild.id) === guarded) applyLocks.delete(guild.id);
  });
}

async function applyGuildTemplateUnlocked(guild, template, { actorId = null, parts = null, wipe = false } = {}) {
  if (!guild) throw new ValidationError('This command must be used inside a server.');
  if (!template || typeof template !== 'object') throw new ValidationError('That template is unreadable.');

  const me = guild.members.me ?? (await guild.members.fetch(guild.client.user.id));
  const canManageChannels = me?.permissions?.has?.(PermissionFlagsBits.ManageChannels);
  const canManageRoles = me?.permissions?.has?.(PermissionFlagsBits.ManageRoles);
  if (!canManageChannels || !canManageRoles) {
    throw new ValidationError('I need **Manage Channels** and **Manage Roles** to apply a template.');
  }

  template = filterTemplateParts(template, parts);
  let roleBackup = null;
  let roleRestore = null;
  let wiped = null;

  if (wipe) {
    // Capture first: if the backup cannot be written, abort while every role
    // assignment is still intact instead of wiping and hoping.
    roleBackup = await captureRoleBackup(guild, { actorId, templateName: template.name ?? null });
    wiped = await wipeGuildStructure(guild, { reason: `Template reinstall${actorId ? ` by ${actorId}` : ''}` });
  }

  const [channels, roles] = await Promise.all([guild.channels.fetch(), guild.roles.fetch()]);
  const roleMap = new Map([[keyOf('@everyone'), guild.id]]);
  const roleKeys = new Set([keyOf('@everyone')]);
  const officialGuild = Boolean(env.discord.officialGuildId) && guild.id === env.discord.officialGuildId;
  const officialStaffKeys = new Set(OFFICIAL_STAFF_ROLES.map(keyOf));
  const categoryMap = new Map();
  const categoryKeys = new Set();
  const channelKeys = new Set(
    [...channels.values()].map((channel) => `${channel.type}:${keyOf(channel.name)}`),
  );
  const channelIds = new Map();
  let rolesCreated = 0;
  let categoriesCreated = 0;
  let channelsCreated = 0;
  let skipped = 0;
  const errors = [...(wiped?.errors ?? [])];
  const reason = `Server template${actorId ? ` applied by ${actorId}` : ''}`;

  for (const entry of template.roles ?? []) {
    const key = keyOf(entry.name);
    if (!key || key === keyOf('@everyone') || roleKeys.has(key)) continue;
    roleKeys.add(key);

    // Official leadership/staff roles never leave the official AstroBot guild.
    if (!officialGuild && officialStaffKeys.has(key)) {
      skipped += 1;
      continue;
    }

    const existing = [...roles.values()].find((role) => !role.managed && keyOf(role.name) === key);
    if (existing) {
      roleMap.set(key, existing.id);
      continue;
    }

    try {
      const role = await guild.roles.create({
        name: entry.name,
        color: Number(entry.color) || 0,
        hoist: Boolean(entry.hoist),
        mentionable: Boolean(entry.mentionable),
        permissions: BigInt(entry.permissions ?? 0),
        reason,
      });
      roleMap.set(key, role.id);
      rolesCreated += 1;
    } catch (error) {
      errors.push(`role ${entry.name}: ${error.message}`);
    }
  }

  // The layout roles now exist again; put members back into the roles they had
  // before the wipe, matched by name (and recreate any held role the template
  // did not rebuild).
  if (roleBackup) {
    try {
      roleRestore = await restoreRoleBackup(guild, roleBackup.id, {
        reason: `Template role restore${actorId ? ` by ${actorId}` : ''}`,
      });
      errors.push(...roleRestore.errors);
    } catch (error) {
      errors.push(`role restore: ${error.message}`);
    }
  }

  for (const entry of template.categories ?? []) {
    const key = keyOf(entry.name);
    if (!key || categoryKeys.has(key)) continue;
    categoryKeys.add(key);

    const existing = channels.find((channel) => channel.type === ChannelType.GuildCategory && keyOf(channel.name) === key);
    if (existing) {
      categoryMap.set(key, existing.id);
      continue;
    }

    try {
      const category = await guild.channels.create({
        name: boldCategoryName(entry.name),
        type: ChannelType.GuildCategory,
        permissionOverwrites: resolveOverwrites(entry.overwrites, roleMap, guild.id),
        reason,
      });
      categoryMap.set(key, category.id);
      categoriesCreated += 1;
    } catch (error) {
      errors.push(`category ${entry.name}: ${error.message}`);
    }
  }

  for (const entry of template.channels ?? []) {
    const key = keyOf(entry.name);
    if (!key) continue;

    const parentKey = entry.parentName ? keyOf(entry.parentName) : null;
    const parentId = parentKey ? categoryMap.get(parentKey) ?? null : null;
    if (parentKey && !parentId) {
      skipped += 1;
      errors.push(`channel ${entry.name}: category ${entry.parentName} is missing`);
      continue;
    }

    const structuralKey = `${entry.type}:${key}`;
    const existing = channels.find(
      (channel) => channel.type === entry.type && keyOf(channel.name) === key,
    );
    if (existing) {
      channelKeys.add(structuralKey);
      if (!channelIds.has(key)) channelIds.set(key, existing.id);
      skipped += 1;
      continue;
    }
    if (channelKeys.has(structuralKey)) {
      skipped += 1;
      continue;
    }

    // Announcement channels need the guild's NEWS feature. Community servers
    // that never enabled it reject type 5, so fall back to a text channel with
    // the same name instead of losing the channel entirely.
    const canAnnounce = Boolean(guild.features?.has?.('NEWS'));
    const createType = entry.type === ChannelType.GuildAnnouncement && !canAnnounce ? ChannelType.GuildText : entry.type;

    const options = {
      name: entry.name,
      type: createType,
      permissionOverwrites: resolveOverwrites(entry.overwrites, roleMap, guild.id),
      reason,
    };
    if (parentId) options.parent = parentId;
    if (entry.type === ChannelType.GuildVoice) {
      if (entry.bitrate) options.bitrate = Number(entry.bitrate);
      if (entry.userLimit) options.userLimit = Number(entry.userLimit);
    } else if (entry.type === ChannelType.GuildText || entry.type === ChannelType.GuildAnnouncement || entry.type === ChannelType.GuildForum) {
      if (entry.topic) options.topic = String(entry.topic).slice(0, 1024);
      if (entry.nsfw) options.nsfw = true;
      if (entry.rateLimitPerUser) options.rateLimitPerUser = Number(entry.rateLimitPerUser);
    }

    try {
      const created = await guild.channels.create(options);
      channelKeys.add(structuralKey);
      if (created?.id && !channelIds.has(key)) channelIds.set(key, created.id);
      channelsCreated += 1;
    } catch (error) {
      errors.push(`channel ${entry.name}: ${error.message}`);
    }
  }

  // Staff roles and kits are settings, not channel structure. Merge them so an
  // apply never removes a role or kit an owner already configured.
  let staffMerged = 0;
  let kitsAdded = 0;
  try {
    const settings = getGuildSettings(guild.id) ?? {};
    const staffIds = (template.staffRoles ?? [])
      .map((name) => roleMap.get(keyOf(name)))
      .filter(Boolean);

    if (staffIds.length > 0) {
      const current = settings.access?.staffRoleIds ?? [];
      const merged = [...new Set([...current, ...staffIds])];
      if (merged.length !== current.length) {
        patchGuildSetting(guild.id, 'access.staffRoleIds', merged, { actorId });
        staffMerged = staffIds.filter((id) => !current.includes(id)).length;
      }
    }

    const templateKits = template.kits ?? [];
    if (templateKits.length > 0) {
      const current = settings.misc?.kits ?? [];
      const existingKeys = new Set(current.map((kit) => keyOf(kit.name)));
      const merged = [...current];
      for (const kit of templateKits) {
        const label = String(kit.name ?? '').trim();
        const key = keyOf(label);
        if (!key || existingKeys.has(key)) continue;

        const roleId = kit.roleName ? roleMap.get(keyOf(kit.roleName)) : kit.roleId ?? null;
        merged.push({
          name: label,
          price: Math.max(0, Number(kit.price) || 0),
          rconCommand: String(kit.rconCommand ?? ''),
          ...(roleId ? { roleId } : {}),
        });
        existingKeys.add(key);
        kitsAdded += 1;
      }

      if (kitsAdded > 0) patchGuildSetting(guild.id, 'misc.kits', merged, { actorId });
    }
  } catch (error) {
    errors.push(`settings: ${error.message}`);
  }

  const panels = await deployTemplatePanels({ guild, template, channelIds, actorId });
  errors.push(...panels.errors);

  return {
    wiped,
    rolesCreated,
    categoriesCreated,
    channelsCreated,
    skipped,
    staffMerged,
    kitsAdded,
    roleBackup,
    roleRestore,
    panelsPosted: panels.posted,
    panels: panels.channels,
    errors,
  };
}

/**
 * Non-destructive preview: what the template would add to this guild, and what
 * already exists by name/type/parent and will therefore be reused.
 */
export function planGuildTemplate(guild, template) {
  const channels = [...(guild?.channels?.cache?.values?.() ?? [])];
  const roles = [...(guild?.roles?.cache?.values?.() ?? [])];

  const roleNames = new Set(roles.map((role) => keyOf(role.name)));
  const officialGuild = Boolean(env.discord.officialGuildId) && guild?.id === env.discord.officialGuildId;
  const officialStaffKeys = new Set(OFFICIAL_STAFF_ROLES.map(keyOf));
  const categories = new Map(
    channels.filter((channel) => channel.type === ChannelType.GuildCategory).map((channel) => [keyOf(channel.name), channel]),
  );

  const seenRoles = new Set();
  let restrictedRoles = 0;
  const rolePlan = (template.roles ?? []).filter((entry) => {
    const key = keyOf(entry.name);
    if (!key || key === keyOf('@everyone') || roleNames.has(key) || seenRoles.has(key)) return false;
    seenRoles.add(key);
    if (!officialGuild && officialStaffKeys.has(key)) {
      restrictedRoles += 1;
      return false;
    }
    return true;
  });

  const seenCategories = new Set();
  const categoryPlan = (template.categories ?? []).filter((entry) => {
    const key = keyOf(entry.name);
    if (!key || categories.has(key) || seenCategories.has(key)) return false;
    seenCategories.add(key);
    return true;
  });

  const seenChannels = new Set();
  const channelPlan = (template.channels ?? []).filter((entry) => {
    const key = keyOf(entry.name);
    if (!key) return false;
    const structuralKey = `${entry.type}:${key}`;
    if (seenChannels.has(structuralKey)) return false;
    seenChannels.add(structuralKey);

    return !channels.some(
      (channel) => channel.type === entry.type && keyOf(channel.name) === key,
    );
  });

  return {
    roles: rolePlan,
    categories: categoryPlan,
    channels: channelPlan,
    existing: {
      roles: (template.roles ?? []).length - rolePlan.length - restrictedRoles,
      categories: (template.categories ?? []).length - categoryPlan.length,
      channels: (template.channels ?? []).length - channelPlan.length,
    },
    restrictedRoles,
    panels: planTemplatePanels(template),
  };
}

function serializeOverwrites(channel, roleById, guildId) {
  return [...channel.permissionOverwrites.cache.values()]
    .filter((overwrite) => overwrite.type === OverwriteType.Role)
    .map((overwrite) => {
      const role = roleById.get(overwrite.id);
      const name = overwrite.id === guildId ? '@everyone' : role?.name;
      if (!name) return null;
      return {
        type: 'role',
        name,
        allow: overwrite.allow.bitfield.toString(),
        deny: overwrite.deny.bitfield.toString(),
      };
    })
    .filter(Boolean);
}

function resolveOverwrites(entries, roleMap, guildId) {
  const result = [];
  for (const entry of entries ?? []) {
    if (entry?.type !== 'role' || !entry.name) continue;
    const key = keyOf(entry.name);
    const id = key === keyOf('@everyone') ? guildId : roleMap.get(key);
    if (!id) continue;
    try {
      result.push({
        id,
        type: OverwriteType.Role,
        allow: BigInt(entry.allow ?? 0),
        deny: BigInt(entry.deny ?? 0),
      });
    } catch {
      // Ignore malformed permission data rather than aborting the whole apply.
    }
  }
  return result;
}
