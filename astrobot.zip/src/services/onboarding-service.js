import { ChannelType } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import {
  addGiveawayEntry,
  createVerification,
  expireVerification,
  getTempChannel,
  grantTimeRole,
  hasTimeRole,
  listGiveawayEntries,
  listDueGiveaways,
  giveawayTicketWeights,
  onboardingGrowth,
  pendingVerifications,
  recentJoins,
  recordOnboardingEvent,
  setGiveawayMessage,
  setTempChannel,
  deleteTempChannel,
  finishGiveaway,
  getVerification,
  markVerified,
} from '../db/repositories/onboarding.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, row, stringSelect } from '../ui/components.js';
import { COLORS } from '../config/constants.js';
import { uniqueId, weightedDraw } from '../utils/random.js';
import { announceGiveawayWinners } from './giveaway-service.js';
import { parseHexColor } from '../utils/parse.js';
import { createLogger } from '../core/logger.js';
import { truncate } from '../utils/format.js';

const log = createLogger('onboarding');

export function fillTemplate(text, member) {
  return String(text ?? '')
    .replaceAll('{user}', `<@${member.id}>`)
    .replaceAll('{username}', member.user?.username ?? 'member')
    .replaceAll('{server}', member.guild?.name ?? 'the server')
    .replaceAll('{memberCount}', String(member.guild?.memberCount ?? 0));
}

function normalizeId(value) {
  if (Array.isArray(value)) return value[0] ?? null;
  return value ?? null;
}

function channelFor(guild, settings, pathValue) {
  const id = normalizeId(pathValue);
  return id ? guild.channels.cache.get(id) ?? null : null;
}

async function sendWelcome(member, settings) {
  const welcome = settings.onboarding?.welcome;
  if (!welcome?.enabled) return;

  const embed = buildEmbed({
    title: fillTemplate(welcome.title, member),
    description: fillTemplate(welcome.message, member),
    color: safeColor(welcome.color),
    image: welcome.imageUrl || member.guild.bannerURL?.({ size: 1024 }) || null,
  });
  const channel = channelFor(member.guild, settings, welcome.channelId ?? settings.channels?.welcome);
  if (channel?.isTextBased?.()) await channel.send({ embeds: [embed], allowedMentions: { parse: [] } }).catch(() => null);

  if (welcome.dm) {
    const dm = buildEmbed({
      title: fillTemplate(welcome.title, member),
      description: fillTemplate(welcome.dmMessage || welcome.message, member),
      color: safeColor(welcome.color),
      image: welcome.imageUrl || null,
    });
    await member.send({ embeds: [dm] }).catch(() => null);
  }
}

async function sendRules(member, settings) {
  const rules = settings.onboarding?.rulesOnJoin;
  if (!rules?.enabled) return;

  const config = settings.messages?.rules ?? {};
  const supportId = config.supportChannelId ?? settings.channels?.tickets ?? settings.tickets?.categoryId ?? null;
  const description = String(config.text ?? '').replaceAll('{support}', supportId ? `<#${supportId}>` : '#support');
  if (!description) return;

  const embed = buildEmbed({
    title: config.title || 'Rules',
    description,
    color: COLORS.brand,
    footer: config.footer || null,
  });

  if (rules.dm) {
    await member.send({ embeds: [embed] }).catch(() => null);
    return;
  }

  const channel = channelFor(member.guild, settings, config.channelId ?? settings.channels?.welcome);
  if (channel?.isTextBased?.()) await channel.send({ embeds: [embed], allowedMentions: { parse: [] } }).catch(() => null);
}

async function sendChallenge(member, settings) {
  const borderwall = settings.onboarding?.borderwall;
  const roleId = normalizeId(borderwall?.verifiedRoleId);
  if (!borderwall?.enabled || !roleId) return;

  const channel =
    channelFor(member.guild, settings, borderwall.channelId) ??
    channelFor(member.guild, settings, settings.channels?.welcome) ??
    member.guild.systemChannel;
  if (!channel?.isTextBased?.()) return;

  const verification = createVerification({
    guildId: member.guild.id,
    userId: member.id,
    channelId: channel.id,
    expiresAt: Date.now() + Math.max(1, Number(borderwall.timeoutMinutes) || 10) * 60_000,
  });

  const embed = buildEmbed({
    title: '🛡️ Borderwall verification',
    description: fillTemplate(borderwall.message, member),
    color: COLORS.warning,
  });
  const message = await channel
    .send({
      content: `<@${member.id}>`,
      embeds: [embed],
      components: [row(button({ id: customId('onboarding', 'verify', verification.id), label: 'Verify', emoji: '✅', style: 3 }))],
      allowedMentions: { users: [member.id] },
    })
    .catch(() => null);

  if (message) {
    verification.message_id = message.id;
    // The repository has no dedicated message update; this is a simple,
    // idempotent update that keeps the timeout message actionable.
    const { getDb } = await import('../db/index.js');
    getDb().prepare('UPDATE onboarding_verifications SET message_id = ? WHERE id = ?').run(message.id, verification.id);
  }
}

export async function onMemberJoin(member) {
  const settings = getGuildSettings(member.guild.id);
  if (!settings.onboarding?.enabled) return;

  if (settings.onboarding.analytics?.enabled !== false) {
    recordOnboardingEvent({ guildId: member.guild.id, userId: member.id, kind: 'join' });
  }

  const auto = settings.onboarding.autoroles;
  if (auto?.enabled && Array.isArray(auto.roleIds) && auto.roleIds.length > 0) {
    const grant = async () => {
      for (const roleId of auto.roleIds.slice(0, 20)) {
        await member.roles.add(roleId, 'Onboarding auto role').catch((error) => log.warn(`Could not grant auto role ${roleId} to ${member.id}`, error));
      }
    };
    const delay = Math.max(0, Number(auto.delaySeconds) || 0);
    if (delay > 0) {
      const timer = setTimeout(() => void grant(), delay * 1000);
      timer.unref?.();
    } else {
      await grant();
    }
  }

  await sendChallenge(member, settings);
  await sendWelcome(member, settings);
  await sendRules(member, settings);
}

export async function onMemberLeave(member) {
  const settings = getGuildSettings(member.guild.id);
  if (!settings.onboarding?.enabled) return;

  if (settings.onboarding.analytics?.enabled !== false) {
    recordOnboardingEvent({ guildId: member.guild.id, userId: member.id, kind: 'leave' });
  }
  const leaver = settings.onboarding.leaver;
  if (!leaver?.enabled) return;

  const channel = channelFor(member.guild, settings, leaver.channelId ?? settings.channels?.joins);
  if (!channel?.isTextBased?.()) return;

  const embed = buildEmbed({
    title: '👋 Member left',
    description: fillTemplate(leaver.message, member),
    color: COLORS.neutral,
  });
  await channel.send({ embeds: [embed], allowedMentions: { parse: [] } }).catch(() => null);
}

export async function onVoiceStateUpdate(oldState, newState) {
  const member = newState.member ?? oldState.member;
  if (!member || member.user?.bot) return;

  const settings = getGuildSettings(member.guild.id);
  const temp = settings.onboarding?.tempChannels;
  if (!temp?.enabled) return;

  const hubId = normalizeId(temp.hubChannelId);
  if (newState.channelId && hubId && newState.channelId === hubId) {
    const guild = member.guild;
    const name = String(temp.name || "{username}'s channel").replaceAll('{username}', member.user.username).replaceAll('{user}', member.user.username);
    const channel = await guild.channels
      .create({
        name: name.slice(0, 100),
        type: ChannelType.GuildVoice,
        parent: normalizeId(temp.categoryId) || undefined,
        userLimit: Math.max(0, Math.min(99, Number(temp.userLimit) || 0)),
        reason: `Temporary channel for ${member.user.tag}`,
      })
      .catch(() => null);

    if (channel) {
      setTempChannel({
        channelId: channel.id,
        guildId: guild.id,
        ownerId: member.id,
        categoryId: normalizeId(temp.categoryId),
      });
      await member.voice.setChannel(channel).catch(() => null);
    }
  }

  if (oldState.channelId) {
    const record = getTempChannel(oldState.channelId);
    if (record && oldState.channel) {
      const humans = oldState.channel.members.filter((entry) => !entry.user.bot).size;
      if (humans === 0) {
        deleteTempChannel(oldState.channelId);
        await oldState.channel.delete('Temporary voice channel is empty').catch(() => null);
      }
    }
  }
}

export async function enterGiveaway(giveawayId, guildId, userId) {
  const entries = listGiveawayEntries(giveawayId);
  if (entries.some((entry) => entry.user_id === userId)) return { entered: false, entries: entries.length };
  const added = addGiveawayEntry(giveawayId, guildId, userId);
  return { entered: added, entries: entries.length + (added ? 1 : 0) };
}

export function giveawayPayload(giveaway, entries) {
  return buildEmbed({
    title: '🎁 Giveaway',
    description: `**${giveaway.prize}**\n\nEnds <t:${Math.floor(Number(giveaway.ends_at) / 1000)}:R> · ${giveaway.winners} winner(s) · ${entries} entries`,
    color: COLORS.gold,
  });
}

export function giveawayButton(giveawayId) {
  return row(button({ id: customId('giveaway', 'enter', giveawayId), label: 'Enter giveaway', emoji: '🎉', style: 3 }));
}

export function roleMenuRow(entries) {
  const valid = (Array.isArray(entries) ? entries : []).filter((entry) => entry?.roleId);
  return row(
    stringSelect({
      id: customId('onboarding', 'roles'),
      placeholder: 'Choose the roles you want',
      min: 0,
      max: Math.min(25, Math.max(1, valid.length)),
      options: valid.slice(0, 25).map((entry) => ({
        label: truncate(entry.label ?? entry.roleId, 100),
        value: normalizeId(entry.roleId),
        description: 'Toggle this role',
        emoji: entry.emoji,
      })),
    }),
  );
}

export async function settleGiveaways(client, { rconManager = null } = {}) {
  let settled = 0;
  for (const giveaway of listDueGiveaways()) {
    const weights = giveawayTicketWeights(giveaway.id);
    const winners = weightedDraw(
      weights.map((entry) => ({ id: entry.userId, weight: entry.weight })),
      Math.min(Math.max(1, Number(giveaway.winners) || 1), Math.max(1, weights.length)),
    );
    const labels = new Map(weights.filter((entry) => entry.label).map((entry) => [entry.userId, entry.label]));
    const winnerLabels = winners.map((userId) => labels.get(userId) ?? null);
    const finished = finishGiveaway(giveaway.id, 'ended', winners);
    await announceGiveawayWinners({ client, rconManager, giveaway: finished ?? giveaway, winners, winnerLabels });
    settled += 1;
  }
  return settled;
}

export async function settleTimeRoles(client) {
  let granted = 0;
  for (const guild of client?.guilds?.cache?.values?.() ?? []) {
    const settings = getGuildSettings(guild.id);
    const entries = settings.onboarding?.timeRoles;
    if (!settings.onboarding?.enabled || !entries?.enabled || !Array.isArray(entries.entries)) continue;

    const joins = recentJoins(guild.id, Date.now() - 30 * 86_400_000);
    for (const entry of entries.entries.slice(0, 25)) {
      const roleId = normalizeId(entry.roleId);
      const minutes = Math.max(1, Number(entry.minutes) || 0);
      if (!roleId) continue;
      for (const join of joins.slice(0, 100)) {
        if (Date.now() - Number(join.created_at) < minutes * 60_000) continue;
        if (hasTimeRole(guild.id, join.user_id, roleId)) continue;
        const member = await guild.members.fetch(join.user_id).catch(() => null);
        if (!member || member.user.bot || member.roles.cache.has(roleId)) {
          if (member) grantTimeRole(guild.id, join.user_id, roleId);
          continue;
        }
        try {
          await member.roles.add(roleId, `Time role: ${minutes} minute milestone`);
          grantTimeRole(guild.id, join.user_id, roleId);
          granted += 1;
        } catch (error) {
          log.warn(`Could not grant time role ${roleId} in ${guild.id}`, error);
        }
      }
    }
  }
  return granted;
}

export async function expireBorderwalls(client) {
  let expired = 0;
  for (const guild of client?.guilds?.cache?.values?.() ?? []) {
    const settings = getGuildSettings(guild.id);
    if (!settings.onboarding?.borderwall?.enabled) continue;
    for (const verification of pendingVerifications(guild.id)) {
      const member = await guild.members.fetch(verification.user_id).catch(() => null);
      if (member && settings.onboarding.borderwall.kick) {
        await member.kick('Borderwall verification expired').catch(() => null);
      }
      expireVerification(verification.id);
      expired += 1;
    }
  }
  return expired;
}

export function onboardingSnapshot(guildId, settings) {
  const growth = onboardingGrowth(guildId);
  return {
    growth,
    features: {
      welcome: Boolean(settings.onboarding?.welcome?.enabled),
      autoroles: Boolean(settings.onboarding?.autoroles?.enabled),
      borderwall: Boolean(settings.onboarding?.borderwall?.enabled),
      freeroles: Boolean(settings.onboarding?.freeroles?.enabled),
      giveaways: Boolean(settings.onboarding?.giveaways?.enabled),
      polls: Boolean(settings.onboarding?.polls?.enabled),
      leaver: Boolean(settings.onboarding?.leaver?.enabled),
      reactionRoles: Boolean(settings.onboarding?.reactionRoles?.enabled),
      tempChannels: Boolean(settings.onboarding?.tempChannels?.enabled),
      timeRoles: Boolean(settings.onboarding?.timeRoles?.enabled),
    },
  };
}

export function startOnboardingLoop(client, { rconManager = null } = {}) {
  let running = false;
  const tick = async () => {
    if (running) return;
    running = true;
    try {
      await settleGiveaways(client, { rconManager });
      await settleTimeRoles(client);
      await expireBorderwalls(client);
    } catch (error) {
      log.error('Onboarding loop failed', error);
    } finally {
      running = false;
    }
  };

  const timer = setInterval(tick, 30_000);
  timer.unref?.();
  const first = setTimeout(tick, 8_000);
  first.unref?.();
  return () => {
    clearInterval(timer);
    clearTimeout(first);
  };
}

export { setGiveawayMessage, getVerification, markVerified, uniqueId, safeColor };

function safeColor(value) {
  try {
    return parseHexColor(value);
  } catch {
    return COLORS.brand;
  }
}
