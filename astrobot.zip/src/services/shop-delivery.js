import { getLink } from '../db/repositories/links.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { runtime } from '../core/runtime.js';
import { ValidationError } from '../core/errors.js';
import { createLogger } from '../core/logger.js';
import { buildItemCommand } from './rust-items.js';

const log = createLogger('shop:delivery');

/**
 * In-game item products are delivered through RCON to the player's linked
 * gamertag. Both preconditions (a link and a live server) are checked before a
 * purchase is charged, so buyers never pay for an item that cannot arrive.
 */
export function itemProductTarget(guildId, userId) {
  const link = getLink(guildId, userId);
  if (!link?.gamertag) {
    throw new ValidationError('Link your gamertag with `/link` before buying in-game items.');
  }

  const connection = runtime.rconManager?.connectionFor(guildId);
  if (!connection) {
    throw new ValidationError('The Rust server is not connected right now, so item delivery is paused.');
  }

  return { link, connection };
}

export async function deliverItemProduct({ guildId, userId, product }) {
  const { link, connection } = itemProductTarget(guildId, userId);
  const quantity = Math.max(1, Math.trunc(Number(product.quantity) || 1));

  const command = buildItemCommand({
    gamertag: link.gamertag,
    shortname: product.shortname,
    name: product.name,
    quantity,
    template: getGuildSettings(guildId).shop.itemCommand,
  });

  await connection.send(command);
  log.info(`Delivered ${quantity}x ${product.shortname} to ${link.gamertag} in guild ${guildId}.`);

  return { command, gamertag: link.gamertag, quantity };
}
