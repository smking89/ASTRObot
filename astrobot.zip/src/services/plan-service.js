import { getDb, transaction } from '../db/index.js';
import { getGuild, setGuildPlan } from '../db/repositories/guilds.js';
import { getMembership, membershipSeatLimit } from '../db/repositories/memberships.js';
import { ValidationError } from '../core/errors.js';
import { DAY_MS, PLAN_CATALOG, TRIAL_DAYS, normalizePlanId } from '../config/plans.js';

/**
 * Plan resolution and entitlement checks.
 *
 * The stored `guilds.plan` value is the purchased plan. `plan_expires_at`
 * bounds paid plans and trials; once it passes, the guild falls back to Basic
 * without deleting its data, so a renewal restores the same limits.
 */

export function guildPlan(guildId) {
  const guild = guildId ? getGuild(guildId) : null;
  const stored = normalizePlanId(guild?.plan);
  const expiresAt = guild?.plan_expires_at ? Number(guild.plan_expires_at) : null;
  const expired = Boolean(expiresAt && expiresAt <= Date.now());
  const id = expired ? 'basic' : stored;
  const definition = PLAN_CATALOG[id];

  return {
    ...definition,
    id,
    storedId: stored,
    expiresAt: expired ? null : expiresAt,
    source: guild?.plan_source ?? null,
    trial: !expired && String(guild?.plan_source ?? '') === 'trial',
    expired,
  };
}

export function planLimits(guildId) {
  return guildPlan(guildId).limits;
}

export function planFeatures(guildId) {
  return guildPlan(guildId).features;
}

export function planHasFeature(guildId, feature) {
  return Boolean(planFeatures(guildId)[feature]);
}

export function planLabel(guildId) {
  return guildPlan(guildId).label;
}

export function trialForGuild(guildId) {
  try {
    return getDb().prepare('SELECT * FROM plan_trials WHERE guild_id = ?').get(guildId) ?? null;
  } catch {
    return null;
  }
}

/** Starts the one-time 14-day Pro trial. Basic-only and once per guild. */
export function startProTrial({ guildId, actorId = null } = {}) {
  const guild = guildId ? getGuild(guildId) : null;
  if (!guild) throw new ValidationError('Install AstroBot in this server before starting a trial.');
  if (trialForGuild(guildId)) {
    throw new ValidationError('This server has already used its 14-day Pro trial.');
  }

  const current = guildPlan(guildId);
  if (current.id !== 'basic') {
    throw new ValidationError(`This server is already on ${current.label}.`);
  }

  const startedAt = Date.now();
  const endsAt = startedAt + TRIAL_DAYS * DAY_MS;
  setGuildPlan(guildId, 'pro', { expiresAt: endsAt, source: 'trial' });
  getDb()
    .prepare('INSERT INTO plan_trials (guild_id, started_at, ends_at, actor_id) VALUES (?, ?, ?, ?)')
    .run(guildId, startedAt, endsAt, actorId);

  return guildPlan(guildId);
}

/**
 * Applies a paid plan and records the buyer so Max can be shared across their
 * guilds. Seat checks happen when an admin attaches a guild, not here: a paid
 * webhook must never fail after money has been taken.
 */
export function applyPaidPlan({ guildId, tier, days, source = 'tip4serv', ownerId = null }) {
  const plan = normalizePlanId(tier);
  const expiresAt = Date.now() + Math.max(1, Number(days) || 30) * DAY_MS;
  setGuildPlan(guildId, plan, { expiresAt, source, ownerId });
  return guildPlan(guildId);
}

export function setManualPlan({ guildId, tier, expiresAt = null, ownerId = null }) {
  setGuildPlan(guildId, normalizePlanId(tier), { expiresAt, source: 'manual', ownerId });
  return guildPlan(guildId);
}

/* ── Subscription seats ──────────────────────────────────────────────────── */

/** Guilds actively carrying this owner's subscription. */
export function ownerSeats(ownerId) {
  if (!ownerId) return [];
  try {
    return getDb()
      .prepare(
        `SELECT id, name, plan, plan_expires_at
         FROM guilds
         WHERE plan_owner_id = ? AND plan NOT IN ('basic', 'free')
           AND (plan_expires_at IS NULL OR plan_expires_at > ?)
         ORDER BY joined_at ASC`,
      )
      .all(String(ownerId), Date.now());
  } catch {
    return [];
  }
}

export function seatSummary(userId) {
  const membership = userId ? getMembership(userId) : null;
  const active = Boolean(membership && (!membership.expires_at || Number(membership.expires_at) > Date.now()));
  const tier = active ? normalizePlanId(membership.tier) : null;
  const definition = tier ? PLAN_CATALOG[tier] : null;
  const seats = active ? ownerSeats(userId) : [];

  return {
    membership,
    active,
    tier,
    label: definition?.label ?? null,
    expiresAt: active ? membership.expires_at : null,
    lifetime: Boolean(active && !membership.expires_at),
    seatLimit: active ? membershipSeatLimit(membership) : 0,
    used: seats.length,
    seats,
  };
}

/** Attach this guild to the owner's subscription, consuming one seat. */
export function attachGuildSeat({ guildId, userId }) {
  const summary = seatSummary(userId);
  if (!summary.active || !summary.tier || summary.tier === 'basic') {
    throw new ValidationError('You have no active Pro or Max subscription. Start a trial or buy a plan from /checkout.');
  }

  const guild = getGuild(guildId);
  if (!guild) throw new ValidationError('This server is not registered yet.');

  const existingPlan = guildPlan(guildId);
  if (guild.plan_owner_id && guild.plan_owner_id !== userId && existingPlan.id !== 'basic') {
    throw new ValidationError('This server is already on another subscription. Use /transfer from the owning server first.');
  }

  const existingSeat = summary.seats.some((seat) => String(seat.id) === String(guildId));
  if (!existingSeat && summary.used >= summary.seatLimit) {
    throw new ValidationError(
      `All ${summary.seatLimit} server seat${summary.seatLimit === 1 ? '' : 's'} are in use. Release another server or buy an extra server.`,
    );
  }

  setGuildPlan(guildId, summary.tier, {
    expiresAt: summary.expiresAt,
    source: 'subscription',
    ownerId: userId,
  });

  return { summary: seatSummary(userId), plan: guildPlan(guildId) };
}

/** Release this guild back to Basic, freeing the seat. */
export function detachGuildSeat({ guildId, userId }) {
  const guild = getGuild(guildId);
  if (!guild) throw new ValidationError('This server is not registered yet.');
  if (guild.plan_owner_id !== userId) {
    throw new ValidationError('This server is not attached to your subscription.');
  }

  setGuildPlan(guildId, 'basic', { expiresAt: null, source: 'detached', ownerId: null });
  return seatSummary(userId);
}

/** Move the subscription from one of the owner's servers to this one. */
export function transferGuildSeat({ guildId, userId, fromGuildId }) {
  const summary = seatSummary(userId);
  if (!summary.active || !summary.tier || summary.tier === 'basic') {
    throw new ValidationError('You have no active Pro or Max subscription to transfer.');
  }
  if (String(guildId) === String(fromGuildId)) {
    throw new ValidationError('Choose a different source server.');
  }

  const source = getGuild(fromGuildId);
  if (!source || !summary.seats.some((seat) => String(seat.id) === String(fromGuildId))) {
    throw new ValidationError('That server is not attached to your subscription.');
  }

  const target = getGuild(guildId);
  if (!target) throw new ValidationError('This server is not registered yet.');
  if (summary.seats.some((seat) => String(seat.id) === String(guildId))) {
    throw new ValidationError('This server already uses one of your seats.');
  }

  const targetPlan = guildPlan(guildId);
  if (target.plan_owner_id && target.plan_owner_id !== userId && targetPlan.id !== 'basic') {
    throw new ValidationError('This server is already on another subscription.');
  }

  transaction(() => {
    setGuildPlan(fromGuildId, 'basic', { expiresAt: null, source: 'transferred', ownerId: null });
    setGuildPlan(guildId, summary.tier, {
      expiresAt: summary.expiresAt,
      source: 'subscription',
      ownerId: userId,
    });
  });

  return { source, target, summary: seatSummary(userId), plan: guildPlan(guildId) };
}

/**
 * Keep already-attached guilds in step with a membership tier/seat change.
 * Extra guilds beyond the new seat allowance fall back to Basic.
 */
export function syncOwnedGuildPlans({ ownerId, tier, expiresAt = null, seatLimit = null }) {
  const seats = ownerSeats(ownerId);
  const keep = seatLimit === null ? seats : seats.slice(0, Math.max(0, Number(seatLimit) || 0));

  for (const seat of keep) {
    setGuildPlan(seat.id, tier, { expiresAt, source: 'subscription', ownerId });
  }
  for (const seat of seats.slice(keep.length)) {
    setGuildPlan(seat.id, 'basic', { expiresAt: null, source: 'seat-released', ownerId: null });
  }

  return keep.length;
}

export function countOwnedPlanGuilds(ownerId, tier) {
  if (!ownerId) return 0;
  try {
    return Number(
      getDb()
        .prepare(
          `SELECT COUNT(*) AS count FROM guilds
           WHERE plan_owner_id = ? AND plan = ? AND (plan_expires_at IS NULL OR plan_expires_at > ?)`,
        )
        .get(String(ownerId), normalizePlanId(tier), Date.now())?.count ?? 0,
    );
  } catch {
    return 0;
  }
}

export function assertGuildSeatAvailable({ ownerId, tier, guildId }) {
  const plan = PLAN_CATALOG[normalizePlanId(tier)];
  if (!ownerId || plan.id === 'basic') return;
  const membership = getMembership(ownerId);
  const membershipMatches =
    membership &&
    normalizePlanId(membership.tier) === plan.id &&
    (!membership.expires_at || Number(membership.expires_at) > Date.now());
  const seatLimit = membershipMatches ? membershipSeatLimit(membership) : plan.limits.discordServers;
  const used = countOwnedPlanGuilds(ownerId, plan.id);
  const alreadyCounted = Boolean(
    getDb()
      .prepare(
        'SELECT 1 FROM guilds WHERE id = ? AND plan_owner_id = ? AND plan = ? AND (plan_expires_at IS NULL OR plan_expires_at > ?)',
      )
      .get(guildId, String(ownerId), plan.id, Date.now()),
  );
  if (alreadyCounted) return;
  if (used >= seatLimit) {
    throw new ValidationError(
      `${plan.label} covers ${seatLimit} Discord server${seatLimit === 1 ? '' : 's'} and this owner already uses all of them.`,
    );
  }
}

/* ── Counts used by the limit checks ─────────────────────────────────────── */

function count(sql, ...params) {
  try {
    return Number(getDb().prepare(sql).get(...params)?.count ?? 0);
  } catch {
    return 0;
  }
}

export function countServers(guildId) {
  return count('SELECT COUNT(*) AS count FROM servers WHERE guild_id = ?', guildId);
}

export function countScheduledTasks(guildId) {
  return count('SELECT COUNT(*) AS count FROM scheduled_tasks WHERE guild_id = ?', guildId);
}

export function countSavedTemplates(guildId) {
  return count('SELECT COUNT(*) AS count FROM server_templates WHERE guild_id = ?', guildId);
}

export function countActiveGiveaways(guildId) {
  return count(
    "SELECT COUNT(*) AS count FROM giveaways WHERE guild_id = ? AND status = 'active' AND ends_at > ? AND username IS NULL",
    guildId,
    Date.now(),
  );
}

export function countActiveHostedGiveaways(guildId) {
  return count(
    "SELECT COUNT(*) AS count FROM giveaways WHERE guild_id = ? AND username IS NOT NULL AND status = 'active' AND ends_at > ?",
    guildId,
    Date.now(),
  );
}

export function hostedGiveawayEntryCount(giveawayId) {
  return (
    count('SELECT COUNT(*) AS count FROM giveaway_page_entries WHERE giveaway_id = ?', giveawayId) +
    count('SELECT COUNT(*) AS count FROM giveaway_entries WHERE giveaway_id = ?', giveawayId)
  );
}

/* ── Assertions ──────────────────────────────────────────────────────────── */

export function assertPlanLimit(guildId, key, currentCount, label) {
  const plan = guildPlan(guildId);
  const limit = plan.limits[key];
  if (limit === null || limit === undefined) return;

  if (limit <= 0) {
    throw new ValidationError(
      `${label} ${label.endsWith('s') ? 'are' : 'is'} not included in the ${plan.label} plan. Upgrade to Pro or Max to use it.`,
    );
  }

  if (Number(currentCount) >= Number(limit)) {
    const noun = limit === 1 && label.endsWith('s') ? label.slice(0, -1) : label;
    throw new ValidationError(
      `The ${plan.label} plan allows ${limit} ${noun.toLowerCase()}. Remove one first or upgrade your plan.`,
    );
  }
}

export function assertPlanFeature(guildId, feature, label) {
  const plan = guildPlan(guildId);
  if (plan.features[feature]) return;
  throw new ValidationError(`${label} is a Pro or Max feature. This server is on ${plan.label}.`);
}

export function assertEntrantCapacity(guildId, giveawayId) {
  const plan = guildPlan(guildId);
  const cap = Number(plan.limits.hostedEntrants) || 0;
  if (cap <= 0) {
    throw new ValidationError('Hosted giveaway pages start on the Pro plan.');
  }
  if (hostedGiveawayEntryCount(giveawayId) >= cap) {
    throw new ValidationError(`This page has reached the ${cap.toLocaleString('en-US')}-entrant ${plan.label} cap.`);
  }
}

/** Serialisable snapshot for the dashboard and API responses. */
export function planSnapshot(guildId) {
  const plan = guildPlan(guildId);
  const trial = trialForGuild(guildId);
  const guild = guildId ? getGuild(guildId) : null;
  const ownerId = guild?.plan_owner_id ?? null;
  return {
    id: plan.id,
    label: plan.label,
    tagline: plan.tagline,
    prices: plan.prices,
    priceLabels: plan.priceLabels,
    limits: plan.limits,
    features: plan.features,
    branding: plan.branding,
    expiresAt: plan.expiresAt,
    source: plan.source,
    trial: plan.trial,
    trialUsed: Boolean(trial),
    trialAvailable: !trial && plan.id === 'basic',
    ownerId,
    seats: ownerId ? seatSummary(ownerId) : null,
  };
}
