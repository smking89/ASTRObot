import { createServer } from 'node:http';
import { createHmac, timingSafeEqual } from 'node:crypto';
import { grantMembership } from '../db/repositories/memberships.js';
import { DAY_MS } from '../config/plans.js';
import { env } from '../config/env.js';
import { createLogger } from '../core/logger.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { credit } from './economy-service.js';
import { addItem } from '../db/repositories/inventory.js';
import { setPremium } from '../db/repositories/battlepass.js';
import { getLink } from '../db/repositories/links.js';
import { buildKitCommand } from './kit-service.js';
import { abortPayment, beginPayment, finishPayment } from '../db/repositories/payments.js';
import { applyPaidPlan, guildPlan } from './plan-service.js';
import { grantSeatAddonOnce } from '../db/repositories/addon-grants.js';

const log = createLogger('tip4serv');

/**
 * Tip4Serv integration.
 *
 * Checkout webhooks are signed with TIP4SERV_WEBHOOK_SECRET (HMAC-SHA256 of the
 * raw body, hex digest) in the X-Tip4Serv-Signature header. We verify against the
 * raw buffer, dedupe transaction ids and route the product to a delivery handler.
 *
 * Configure the callback URL in Tip4Serv to:
 *   https://<your-host>:<TIP4SERV_WEBHOOK_PORT><TIP4SERV_WEBHOOK_PATH>
 */
export function verifyTip4ServSignature(rawBody, signature) {
  if (!env.tip4serv.webhookSecret) return false;
  if (!signature) return false;

  const expected = createHmac('sha256', env.tip4serv.webhookSecret).update(rawBody).digest('hex');
  try {
    return timingSafeEqual(Buffer.from(expected, 'utf8'), Buffer.from(String(signature), 'utf8'));
  } catch {
    return false;
  }
}

/**
 * Products come from /config shop (settings.shop.products). The premium battle
 * pass is sold as its own Tip4Serv product id, so it resolves even when it is
 * not listed in the coin shop.
 */
export function findProduct(guildId, productId) {
  const settings = getGuildSettings(guildId);
  const products = settings.shop.products ?? [];
  const product = products.find((entry) => String(entry.id) === String(productId)) ?? null;
  if (product) return product;

  const premiumProductId = String(settings.battlePass?.premium?.tip4servProductId ?? '').trim();
  if (premiumProductId && premiumProductId === String(productId ?? '')) {
    return { id: premiumProductId, name: 'Premium Battle Pass', premium: true };
  }

  // Paid plan checkout configured from /config → Checkout. Each plan/interval
  // is its own product, so the signed webhook knows the tier and duration.
  const checkout = settings.checkout ?? {};
  const planProducts = [
    { key: 'proMonthlyProductId', tier: 'pro', days: 30, name: 'Astro Pro monthly' },
    { key: 'proYearlyProductId', tier: 'pro', days: 365, name: 'Astro Pro yearly' },
    { key: 'maxMonthlyProductId', tier: 'max', days: 30, name: 'Astro Max monthly' },
    { key: 'maxYearlyProductId', tier: 'max', days: 365, name: 'Astro Max yearly' },
  ];
  for (const entry of planProducts) {
    const configured = String(checkout[entry.key] ?? '').trim();
    if (configured && configured === String(productId ?? '')) {
      return {
        id: configured,
        name: entry.name,
        membershipTier: entry.tier,
        membershipDays: entry.days,
      };
    }
  }

  // Extra Discord-server add-on. One product adds one seat; the seat is added
  // to the buyer's existing membership and does not change its tier.
  const seatProducts = [
    { key: 'seatMonthlyProductId', days: 30, name: 'Astro extra Discord server monthly' },
    { key: 'seatYearlyProductId', days: 365, name: 'Astro extra Discord server yearly' },
  ];
  for (const entry of seatProducts) {
    const configured = String(checkout[entry.key] ?? '').trim();
    if (configured && configured === String(productId ?? '')) {
      return { id: configured, name: entry.name, seatAddon: true, seatDays: entry.days };
    }
  }

  // Legacy single Pro product from before the Basic/Pro/Max split.
  const membershipProductId = String(checkout.tip4servProductId ?? '').trim();
  if (membershipProductId && membershipProductId === String(productId ?? '')) {
    return {
      id: membershipProductId,
      name: 'Astro Pro membership',
      membershipTier: 'pro',
      membershipDays: Math.max(1, Number(checkout.membershipDays) || 30),
    };
  }
  return null;
}

/**
 * Delivery: coins are credited instantly, kits go through the RCON kit giver,
 * roles are granted on the buyer's guild member.
 */
export async function deliverPurchase({ client, rconManager, guildId, userId, product, transactionId, subscriptionRef = null }) {
  const delivered = [];

  if (product.premium || product.premiumBattlePass) {
    setPremium(guildId, userId, true);
    delivered.push('premium battle pass');
  }

  if (product.coins) {
    credit({
      guildId,
      userId,
      amount: Number(product.coins),
      kind: 'tip4serv',
      respectCap: product.respectCap !== false,
      metadata: { transactionId, productId: product.id },
    });
    delivered.push(`${product.coins} coins`);
  }

  if (product.kit) {
    addItem({ guildId, userId, itemKey: `kit:${product.kit}`, quantity: 1, metadata: { source: 'tip4serv' } });
    const connection = rconManager?.connectionFor(guildId);
    const link = getLink(guildId, userId);
    if (connection && link?.gamertag) {
      await connection.send(buildKitCommand({ kitName: product.kit, gamertag: link.gamertag })).catch((error) => {
        log.warn(`Kit delivery over RCON failed for ${userId}`, error);
      });
    }
    delivered.push(`kit ${product.kit}`);
  }

  if (product.seatAddon) {
    const days = Math.max(1, Number(product.seatDays) || 30);
    const currentPlan = guildPlan(guildId);
    const tier = currentPlan.id === 'basic' ? 'pro' : currentPlan.id;
    // Recurring seat add-ons are one entitlement per subscription. The first
    // invoice adds the seat; later renewals reuse the same subscription id and
    // must not add another one. One-time purchases use the transaction id.
    const grant = grantSeatAddonOnce({
      providerRef: String(subscriptionRef || transactionId || '').trim(),
      guildId,
      userId,
      productId: product.id,
      seats: 1,
      tier,
      expiresAt: Date.now() + days * DAY_MS,
    });
    delivered.push(grant.granted ? 'extra Discord server seat' : 'extra Discord server seat already active');
  }

  if (product.membershipTier) {
    const days = Math.max(1, Number(product.membershipDays) || 30);
    const expiresAt = Date.now() + days * 86_400_000;
    grantMembership({
      userId,
      tier: product.membershipTier,
      grantedBy: 'tip4serv',
      expiresAt,
    });
    // The purchase applies to the guild in the signed payload. The buyer is
    // recorded as the plan owner so Max can be attached to their other guilds.
    applyPaidPlan({ guildId, tier: product.membershipTier, days, source: 'tip4serv', ownerId: userId });
    delivered.push(`${product.membershipTier} plan (${days}d)`);

    // The portal builder is also gated on a Pro role, so grant it alongside the
    // membership row when the owner configured one.
    const proRoleId = getGuildSettings(guildId).giveawayPortal?.proRoleId;
    if (proRoleId) {
      const guild = await client.guilds.fetch(guildId).catch(() => null);
      const member = guild ? await guild.members.fetch(userId).catch(() => null) : null;
      if (member) await member.roles.add(proRoleId, `Astro Pro membership ${transactionId}`).catch(() => null);
    }
  }

  if (product.roleId) {
    const guild = await client.guilds.fetch(guildId).catch(() => null);
    const member = guild ? await guild.members.fetch(userId).catch(() => null) : null;
    if (member) await member.roles.add(product.roleId, `Tip4Serv purchase ${transactionId}`).catch(() => null);
    delivered.push(`role ${product.roleId}`);
  }

  return delivered;
}

/**
 * Starts the webhook listener. Returns { server, close } or null when the
 * integration is not configured.
 */
export function startTip4ServWebhook({ client, rconManager, onDelivery }) {
  if (!env.tip4serv.webhookSecret) {
    log.info('Tip4Serv webhook disabled (TIP4SERV_WEBHOOK_SECRET not set).');
    return null;
  }

  const server = createServer(async (request, response) => {
    if (request.method !== 'POST' || request.url !== env.tip4serv.webhookPath) {
      response.writeHead(404).end();
      return;
    }

    const chunks = [];
    for await (const chunk of request) chunks.push(chunk);
    const raw = Buffer.concat(chunks);
    const signature = request.headers['x-tip4serv-signature'];

    if (!verifyTip4ServSignature(raw, signature)) {
      log.warn('Rejected Tip4Serv webhook with invalid signature.');
      response.writeHead(401).end('invalid signature');
      return;
    }

    let payload;
    try {
      payload = JSON.parse(raw.toString('utf8'));
    } catch {
      response.writeHead(400).end('invalid json');
      return;
    }

    const transactionId = String(payload.transaction_id ?? payload.id ?? '');
    const subscriptionRef = String(
      payload.subscription_id ??
        payload.subscriptionId ??
        payload.custom?.subscription_id ??
        payload.custom?.subscriptionId ??
        '',
    ).trim();

    const guildId = String(payload.guild_id ?? payload.guildId ?? payload.custom?.guild_id ?? payload.custom?.guildId ?? '');
    const userId = String(
      payload.discord_id ?? payload.discordId ?? payload.custom?.discord_id ?? payload.custom?.discordId ?? payload.user_id ?? '',
    );
    const product = findProduct(guildId, payload.product_id ?? payload.package_id);

    if (!guildId || !userId || !product) {
      log.warn(`Tip4Serv payload missing guild/user/product: ${raw.toString('utf8').slice(0, 300)}`);
      response.writeHead(422).end('unmapped product');
      return;
    }

    // Claim the transaction id in SQLite before delivering anything. A webhook
    // retry after a restart (or a concurrent duplicate) hits the primary key and
    // is answered without granting the purchase again.
    const claimed = beginPayment({ transactionId, guildId, userId, productId: product.id, provider: 'tip4serv' });
    if (!claimed) {
      log.info(`Ignored duplicate Tip4Serv transaction ${transactionId}.`);
      response.writeHead(200).end('duplicate');
      return;
    }

    try {
      const delivered = await deliverPurchase({ client, rconManager, guildId, userId, product, transactionId, subscriptionRef });
      finishPayment(transactionId, { delivered });
      if (typeof onDelivery === 'function') await onDelivery({ guildId, userId, product, delivered, transactionId });
      log.info(`Delivered ${product.id} to ${userId} (${delivered.join(', ')})`);
      response.writeHead(200).end('ok');
    } catch (error) {
      // Delivery failed: release the pending claim so Tip4Serv's retry can run.
      abortPayment(transactionId, error.message);
      log.error('Tip4Serv delivery failed', error);
      response.writeHead(500).end('delivery failed');
    }
  });

  server.listen(env.tip4serv.webhookPort, () => {
    log.info(`Tip4Serv webhook listening on :${env.tip4serv.webhookPort}${env.tip4serv.webhookPath}`);
  });
  server.on('error', (error) => log.error('Tip4Serv webhook server error', error));

  return {
    server,
    close: () => new Promise((resolve) => server.close(resolve)),
  };
}

