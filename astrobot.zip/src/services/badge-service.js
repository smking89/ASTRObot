import { existsSync, mkdirSync, unlinkSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { env } from '../config/env.js';
import { uniqueId } from '../utils/random.js';
import { badgeIconPath } from '../ui/badge-assets.js';
import {
  deleteAwardedBadge,
  deleteAwardedBadgesFor,
  deleteClanBadgeRow,
  getClanBadgeRow,
  insertAwardedBadge,
  insertClanBadge,
  listAwardedBadges,
  listClanBadgeRows,
} from '../db/repositories/badges.js';
import { ValidationError } from '../core/errors.js';

/**
 * Personal badges are awarded by staff and can also be uploaded by clan
 * leaders. Every badge renders as a real PNG, never an emoji.
 */

export const DEFAULT_BADGES = Object.freeze([
  { id: 'first_blood', label: 'First Blood', icon: 'first_blood', requirement: '1 kill' },
  { id: 'hunter', label: 'Hunter', icon: 'hunter', requirement: '100 kills' },
  { id: 'survivor', label: 'Survivor', icon: 'survivor', requirement: '7 day streak' },
  { id: 'banker', label: 'Banker', icon: 'banker', requirement: '1M banked' },
  { id: 'prestige', label: 'Prestige', icon: 'prestige', requirement: 'Reach level 1000' },
]);

export function clanBadgeDir(guildId) {
  return join(dirname(env.databasePath), 'clan-badges', String(guildId));
}

export function listClanBadges(guildId) {
  return listClanBadgeRows(guildId).map((row) => ({
    id: row.id,
    label: row.label,
    file: row.file,
    requirement: 'Clan badge',
    createdBy: row.created_by,
  }));
}

export function listBadges(guildId) {
  const builtins = DEFAULT_BADGES.map((badge) => ({ ...badge, file: badgeIconPath(badge.icon) }));
  return [...builtins, ...listClanBadges(guildId)];
}

/**
 * Autocomplete choices for the badge pickers: label + ID, filtered by input.
 * `onlyIds` narrows the catalogue to badges a specific member already owns, so
 * a revoke dropdown cannot offer something they do not have.
 */
export function badgeChoices(guildId, query = '', { limit = 25, onlyIds = null } = {}) {
  const needle = String(query ?? '').trim().toLowerCase();
  return listBadges(guildId)
    .filter((badge) => (onlyIds ? onlyIds.has(badge.id) : true))
    .filter((badge) => !needle || badge.id.toLowerCase().includes(needle) || badge.label.toLowerCase().includes(needle))
    .slice(0, limit)
    .map((badge) => ({ name: `${badge.label} · ${badge.id}`.slice(0, 100), value: badge.id }));
}

/** Badge IDs a member currently holds, for the revoke dropdown. */
export function ownedBadgeIds(guildId, userId) {
  return new Set(
    badgesFor(guildId, userId).map((row) => String(row.badge_id ?? row.badgeId ?? row.id ?? '')),
  );
}

export function badgeDefinition(guildId, value) {
  const needle = String(value ?? '').trim().toLowerCase();
  if (!needle) return null;
  return listBadges(guildId).find((badge) => badge.id.toLowerCase() === needle || badge.label.toLowerCase() === needle) ?? null;
}

const ALLOWED_TYPES = Object.freeze({ 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp' });
const MAX_UPLOAD_BYTES = 512 * 1024;

export function validateBadgeUpload({ contentType, size } = {}) {
  if (Number(size) > MAX_UPLOAD_BYTES) throw new ValidationError('Badge icons must be 512 KB or smaller.');
  const extension = ALLOWED_TYPES[String(contentType ?? '').toLowerCase()];
  if (!extension) throw new ValidationError('Upload a PNG, JPEG or WebP image.');
  return extension;
}

export function addClanBadge({ guildId, label, buffer, contentType, actorId = null }) {
  const name = String(label ?? '').trim().slice(0, 40);
  if (name.length < 2) throw new ValidationError('Give the badge a name of at least 2 characters.');

  const extension = validateBadgeUpload({ contentType, size: buffer?.length });
  const id = uniqueId('badge');
  const directory = clanBadgeDir(guildId);
  mkdirSync(directory, { recursive: true });

  const file = join(directory, `${id}.${extension}`);
  writeFileSync(file, buffer);
  insertClanBadge({ id, guildId, label: name, file, createdBy: actorId });

  return { id, label: name, file, requirement: 'Clan badge' };
}

export function removeClanBadge(guildId, id, { actorId = null } = {}) {
  const row = getClanBadgeRow(guildId, String(id ?? ''));
  if (!row) throw new ValidationError('No clan badge with that ID.');

  deleteClanBadgeRow(guildId, row.id);
  // Awards point at the badge id, so leaving them behind would hand members a
  // badge that no longer exists and cannot be revoked from the picker.
  const awardsRemoved = deleteAwardedBadgesFor(guildId, row.id);
  if (row.file && existsSync(row.file)) unlinkSync(row.file);
  return { id: row.id, label: row.label, actorId, awardsRemoved };
}

export function awardBadge({ guildId, userId, badgeId, awardedBy = null }) {
  return { created: insertAwardedBadge({ guildId, userId, badgeId, awardedBy }) };
}

export function revokeBadge({ guildId, userId, badgeId }) {
  return deleteAwardedBadge(guildId, userId, badgeId);
}

export function badgesFor(guildId, userId) {
  return listAwardedBadges(guildId, userId);
}
