import { mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { ChannelType, OverwriteType } from 'discord.js';
import { ValidationError } from '../core/errors.js';

/**
 * Structural server snapshots for /nuke.
 *
 * A snapshot records every role, category and channel (with permission
 * overwrites) so a wipe can be undone. Snapshots live on disk under
 * data/backups/<guildId>/ and are never uploaded anywhere.
 */

const BACKUP_DIR = path.join(process.cwd(), 'data', 'backups');
const CLONED_CHANNEL_TYPES = new Set([
  ChannelType.GuildText,
  ChannelType.GuildVoice,
  ChannelType.GuildAnnouncement,
  ChannelType.GuildForum,
  ChannelType.GuildStageVoice,
]);

function serializeOverwrites(channel, roleNames, everyoneId) {
  return [...channel.permissionOverwrites.cache.values()].map((entry) => ({
    type: entry.type === OverwriteType.Role ? 'role' : 'member',
    targetId: entry.id,
    targetName:
      entry.type === OverwriteType.Role
        ? entry.id === everyoneId
          ? '@everyone'
          : roleNames.get(entry.id) ?? null
        : null,
    allow: entry.allow.bitfield.toString(),
    deny: entry.deny.bitfield.toString(),
  }));
}

/** Reads the live guild structure into a plain JSON snapshot. */
export async function captureStructure(guild) {
  if (!guild?.id) throw new ValidationError('This action must be used inside a server.');

  const [channels, roles] = await Promise.all([guild.channels.fetch(), guild.roles.fetch()]);
  const roleNames = new Map([...roles.values()].map((role) => [role.id, role.name]));

  const categories = [...channels.values()]
    .filter((channel) => channel.type === ChannelType.GuildCategory)
    .sort((a, b) => a.position - b.position)
    .map((channel) => ({
      name: channel.name,
      position: channel.position,
      overwrites: serializeOverwrites(channel, roleNames, guild.id),
    }));

  const serializedChannels = [...channels.values()]
    .filter((channel) => CLONED_CHANNEL_TYPES.has(channel.type))
    .sort((a, b) => a.position - b.position)
    .map((channel) => ({
      name: channel.name,
      type: channel.type,
      position: channel.position,
      parentName: channel.parent?.name ?? null,
      topic: 'topic' in channel ? channel.topic ?? null : null,
      nsfw: 'nsfw' in channel ? Boolean(channel.nsfw) : false,
      rateLimitPerUser: 'rateLimitPerUser' in channel ? Number(channel.rateLimitPerUser ?? 0) : 0,
      bitrate: 'bitrate' in channel ? Number(channel.bitrate ?? 0) : null,
      userLimit: 'userLimit' in channel ? Number(channel.userLimit ?? 0) : null,
      overwrites: serializeOverwrites(channel, roleNames, guild.id),
    }));

  const serializedRoles = [...roles.values()]
    .filter((role) => role.id !== guild.id && !role.managed)
    .sort((a, b) => a.position - b.position)
    .map((role) => ({
      name: role.name,
      color: role.hexColor,
      hoist: role.hoist,
      mentionable: role.mentionable,
      permissions: role.permissions.bitfield.toString(),
      position: role.position,
    }));

  return {
    format: 'astrobot-structure',
    version: 1,
    capturedAt: new Date().toISOString(),
    guild: { id: guild.id, name: guild.name, ownerId: guild.ownerId },
    roles: serializedRoles,
    categories,
    channels: serializedChannels,
  };
}

/** Persists a snapshot and returns its backup id. */
export function saveSnapshot(guildId, snapshot) {
  const dir = path.join(BACKUP_DIR, String(guildId));
  mkdirSync(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[-:]/g, '').replace('T', '-').slice(0, 15);
  const id = `AB-${stamp}`;
  writeFileSync(path.join(dir, `${id}.json`), JSON.stringify(snapshot, null, 2), 'utf8');
  return id;
}

export function listSnapshots(guildId) {
  try {
    return readdirSync(path.join(BACKUP_DIR, String(guildId)))
      .filter((file) => file.endsWith('.json'))
      .map((file) => file.slice(0, -5))
      .sort()
      .reverse();
  } catch {
    return [];
  }
}

/** Loads a snapshot by id; pass "latest" for the newest one. */
export function loadSnapshot(guildId, id = 'latest') {
  const wanted = !id || id === 'latest' ? listSnapshots(guildId)[0] : id;
  if (!wanted) throw new ValidationError('No backup has been saved for this server yet.');

  try {
    const raw = readFileSync(path.join(BACKUP_DIR, String(guildId), `${wanted}.json`), 'utf8');
    return { id: wanted, snapshot: JSON.parse(raw) };
  } catch {
    throw new ValidationError(`Backup \`${wanted}\` could not be read.`);
  }
}

function buildOverwrites(list, roleIds) {
  return (list ?? []).flatMap((entry) => {
    const id = entry.type === 'role' ? roleIds.get(entry.targetName) : entry.targetId;
    if (!id) return [];
    return [
      {
        id,
        type: entry.type === 'role' ? OverwriteType.Role : OverwriteType.Member,
        allow: BigInt(entry.allow ?? '0'),
        deny: BigInt(entry.deny ?? '0'),
      },
    ];
  });
}

/**
 * Rebuilds a snapshot on an (ideally empty) guild. Existing role names are
 * reused instead of duplicated, so restoring twice is safe.
 */
export async function restoreStructure(guild, snapshot, { reason = 'Restore server backup' } = {}) {
  if (!guild?.id) throw new ValidationError('This action must be used inside a server.');
  if (!snapshot?.roles || !snapshot?.channels) throw new ValidationError('That backup is not an AstroBot structure snapshot.');

  const result = { rolesCreated: 0, categoriesCreated: 0, channelsCreated: 0, rolesReused: 0, errors: [] };

  await guild.roles.fetch().catch(() => null);
  const roleIds = new Map([['@everyone', guild.id]]);
  for (const role of guild.roles.cache.values()) roleIds.set(role.name, role.id);

  for (const entry of [...snapshot.roles].sort((a, b) => a.position - b.position)) {
    const existing = guild.roles.cache.find((role) => role.name === entry.name);
    if (existing) {
      result.rolesReused += 1;
      continue;
    }
    try {
      const role = await guild.roles.create({
        name: entry.name,
        color: entry.color ?? 0,
        hoist: Boolean(entry.hoist),
        mentionable: Boolean(entry.mentionable),
        permissions: BigInt(entry.permissions ?? '0'),
        reason,
      });
      roleIds.set(entry.name, role.id);
      result.rolesCreated += 1;
    } catch (error) {
      result.errors.push(`role ${entry.name}: ${error.message}`);
    }
  }

  const categoryIds = new Map();
  for (const entry of snapshot.categories ?? []) {
    try {
      const category = await guild.channels.create({
        name: entry.name,
        type: ChannelType.GuildCategory,
        permissionOverwrites: buildOverwrites(entry.overwrites, roleIds),
        reason,
      });
      categoryIds.set(entry.name, category.id);
      result.categoriesCreated += 1;
    } catch (error) {
      result.errors.push(`category ${entry.name}: ${error.message}`);
    }
  }

  for (const entry of snapshot.channels) {
    try {
      await guild.channels.create({
        name: entry.name,
        type: entry.type,
        parent: entry.parentName ? categoryIds.get(entry.parentName) ?? null : null,
        topic: entry.topic ?? undefined,
        nsfw: Boolean(entry.nsfw),
        rateLimitPerUser: entry.rateLimitPerUser ?? 0,
        bitrate: entry.bitrate ?? undefined,
        userLimit: entry.userLimit ?? undefined,
        permissionOverwrites: buildOverwrites(entry.overwrites, roleIds),
        reason,
      });
      result.channelsCreated += 1;
    } catch (error) {
      result.errors.push(`channel ${entry.name}: ${error.message}`);
    }
  }

  return result;
}
