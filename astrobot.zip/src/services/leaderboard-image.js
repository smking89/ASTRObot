import { createCanvas, GlobalFonts, loadImage } from '@napi-rs/canvas';
import { fileURLToPath } from 'node:url';

/**
 * Helios-style leaderboard renderer.
 *
 * One wide card: dark navy rows, solid gold/silver/bronze rows for the podium,
 * a "TOP N" header and a rounded footer. Prize chests sit on the podium rows.
 */

let fontsReady = false;
let logoPromise = null;
let prizeIconsPromise = null;

function prepareFonts() {
  if (fontsReady) return;
  fontsReady = true;
  try {
    GlobalFonts.registerFromPath('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 'AstroSans');
    GlobalFonts.registerFromPath('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 'AstroSansBold');
  } catch {
    // System fonts are fine when the bundled ones are unavailable.
  }
}

const family = (bold) => {
  const wanted = bold ? 'AstroSansBold' : 'AstroSans';
  const available = GlobalFonts.families?.some((entry) => entry.family === wanted);
  return available ? wanted : 'sans-serif';
};

/** White, transparent version of the AstroBot mark (no white chip). */
async function prepareLogo() {
  if (!logoPromise) {
    logoPromise = (async () => {
      try {
        const image = await loadImage(
          fileURLToPath(new URL('../../dashboard/public/astro-icon.png', import.meta.url)),
        );

        const tinted = createCanvas(image.width, image.height);
        const tintCtx = tinted.getContext('2d');
        tintCtx.drawImage(image, 0, 0);
        tintCtx.globalCompositeOperation = 'source-in';
        tintCtx.fillStyle = '#ffffff';
        tintCtx.fillRect(0, 0, image.width, image.height);

        // Trim the wide transparent padding around the mark.
        const { data } = tintCtx.getImageData(0, 0, image.width, image.height);
        let minX = image.width;
        let minY = image.height;
        let maxX = -1;
        let maxY = -1;
        for (let y = 0; y < image.height; y += 1) {
          for (let x = 0; x < image.width; x += 1) {
            if (data[(y * image.width + x) * 4 + 3] < 12) continue;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
          }
        }
        if (maxX <= minX || maxY <= minY) return tinted;

        const width = maxX - minX + 1;
        const height = maxY - minY + 1;
        const cropped = createCanvas(width, height);
        cropped.getContext('2d').drawImage(tinted, -minX, -minY);
        return cropped;
      } catch {
        return null;
      }
    })();
  }
  return logoPromise;
}

function preparePrizeIcons() {
  if (!prizeIconsPromise) {
    prizeIconsPromise = Promise.all(
      [1, 2, 3].map((rank) =>
        loadImage(
          fileURLToPath(new URL(`../../dashboard/public/rewards/prize-${rank}.png`, import.meta.url)),
        ).catch(() => null),
      ),
    );
  }
  return prizeIconsPromise;
}

const truncate = (text, max) => {
  const value = String(text ?? '');
  return value.length > max ? `${value.slice(0, max - 1)}…` : value;
};

const formatPrize = (value) =>
  new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 1 }).format(Number(value) || 0);

function roundRect(ctx, x, y, width, height, radius) {
  const r = Math.min(radius, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + width, y, x + width, y + height, r);
  ctx.arcTo(x + width, y + height, x, y + height, r);
  ctx.arcTo(x, y + height, x, y, r);
  ctx.arcTo(x, y, x + width, y, r);
  ctx.closePath();
}

const PALETTE = Object.freeze({
  background: '#081120',
  panel: '#0c1830',
  line: '#1e3352',
  text: '#f4f8ff',
  muted: '#8ea4c2',
  accent: '#e62127',
  green: '#5ee6a8',
  gold: '#f6c453',
  silver: '#c8d4e4',
  bronze: '#cf8a5b',
  podiumText: '#0b1524',
});

export async function renderLeaderboardImage({
  title = 'Leaderboard',
  subtitle = '',
  eyebrow = 'ASTROBOT',
  rows = [],
  footer = '',
  prizes = [],
  prizeLabel = '',
} = {}) {
  prepareFonts();

  const width = 1000;
  const pad = 28;
  const headerTop = 22;
  const headerHeight = 136;
  const rowHeight = 52;
  const rowGap = 8;
  const startY = headerTop + headerHeight + 22;
  const rowCount = Math.max(rows.length, 1);
  const footerY = startY + rowCount * (rowHeight + rowGap) + 12;
  const height = footerY + 44 + pad;

  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = PALETTE.background;
  ctx.fillRect(0, 0, width, height);

  const glow = ctx.createLinearGradient(0, 0, width * 0.7, 0);
  glow.addColorStop(0, 'rgba(230, 33, 39, 0.22)');
  glow.addColorStop(1, 'rgba(8, 17, 32, 0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, width * 0.7, headerTop + headerHeight);

  ctx.fillStyle = PALETTE.accent;
  ctx.fillRect(0, 0, width, 5);

  // Header card
  ctx.fillStyle = PALETTE.panel;
  roundRect(ctx, pad, headerTop, width - pad * 2, headerHeight, 16);
  ctx.fill();
  ctx.strokeStyle = 'rgba(230, 33, 39, 0.45)';
  ctx.lineWidth = 2;
  ctx.stroke();

  const logo = await prepareLogo();
  let textX = pad + 24;
  if (logo) {
    const logoHeight = 44;
    const logoWidth = Math.round((logo.width / logo.height) * logoHeight);
    ctx.drawImage(logo, pad + 24, headerTop + (headerHeight - logoHeight) / 2, logoWidth, logoHeight);
    textX = pad + 24 + logoWidth + 18;
  }

  ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = PALETTE.accent;
  ctx.font = `700 14px ${family(true)}`;
  ctx.fillText(eyebrow.toUpperCase().slice(0, 24), textX, headerTop + 34);

  const displayTitle = /leaderboard|leaders/i.test(title) ? title : `${title} Leaderboard`;
  ctx.fillStyle = PALETTE.text;
  ctx.font = `800 38px ${family(true)}`;
  ctx.fillText(truncate(displayTitle, 30), textX, headerTop + 78);

  ctx.fillStyle = PALETTE.muted;
  ctx.font = `400 15px ${family(false)}`;
  ctx.fillText(truncate(subtitle || 'Server rankings', 42), textX, headerTop + 108);

  ctx.textAlign = 'right';
  ctx.fillStyle = PALETTE.green;
  ctx.font = `800 22px ${family(true)}`;
  ctx.fillText('TOP 15', width - pad - 22, headerTop + 44);

  ctx.fillStyle = PALETTE.muted;
  ctx.font = `400 13px ${family(false)}`;
  ctx.fillText('refresh every 5 min', width - pad - 22, headerTop + 68);

  const prizeSet = prizes.map((amount) => Math.max(0, Math.trunc(Number(amount) || 0)));
  if (prizeSet.some(Boolean) && prizeLabel) {
    ctx.fillStyle = PALETTE.gold;
    ctx.font = `600 13px ${family(true)}`;
    ctx.fillText(prizeLabel.slice(0, 34), width - pad - 22, headerTop + 94);
  }
  ctx.textAlign = 'left';

  if (rows.length === 0) {
    ctx.fillStyle = PALETTE.muted;
    ctx.font = `400 22px ${family(false)}`;
    ctx.fillText('No players on the board yet.', pad + 20, startY + 40);
  }

  const prizeIcons = await preparePrizeIcons();
  const podium = [PALETTE.gold, PALETTE.silver, PALETTE.bronze];

  rows.forEach((row, index) => {
    const y = startY + index * (rowHeight + rowGap);
    const isPodium = index < 3;

    ctx.fillStyle = isPodium ? podium[index] : '#101d33';
    roundRect(ctx, pad, y, width - pad * 2, rowHeight, 10);
    ctx.fill();

    ctx.strokeStyle = isPodium ? 'rgba(0, 0, 0, 0.18)' : PALETTE.line;
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.fillStyle = isPodium ? PALETTE.podiumText : PALETTE.muted;
    ctx.font = `800 19px ${family(true)}`;
    ctx.fillText(`${index + 1}.`, pad + 18, y + rowHeight / 2 + 7);

    ctx.fillStyle = isPodium ? PALETTE.podiumText : PALETTE.text;
    ctx.font = `700 22px ${family(true)}`;
    ctx.fillText(truncate(row.name, 30), pad + 62, y + rowHeight / 2 + 8);

    const prize = index < 3 ? prizeSet[index] ?? 0 : 0;
    let valueRight = width - pad - 20;

    // The podium always carries its chest, even before a coin amount is set.
    if (index < 3) {
      const chipWidth = prize > 0 ? 118 : 44;
      const chipHeight = 34;
      const chipX = valueRight - chipWidth;
      const chipY = y + (rowHeight - chipHeight) / 2;
      const icon = prizeIcons[index];

      ctx.fillStyle = 'rgba(8, 15, 28, 0.88)';
      roundRect(ctx, chipX, chipY, chipWidth, chipHeight, 8);
      ctx.fill();

      if (icon) ctx.drawImage(icon, chipX + (prize > 0 ? 6 : 10), chipY + 5, 24, 24);

      if (prize > 0) {
        ctx.fillStyle = PALETTE.gold;
        ctx.font = `700 16px ${family(true)}`;
        ctx.fillText(formatPrize(prize), chipX + (icon ? 36 : 12), chipY + 23);
      }

      valueRight = chipX - 16;
    }

    ctx.textAlign = 'right';
    ctx.fillStyle = isPodium ? PALETTE.podiumText : PALETTE.green;
    ctx.font = `800 22px ${family(true)}`;
    ctx.fillText(truncate(row.value, 22), valueRight, y + rowHeight / 2 + 8);
    ctx.textAlign = 'left';
  });

  // Footer bar
  ctx.fillStyle = PALETTE.panel;
  roundRect(ctx, pad, footerY, width - pad * 2, 44, 10);
  ctx.fill();
  ctx.strokeStyle = PALETTE.line;
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.fillStyle = PALETTE.muted;
  ctx.font = `400 14px ${family(false)}`;
  ctx.textAlign = 'center';
  ctx.fillText(truncate(`${footer} · AstroBot Leaderboard`, 110), width / 2, footerY + 28);
  ctx.textAlign = 'left';

  return canvas.toBuffer('image/png');
}
