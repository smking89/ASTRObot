import { COLORS } from '../config/constants.js';
import { createLogger } from '../core/logger.js';
import { ValidationError } from '../core/errors.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { getServer } from '../db/repositories/servers.js';
import {
  listAllWipeProfiles,
  listAllWipeProfilesAwaitingOnline,
  listWipeProfiles,
  listWipeProfilesAwaitingOnline,
  updateWipeProfile,
} from '../db/repositories/wipes.js';
import { buildEmbed } from '../ui/embeds.js';
import { htmlToMarkdown, htmlToPlainText } from '../utils/html.js';

const log = createLogger('wipe');

export const WIPE_TYPES = Object.freeze({ bp: 'Blueprint wipe', full: 'Full wipe' });

export const DEFAULT_WIPE_MESSAGES = Object.freeze({
  first: '🧨 **{wipe} in {minutes} minutes** — {server}\nSave your loot and get to safety.',
  second: '⚠️ **{minutes} minutes until the {wipe}** — {server}\nFinish your fights and store your gear.',
  third: '🚨 **{minutes} minutes left** — {server} is going down for the {wipe}.',
  online: '✅ **{server} is back online** — the {wipe} is complete. Queue up!',
});

export function parseWipeMessages(value) {
  let data = value;
  if (typeof value === 'string') {
    try {
      data = JSON.parse(value);
    } catch {
      data = null;
    }
  }

  const messages = {};
  for (const key of Object.keys(DEFAULT_WIPE_MESSAGES)) {
    const text = data && typeof data[key] === 'string' ? data[key].trim() : '';
    messages[key] = text || DEFAULT_WIPE_MESSAGES[key];
  }
  return messages;
}

/** Renders placeholders and converts optional HTML for Discord or RCON. */
export function renderWipeMessage(template, vars = {}, mode = 'discord') {
  const raw = String(template ?? '').replace(/\{(minutes|server|wipe|time)\}/gi, (match, key) =>
    String(vars[key.toLowerCase()] ?? match),
  );
  if (mode === 'game') return htmlToPlainText(raw).slice(0, 240);
  return htmlToMarkdown(raw).slice(0, 1900);
}

/** Rust console command used for in-game messages. */
export function gameSayCommand(text) {
  const line = htmlToPlainText(text).replaceAll('"', "'").slice(0, 240);
  return line ? `global.say "${line}"` : null;
}

/** `restart 300` means wait at least five minutes before calling it online. */
export function parseRestartDelay(command) {
  const match = /(\d{1,4})\s*$/.exec(String(command ?? '').trim());
  return match ? Math.max(0, Math.min(3600, Number(match[1]))) : 0;
}

/** Saved delay wins; legacy profiles fall back to `restart 300`-style commands. */
export function restartDelayFor(profile) {
  if (profile?.restart_delay != null) {
    const configured = Number(profile.restart_delay);
    if (Number.isFinite(configured)) return Math.max(0, Math.min(3600, Math.floor(configured)));
  }
  return parseRestartDelay(profile?.restart_command);
}

export function restartCommandFor(profile) {
  const command = String(profile?.restart_command ?? '').trim() || 'restart';
  if (profile?.restart_delay == null) return command;
  return `${command} ${restartDelayFor(profile)}`.trim();
}

export function parseCountdowns(value) {
  const raw = Array.isArray(value) ? value : String(value ?? '').split(/[\s,]+/);
  const minutes = raw
    .map((entry) => Number(entry))
    .filter((entry) => Number.isFinite(entry) && entry > 0 && entry <= 10_080);
  const unique = [...new Set(minutes)].sort((a, b) => b - a);
  return unique.length ? unique : [60, 30, 10];
}

export function parseMapRotation(value) {
  if (Array.isArray(value)) return normalizeRotation(value);
  const raw = String(value ?? '').trim();
  if (!raw) return [];

  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new ValidationError('Map rotation must be a JSON list, e.g. [{"seed":123,"worldsize":3000}].');
  }
  if (!Array.isArray(parsed)) throw new ValidationError('Map rotation must be a JSON list.');
  return normalizeRotation(parsed);
}

function normalizeRotation(entries) {
  return entries
    .map((entry) => ({
      seed: Number(entry?.seed) || 0,
      worldsize: Number(entry?.worldsize) || 0,
      levelurl: entry?.levelurl ? String(entry.levelurl) : null,
    }))
    .filter((entry) => entry.seed > 0 || entry.levelurl);
}

export function nextWipeAt(now, intervalHours) {
  return now + Math.max(1, Number(intervalHours) || 168) * 3_600_000;
}

export function minutesUntil(profile, now = Date.now()) {
  return Math.ceil((Number(profile.next_wipe_at) - now) / 60_000);
}

/** The largest countdown stage that is due and has not been announced yet. */
export function dueStage(profile, now = Date.now()) {
  const left = minutesUntil(profile, now);
  if (left <= 0) return null;

  const announced = new Set(
    String(profile.announced_stages ?? '')
      .split(',')
      .filter(Boolean)
      .map(Number),
  );
  return parseCountdowns(profile.countdowns).find((stage) => left <= stage && !announced.has(stage)) ?? null;
}

/** Pure plan: which RCON commands run and which map entry is used. */
export function planWipe(profile) {
  const rotation = parseMapRotation(profile.map_rotation);
  const index = rotation.length ? (Number(profile.rotation_index) || 0) % rotation.length : 0;
  const map = rotation.length ? rotation[index] : null;
  const commands = [];

  if (Number(profile.rotate_map) && map) {
    if (map.seed) commands.push(`server.seed ${map.seed}`);
    if (map.worldsize) commands.push(`server.worldsize ${map.worldsize}`);
    if (map.levelurl) commands.push(`server.levelurl ${map.levelurl}`);
  }
  if (Number(profile.auto_restart)) commands.push(restartCommandFor(profile));

  return {
    map,
    commands,
    nextIndex: rotation.length ? (index + 1) % rotation.length : 0,
  };
}

function messageVars(profile, server, minutes = 0) {
  return {
    server: server?.label ?? profile.server_id,
    wipe: WIPE_TYPES[profile.wipe_type] ?? WIPE_TYPES.bp,
    minutes: String(Math.max(0, Math.round(Number(minutes) || 0))),
    time: new Date(Number(profile.next_wipe_at)).toISOString().replace('T', ' ').slice(0, 16) + ' UTC',
  };
}

function wipeChannelId(profile) {
  if (profile.channel_id) return profile.channel_id;
  try {
    return getGuildSettings(profile.guild_id).channels?.broadcasts ?? null;
  } catch {
    return null;
  }
}

async function sendPayload(client, channelId, payload) {
  if (!channelId) return false;
  try {
    const channel = await client?.channels?.fetch?.(channelId);
    if (!channel?.send) return false;
    await channel.send(payload);
    return true;
  } catch (error) {
    log.warn(`Cannot post wipe message to ${channelId}`, error);
    return false;
  }
}

function countdownEmbed(profile, stage, server) {
  return buildEmbed({
    title: `🧨 Wipe in ${stage} minutes`,
    color: stage <= 10 ? COLORS.danger : COLORS.warning,
    description: `**${profile.name}** — ${WIPE_TYPES[profile.wipe_type] ?? profile.wipe_type}`,
    fields: [
      { name: 'Server', value: server ? `**${server.label}**` : `\`${profile.server_id}\``, inline: true },
      { name: 'Wipe at', value: `<t:${Math.floor(profile.next_wipe_at / 1000)}:F>`, inline: true },
      {
        name: 'What happens',
        value: [
          Number(profile.auto_restart) ? 'Server restart' : null,
          Number(profile.rotate_map) && parseMapRotation(profile.map_rotation).length ? 'Map rotation' : null,
        ]
          .filter(Boolean)
          .join(' · ') || 'Announcement only',
      },
    ],
    footer: 'AstroBot wipe controller',
  });
}

/**
 * Posts one warning. The first, second and third due stages use the matching
 * custom message; extra stages reuse the third. Discord gets markdown, the game
 * gets `global.say "…"`.
 */
async function postCountdown(profile, stage, now, client, rconManager) {
  const server = getServer(profile.server_id);
  const announced = new Set(
    String(profile.announced_stages ?? '')
      .split(',')
      .filter(Boolean)
      .map(Number),
  );
  const messages = parseWipeMessages(profile.wipe_messages);
  const stages = parseCountdowns(profile.countdowns);
  const key = ['first', 'second', 'third'][Math.min(Math.max(0, stages.indexOf(stage)), 2)];
  const vars = messageVars(profile, server, stage);
  const content = renderWipeMessage(messages[key], vars, 'discord');

  const sent = await sendPayload(client, wipeChannelId(profile), {
    content,
    allowedMentions: { parse: [] },
  });
  if (!sent) {
    // A missing channel should not hide the warning from the panel; the embed
    // path is also the fallback when a custom message is empty.
    await sendPayload(client, wipeChannelId(profile), {
      embeds: [countdownEmbed(profile, stage, server)],
      allowedMentions: { parse: [] },
    });
  }

  if (Number(profile.announce_in_game)) {
    const connection = rconManager?.connections?.get?.(profile.server_id);
    if (connection?.connected) {
      const command = gameSayCommand(renderWipeMessage(messages[key], vars, 'game'));
      if (command) await connection.send(command).catch((error) => log.warn(`In-game wipe warning failed for ${profile.id}`, error));
    }
  }

  announced.add(stage);
  updateWipeProfile(profile.id, { announced_stages: [...announced].sort((a, b) => b - a).join(',') });
  return true;
}

/** Runs the wipe: rotation commands, restart, summary and reschedule. */
export async function executeWipe(profile, { client, rconManager, now = Date.now() } = {}) {
  const plan = planWipe(profile);
  const connection = rconManager?.connections?.get?.(profile.server_id);
  const errors = [];

  for (const command of plan.commands) {
    try {
      if (!connection?.connected) throw new Error('RCON offline');
      await connection.send(command);
    } catch (error) {
      errors.push(`${command}: ${error.message}`);
    }
  }

  const next = nextWipeAt(now, profile.interval_hours);
  const restartCommand = restartCommandFor(profile);
  const restartFailed = errors.some((entry) => entry.startsWith(`${restartCommand}:`));
  const awaitingOnline = Number(profile.auto_restart) && !restartFailed;
  const onlineAfter = awaitingOnline ? now + restartDelayFor(profile) * 1000 + 10_000 : null;

  updateWipeProfile(profile.id, {
    last_wipe_at: now,
    next_wipe_at: next,
    announced_stages: '',
    rotation_index: plan.nextIndex,
    awaiting_online: awaitingOnline ? 1 : 0,
    online_after: onlineAfter,
    online_announced_at: null,
  });

  const server = getServer(profile.server_id);
  const embed = buildEmbed({
    title: '✅ Wipe executed',
    color: errors.length ? COLORS.warning : COLORS.success,
    description: `**${profile.name}** — ${WIPE_TYPES[profile.wipe_type] ?? profile.wipe_type}`,
    fields: [
      { name: 'Server', value: server ? `**${server.label}**` : `\`${profile.server_id}\``, inline: true },
      { name: 'Next wipe', value: `<t:${Math.floor(next / 1000)}:F>`, inline: true },
      { name: 'Back online', value: awaitingOnline ? 'Waiting for the server to reconnect' : 'Restart disabled', inline: true },
      {
        name: 'Map',
        value: plan.map
          ? [
              plan.map.seed ? `seed **${plan.map.seed}**` : null,
              plan.map.worldsize ? `size **${plan.map.worldsize}**` : null,
              plan.map.levelurl ? `\`${plan.map.levelurl}\`` : null,
            ]
              .filter(Boolean)
              .join(' · ')
          : 'Rotation off',
        inline: true,
      },
      { name: 'Commands sent', value: plan.commands.length ? `\`${plan.commands.join('` · `')}\`` : 'None', inline: false },
      ...(errors.length ? [{ name: 'Warnings', value: errors.slice(0, 5).join('\n').slice(0, 1024), inline: false }] : []),
    ],
    footer: 'AstroBot wipe controller',
  });

  await sendPayload(client, wipeChannelId(profile), { embeds: [embed], allowedMentions: { parse: [] } });
  return { commands: plan.commands, errors, next, awaitingOnline };
}

/**
 * Called when RCON reconnects. Posts the configured back-online message once
 * the restart delay has elapsed, then clears the pending flag.
 */
export async function announceServerOnline({ connection, client, now = Date.now() } = {}) {
  if (!connection?.serverId) return 0;
  const profiles = listWipeProfilesAwaitingOnline(connection.serverId, now);
  for (const profile of profiles) {
    const server = getServer(profile.server_id);
    const messages = parseWipeMessages(profile.wipe_messages);
    const vars = messageVars(profile, server, 0);
    const content = renderWipeMessage(messages.online, vars, 'discord');

    await sendPayload(client, wipeChannelId(profile), {
      content,
      allowedMentions: { parse: [] },
    });

    if (Number(profile.announce_in_game) && connection.connected) {
      const command = gameSayCommand(renderWipeMessage(messages.online, vars, 'game'));
      if (command) await connection.send(command).catch((error) => log.warn(`In-game online message failed for ${profile.id}`, error));
    }

    updateWipeProfile(profile.id, { awaiting_online: 0, online_announced_at: now });
    log.info(`Announced ${server?.label ?? profile.server_id} back online after ${profile.name}.`);
  }
  return profiles.length;
}

/** Called on a timer: announces due countdowns, executes due wipes and catches reconnects. */
export async function tickWipes({ client, rconManager, now = Date.now() } = {}) {
  for (const profile of listAllWipeProfiles()) {
    try {
      if (Number(profile.next_wipe_at) <= now) {
        await executeWipe(profile, { client, rconManager, now });
        continue;
      }
      const stage = dueStage(profile, now);
      if (stage) await postCountdown(profile, stage, now, client, rconManager);
    } catch (error) {
      log.warn(`Wipe tick failed for ${profile.id}`, error);
    }
  }

  // A reconnect event normally handles this, but the timer catches a connection
  // that was already healthy before the restart delay elapsed.
  for (const profile of listAllWipeProfilesAwaitingOnline(now)) {
    const connection = rconManager?.connections?.get?.(profile.server_id);
    if (connection?.connected) {
      await announceServerOnline({ connection, client, now }).catch((error) => log.warn(`Wipe online check failed for ${profile.id}`, error));
    }
  }
}

export { listWipeProfiles };
