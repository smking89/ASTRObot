import { getGuildSettings, patchGuildSetting } from '../db/repositories/guilds.js';
import { allRustItems } from './rust-items.js';
import { defaultStockValue } from './shop-stock.js';

/**
 * One-click shop builder.
 *
 * Prices are derived from the catalog rather than typed by hand: the item's
 * category value, its stack size (small stacks are more valuable per item) and
 * weapon/explosive/armor keywords feed a base price. The owner's price tier then
 * multiplies that base, and the multipliers are configurable in /config shop.
 */

export const QUICK_TIERS = Object.freeze({
  cheap: { label: 'Cheap', multiplier: 0.6, description: 'Community-friendly prices' },
  mid: { label: 'Mid', multiplier: 1, description: 'Balanced prices' },
  expensive: { label: 'Expensive', multiplier: 2, description: 'High-end economy' },
});

/** Categories that make up the generated shop, in display order. */
export const SHOP_CATEGORIES = Object.freeze([
  'Weapons',
  'Ammo',
  'Attachments',
  'Explosives',
  'Armor',
  'Clothing',
  'Medical',
  'Food',
  'Tools',
  'Resources',
  'Components',
  'Building',
  'Deployables',
  'Vehicles',
  'Misc',
]);

/** Relative value of a category at a full base price. */
const CATEGORY_VALUE = Object.freeze({
  Weapons: 14,
  Ammo: 3,
  Attachments: 8,
  Explosives: 18,
  Armor: 11,
  Clothing: 5,
  Medical: 5,
  Food: 2,
  Tools: 3,
  Resources: 2,
  Components: 4,
  Building: 7,
  Deployables: 6,
  Vehicles: 24,
  Misc: 4,
});

const WEAPON_PATTERN = /\b(rifle|smg|pistol|shotgun|machine gun|bolt action|lmg|weapon)\b/;
const EXPLOSIVE_PATTERN = /\b(explosive|rocket|grenade|satchel|c4|bomb)\b/;
const ARMOR_PATTERN = /\b(armor|helmet|facemask|chest plate|jacket)\b/;

/**
 * Tier 3 is not a field in the item dump, so the catalog is classified by its
 * workbench-tier shortnames. The list covers the weapons, attachments, raid
 * tools and high-end deployables owners expect the quick setup to hide by
 * default. Explosives are filtered separately as well.
 */
const TIER3_SHORTNAMES = new Set([
  'rifle.ak',
  'rifle.bolt',
  'rifle.l96',
  'rifle.lr300',
  'lmg.m249',
  'smg.mp5',
  'pistol.python',
  'rocket.launcher',
  'multiplegrenadelauncher',
  'weapon.mod.8x.scope',
  'weapon.mod.muzzlebrake',
  'explosive.timed',
  'explosive.satchel',
  'ammo.rocket.basic',
  'ammo.rocket.hv',
  'ammo.rocket.fire',
  'ammo.rifle.explosive',
  'heavy.plate.helmet',
  'heavy.plate.jacket',
  'heavy.plate.pants',
  'door.hinged.toptier',
  'autoturret',
  'samsite',
  'cctv.camera',
  'computerstation',
  'electric.solarpanel.large',
  'generator.wind.scrap',
  'electric.fuelgenerator.small',
  'wall.frame.garagedoor',
]);

const TIER3_PATTERN = /\b(tier 3|tier-3|workbench 3|workbench-3)\b/i;

/** True when an item belongs to the workbench-3 / high-end catalog set. */
export function isTier3Item(item) {
  if (!item) return false;
  if (TIER3_SHORTNAMES.has(String(item.shortname ?? '').toLowerCase())) return true;
  return TIER3_PATTERN.test(`${item.name ?? ''} ${item.description ?? ''}`);
}

/** True for explosives, explosive ammo and explosive deployables. */
export function isExplosiveItem(item) {
  if (!item) return false;
  if (String(item.category ?? '') === 'Explosives') return true;
  return EXPLOSIVE_PATTERN.test(`${item.name ?? ''} ${item.shortname ?? ''}`);
}

const wizardStates = new Map();
const stateKey = (guildId, userId) => `${guildId}:${userId}`;

/** Currency options: the guild currency plus any names added in /config shop. */
export function configuredCurrencies(settings) {
  const values = [settings?.economy?.currency ?? 'coins', ...(settings?.shop?.currencies ?? [])];
  return [...new Set(values.map((value) => String(value ?? '').trim()).filter(Boolean))].slice(0, 25);
}

/** Tier multipliers from settings, falling back to the defaults above. */
export function priceMultipliers(settings) {
  const configured = settings?.shop?.priceTiers ?? {};
  const result = {};

  for (const [key, tier] of Object.entries(QUICK_TIERS)) {
    const value = Number(configured[key]);
    result[key] = Number.isFinite(value) && value > 0 ? value : tier.multiplier;
  }

  return result;
}

/**
 * Catalog-derived base price: category value × stack scarcity × keyword boost.
 * A stack of 1 is worth 20× a stack of 100, and weapons/explosives/armor carry a
 * multiplier because a single unit is far more useful than a resource.
 */
export function autoPrice(item, category) {
  if (!item) return 1;

  const stack = Math.max(1, Number(item.stackSize) || 1);
  const stackFactor = Math.min(20, Math.max(1, 100 / stack));
  const text = `${item.name} ${item.description ?? ''}`.toLowerCase();
  const keyword = WEAPON_PATTERN.test(text) ? 1.5 : EXPLOSIVE_PATTERN.test(text) ? 1.4 : ARMOR_PATTERN.test(text) ? 1.2 : 1;
  const value = CATEGORY_VALUE[category] ?? 5;

  return Math.max(1, Math.round(value * stackFactor * keyword));
}

export function quickSetupState(guildId, userId) {
  const key = stateKey(guildId, userId);
  if (!wizardStates.has(key)) {
    const settings = getGuildSettings(guildId);
    wizardStates.set(key, {
      tier: 'mid',
      currency: settings.economy.currency ?? 'coins',
      roleId: null,
      tier3: false,
      explosives: false,
    });
  }
  return wizardStates.get(key);
}

export function updateQuickSetup(guildId, userId, patch) {
  return Object.assign(quickSetupState(guildId, userId), patch);
}

export function resetQuickSetup(guildId, userId) {
  wizardStates.delete(stateKey(guildId, userId));
}

/**
 * Resolves the selected options into ready-to-store products. The whole Rust
 * catalogue is used — every item that ships with artwork becomes a product, in
 * its catalogued category, with its real shortname so RCON delivery works.
 */
export function buildQuickSetupProducts(state, multipliers = null, defaultStock = null) {
  const effective = { ...priceMultipliers(null), ...(multipliers ?? {}) };
  const tierMultiplier = effective[state.tier] ?? 1;

  return allRustItems()
    .filter((item) => item.image)
    .filter((item) => state.tier3 || !isTier3Item(item))
    .filter((item) => state.explosives || !isExplosiveItem(item))
    .map((item) => ({
      id: item.shortname,
      name: item.name,
      shortname: item.shortname,
      itemId: item.itemId,
      image: item.image,
      description: item.description,
      stackSize: item.stackSize,
      quantity: 1,
      price: Math.max(1, Math.round(autoPrice(item, item.category) * tierMultiplier)),
      category: item.category,
      stock: defaultStock,
      requiredRoleId: state.roleId ?? null,
      coins: 0,
    }));
}

export function quickSetupPreview(state, multipliers = null, defaultStock = null) {
  const products = buildQuickSetupProducts(state, multipliers, defaultStock);
  const groups = new Map();

  for (const product of products) {
    if (!groups.has(product.category)) groups.set(product.category, []);
    groups.get(product.category).push(product);
  }

  const categories = [...groups.entries()].map(([category, items]) => ({
    category,
    count: items.length,
    from: Math.min(...items.map((item) => item.price)),
    to: Math.max(...items.map((item) => item.price)),
  }));

  return { products, categories };
}

/** Appends the generated catalog, skips duplicates and switches the currency. */
export function applyQuickSetup({ guildId, state, actorId = null, multipliers = null }) {
  const settings = getGuildSettings(guildId);
  const existing = settings.shop.products ?? [];
  const listed = new Set(existing.map((product) => product.shortname).filter(Boolean));

  const generated = buildQuickSetupProducts(state, multipliers, defaultStockValue(settings));
  const added = generated.filter((product) => !listed.has(product.shortname));

  let next = settings;
  if (added.length > 0) {
    next = patchGuildSetting(guildId, 'shop.products', [...existing, ...added], { actorId }).settings;
  }
  if (state.currency && state.currency !== next.economy.currency) {
    next = patchGuildSetting(guildId, 'economy.currency', state.currency, { actorId }).settings;
  }

  return {
    added: added.length,
    skipped: generated.length - added.length,
    total: (next.shop.products ?? []).length,
    settings: next,
  };
}
