import { mkdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { getDb } from '../db/index.js';

/**
 * Creates a consistent SQLite snapshot while the bot/dashboard are running.
 * The snapshot is intentionally a normal .db file so the existing dashboard
 * backup download and manual restore workflow keep working.
 */
export function createDatabaseBackup(label = 'manual') {
  const dir = join('data', 'backups');
  mkdirSync(dir, { recursive: true });
  const safeLabel = String(label || 'manual')
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40) || 'manual';
  const name = `astrobot-${safeLabel}-${new Date().toISOString().replace(/[:.]/g, '-')}.db`;
  const target = join(dir, name);
  getDb().exec(`VACUUM INTO '${target.replaceAll("'", "''")}'`);
  return { name, path: target, bytes: statSync(target).size, createdAt: new Date().toISOString() };
}
