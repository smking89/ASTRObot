/**
 * Object helpers used by the settings store and panel renderers.
 */

export function isPlainObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** Deep-merge defaults with a stored partial. Arrays are replaced, never merged. */
export function deepMerge(base, override) {
  if (!isPlainObject(base) || !isPlainObject(override)) {
    return override === undefined ? base : override;
  }

  const result = { ...base };
  for (const [key, value] of Object.entries(override)) {
    result[key] = isPlainObject(value) && isPlainObject(base[key]) ? deepMerge(base[key], value) : value;
  }
  return result;
}

/** Reads "a.b.c" from a nested object. */
export function getPath(source, path, fallback = undefined) {
  const segments = path.split('.');
  let current = source;
  for (const segment of segments) {
    if (!isPlainObject(current) || !(segment in current)) return fallback;
    current = current[segment];
  }
  return current ?? fallback;
}

/** Immutably sets "a.b.c" on a nested object and returns the new root. */
export function setPath(source, path, value) {
  const segments = path.split('.');
  const root = { ...source };
  let cursor = root;

  for (let index = 0; index < segments.length - 1; index += 1) {
    const segment = segments[index];
    cursor[segment] = isPlainObject(cursor[segment]) ? { ...cursor[segment] } : {};
    cursor = cursor[segment];
  }

  cursor[segments.at(-1)] = value;
  return root;
}

export function chunk(array, size) {
  const output = [];
  for (let index = 0; index < array.length; index += size) {
    output.push(array.slice(index, index + size));
  }
  return output;
}

/** Returns a new object without the listed keys. */
export function omit(source, keys) {
  const blocked = new Set(keys);
  return Object.fromEntries(Object.entries(source).filter(([key]) => !blocked.has(key)));
}
