import { createCipheriv, createDecipheriv, createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { env } from '../config/env.js';

/**
 * Secret at rest helper for RCON passwords and webhook credentials.
 * AES-256-GCM with a key derived from BOT_ENCRYPTION_KEY.
 */

const PREFIX = 'v1';
const key = env.encryptionKey ? createHash('sha256').update(env.encryptionKey).digest() : null;

export function isEncryptionEnabled() {
  return Boolean(key);
}

export function encryptSecret(value) {
  if (!key) return `plain:${value}`;

  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(String(value), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();

  return `${PREFIX}:${iv.toString('base64')}:${tag.toString('base64')}:${ciphertext.toString('base64')}`;
}

export function decryptSecret(stored) {
  const value = String(stored ?? '');
  if (value.startsWith('plain:')) return value.slice(6);
  if (!key) throw new Error('BOT_ENCRYPTION_KEY is required to read encrypted secrets.');

  const [prefix, ivPart, tagPart, dataPart] = value.split(':');
  if (prefix !== PREFIX || !ivPart || !tagPart || !dataPart) {
    throw new Error('Malformed encrypted secret.');
  }

  const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(ivPart, 'base64'));
  decipher.setAuthTag(Buffer.from(tagPart, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(dataPart, 'base64')), decipher.final()]).toString('utf8');
}

/** Constant-time comparison for webhook signatures and license checks. */
export function safeEqual(a, b) {
  const left = Buffer.from(String(a));
  const right = Buffer.from(String(b));
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

export function hmacSha256Hex(secret, payload) {
  return createHash('sha256').update(secret).update(payload).digest('hex');
}
