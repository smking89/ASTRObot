import { randomInt, randomUUID } from 'node:crypto';

/** Crypto-backed randomness — wager and loot outcomes must not use Math.random. */

export function rollInt(min, max) {
  return randomInt(min, max + 1);
}

export function rollDie(sides = 6) {
  return rollInt(1, sides);
}

export function pick(list) {
  if (!Array.isArray(list) || list.length === 0) return undefined;
  return list[rollInt(0, list.length - 1)];
}

export function shuffle(input) {
  const array = [...input];
  for (let index = array.length - 1; index > 0; index -= 1) {
    const swap = rollInt(0, index);
    [array[index], array[swap]] = [array[swap], array[index]];
  }
  return array;
}

/** Percent chance, 0-100. */
export function chance(percent) {
  return rollInt(1, 100) <= percent;
}

export function uniqueId(prefix = 'id') {
  return `${prefix}_${randomUUID().replaceAll('-', '').slice(0, 16)}`;
}

/** Fisher-Yates draw of `count` unique entries. */
export function draw(list, count) {
  return shuffle(list).slice(0, Math.max(0, count));
}

/**
 * Weighted draw without replacement. `entries` is [{ id, weight }]. Used for
 * giveaway tickets, where bonus tasks add extra chances without duplicating the
 * entrant in the public entry list.
 */
export function weightedDraw(entries, count) {
  const pool = (Array.isArray(entries) ? entries : [])
    .filter((entry) => entry && entry.id != null)
    .map((entry) => [entry.id, Math.max(1, Math.min(1000, Math.trunc(Number(entry.weight) || 1)))]);

  const winners = [];
  const total = Math.min(Math.max(0, Number(count) || 0), pool.length);

  for (let picked = 0; picked < total; picked += 1) {
    const weightTotal = pool.reduce((sum, [, weight]) => sum + weight, 0);
    let roll = rollInt(1, weightTotal);
    let index = 0;
    for (; index < pool.length; index += 1) {
      roll -= pool[index][1];
      if (roll <= 0) break;
    }
    if (index >= pool.length) index = pool.length - 1;
    winners.push(pool[index][0]);
    pool.splice(index, 1);
  }

  return winners;
}
