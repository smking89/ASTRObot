import { ValidationError } from '../core/errors.js';

/** Input parsing shared by commands, modals and the RCON parser. */

export function parseIntStrict(value, { min = Number.MIN_SAFE_INTEGER, max = Number.MAX_SAFE_INTEGER, label = 'value' } = {}) {
  const parsed = Number.parseInt(String(value ?? '').trim(), 10);
  if (!Number.isFinite(parsed)) throw new ValidationError(`**${label}** must be a whole number.`);
  if (parsed < min || parsed > max) {
    throw new ValidationError(`**${label}** must be between ${min} and ${max}.`);
  }
  return parsed;
}

export function parseBigIntString(value, label = 'amount') {
  const cleaned = String(value ?? '').replaceAll(/[,_\s]/g, '');
  if (!/^\d+$/.test(cleaned)) throw new ValidationError(`**${label}** must be a positive whole number.`);
  return BigInt(cleaned);
}

export function parseBoolean(value) {
  return ['1', 'true', 'yes', 'on', 'enabled'].includes(String(value ?? '').toLowerCase());
}

/** Accepts "90", "90s", "15m", "2h", "7d". */
export function parseDuration(value) {
  const match = /^(\d+)\s*(s|m|h|d|w)?$/i.exec(String(value ?? '').trim());
  if (!match) throw new ValidationError('Duration must look like `30s`, `15m`, `2h`, `7d`.');
  const units = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000, w: 604_800_000 };
  return Number.parseInt(match[1], 10) * (units[(match[2] ?? 'm').toLowerCase()] ?? 60_000);
}

/** Parses "x,y,z", "(x, y, z)" or "x y z" into a coordinate triple. */
export function parseCoordinates(value) {
  const numbers = String(value ?? '')
    .replaceAll(/[()[\]]/g, ' ')
    .split(/[,;\s]+/)
    .filter(Boolean)
    .map(Number);

  if (numbers.length !== 3 || numbers.some((entry) => !Number.isFinite(entry))) {
    throw new ValidationError('Coordinates must be three numbers: `x, y, z`.');
  }
  return { x: numbers[0], y: numbers[1], z: numbers[2] };
}

/** Chat input option is a string; allow "<@id>" mentions and bare snowflakes. */
export function parseUserId(value) {
  const match = /^<@!?(\d{15,20})>$/.exec(String(value ?? '').trim()) ?? /^(\d{15,20})$/.exec(String(value ?? '').trim());
  if (!match) throw new ValidationError('That is not a valid Discord user mention.');
  return match[1];
}

export function parseHexColor(value) {
  const cleaned = String(value ?? '').replace(/^#/, '').trim();
  if (!/^[0-9a-f]{6}$/i.test(cleaned)) throw new ValidationError('Color must be a 6 digit hex code such as `#8b5cf6`.');
  return Number.parseInt(cleaned, 16);
}

/**
 * Splits a whitespace separated argument string, preserving quoted segments.
 * Used by the admin console-style commands (/give, /dev ads).
 */
export function splitArguments(input) {
  const matches = String(input ?? '').matchAll(/"([^"]*)"|'([^']*)'|(\S+)/g);
  return [...matches].map((match) => match[1] ?? match[2] ?? match[3]);
}
