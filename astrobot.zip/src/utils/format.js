import { EMOJI } from '../config/constants.js';

/** Number formatting, coin display, duration and text helpers. */

export function formatNumber(value) {
  return new Intl.NumberFormat('en-US').format(Math.trunc(Number(value) || 0));
}

export function formatCoins(value, currency = 'coins') {
  return `${EMOJI.coin} **${formatNumber(value)}** ${currency}`;
}

export function formatSigned(value, currency = 'coins') {
  const number = Math.trunc(Number(value) || 0);
  const sign = number > 0 ? '+' : number < 0 ? '-' : '';
  return `${sign}${formatNumber(Math.abs(number))} ${currency}`;
}

export function formatDuration(ms) {
  const total = Math.max(0, Math.trunc(ms / 1000));
  const days = Math.floor(total / 86_400);
  const hours = Math.floor((total % 86_400) / 3_600);
  const minutes = Math.floor((total % 3_600) / 60);
  const seconds = total % 60;

  const parts = [];
  if (days) parts.push(`${days}d`);
  if (hours) parts.push(`${hours}h`);
  if (minutes && !days) parts.push(`${minutes}m`);
  if (seconds && !days && !hours) parts.push(`${seconds}s`);
  return parts.length > 0 ? parts.join(' ') : '0s';
}

export function relativeTimestamp(date, style = 'R') {
  const time = date instanceof Date ? date : new Date(date);
  return `<t:${Math.floor(time.getTime() / 1000)}:${style}>`;
}

export function truncate(text, max = 1024) {
  const value = String(text ?? '');
  return value.length <= max ? value : `${value.slice(0, Math.max(0, max - 1))}…`;
}

export function codeBlock(text, language = '') {
  return `\`\`\`${language}\n${truncate(text, 1900)}\n\`\`\``;
}

export function inlineCode(text) {
  return `\`${String(text ?? '').replaceAll('`', 'ˋ')}\``;
}

/** Rust grid reference (e.g. "K12") from world coordinates. */
export function gridRef(x, z) {
  if (!Number.isFinite(x) || !Number.isFinite(z)) return '--';
  const column = String.fromCharCode(65 + Math.min(25, Math.max(0, Math.floor((x + 2000) / 146))));
  const row = Math.max(0, Math.floor((2000 - z) / 146));
  return `${column}${row}`;
}

export function progressBar(current, max, size = 12) {
  const ratio = max <= 0 ? 0 : Math.min(1, Math.max(0, current / max));
  const filled = Math.round(ratio * size);
  return `${'█'.repeat(filled)}${'░'.repeat(Math.max(0, size - filled))} ${Math.round(ratio * 100)}%`;
}

export function pluralize(count, singular, plural = `${singular}s`) {
  return `${formatNumber(count)} ${count === 1 ? singular : plural}`;
}

export function titleCase(value) {
  return String(value)
    .replaceAll(/[-_]/g, ' ')
    .replaceAll(/\b\w/g, (letter) => letter.toUpperCase());
}
