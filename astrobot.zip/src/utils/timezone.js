/** IANA timezone helpers built on Intl, with no external dependency. */

const formatterCache = new Map();

function formatterFor(timeZone) {
  let formatter = formatterCache.get(timeZone);
  if (!formatter) {
    formatter = new Intl.DateTimeFormat('en-US', {
      timeZone,
      hour12: false,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    formatterCache.set(timeZone, formatter);
  }
  return formatter;
}

/** Returns a valid IANA zone, falling back to UTC. */
export function formatTimeZone(value, fallback = 'UTC') {
  const zone = String(value ?? '').trim() || fallback;
  try {
    formatterFor(zone).format(new Date());
    return zone;
  } catch {
    return fallback;
  }
}

export function zonedParts(date, timeZone = 'UTC') {
  const zone = formatTimeZone(timeZone);
  const parts = Object.fromEntries(
    formatterFor(zone)
      .formatToParts(date instanceof Date ? date : new Date(date))
      .map((part) => [part.type, part.value]),
  );
  return {
    year: Number(parts.year),
    month: Number(parts.month),
    day: Number(parts.day),
    hour: Number(parts.hour) % 24,
    minute: Number(parts.minute),
    second: Number(parts.second),
  };
}

function offsetMs(timeZone, date) {
  const parts = zonedParts(date, timeZone);
  const asUtc = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second);
  return asUtc - Math.floor(date.getTime() / 1000) * 1000;
}

/** Converts wall-clock components in a zone to a UTC timestamp. */
export function zonedTimeToUtc({ year, month, day, hour, minute }, timeZone = 'UTC') {
  const zone = formatTimeZone(timeZone);
  const guess = Date.UTC(year, month - 1, day, hour, minute, 0, 0);
  const firstOffset = offsetMs(zone, new Date(guess));
  let stamp = guess - firstOffset;
  const secondOffset = offsetMs(zone, new Date(stamp));
  if (secondOffset !== firstOffset) stamp = guess - secondOffset;
  return stamp;
}

export function addZonedDays({ year, month, day }, amount) {
  const next = new Date(Date.UTC(year, month - 1, day + amount));
  return { year: next.getUTCFullYear(), month: next.getUTCMonth() + 1, day: next.getUTCDate() };
}

export function weekdayOf({ year, month, day }) {
  return new Date(Date.UTC(year, month - 1, day)).getUTCDay();
}
