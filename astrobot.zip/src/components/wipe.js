import { TextInputStyle } from 'discord.js';
import { createWipeProfile, deleteWipeProfile, getWipeProfile, updateWipeProfile } from '../db/repositories/wipes.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { listServers } from '../db/repositories/servers.js';
import {
  executeWipe,
  nextWipeAt,
  parseCountdowns,
  parseMapRotation,
  parseWipeMessages,
  restartDelayFor,
  WIPE_TYPES,
} from '../services/wipe-service.js';
import { runtime } from '../core/runtime.js';
import { ValidationError } from '../core/errors.js';
import { modal, customId } from '../ui/components.js';
import { formatTimeZone, zonedParts, zonedTimeToUtc } from '../utils/timezone.js';

function serverFor(guildId, value) {
  const needle = String(value ?? '').trim().toLowerCase();
  if (!needle) throw new ValidationError('Name the connected server this profile belongs to.');
  const server = listServers(guildId).find(
    (entry) => entry.id.toLowerCase() === needle || entry.label.toLowerCase() === needle,
  );
  if (!server) throw new ValidationError(`No connected server named "${value}". Check /server manage.`);
  return server;
}

function parseWipeDate(value, timeZone) {
  const match = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{1,2}):(\d{2})$/.exec(String(value ?? '').trim());
  if (!match) throw new ValidationError('Use the format YYYY-MM-DD HH:MM, for example 2026-12-01 20:30.');

  const hours = Number(match[4]);
  const minutes = Number(match[5]);
  if (hours > 23 || minutes > 59) throw new ValidationError('That clock time is not valid.');

  const wall = { year: Number(match[1]), month: Number(match[2]), day: Number(match[3]), hour: hours, minute: minutes };
  const zone = formatTimeZone(timeZone);
  const timestamp = zonedTimeToUtc(wall, zone);
  const roundTrip = zonedParts(timestamp, zone);
  if (
    roundTrip.year !== wall.year ||
    roundTrip.month !== wall.month ||
    roundTrip.day !== wall.day ||
    roundTrip.hour !== wall.hour ||
    roundTrip.minute !== wall.minute
  ) {
    throw new ValidationError('That date/time does not exist in this timezone.');
  }
  if (timestamp <= Date.now()) throw new ValidationError('Pick a wipe time in the future.');
  return timestamp;
}

function channelIdFrom(value, guild) {
  const raw = String(value ?? '').trim().replace(/[<#>]/g, '');
  if (!raw) return null;
  if (!/^\d{17,20}$/.test(raw)) throw new ValidationError('Channel must be a channel ID.');
  if (guild && !guild.channels.cache.has(raw)) throw new ValidationError('That channel does not exist in this server.');
  return raw;
}

/** Wipe controller buttons and modals. */
export default {
  id: 'wipe',
  access: 'admin',
  async execute(ctx) {
    const [action, profileId] = ctx.args;

    if (action === 'open') return ctx.panel('wipe');

    if (action === 'select') {
      return ctx.panel('wipe', { selected: ctx.values?.[0] ?? profileId });
    }

    if (action === 'create') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('wipe', 'create'),
            title: 'New wipe profile',
            fields: [
              { id: 'name', label: 'Profile name', placeholder: 'Weekly BP wipe', required: true, maxLength: 60 },
              { id: 'server', label: 'Server label or id', placeholder: 'Main Server', required: true, maxLength: 100 },
              { id: 'type', label: 'Type: bp or full', placeholder: 'bp', required: false, maxLength: 4 },
              { id: 'interval', label: 'Interval in hours', placeholder: '168', required: true, maxLength: 5 },
              { id: 'channel', label: 'Announcement channel ID (optional)', required: false, maxLength: 20 },
            ],
          }),
        );
      }

      const server = serverFor(ctx.guildId, ctx.option('server'));
      const wipeType = String(ctx.option('type') ?? 'bp').trim().toLowerCase();
      if (!(wipeType in WIPE_TYPES)) throw new ValidationError('Wipe type must be bp or full.');

      const intervalHours = Number(ctx.option('interval'));
      if (!Number.isFinite(intervalHours) || intervalHours < 1 || intervalHours > 8760) {
        throw new ValidationError('Interval must be between 1 and 8760 hours.');
      }

      const channelId = channelIdFrom(ctx.option('channel'), ctx.guild);
      const profile = createWipeProfile({
        guildId: ctx.guildId,
        serverId: server.id,
        name: String(ctx.option('name') ?? '').trim().slice(0, 60),
        wipeType,
        intervalHours: Math.trunc(intervalHours),
        nextWipeAt: nextWipeAt(Date.now(), intervalHours),
        channelId,
        countdowns: parseCountdowns('60,30,10'),
      });

      return ctx.panel('wipe', { selected: profile.id, notice: `Created **${profile.name}**.` });
    }

    const profile = profileId && profileId !== 'none' ? getWipeProfile(profileId) : null;
    if (profile && profile.guild_id !== ctx.guildId) throw new ValidationError('That profile belongs to another server.');
    if (!profile) throw new ValidationError('That wipe profile no longer exists.');

    if (action === 'delete') {
      deleteWipeProfile(profile.id);
      return ctx.panel('wipe', { notice: `Deleted **${profile.name}**.` });
    }

    if (action === 'toggle') {
      updateWipeProfile(profile.id, { auto_restart: Number(profile.auto_restart) ? 0 : 1 });
      return ctx.panel('wipe', {
        selected: profile.id,
        notice: Number(profile.auto_restart) ? 'Automatic restart disabled.' : 'Automatic restart enabled.',
      });
    }

    if (action === 'map') {
      if (!ctx.isModal) {
        const current = parseMapRotation(profile.map_rotation)[0];
        return ctx.modal(
          modal({
            id: customId('wipe', 'map', profile.id),
            title: 'Set map rotation',
            fields: [
              { id: 'seed', label: 'Seed (blank clears rotation)', value: current?.seed ? String(current.seed) : '', required: false, maxLength: 12 },
              { id: 'worldsize', label: 'World size', value: current?.worldsize ? String(current.worldsize) : '', required: false, maxLength: 8 },
              { id: 'levelurl', label: 'Custom map URL (optional)', value: current?.levelurl ?? '', required: false, maxLength: 200 },
            ],
          }),
        );
      }

      const seed = Number(ctx.option('seed'));
      const worldsize = Number(ctx.option('worldsize'));
      const levelurl = String(ctx.option('levelurl') ?? '').trim();
      const rotation = seed > 0 || levelurl ? [{ seed: seed || 0, worldsize: worldsize || 0, levelurl: levelurl || null }] : [];

      updateWipeProfile(profile.id, {
        map_rotation: JSON.stringify(rotation),
        rotate_map: rotation.length ? 1 : 0,
        rotation_index: 0,
      });
      return ctx.panel('wipe', {
        selected: profile.id,
        notice: rotation.length ? 'Map rotation saved for the next wipe.' : 'Map rotation cleared.',
      });
    }

    if (action === 'settime') {
      const zone = formatTimeZone(getGuildSettings(ctx.guildId).announcements?.timezone);
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('wipe', 'settime', profile.id),
            title: 'Set wipe date and time',
            fields: [
              {
                id: 'datetime',
                label: `Date/time (${zone})`,
                placeholder: '2026-12-01 20:30',
                required: true,
                maxLength: 16,
              },
            ],
          }),
        );
      }

      const runAt = parseWipeDate(ctx.option('datetime'), zone);
      updateWipeProfile(profile.id, {
        next_wipe_at: runAt,
        announced_stages: '',
        awaiting_online: 0,
        online_after: null,
        online_announced_at: null,
      });
      return ctx.panel('wipe', {
        selected: profile.id,
        notice: `Next wipe set to <t:${Math.floor(runAt / 1000)}:F> in **${zone}**.`,
      });
    }

    if (action === 'messages') {
      if (!ctx.isModal) {
        const messages = parseWipeMessages(profile.wipe_messages);
        return ctx.modal(
          modal({
            id: customId('wipe', 'messages', profile.id),
            title: 'Countdown messages',
            fields: [
              { id: 'first', label: '1st warning', value: messages.first, required: false, style: TextInputStyle.Paragraph, maxLength: 1800 },
              { id: 'second', label: '2nd warning', value: messages.second, required: false, style: TextInputStyle.Paragraph, maxLength: 1800 },
              { id: 'third', label: '3rd warning', value: messages.third, required: false, style: TextInputStyle.Paragraph, maxLength: 1800 },
              { id: 'online', label: 'Back-online announcement', value: messages.online, required: false, style: TextInputStyle.Paragraph, maxLength: 1800 },
              {
                id: 'stages',
                label: 'Countdown minutes',
                value: parseCountdowns(profile.countdowns).join(','),
                placeholder: '60,30,10',
                required: false,
                maxLength: 60,
              },
            ],
          }),
        );
      }

      const messages = parseWipeMessages({
        first: ctx.option('first'),
        second: ctx.option('second'),
        third: ctx.option('third'),
        online: ctx.option('online'),
      });
      updateWipeProfile(profile.id, {
        wipe_messages: JSON.stringify(messages),
        countdowns: parseCountdowns(ctx.option('stages')).join(','),
        announced_stages: '',
      });
      return ctx.panel('wipe', {
        selected: profile.id,
        notice: 'Wipe messages saved. Plain text and simple HTML both work.',
      });
    }

    if (action === 'ingame') {
      const enabled = !Number(profile.announce_in_game);
      updateWipeProfile(profile.id, { announce_in_game: enabled ? 1 : 0 });
      return ctx.panel('wipe', {
        selected: profile.id,
        notice: `In-game ` + (enabled ? '`global.say` warnings enabled.' : 'warnings disabled.'),
      });
    }

    if (action === 'restart') {
      if (!ctx.isModal) {
        const delay = restartDelayFor(profile);
        const command = String(profile.restart_command ?? 'restart').trim().replace(/\s+\d{1,4}$/, '') || 'restart';
        return ctx.modal(
          modal({
            id: customId('wipe', 'restart', profile.id),
            title: 'Restart setup',
            fields: [
              {
                id: 'command',
                label: 'Restart command (without delay)',
                value: command,
                placeholder: 'restart',
                required: true,
                maxLength: 80,
              },
              {
                id: 'delay',
                label: 'Restart delay (seconds)',
                value: String(delay),
                placeholder: '300',
                required: false,
                maxLength: 4,
              },
            ],
          }),
        );
      }

      const command = String(ctx.option('command') ?? '').trim();
      if (!command || command.length > 80) throw new ValidationError('Restart command is required (80 characters max).');
      if (/\s+\d{1,4}$/.test(command)) {
        throw new ValidationError('Put the restart delay in its own field, e.g. command `restart` and delay `300`.');
      }

      const delay = Number(ctx.option('delay') ?? 0);
      if (!Number.isInteger(delay) || delay < 0 || delay > 3600) {
        throw new ValidationError('Restart delay must be a whole number from 0 to 3600 seconds.');
      }

      updateWipeProfile(profile.id, { restart_command: command, restart_delay: delay });
      return ctx.panel('wipe', {
        selected: profile.id,
        notice: `Restart saved: \`${command}\` with a ${delay}s delay.`,
      });
    }

    if (action === 'run') {
      await ctx.deferUpdate();
      const result = await executeWipe(profile, { client: ctx.client, rconManager: runtime.rconManager });
      return ctx.panel('wipe', {
        selected: profile.id,
        notice: [
          `Ran **${profile.name}**.`,
          result.commands.length ? `Sent ${result.commands.length} RCON command(s).` : 'No RCON commands configured.',
          result.awaitingOnline ? 'Waiting for the server to reconnect before posting the back-online announcement.' : null,
          result.errors.length ? `Warnings: ${result.errors.slice(0, 3).join('; ')}` : null,
        ]
          .filter(Boolean)
          .join('\n'),
      });
    }

    return ctx.panel('wipe');
  },
};
