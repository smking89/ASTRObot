import { MessageFlags, TextInputStyle } from 'discord.js';
import { patchGuildSetting } from '../db/repositories/guilds.js';
import { addPlayerStat } from '../db/repositories/players.js';
import { LEADERBOARD_METRICS } from '../services/leaderboard-service.js';
import { PRIZE_PERIODS, normalizePrizeSet, prizesFor, savePrizes } from '../services/leaderboard-prizes.js';
import { buildEmbed } from '../ui/embeds.js';
import { customId, modal } from '../ui/components.js';
import { COLORS } from '../config/constants.js';
import { ValidationError } from '../core/errors.js';

const MAX_PRIZE = 100_000_000;

/** /leaderboard-prizes actions: set, clear, choose the displayed period, record a competition win. */
export default {
  id: 'lbprize',
  access: 'admin',
  async execute(ctx) {
    const [action, periodArg, metricArg] = ctx.args;
    const period = PRIZE_PERIODS.some((entry) => entry.id === periodArg) ? periodArg : 'weekly';
    const metric = LEADERBOARD_METRICS.some((entry) => entry.id === metricArg) ? metricArg : LEADERBOARD_METRICS[0].id;
    const back = (next = {}) => ctx.panel('leaderboard-prizes', { period, metric, ...next });

    if (action === 'period') {
      const value = String(ctx.values?.[0] ?? '');
      return ctx.panel('leaderboard-prizes', { period: PRIZE_PERIODS.some((entry) => entry.id === value) ? value : period, metric });
    }

    if (action === 'metric') {
      const value = String(ctx.values?.[0] ?? '');
      return ctx.panel('leaderboard-prizes', {
        period,
        metric: LEADERBOARD_METRICS.some((entry) => entry.id === value) ? value : metric,
      });
    }

    if (action === 'display') {
      patchGuildSetting(ctx.guildId, 'leaderboardPrizes.displayPeriod', period, { actorId: ctx.userId });
      return back({ notice: `Boards now show the ${period} prizes.` });
    }

    if (action === 'clear') {
      savePrizes(ctx.guildId, { period, metric, amounts: [0, 0, 0], actorId: ctx.userId });
      return back({ notice: 'Prizes cleared for this board.' });
    }

    if (action === 'edit') {
      if (!ctx.isModal) {
        const current = prizesFor(ctx.guildId, period, metric);
        return ctx.modal(
          modal({
            id: customId('lbprize', 'edit', period, metric),
            title: `${period} prizes · ${LEADERBOARD_METRICS.find((entry) => entry.id === metric)?.label ?? metric}`.slice(0, 45),
            fields: [
              { id: 'first', label: '1st place coins', required: true, maxLength: 10, value: String(current[0]) },
              { id: 'second', label: '2nd place coins', required: true, maxLength: 10, value: String(current[1]) },
              { id: 'third', label: '3rd place coins', required: true, maxLength: 10, value: String(current[2]) },
            ],
          }),
        );
      }

      const amounts = ['first', 'second', 'third'].map((key) =>
        Math.max(0, Math.min(MAX_PRIZE, Math.trunc(Number(String(ctx.option(key) ?? '').replaceAll(/[^0-9]/g, '')) || 0))),
      );
      savePrizes(ctx.guildId, { period, metric, amounts, actorId: ctx.userId });
      return back({ notice: `Saved ${amounts.map((amount) => amount.toLocaleString('en-US')).join(' / ')} coins.` });
    }

    if (action === 'compwin') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('lbprize', 'compwin'),
            title: 'Record competition win',
            fields: [
              { id: 'user', label: 'Winner user ID', required: true, maxLength: 25 },
              { id: 'label', label: 'Competition name (optional)', required: false, maxLength: 80, style: TextInputStyle.Short },
            ],
          }),
        );
      }

      const userId = String(ctx.option('user') ?? '').trim();
      if (!/^\d{5,25}$/.test(userId)) throw new ValidationError('That is not a Discord user ID.');
      const wins = addPlayerStat(ctx.guildId, userId, 'competition_wins', 1);
      const label = String(ctx.option('label') ?? '').trim();

      return ctx.reply({
        embeds: [
          buildEmbed({
            description: `🏅 Recorded a competition win for <@${userId}>${label ? ` · **${label}**` : ''}. They now have **${Number(wins.competition_wins ?? 0)}** competition win(s).`,
            color: COLORS.success,
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    return back();
  },
};
