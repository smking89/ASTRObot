import { MessageFlags } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { getLink } from '../db/repositories/links.js';
import { provideKit } from '../services/kit-service.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { formatCoins } from '../utils/format.js';
import { ValidationError } from '../core/errors.js';
import { parseIntStrict } from '../utils/parse.js';

/** /player-panel buttons. */
export default {
  id: 'ppanel',
  access: 'player',
  async execute(ctx) {
    const [action, indexArg] = ctx.args;

    if (action === 'open') return ctx.panel('player-panel');

    if (action === 'select') {
      return ctx.panel('player-panel', { selectedIndex: ctx.values?.[0] });
    }

    if (action === 'claim') {
      const kits = getGuildSettings(ctx.guildId).misc.kits ?? [];
      const index = parseIntStrict(indexArg ?? 0, { min: 0, max: Math.max(0, kits.length - 1), label: 'kit' });
      const kit = kits[index];

      if (!kit) throw new ValidationError('That kit no longer exists.');

      if (kit.roleId) {
        const member = await ctx.guild.members.fetch(ctx.userId).catch(() => null);
        if (!member?.roles.cache.has(kit.roleId)) throw new ValidationError('You do not have the role required for this kit.');
      }

      const link = getLink(ctx.guildId, ctx.userId);
      if (!link) throw new ValidationError('Link your console account with `/link` before claiming kits.');

      const result = await provideKit({
        guildId: ctx.guildId,
        userId: ctx.userId,
        kit,
        gamertag: link.gamertag,
      });

      return ctx.reply({
        embeds: [
          buildEmbed({
            description: result.delivered
              ? `Kit **${kit.name}** delivered${kit.price ? ` for ${formatCoins(kit.price)}` : ''}.`
              : `Kit **${kit.name}** added to your inventory; delivery will run when the server reconnects.`,
            color: COLORS.success,
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    return ctx.panel('player-panel');
  },
};
