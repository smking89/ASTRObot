import { TextInputStyle } from 'discord.js';
import { CARD_BACKS } from '../services/games/cards.js';
import { setPref } from '../db/repositories/prefs.js';
import { modal, customId } from '../ui/components.js';
import { ValidationError } from '../core/errors.js';

/** /card-style panel buttons. */
export default {
  id: 'card',
  access: 'player',
  async execute(ctx) {
    const [action, key] = ctx.args;

    if (action === 'set') {
      if (!(key in CARD_BACKS)) throw new ValidationError('Unknown card back.');
      setPref(ctx.guildId, ctx.userId, 'cardBack', key);
      return ctx.panel('card-style', { notice: `Deck set to **${key}**.` });
    }

    if (action === 'custom') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('card', 'custom'),
            title: 'Custom card back',
            fields: [
              {
                id: 'url',
                label: 'Direct image URL (https)',
                style: TextInputStyle.Short,
                required: true,
                maxLength: 400,
              },
            ],
          }),
        );
      }

      const url = String(ctx.option('url')).trim();
      if (!/^https:\/\/\S+\.(png|jpe?g|webp|gif)(\?\S*)?$/i.test(url)) {
        throw new ValidationError('Provide a direct https image URL ending in .png, .jpg, .webp or .gif.');
      }

      setPref(ctx.guildId, ctx.userId, 'cardBackUrl', url);
      setPref(ctx.guildId, ctx.userId, 'cardBack', 'custom');
      return ctx.panel('card-style', { notice: 'Custom artwork saved.' });
    }

    if (action === 'reset') {
      setPref(ctx.guildId, ctx.userId, 'cardBack', 'classic');
      setPref(ctx.guildId, ctx.userId, 'cardBackUrl', '');
      return ctx.panel('card-style', { notice: 'Deck reset to classic.' });
    }

    return ctx.panel('card-style');
  },
};
