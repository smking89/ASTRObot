import { ValidationError } from '../core/errors.js';

/** Entry point for superadmin-only panel buttons. */
const DEV_PANELS = new Set([
  'dev',
  'license',
  'analytics',
  'status',
  'server',
  'config',
  'templates',
  'announcements',
  'market-admin',
  'wipe',
  'polls',
  'superadmin-hub',
]);

export default {
  id: 'openpanel-dev',
  access: 'player',
  async execute(ctx) {
    if (!ctx.grants?.has?.('developer')) throw new ValidationError('That panel is for the platform operator only.');
    const panelId = String(ctx.args?.[0] ?? '').trim();
    if (!DEV_PANELS.has(panelId)) throw new ValidationError('That panel is not available from this button.');
    return ctx.panel(panelId);
  },
};
