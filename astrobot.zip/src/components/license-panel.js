import { MessageFlags } from 'discord.js';
import { getLicenseByKey, listLicensesFor } from '../db/repositories/licenses.js';
import {
  activateUserLicense,
  licensePlanLabel,
  licenseServerLimit,
  transferUserLicense,
} from '../services/license-service.js';
import { modal, customId } from '../ui/components.js';
import { parseUserId } from '../utils/parse.js';
import { ValidationError } from '../core/errors.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';

/** /license panel buttons. */
export default {
  id: 'lic',
  access: 'player',
  async execute(ctx) {
    const [action] = ctx.args;

    if (action === 'activate') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('lic', 'activate'),
            title: 'Activate a license',
            fields: [{ id: 'key', label: 'License key', placeholder: 'AB-XXXX-XXXX-XXXX', required: true, maxLength: 30 }],
          }),
        );
      }

      const license = activateUserLicense({
        key: String(ctx.option('key')).trim().toUpperCase(),
        userId: ctx.userId,
      });

      return ctx.panel('license', {
        notice: `**${licensePlanLabel(license)}** activated with **${licenseServerLimit(license)} server seat${licenseServerLimit(license) === 1 ? '' : 's'}** on your account. Use \`/plan\` to attach a server.`,
      });
    }

    if (action === 'manage') {
      const licenses = listLicensesFor(ctx.userId);
      return ctx.reply({
        embeds: [
          buildEmbed({
            title: 'Your licenses',
            color: COLORS.brand,
            description: licenses
              .map(
                (license) =>
                  `\`${license.key}\` · ${licensePlanLabel(license)} · ${licenseServerLimit(license)} seat${licenseServerLimit(license) === 1 ? '' : 's'} · ${license.status}` +
                  (license.expires_at ? ` · expires <t:${Math.floor(Number(license.expires_at) / 1000)}:R>` : ' · lifetime'),
              )
              .join('\n'),
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (action === 'transfer') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('lic', 'transfer'),
            title: 'Transfer a license',
            fields: [
              { id: 'key', label: 'License key', required: true, maxLength: 30 },
              { id: 'user', label: 'New owner', placeholder: '@user or ID', required: true },
            ],
          }),
        );
      }

      const key = String(ctx.option('key')).trim().toUpperCase();
      const license = getLicenseByKey(key);
      if (!license) throw new ValidationError('License not found.');
      if (license.owner_id !== ctx.userId) throw new ValidationError('You do not own that license.');
      if (license.status === 'revoked') throw new ValidationError('That license was revoked.');

      const newOwner = parseUserId(ctx.option('user'));
      if (newOwner === ctx.userId) throw new ValidationError('Choose a different Discord account.');
      transferUserLicense({ licenseId: license.id, newOwnerId: newOwner, actorId: ctx.userId });

      return ctx.panel('license', {
        notice: `License transferred to <@${newOwner}>. The plan and seats follow their account.`,
      });
    }

    return ctx.panel('license');
  },
};
