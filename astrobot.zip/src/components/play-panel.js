import { MessageFlags, TextInputStyle } from 'discord.js';
import { GAME_CATALOG, MULTIPLAYER_CATALOG } from '../panels/play.js';
import { modal, customId } from '../ui/components.js';
import { parseIntStrict, parseUserId } from '../utils/parse.js';
import { balances, credit, debit } from '../services/economy-service.js';
import { createSession, getSession } from '../core/registry.js';
import { uniqueId } from '../utils/random.js';
import { ValidationError } from '../core/errors.js';
import { getPref } from '../db/repositories/prefs.js';
import { startRound } from '../services/games/blackjack.js';
import { startUno } from '../services/games/uno.js';
import { startTower } from '../services/games/tower.js';
import { rollDice, DICE_CHOICES } from '../services/games/dice.js';
import { spinSlots } from '../services/games/slots.js';
import { spinWheel } from '../services/games/wheel.js';
import { startMines, MINES_CHOICES } from '../services/games/mines.js';
import { startCrash, getCrashHistory } from '../services/games/crash.js';
import { spinRoulette, parseRouletteBet } from '../services/games/roulette.js';
import { dropPlinko } from '../services/games/plinko.js';
import { openLootbox } from '../services/games/lootbox.js';
import { startDefuse } from '../services/games/defuse.js';
import { startMinefield } from '../services/games/minefield.js';
import { spinRecycler } from '../services/games/recycler.js';
import { fireRange, RANGE_WEAPONS } from '../services/games/range.js';
import { startScratch } from '../services/games/scratch.js';
import {
  blackjackView,
  challengeView,
  crashView,
  diceView,
  minesView,
  plinkoView,
  rouletteView,
  slotsView,
  wheelView,
  towerView,
  unoView,
  lootboxView,
  defuseView,
  minefieldView,
  recyclerView,
  rangeView,
  scratchView,
} from '../ui/game-views.js';
import { buildEmbed } from '../ui/embeds.js';
import { formatCoins } from '../utils/format.js';
import { COLORS } from '../config/constants.js';
import { assertMultiplayerGame, assertSoloGame, getGameConfig, wagerBounds } from '../services/games/game-config.js';
import { createChallenge } from '../services/games/challenge.js';
import { contributeJackpot, maybeAwardJackpot } from '../services/jackpot-service.js';
import { awardGamePrize } from '../services/game-prize-service.js';
import { withGameArt } from '../ui/game-art.js';
import { CORE_MULTIPLAYER_GAMES, CORE_SOLO_GAMES } from '../config/plans.js';
import { assertPlanFeature, guildPlan, planHasFeature } from '../services/plan-service.js';

function assertPlanGame(guildId, gameId, mode) {
  const plan = guildPlan(guildId);
  const allowed =
    mode === 'multiplayer'
      ? plan.features.fullGames || CORE_MULTIPLAYER_GAMES.includes(gameId)
      : plan.features.fullGames || CORE_SOLO_GAMES.includes(gameId);
  if (allowed) return;
  const label = [...GAME_CATALOG, ...MULTIPLAYER_CATALOG].find((entry) => entry.id === gameId)?.label ?? gameId;
  throw new ValidationError(
    `${label} is not included in the ${plan.label} plan. Upgrade from /checkout to unlock the full game suite.`,
  );
}

/** /play panel: opens a wager modal, escrows the stake and starts the game. */
export default {
  id: 'play',
  access: 'player',
  async execute(ctx) {
    let [action, gameId] = ctx.args;
    let serverId = ctx.args?.[2] ?? '';

    if (action === 'select-mode') {
      return ctx.panel('play', { mode: ctx.values?.[0] === 'multiplayer' ? 'multiplayer' : 'solo' });
    }

    if (action === 'select-server') {
      const mode = ctx.args?.[1] === 'multiplayer' ? 'multiplayer' : 'solo';
      return ctx.panel('play', { mode, serverId: ctx.values?.[0] ?? 'none' });
    }

    if (action === 'select-game') {
      const mode = ctx.args?.[1] === 'multiplayer' ? 'multiplayer' : 'solo';
      gameId = ctx.values?.[0];
      serverId = ctx.args?.[2] ?? 'none';
      if (mode === 'solo' && gameId === 'ticket') {
        assertPlanFeature(ctx.guildId, 'jackpot', 'The progressive jackpot and ticket raffle');
        return ctx.panel('jackpot');
      }
      assertPlanGame(ctx.guildId, gameId, mode);
      action = mode === 'multiplayer' ? 'challenge' : 'open';
    }

    if (action === 'reset') return ctx.panel('play');
    if (action === 'run') return ctx.panel('play');
    if (action === 'change-server') {
      return ctx.panel('play', { mode: ctx.args?.[1] === 'multiplayer' ? 'multiplayer' : 'solo' });
    }

    if (action === 'jackpot') {
      assertPlanFeature(ctx.guildId, 'jackpot', 'The progressive jackpot and ticket raffle');
      return ctx.panel('jackpot');
    }

    if (action === 'mode') {
      return ctx.panel('play', { mode: gameId === 'multiplayer' ? 'multiplayer' : 'solo' });
    }

    const config = getGameConfig(ctx.guildId);
    if (action === 'challenge') return handleChallenge(ctx, gameId, config, serverId);

    const game = GAME_CATALOG.find((entry) => entry.id === gameId);
    if (action !== 'open' || !game) return ctx.panel('play');

    assertPlanGame(ctx.guildId, gameId, 'solo');
    assertSoloGame(config, gameId);
    const account = balances(ctx.guildId, ctx.userId);
    const bounds = wagerBounds(config, account.wallet);

    if (!ctx.isModal) {
      const fields = [
        {
          id: 'wager',
          label: `Wager (${bounds.min}-${bounds.max})`,
          placeholder: String(bounds.min),
          required: true,
        },
      ];
      if (gameId === 'dice') {
        fields.push({
          id: 'choice',
          label: 'Bet (low / seven / high)',
          placeholder: 'low',
          required: true,
          maxLength: 8,
        });
      }
      if (gameId === 'mines') {
        fields.push({
          id: 'mines',
          label: 'Mines (3, 5 or 10)',
          placeholder: '3',
          required: false,
          maxLength: 2,
        });
      }
      if (gameId === 'crash') {
        fields.push({
          id: 'auto',
          label: 'Auto cash out (optional)',
          placeholder: '2.5',
          required: false,
          maxLength: 6,
        });
      }
      if (gameId === 'roulette') {
        fields.push({
          id: 'bet',
          label: 'Bet (red, black, 0-36)',
          placeholder: 'red',
          required: true,
          maxLength: 20,
        });
      }
      if (gameId === 'range') {
        fields.push({
          id: 'weapon',
          label: 'Weapon (pistol / smg / rifle / sniper)',
          placeholder: 'rifle',
          required: true,
          maxLength: 8,
        });
      }

      return ctx.modal(
        modal({
          id: customId('play', 'open', gameId, serverId || 'none'),
          title: `${game.label} · wager`,
          fields,
        }),
      );
    }

    // Re-read settings when the modal is submitted: an admin may have changed
    // the limits or disabled the game while the modal was open.
    const current = getGameConfig(ctx.guildId);
    assertPlanGame(ctx.guildId, gameId, 'solo');
    assertSoloGame(current, gameId);
    const jackpotEnabled = planHasFeature(ctx.guildId, 'jackpot');
    const currentAccount = balances(ctx.guildId, ctx.userId);
    const currentBounds = wagerBounds(current, currentAccount.wallet);
    const wager = parseIntStrict(ctx.option('wager'), { min: currentBounds.min, max: currentBounds.max, label: 'wager' });
    if (currentAccount.wallet < wager) throw new ValidationError(`You only have ${formatCoins(currentAccount.wallet)} in your wallet.`);

    const choice = ctx.option('choice')?.toLowerCase() ?? 'low';
    if (gameId === 'dice' && !DICE_CHOICES[choice]) throw new ValidationError('Bet must be `low`, `seven` or `high`.');

    let mines = 3;
    if (gameId === 'mines') {
      const raw = String(ctx.option('mines') ?? '').trim();
      mines = raw ? parseIntStrict(raw, { min: 3, max: 10, label: 'mines' }) : 3;
      if (!MINES_CHOICES.includes(mines)) throw new ValidationError('Mines must be `3`, `5` or `10`.');
    }

    let autoCashout = null;
    if (gameId === 'crash') {
      const raw = String(ctx.option('auto') ?? '').trim();
      if (raw) {
        const value = Number(raw);
        if (!Number.isFinite(value) || value <= 1 || value > 100) {
          throw new ValidationError('Auto cash out must be between `1.01x` and `100x`.');
        }
        autoCashout = Math.round(value * 100) / 100;
      }
    }

    let bet = null;
    if (gameId === 'roulette') {
      bet = String(ctx.option('bet') ?? '').trim();
      try {
        parseRouletteBet(bet);
      } catch (error) {
        throw new ValidationError(error.message);
      }
    }

    let weapon = null;
    if (gameId === 'range') {
      weapon = String(ctx.option('weapon') ?? '').trim().toLowerCase();
      if (!RANGE_WEAPONS[weapon]) throw new ValidationError('Weapon must be `pistol`, `smg`, `rifle` or `sniper`.');
    }

    debit({ guildId: ctx.guildId, userId: ctx.userId, amount: wager, kind: `wager_${gameId}` });

    // Instant games settle immediately; stateful games get a session.
    if (gameId === 'dice') {
      const result = rollDice({ wager, choice });
      if (result.payout > 0) credit({ guildId: ctx.guildId, userId: ctx.userId, amount: result.payout, kind: 'casino_win', respectCap: false });
      result.prize = awardGamePrize({ guildId: ctx.guildId, userId: ctx.userId, game: 'dice', won: result.won });
      return respond(ctx, withGameArt({ ...diceView(result), components: [] }, { guildId: ctx.guildId, gameId: 'dice', outcome: result.won ? 'win' : 'lose' }));
    }

    if (gameId === 'slots') {
      if (jackpotEnabled) contributeJackpot({ guildId: ctx.guildId, wager, game: 'slots', client: ctx.client });
      const result = spinSlots({ wager });
      result.jackpot = jackpotEnabled ? maybeAwardJackpot({ guildId: ctx.guildId, userId: ctx.userId, game: 'slots' }) : null;
      if (result.payout > 0) credit({ guildId: ctx.guildId, userId: ctx.userId, amount: result.payout, kind: 'casino_win', respectCap: false });
      result.prize = awardGamePrize({ guildId: ctx.guildId, userId: ctx.userId, game: 'slots', won: result.won });
      return respond(ctx, withGameArt({ ...slotsView(result), components: [] }, { guildId: ctx.guildId, gameId: 'slots', outcome: result.won ? 'win' : 'lose' }));
    }

    if (gameId === 'wheel') {
      if (jackpotEnabled) contributeJackpot({ guildId: ctx.guildId, wager, game: 'wheel', client: ctx.client });
      const result = spinWheel({ wager });
      result.jackpot = jackpotEnabled ? maybeAwardJackpot({ guildId: ctx.guildId, userId: ctx.userId, game: 'wheel' }) : null;
      if (result.payout > 0) credit({ guildId: ctx.guildId, userId: ctx.userId, amount: result.payout, kind: 'casino_win', respectCap: false });
      result.prize = awardGamePrize({ guildId: ctx.guildId, userId: ctx.userId, game: 'wheel', won: result.won });
      return respond(ctx, withGameArt({ ...wheelView(result), components: [] }, { guildId: ctx.guildId, gameId: 'wheel', outcome: result.multiplier > 1 ? 'win' : 'lose' }));
    }

    if (gameId === 'roulette') {
      const result = spinRoulette({ wager, bet });
      if (result.payout > 0) credit({ guildId: ctx.guildId, userId: ctx.userId, amount: result.payout, kind: 'casino_win', respectCap: false });
      result.prize = awardGamePrize({ guildId: ctx.guildId, userId: ctx.userId, game: 'roulette', won: result.won });
      return respond(ctx, withGameArt(rouletteView(result), { guildId: ctx.guildId, gameId: 'roulette', outcome: result.won ? 'win' : 'lose' }));
    }

    if (gameId === 'plinko') {
      const result = dropPlinko({ wager });
      if (result.payout > 0) credit({ guildId: ctx.guildId, userId: ctx.userId, amount: result.payout, kind: 'casino_win', respectCap: false });
      result.prize = awardGamePrize({ guildId: ctx.guildId, userId: ctx.userId, game: 'plinko', won: result.won });
      return respond(ctx, withGameArt(plinkoView(result), { guildId: ctx.guildId, gameId: 'plinko', outcome: result.won ? 'win' : 'lose' }));
    }

    if (gameId === 'lootbox') {
      const result = openLootbox({ wager });
      if (result.payout > 0) credit({ guildId: ctx.guildId, userId: ctx.userId, amount: result.payout, kind: 'casino_win', respectCap: false });
      result.prize = awardGamePrize({ guildId: ctx.guildId, userId: ctx.userId, game: 'lootbox', won: result.won });
      return respond(ctx, withGameArt(lootboxView(result), { guildId: ctx.guildId, gameId: 'lootbox', outcome: result.payout > 0 ? 'win' : 'lose' }));
    }

    if (gameId === 'recycler') {
      const result = spinRecycler({ wager });
      if (result.payout > 0) credit({ guildId: ctx.guildId, userId: ctx.userId, amount: result.payout, kind: 'casino_win', respectCap: false });
      result.prize = awardGamePrize({ guildId: ctx.guildId, userId: ctx.userId, game: 'recycler', won: result.won });
      return respond(ctx, withGameArt(recyclerView(result), { guildId: ctx.guildId, gameId: 'recycler', outcome: result.won ? 'win' : 'lose' }));
    }

    if (gameId === 'range') {
      const result = fireRange({ wager, weapon });
      if (result.payout > 0) credit({ guildId: ctx.guildId, userId: ctx.userId, amount: result.payout, kind: 'casino_win', respectCap: false });
      result.prize = awardGamePrize({ guildId: ctx.guildId, userId: ctx.userId, game: 'range', won: result.won });
      return respond(ctx, withGameArt(rangeView(result), { guildId: ctx.guildId, gameId: 'range', outcome: result.won ? 'win' : 'lose' }));
    }

    const sessionId = uniqueId('game');

    if (gameId.startsWith('scratch-')) {
      const state = startScratch({ wager, themeId: gameId });
      createSession(sessionId, {
        userId: ctx.userId,
        guildId: ctx.guildId,
        game: gameId,
        state,
        wager,
        settled: false,
      });
      return respond(ctx, withGameArt(scratchView(state, sessionId), { guildId: ctx.guildId, gameId }));
    }

    if (gameId === 'crash') {
      if (jackpotEnabled) contributeJackpot({ guildId: ctx.guildId, wager, game: 'crash', client: ctx.client });
      const state = startCrash({ wager, autoCashout });
      createSession(sessionId, {
        userId: ctx.userId,
        guildId: ctx.guildId,
        game: 'crash',
        state,
        wager,
        settled: false,
        finalized: false,
        message: null,
      });
      const response = await respond(
        ctx,
        withGameArt(crashView(state, sessionId, { history: getCrashHistory(ctx.guildId) }), { guildId: ctx.guildId, gameId: 'crash' }),
      );
      const session = getSession(sessionId);
      if (session) {
        session.message = response?.message ?? response ?? null;
        // The panel is ephemeral, so the timed loop must edit through the
        // interaction webhook token rather than the channel message endpoint.
        session.editResponse = ctx.interaction?.webhook?.editMessage
          ? (payload) => ctx.interaction.webhook.editMessage('@original', payload)
          : null;
      }
      return response;
    }

    if (gameId === 'defuse') {
      const state = startDefuse({ wager });
      createSession(sessionId, {
        userId: ctx.userId,
        guildId: ctx.guildId,
        game: 'defuse',
        state,
        wager,
        settled: false,
      });
      return respond(ctx, withGameArt(defuseView(state, sessionId), { guildId: ctx.guildId, gameId: 'defuse' }));
    }

    if (gameId === 'minefield') {
      const state = startMinefield({ wager });
      createSession(sessionId, {
        userId: ctx.userId,
        guildId: ctx.guildId,
        game: 'minefield',
        state,
        wager,
        settled: false,
      });
      return respond(ctx, withGameArt(minefieldView(state, sessionId), { guildId: ctx.guildId, gameId: 'minefield' }));
    }

    if (gameId === 'mines') {
      const state = startMines({ wager, mines });
      createSession(sessionId, {
        userId: ctx.userId,
        guildId: ctx.guildId,
        game: 'mines',
        state,
        wager,
        settled: false,
      });
      return respond(ctx, withGameArt(minesView(state, sessionId), { guildId: ctx.guildId, gameId: 'mines' }));
    }

    let payload;

    if (gameId === 'blackjack') {
      const state = startRound({ wager, deckStyle: getPref(ctx.guildId, ctx.userId, 'cardBack', 'classic') });
      const natural = state.status === 'ended';
      if (natural && state.payout > 0) {
        credit({ guildId: ctx.guildId, userId: ctx.userId, amount: state.payout, kind: 'casino_win', respectCap: false });
      }
      if (natural && state.payout > state.wager) {
        state.prize = awardGamePrize({ guildId: ctx.guildId, userId: ctx.userId, game: 'blackjack', won: true });
      }
      createSession(sessionId, { userId: ctx.userId, guildId: ctx.guildId, game: 'blackjack', state, wager, settled: natural });
      payload = withGameArt(await blackjackView(state, sessionId), { guildId: ctx.guildId, gameId: 'blackjack' });
    } else if (gameId === 'uno') {
      const state = startUno({ wager });
      createSession(sessionId, { userId: ctx.userId, guildId: ctx.guildId, game: 'uno', state, wager, settled: false });
      payload = await unoView(state, sessionId, { guildId: ctx.guildId, userId: ctx.userId });
    } else if (gameId === 'tower') {
      const state = startTower({ wager });
      createSession(sessionId, { userId: ctx.userId, guildId: ctx.guildId, game: 'tower', state, wager, settled: false });
      payload = withGameArt(towerView(state, sessionId), { guildId: ctx.guildId, gameId: 'tower' });
    }

    return respond(ctx, payload);
  },
};

/** 1v1 challenges are posted publicly so the opponent can accept. */
async function handleChallenge(ctx, gameId, config, serverId = '') {
  const game = MULTIPLAYER_CATALOG.find((entry) => entry.id === gameId);
  if (!game) return ctx.panel('play', { mode: 'multiplayer' });

  assertPlanGame(ctx.guildId, gameId, 'multiplayer');
  assertMultiplayerGame(config, gameId);

  if (!ctx.isModal) {
    return ctx.modal(
      modal({
        id: customId('play', 'challenge', gameId, serverId || 'none'),
        title: `${game.label} · 1v1 challenge`,
        fields: [
          { id: 'opponent', label: 'Opponent @mention', placeholder: '@player', required: true, maxLength: 60 },
          { id: 'wager', label: `Wager (${config.minWager}-${config.maxWager})`, placeholder: String(config.minWager), required: true },
        ],
      }),
    );
  }

  const current = getGameConfig(ctx.guildId);
  assertMultiplayerGame(current, gameId);

  const mention = String(ctx.option('opponent') ?? '').trim();
  if (!/^<@!?\d{15,20}>$/.test(mention)) {
    throw new ValidationError('Mention the opponent with @, for example `@player`.');
  }

  const opponentId = parseUserId(mention);
  if (String(opponentId) === String(ctx.userId)) throw new ValidationError('You cannot challenge yourself.');

  const member = await ctx.guild.members.fetch(opponentId).catch(() => null);
  if (!member) throw new ValidationError('That member is not in this server.');
  if (member.user?.bot) throw new ValidationError('You cannot challenge a bot.');

  const account = balances(ctx.guildId, ctx.userId);
  const bounds = wagerBounds(current, account.wallet);
  const wager = parseIntStrict(ctx.option('wager'), { min: bounds.min, max: bounds.max, label: 'wager' });

  const challenge = createChallenge({
    guildId: ctx.guildId,
    channelId: ctx.channelId,
    challengerId: ctx.userId,
    opponentId,
    wager,
    game: gameId,
  });

  return ctx.reply({
    ...challengeView(challenge),
    allowedMentions: { users: [opponentId] },
  });
}

/** Modal submits cannot call update(); edit the panel message instead. */
function respond(ctx, payload) {
  return ctx.isModal ? ctx.edit(payload) : ctx.update(payload);
}

export { buildEmbed, MessageFlags, TextInputStyle, COLORS };
