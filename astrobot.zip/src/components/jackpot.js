import { ValidationError } from '../core/errors.js';
import { patchGuildSetting } from '../db/repositories/guilds.js';
import { formatCoins } from '../utils/format.js';
import { JACKPOT_PLACE_LABELS, buyJackpotTicket, drawJackpot } from '../services/jackpot-raffle-service.js';
import { planHasFeature } from '../services/plan-service.js';

const ADMIN_ACTIONS = new Set(['channel', 'channel-save', 'draw', 'draw-confirm', 'draw-cancel']);

/** Ticket purchases and the admin-only raffle draw/channel controls. */
export default {
  id: 'jackpot',
  access: 'player',
  async execute(ctx) {
    const [action, tierId] = ctx.args;

    if (!planHasFeature(ctx.guildId, 'jackpot')) {
      throw new ValidationError('The progressive jackpot and ticket raffle are Pro features. This server is on Basic.');
    }

    if (action === 'pick-tier') {
      return ctx.panel('jackpot', { tier: ctx.values?.[0] ?? null });
    }

    if (action === 'buy') {
      const selectedTier = tierId || ctx.values?.[0];
      if (!selectedTier) throw new ValidationError('Choose a ticket tier first.');
      const result = buyJackpotTicket({
        guildId: ctx.guildId,
        userId: ctx.userId,
        tierId: selectedTier,
      });
      return ctx.panel('jackpot', {
        tier: result.tier.id,
        notice: `Bought a **${result.tier.label}** ticket for **${formatCoins(result.tier.cost)}** and added **${result.tier.entries}** raffle entries.`,
      });
    }

    if (ADMIN_ACTIONS.has(action) && !ctx.grants?.has?.('admin')) {
      throw new ValidationError('Only admins can manage the jackpot raffle.');
    }

    if (action === 'channel') return ctx.panel('jackpot', { channelPicker: true });

    if (action === 'channel-save') {
      const channelId = String(ctx.values?.[0] ?? '');
      if (!/^\d{17,20}$/.test(channelId)) throw new ValidationError('Pick a channel from the menu.');
      patchGuildSetting(ctx.guildId, 'games.jackpot.milestoneChannelId', channelId, { actorId: ctx.userId });
      return ctx.panel('jackpot', { notice: `Milestone alerts will post in <#${channelId}>.` });
    }

    if (action === 'draw') return ctx.panel('jackpot', { drawConfirm: true });
    if (action === 'draw-cancel') return ctx.panel('jackpot');

    if (action === 'draw-confirm') {
      const result = drawJackpot({ guildId: ctx.guildId, actorId: ctx.userId });
      const winners = result.winners
        .map((winner) => `${JACKPOT_PLACE_LABELS[winner.place]} <@${winner.userId}> ${formatCoins(winner.amount)}`)
        .join(' · ');
      return ctx.panel('jackpot', {
        notice: `Draw complete. ${winners}${result.remaining > 0 ? ` · ${formatCoins(result.remaining)} rolls into the next pool` : ''}`,
      });
    }

    return ctx.panel('jackpot');
  },
};