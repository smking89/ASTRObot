import { TextInputStyle } from 'discord.js';
import { getGuildSettings, patchGuildSetting } from '../db/repositories/guilds.js';
import { modal, customId } from '../ui/components.js';
import { parseIntStrict } from '../utils/parse.js';
import { ValidationError } from '../core/errors.js';

/** /kit-panel admin buttons. */
export default {
  id: 'kit',
  access: 'restricted',
  async execute(ctx) {
    const [action] = ctx.args;
    const kits = getGuildSettings(ctx.guildId).misc.kits ?? [];

    if (action === 'add') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('kit', 'add'),
            title: 'Register a kit',
            fields: [
              { id: 'name', label: 'Kit name', required: true, maxLength: 40 },
              { id: 'price', label: 'Price in coins (0 = free)', placeholder: '0', required: true },
              {
                id: 'command',
                label: 'RCON command',
                placeholder: 'kit givetoplayer "{kit}" "{user}"',
                required: true,
                maxLength: 200,
              },
              { id: 'role', label: 'Required role ID (optional)', required: false, maxLength: 25 },
            ],
          }),
        );
      }

      const price = parseIntStrict(ctx.option('price'), { min: 0, max: 10_000_000, label: 'price' });
      const kit = {
        name: String(ctx.option('name')).trim(),
        price,
        rconCommand: String(ctx.option('command')).trim(),
        roleId: ctx.option('role') ? String(ctx.option('role')).replaceAll(/\D/g, '') : null,
      };

      const { settings } = patchGuildSetting(ctx.guildId, 'misc.kits', [...kits, kit], { actorId: ctx.userId });
      ctx.guildConfig = settings;
      return ctx.panel('kit-panel', { notice: `Kit **${kit.name}** registered.` });
    }

    if (action === 'remove') {
      if (!ctx.isModal) {
        if (kits.length === 0) throw new ValidationError('There are no kits to remove.');
        return ctx.modal(
          modal({
            id: customId('kit', 'remove'),
            title: 'Remove a kit',
            fields: [{ id: 'index', label: `Kit number (1-${kits.length})`, required: true }],
          }),
        );
      }

      const index = parseIntStrict(ctx.option('index'), { min: 1, max: kits.length, label: 'kit number' }) - 1;
      const removed = kits[index];
      const { settings } = patchGuildSetting(
        ctx.guildId,
        'misc.kits',
        kits.filter((_, position) => position !== index),
        { actorId: ctx.userId },
      );
      ctx.guildConfig = settings;
      return ctx.panel('kit-panel', { notice: `Kit **${removed.name}** removed.` });
    }

    return ctx.panel('kit-panel');
  },
};
