import { MessageFlags, TextInputStyle } from 'discord.js';
import { burn, economyScopeKey, mint } from '../services/economy-service.js';
import { getGuildSettings, patchGuildSetting } from '../db/repositories/guilds.js';
import { economyTotals, topPlayers } from '../db/repositories/players.js';
import { modal, customId } from '../ui/components.js';
import { parseUserId, parseIntStrict } from '../utils/parse.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { formatCoins, formatNumber } from '../utils/format.js';

/** /shop-mint panel buttons. */
export default {
  id: 'mint',
  access: 'admin',
  async execute(ctx) {
    const [action] = ctx.args;

    if (action === 'mint' || action === 'burn') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('mint', action),
            title: action === 'mint' ? 'Mint currency' : 'Burn currency',
            fields: [
              { id: 'user', label: 'Account', placeholder: '@user or ID', required: true },
              { id: 'amount', label: 'Amount', required: true },
              {
                id: 'override',
                label: 'Ignore wallet cap? (yes/no)',
                required: false,
                placeholder: 'no',
                style: TextInputStyle.Short,
              },
            ],
          }),
        );
      }

      const targetId = parseUserId(ctx.option('user'));
      const amount = parseIntStrict(ctx.option('amount'), { min: 1, max: 1_000_000_000, label: 'amount' });
      const respectCap = String(ctx.option('override') ?? 'no').toLowerCase() !== 'yes';

      if (action === 'mint') {
        const result = mint({ guildId: ctx.guildId, userId: targetId, amount, actorId: ctx.userId, respectCap });
        return ctx.reply({
          embeds: [
            buildEmbed({
              description: `Minted ${formatCoins(result.credited)} to <@${targetId}>${result.overflow ? ` · ${formatCoins(result.overflow)} blocked by cap` : ''}.`,
              color: COLORS.success,
            }),
          ],
          flags: MessageFlags.Ephemeral,
        });
      }

      burn({ guildId: ctx.guildId, userId: targetId, amount, actorId: ctx.userId });
      return ctx.reply({
        embeds: [buildEmbed({ description: `Burned ${formatCoins(amount)} from <@${targetId}>.`, color: COLORS.danger })],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (action === 'setcap') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('mint', 'setcap'),
            title: 'Wallet cap',
            fields: [{ id: 'cap', label: 'Wallet cap', required: true }],
          }),
        );
      }

      const cap = parseIntStrict(ctx.option('cap'), { min: 0, max: 1_000_000_000, label: 'cap' });
      const { settings } = patchGuildSetting(ctx.guildId, 'economy.walletCap', cap, { actorId: ctx.userId });
      ctx.guildConfig = settings;
      return ctx.panel('shop-mint', { notice: `Wallet cap set to ${formatCoins(cap)}.` });
    }

    if (action === 'history') {
      const settings = getGuildSettings(ctx.guildId);
      const scopeKey = economyScopeKey(ctx.guildId, settings);
      const totals = economyTotals(ctx.guildId, scopeKey);
      const top = topPlayers(ctx.guildId, 'wallet', 10, scopeKey);

      return ctx.reply({
        embeds: [
          buildEmbed({
            title: 'Circulation',
            color: COLORS.info,
            description: `Supply: ${formatCoins(Number(totals.wallet) + Number(totals.bank))} across ${formatNumber(totals.players)} accounts.`,
            fields: [
              {
                name: 'Top wallets',
                value: top.map((row, index) => `${index + 1}. <@${row.user_id}> · ${formatCoins(row.wallet)}`).join('\n') || 'None',
              },
            ],
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    return ctx.panel('shop-mint');
  },
};
