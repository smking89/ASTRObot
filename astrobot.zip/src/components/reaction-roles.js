import { getGuildSettings } from '../db/repositories/guilds.js';
import { ValidationError } from '../core/errors.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { roleMenuRow } from '../services/onboarding-service.js';

/** Post the persistent reaction/button role menu. */
export default {
  id: 'reaction-roles',
  access: 'restricted',
  async execute(ctx) {
    const settings = getGuildSettings(ctx.guildId);
    const config = settings.onboarding?.reactionRoles;
    if (!config?.enabled) throw new ValidationError('Reaction roles are disabled.');
    const entries = Array.isArray(config.entries) ? config.entries.filter((entry) => entry?.roleId) : [];
    if (entries.length === 0) throw new ValidationError('Add at least one role entry in the config first.');

    const channelId = config.channelId ?? ctx.channelId;
    const channel = await ctx.client?.channels?.fetch?.(channelId).catch(() => null);
    if (!channel?.isTextBased?.()) throw new ValidationError('Configure a text channel for the role menu.');

    const embed = buildEmbed({
      title: '🎭 Choose your roles',
      description: 'Use the menu below to add or remove a role. Your selection updates immediately.',
      color: COLORS.brand,
    });
    await channel.send({
      embeds: [embed],
      components: [roleMenuRow(entries)],
      allowedMentions: { parse: [] },
    });
    return ctx.panel('reaction-roles', { notice: `Role menu posted in <#${channel.id}>.` });
  },
};
