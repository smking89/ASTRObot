import { METRICS } from '../panels/leaderboards.js';

/** Select menu on the leaderboards panel. */
export default {
  id: 'lb',
  access: 'player',
  async execute(ctx) {
    const metric = ctx.values?.[0];
    if (!METRICS.some((entry) => entry.id === metric)) return ctx.panel('leaderboards');
    return ctx.panel('leaderboards', { metric });
  },
};
