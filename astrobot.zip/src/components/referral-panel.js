import { MessageFlags } from 'discord.js';
import { claimReferral, createReferralCode, getReferralForOwner } from '../db/repositories/referrals.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { credit } from '../services/economy-service.js';
import { modal, customId } from '../ui/components.js';
import { parseIntStrict } from '../utils/parse.js';
import { ValidationError } from '../core/errors.js';
import { formatCoins } from '../utils/format.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';

/** /referral panel buttons. */
export default {
  id: 'ref',
  access: 'player',
  async execute(ctx) {
    const [action] = ctx.args;

    if (action === 'leaderboard') return ctx.panel('leaderboards', { metric: 'referrals' });

    if (action === 'create') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('ref', 'create'),
            title: 'Create referral code',
            fields: [
              { id: 'code', label: 'Code (3-16 characters)', required: true, maxLength: 16, minLength: 3 },
              { id: 'uses', label: 'Max redemptions (blank = unlimited)', required: false },
            ],
          }),
        );
      }

      const existing = getReferralForOwner(ctx.guildId, ctx.userId);
      const code = String(ctx.option('code')).trim().toUpperCase().replaceAll(/[^A-Z0-9_-]/g, '');
      if (code.length < 3) throw new ValidationError('Code must be at least 3 characters.');

      const usesRaw = ctx.option('uses');
      const maxUses = usesRaw ? parseIntStrict(usesRaw, { min: 1, max: 10_000, label: 'max uses' }) : null;

      createReferralCode({ guildId: ctx.guildId, ownerId: ctx.userId, code, maxUses });
      return ctx.panel('referral', {
        notice: existing ? `New code **${code}** created (your previous code stays active).` : `Code **${code}** created.`,
      });
    }

    if (action === 'redeem') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('ref', 'redeem'),
            title: 'Redeem a referral code',
            fields: [{ id: 'code', label: 'Referral code', required: true, maxLength: 16 }],
          }),
        );
      }

      const settings = getGuildSettings(ctx.guildId);
      const reward = Number(settings.economy.referralBonus) || 0;
      const result = claimReferral({
        guildId: ctx.guildId,
        code: String(ctx.option('code')).trim().toUpperCase(),
        invitedId: ctx.userId,
        reward,
      });

      const reasons = {
        invalid: 'That code is not valid in this server.',
        self: 'You cannot redeem your own code.',
        exhausted: 'That code has reached its limit.',
        already_claimed: 'You have already redeemed a referral code here.',
      };

      if (!result.ok) throw new ValidationError(reasons[result.reason] ?? 'That code could not be redeemed.');

      credit({ guildId: ctx.guildId, userId: result.referral.owner_id, amount: reward, kind: 'referral_bonus' });
      credit({ guildId: ctx.guildId, userId: ctx.userId, amount: Math.floor(reward / 2), kind: 'referral_signup' });

      return ctx.reply({
        embeds: [
          buildEmbed({
            description: `Code redeemed. <@${result.referral.owner_id}> earned ${formatCoins(reward)} and you received ${formatCoins(Math.floor(reward / 2))}.`,
            color: COLORS.success,
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    return ctx.reply({ content: 'Unknown action.', flags: MessageFlags.Ephemeral });
  },
};
