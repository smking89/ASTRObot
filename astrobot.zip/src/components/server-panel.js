import { MessageFlags } from 'discord.js';
import { addServer, getServer, listServers, removeServer, updateServer } from '../db/repositories/servers.js';
import { listTasks, setTaskEnabled, upsertTask, removeTask } from '../db/repositories/tasks.js';
import { runtime } from '../core/runtime.js';
import { modal, customId } from '../ui/components.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { ValidationError } from '../core/errors.js';
import { formatDuration, truncate } from '../utils/format.js';
import { parseIntStrict } from '../utils/parse.js';
import { assertPlanLimit, countScheduledTasks, countServers } from '../services/plan-service.js';

/** /server panel buttons. */
export default {
  id: 'srv',
  access: 'admin',
  async execute(ctx) {
    const [action, arg] = ctx.args;

    if (action === 'add') {
      assertPlanLimit(ctx.guildId, 'rconServers', countServers(ctx.guildId), 'Rust/RCON servers');
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('srv', 'add'),
            title: 'Connect a Rust server',
            fields: [
              { id: 'label', label: 'Display name', required: true, maxLength: 40 },
              { id: 'host', label: 'Host or IP', required: true, maxLength: 120 },
              { id: 'port', label: 'RCON port', placeholder: '28016', required: true },
              { id: 'password', label: 'RCON password', required: true, maxLength: 120 },
            ],
          }),
        );
      }

      const port = parseIntStrict(ctx.option('port'), { min: 1, max: 65_535, label: 'port' });
      addServer({
        guildId: ctx.guildId,
        label: String(ctx.option('label')).trim(),
        host: String(ctx.option('host')).trim(),
        port,
        password: String(ctx.option('password')),
      });

      runtime.rconManager?.syncServers();
      return ctx.panel('server', { notice: 'Server saved. Connection is being established.' });
    }

    if (action === 'select') {
      const server = getServer(ctx.values?.[0]);
      if (!server) throw new ValidationError('Server not found.');
      return ctx.panel('server', { notice: `Selected **${server.label}**.` });
    }

    if (action === 'test') {
      const connection = runtime.rconManager?.connectionFor(ctx.guildId);

      if (!connection) {
        return ctx.reply({
          embeds: [buildEmbed({ description: 'No RCON connection is currently established for this guild.', color: COLORS.danger })],
          flags: MessageFlags.Ephemeral,
        });
      }

      const started = Date.now();
      // `playerlist` is the one probe the RCON parser understands, so the test
      // button exercises the same path as /link and presence tracking.
      await connection.send('playerlist').catch(() => null);

      return ctx.reply({
        embeds: [
          buildEmbed({
            description: `Connected to **${connection.label}** · handshake ${connection.connected ? 'ok' : 'pending'} · ${Date.now() - started}ms`,
            color: COLORS.success,
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (action === 'tasks') {
      const tasks = listTasks(ctx.guildId);

      return ctx.reply({
        embeds: [
          buildEmbed({
            title: 'Scheduled tasks',
            color: COLORS.info,
            description:
              truncate(
                tasks
                  .map(
                    (task) =>
                      `\`${task.id}\` · **${task.name}** · ${task.kind} · every ${formatDuration(task.interval_seconds * 1000)} · ${task.enabled ? 'on' : 'off'}` +
                      (task.command ? `\n> ${task.command}` : ''),
                  )
                  .join('\n'),
                4000,
              ) || 'No tasks configured. Use `/server manage` to add one.',
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (action === 'task-add') {
      assertPlanLimit(ctx.guildId, 'scheduledTasks', countScheduledTasks(ctx.guildId), 'Scheduled tasks');
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('srv', 'task-add'),
            title: 'Schedule a console command',
            fields: [
              { id: 'name', label: 'Task name', required: true, maxLength: 40 },
              { id: 'command', label: 'Console command', required: true, maxLength: 200 },
              { id: 'interval', label: 'Interval in seconds', placeholder: '3600', required: true },
            ],
          }),
        );
      }

      const interval = parseIntStrict(ctx.option('interval'), { min: 30, max: 604_800, label: 'interval' });
      upsertTask({
        guildId: ctx.guildId,
        name: String(ctx.option('name')).trim(),
        kind: 'command',
        intervalSeconds: interval,
        command: String(ctx.option('command')).trim(),
      });

      return ctx.panel('server', { notice: 'Scheduled task created.' });
    }

    if (action === 'task-toggle') {
      const task = listTasks(ctx.guildId).find((entry) => entry.id === arg);
      if (!task) throw new ValidationError('Task not found.');
      setTaskEnabled(task.id, !task.enabled);
      return ctx.panel('server', { notice: `Task ${task.enabled ? 'disabled' : 'enabled'}.` });
    }

    if (action === 'task-remove') {
      removeTask(arg);
      return ctx.panel('server', { notice: 'Task removed.' });
    }

    if (action === 'remove') {
      if (!removeServer(arg)) throw new ValidationError('Server not found.');
      runtime.rconManager?.syncServers();
      return ctx.panel('server', { notice: 'Server removed.' });
    }

    if (action === 'disable') {
      const server = getServer(arg);
      if (!server) throw new ValidationError('Server not found.');
      updateServer(server.id, { enabled: !server.enabled });
      runtime.rconManager?.syncServers();
      return ctx.panel('server', { notice: `Server ${server.enabled ? 'disabled' : 'enabled'}.` });
    }

    return ctx.panel('server');
  },
};

export { listServers };
