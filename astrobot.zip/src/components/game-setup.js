import { TextInputStyle } from 'discord.js';
import { MAX_WAGER, SOLO_GAME_IDS, MULTIPLAYER_GAME_IDS, PRIZE_POOL_GAME_IDS } from '../services/games/game-config.js';
import { getGuildSettings, patchGuildSetting } from '../db/repositories/guilds.js';
import { DEFAULT_GUILD_SETTINGS } from '../config/defaults.js';
import { modal, customId } from '../ui/components.js';
import { parseIntStrict } from '../utils/parse.js';
import { ValidationError } from '../core/errors.js';

/** Admin-only game setup actions, reached from the /play Game Setup button. */
export default {
  id: 'setup',
  access: 'admin',
  async execute(ctx) {
    const [action, scope, argGameId] = ctx.args;
    const gameId = ctx.values?.[0] ?? argGameId;

    if (action === 'open') return ctx.panel('game-setup');

    if (action === 'quick' || action === 'reset') {
      const games = structuredClone(DEFAULT_GUILD_SETTINGS.games);
      if (action === 'quick') {
        const current = rawGames(ctx);
        games.jackpot = current.jackpot ?? games.jackpot;
      }
      await save(ctx, games);
      return ctx.panel('play');
    }

    if (action === 'toggle') {
      if (!['solo', 'multiplayer'].includes(scope)) return ctx.panel('game-setup');
      const valid = scope === 'solo' ? SOLO_GAME_IDS : MULTIPLAYER_GAME_IDS;
      if (!valid.includes(gameId)) throw new ValidationError('Unknown game.');

      const games = rawGames(ctx);
      const group = games[scope] ?? {};
      games[scope] = { ...group, [gameId]: group[gameId] === false };
      await save(ctx, games);
      return ctx.panel('game-setup');
    }

    if (action === 'all') {
      const enable = scope === 'on';
      const games = rawGames(ctx);
      if (enable) games.enabled = true;
      games.soloEnabled = enable;
      games.multiplayerEnabled = enable;
      games.solo = Object.fromEntries(SOLO_GAME_IDS.map((id) => [id, enable]));
      games.multiplayer = Object.fromEntries(MULTIPLAYER_GAME_IDS.map((id) => [id, enable]));
      await save(ctx, games);
      return ctx.panel('game-setup');
    }

    if (action === 'casino') {
      const games = rawGames(ctx);
      games.enabled = scope === 'open';
      await save(ctx, games);
      return ctx.panel('game-setup');
    }

    if (action === 'limits') {
      const games = rawGames(ctx);
      const min = Number(games.minWager) || 1;
      const max = Number(games.maxWager) || 100_000;
      return ctx.modal(
        modal({
          id: customId('setup', 'save-limits'),
          title: 'Casino wager limits',
          fields: [
            { id: 'min', label: 'Minimum wager', value: min, required: true },
            { id: 'max', label: 'Maximum wager', value: max, required: true },
          ],
        }),
      );
    }

    if (action === 'jackpot') {
      const jackpot = rawGames(ctx).jackpot ?? {};
      return ctx.modal(
        modal({
          id: customId('setup', 'save-jackpot'),
          title: 'Jackpot settings',
          fields: [
            { id: 'seed', label: 'Seed balance', value: Number(jackpot.seed ?? 2_500), required: true },
            { id: 'min', label: 'Minimum payout', value: Number(jackpot.min ?? 2_500), required: true },
            { id: 'rake', label: 'Rake percent (0-25)', value: Number(jackpot.rakePercent ?? 2), required: true },
            {
              id: 'milestone',
              label: 'Milestone threshold (0 off)',
              value: Number(jackpot.milestoneThreshold ?? 10_000),
              required: true,
            },
            {
              id: 'odds',
              label: 'Odds JSON (slots/wheel/crash)',
              value: JSON.stringify(jackpot.odds ?? { slots: 4_000, wheel: 3_000, crash: 2_500 }),
              required: true,
            },
          ],
        }),
      );
    }

    if (action === 'save-jackpot') {
      const seed = parseIntStrict(ctx.option('seed'), { min: 1, max: MAX_WAGER, label: 'jackpot seed' });
      const min = parseIntStrict(ctx.option('min'), { min: 1, max: MAX_WAGER, label: 'jackpot minimum' });
      const rakePercent = parseIntStrict(ctx.option('rake'), { min: 0, max: 25, label: 'jackpot rake' });
      const milestoneThreshold = parseIntStrict(ctx.option('milestone'), {
        min: 0,
        max: MAX_WAGER,
        label: 'jackpot milestone threshold',
      });
      let rawOdds;
      try {
        rawOdds = JSON.parse(String(ctx.option('odds') ?? ''));
      } catch {
        throw new ValidationError('Jackpot odds must be valid JSON.');
      }
      if (!rawOdds || typeof rawOdds !== 'object' || Array.isArray(rawOdds)) {
        throw new ValidationError('Jackpot odds must be a JSON object.');
      }
      const odds = {};
      for (const game of ['slots', 'wheel', 'crash']) {
        odds[game] = parseIntStrict(rawOdds[game], { min: 1, max: 100_000_000, label: `${game} odds` });
      }
      const games = rawGames(ctx);
      games.jackpot = { ...(games.jackpot ?? {}), seed, min, rakePercent, milestoneThreshold, odds };
      await save(ctx, games);
      return ctx.panel('game-setup');
    }

    if (action === 'jackpot-raffle') {
      const raffle = rawGames(ctx).jackpot?.raffle ?? {};
      return ctx.modal(
        modal({
          id: customId('setup', 'save-jackpot-raffle'),
          title: 'Jackpot raffle',
          fields: [
            { id: 'enabled', label: 'Enabled (true/false)', value: String(raffle.enabled ?? true), required: true },
            { id: 'mode', label: 'Prize mode (fixed/pool)', value: String(raffle.prizeMode ?? 'pool'), required: true },
            {
              id: 'prizes',
              label: 'Fixed prizes JSON',
              value: JSON.stringify(raffle.prizes ?? { first: 5_000, second: 2_500, third: 1_000 }),
              required: true,
              style: TextInputStyle.Paragraph,
            },
            {
              id: 'shares',
              label: 'Pool shares JSON',
              value: JSON.stringify(raffle.poolShares ?? { first: 50, second: 30, third: 20 }),
              required: true,
            },
            {
              id: 'tiers',
              label: 'Ticket tiers JSON',
              value: JSON.stringify(
                raffle.tiers ?? [
                  { id: 'bronze', label: 'Bronze', cost: 100, entries: 1 },
                  { id: 'silver', label: 'Silver', cost: 250, entries: 3 },
                  { id: 'gold', label: 'Gold', cost: 500, entries: 7 },
                ],
              ),
              required: true,
              style: TextInputStyle.Paragraph,
            },
          ],
        }),
      );
    }

    if (action === 'save-jackpot-raffle') {
      const enabled = ['true', '1', 'yes', 'on'].includes(String(ctx.option('enabled') ?? '').toLowerCase());
      const prizeMode = String(ctx.option('mode') ?? '').trim().toLowerCase();
      if (!['fixed', 'pool'].includes(prizeMode)) throw new ValidationError('Raffle prize mode must be `fixed` or `pool`.');

      const prizes = parsePrizeMap(ctx.option('prizes'), 'fixed prize');
      const poolShares = parseShareMap(ctx.option('shares'));
      const tiers = parseTicketTiers(ctx.option('tiers'));
      if (prizeMode === 'fixed' && prizes.first + prizes.second + prizes.third <= 0) {
        throw new ValidationError('Set at least one fixed raffle prize.');
      }
      if (prizeMode === 'pool' && poolShares.first + poolShares.second + poolShares.third <= 0) {
        throw new ValidationError('Set at least one raffle pool share.');
      }

      const games = rawGames(ctx);
      games.jackpot = {
        ...(games.jackpot ?? {}),
        raffle: { enabled, prizeMode, prizes, poolShares, tiers },
      };
      await save(ctx, games);
      return ctx.panel('jackpot');
    }

    if (action === 'prize-pools') {
      const pools = getGameConfig(ctx.guildId).prizePools;
      return ctx.modal(
        modal({
          id: customId('setup', 'save-prize-pools'),
          title: 'Game prize pools',
          fields: [
            {
              id: 'pools',
              label: 'Prize pools JSON',
              value: JSON.stringify(pools),
              required: true,
              style: TextInputStyle.Paragraph,
            },
          ],
        }),
      );
    }

    if (action === 'save-prize-pools') {
      const games = rawGames(ctx);
      games.prizePools = parsePrizePools(ctx.option('pools'));
      await save(ctx, games);
      return ctx.panel('game-setup');
    }

    if (action === 'save-limits') {
      const min = parseIntStrict(ctx.option('min'), { min: 1, max: MAX_WAGER, label: 'minimum wager' });
      const max = parseIntStrict(ctx.option('max'), { min, max: MAX_WAGER, label: 'maximum wager' });
      const games = rawGames(ctx);
      games.minWager = min;
      games.maxWager = max;
      await save(ctx, games);
      return ctx.panel('game-setup');
    }

    return ctx.panel('game-setup');
  },
};

function rawGames(ctx) {
  const games = getGuildSettings(ctx.guildId).games ?? {};
  return { ...games, solo: { ...(games.solo ?? {}) }, multiplayer: { ...(games.multiplayer ?? {}) } };
}

function parsePrizePools(raw) {
  const parsed = parseJsonObject(raw, 'Game prize pools');
  const pools = {};

  for (const game of PRIZE_POOL_GAME_IDS) {
    const entry = parsed[game] ?? {};
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) {
      throw new ValidationError(`${game} prize pool must be an object.`);
    }

    const enabled = entry.enabled === true || ['true', '1', 'yes', 'on'].includes(String(entry.enabled ?? '').toLowerCase());
    if (entry.prizes !== undefined && !Array.isArray(entry.prizes)) {
      throw new ValidationError(`${game} prizes must be an array of amounts.`);
    }
    const prizes = (entry.prizes ?? [])
      .slice(0, 20)
      .map((value, index) => parseIntStrict(value, { min: 1, max: MAX_WAGER, label: `${game} prize ${index + 1}` }));

    if (enabled && prizes.length === 0) {
      throw new ValidationError(`Add at least one prize before enabling ${game}.`);
    }
    pools[game] = { enabled: enabled && prizes.length > 0, prizes };
  }

  return pools;
}

async function save(ctx, games) {
  patchGuildSetting(ctx.guildId, 'games', games, { actorId: ctx.userId });
}

function parseJsonObject(raw, label) {
  let parsed;
  try {
    parsed = JSON.parse(String(raw ?? ''));
  } catch {
    throw new ValidationError(`${label} must be valid JSON.`);
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new ValidationError(`${label} must be a JSON object.`);
  }
  return parsed;
}

function parsePrizeMap(raw, label) {
  const parsed = parseJsonObject(raw, 'Raffle prizes');
  return Object.fromEntries(
    ['first', 'second', 'third'].map((place) => [
      place,
      parseIntStrict(parsed[place] ?? 0, { min: 0, max: MAX_WAGER, label: `${place} ${label}` }),
    ]),
  );
}

function parseShareMap(raw) {
  const parsed = parseJsonObject(raw, 'Raffle pool shares');
  return Object.fromEntries(
    ['first', 'second', 'third'].map((place) => [
      place,
      parseIntStrict(parsed[place] ?? 0, { min: 0, max: 100, label: `${place} pool share` }),
    ]),
  );
}

function parseTicketTiers(raw) {
  let parsed;
  try {
    parsed = JSON.parse(String(raw ?? ''));
  } catch {
    throw new ValidationError('Ticket tiers must be valid JSON.');
  }
  if (!Array.isArray(parsed) || parsed.length < 1 || parsed.length > 25) {
    throw new ValidationError('Ticket tiers must be a JSON array with 1-25 entries.');
  }

  const ids = new Set();
  return parsed.map((entry, index) => {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) {
      throw new ValidationError(`Ticket tier ${index + 1} must be an object.`);
    }
    const id = String(entry.id ?? '').trim().toLowerCase();
    if (!/^[a-z0-9-]{1,20}$/.test(id)) throw new ValidationError(`Ticket tier ${index + 1} has an invalid id.`);
    if (ids.has(id)) throw new ValidationError(`Ticket tier id \`${id}\` is duplicated.`);
    ids.add(id);

    const label = String(entry.label ?? '').trim();
    if (!label || label.length > 40) throw new ValidationError(`Ticket tier ${index + 1} needs a label of 1-40 characters.`);
    const cost = parseIntStrict(entry.cost, { min: 1, max: MAX_WAGER, label: `${id} ticket cost` });
    const entries = parseIntStrict(entry.entries, { min: 1, max: 100_000, label: `${id} ticket entries` });
    return { id, label, cost, entries };
  });
}
