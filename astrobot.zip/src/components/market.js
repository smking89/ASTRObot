import { MessageFlags, TextInputStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { getListing } from '../db/repositories/marketplace.js';
import { ValidationError } from '../core/errors.js';
import { modal, customId } from '../ui/components.js';
import { parseIntStrict } from '../utils/parse.js';
import {
  buyListing,
  cancelListing,
  createListing,
  listMarketAssets,
  listMarketplace,
  placeBid,
} from '../services/marketplace-service.js';

const decodeAsset = (value) => {
  try {
    return Buffer.from(String(value), 'base64url').toString('utf8');
  } catch {
    return '';
  }
};

const requireMarket = (guildId) => {
  const settings = getGuildSettings(guildId);
  if (!settings.marketplace?.enabled) throw new ValidationError('The marketplace is closed.');
  return settings;
};

/** Marketplace buttons, modals and selection menus. */
export default {
  id: 'market',
  access: 'player',
  async execute(ctx) {
    const [action, arg] = ctx.args;
    const settings = requireMarket(ctx.guildId);

    if (action === 'select-listing') {
      return ctx.panel('market', { listing: ctx.values?.[0] });
    }
    if (action === 'select-asset') {
      return ctx.panel('market', { asset: ctx.values?.[0] });
    }
    if (action === 'mine') {
      return ctx.panel('market', { mine: true });
    }
    if (action === 'all') {
      return ctx.panel('market');
    }
    if (action === 'refresh') {
      return ctx.panel('market');
    }
    if (action === 'admin') {
      if (!ctx.grants?.has?.('admin') && !ctx.grants?.has?.('restricted')) throw new ValidationError('That analytics panel is for staff only.');
      return ctx.panel('market-admin');
    }

    if (action === 'sell') {
      const assetKey = decodeAsset(arg);
      if (!assetKey) throw new ValidationError('Select an asset first.');
      const member = await ctx.guild.members.fetch(ctx.userId).catch(() => null);
      const asset = listMarketAssets(ctx.guildId, member).find((entry) => entry.key === assetKey);
      if (!asset) throw new ValidationError('That asset is no longer available to sell.');

      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('market', 'sell', arg),
            title: 'Create marketplace listing',
            fields: [
              {
                id: 'price',
                label: 'Price',
                placeholder: '1000',
                required: true,
                maxLength: 12,
              },
              {
                id: 'mode',
                label: 'Mode (buy_now, bid, or sale)',
                value: 'buy_now',
                required: true,
                maxLength: 20,
              },
              {
                id: 'vip_price',
                label: 'VIP price (optional)',
                placeholder: 'Leave blank for the automatic VIP discount',
                required: false,
                maxLength: 12,
              },
              {
                id: 'quantity',
                label: 'Quantity',
                value: '1',
                required: false,
                maxLength: 6,
              },
            ],
          }),
        );
      }

      const price = parseIntStrict(ctx.option('price'), { min: 1, max: 1_000_000_000, label: 'price' });
      const mode = String(ctx.option('mode') ?? 'buy_now').trim().toLowerCase();
      if (!['buy_now', 'bid', 'sale'].includes(mode)) throw new ValidationError('Mode must be buy_now, bid, or sale.');
      const vipRaw = ctx.option('vip_price');
      const vipPrice = vipRaw ? parseIntStrict(vipRaw, { min: 1, max: 1_000_000_000, label: 'VIP price' }) : null;
      const quantity = parseIntStrict(ctx.option('quantity') || 1, { min: 1, max: 999, label: 'quantity' });
      if (asset.kind === 'role' && quantity !== 1) throw new ValidationError('Roles are listed one at a time.');
      if (asset.quantity < quantity) throw new ValidationError('You do not have that many of that item.');

      await createListing({
        guildId: ctx.guildId,
        sellerId: ctx.userId,
        member,
        kind: asset.kind,
        assetKey: asset.key,
        assetLabel: asset.label,
        quantity,
        price,
        vipPrice,
        mode,
      });
      return ctx.panel('market', { notice: `Listed **${asset.label}** for ${price.toLocaleString('en-US')} ${settings.marketplace.currency || settings.economy.currency}.` });
    }

    if (action === 'buy') {
      const listing = getListing(arg);
      if (!listing) throw new ValidationError('That listing no longer exists.');
      const result = await buyListing({
        client: ctx.client,
        guildId: ctx.guildId,
        buyerId: ctx.userId,
        listingId: listing.id,
      });
      return ctx.panel('market', {
        notice: `Bought **${result.listing.asset_label}** for ${result.amount.toLocaleString('en-US')}. Fee paid to treasury: ${result.fee.toLocaleString('en-US')}.`,
      });
    }

    if (action === 'bid') {
      const listing = getListing(arg);
      if (!listing || listing.mode !== 'bid') throw new ValidationError('That auction no longer exists.');
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('market', 'bid', listing.id),
            title: 'Place a bid',
            fields: [
              {
                id: 'amount',
                label: 'Your bid',
                placeholder: String(Math.max(Number(listing.price) || 1, Number(listing.high_bid) || 0) + (Number(settings.marketplace.minBidIncrement) || 1)),
                required: true,
                maxLength: 12,
              },
            ],
          }),
        );
      }
      const amount = parseIntStrict(ctx.option('amount'), { min: 1, max: 1_000_000_000, label: 'bid' });
      placeBid({ guildId: ctx.guildId, userId: ctx.userId, listingId: listing.id, amount });
      return ctx.panel('market', { listing: listing.id, notice: `Your bid of ${amount.toLocaleString('en-US')} is now the highest.` });
    }

    if (action === 'cancel') {
      const listing = getListing(arg);
      if (!listing) throw new ValidationError('That listing no longer exists.');
      cancelListing({ guildId: ctx.guildId, userId: ctx.userId, listingId: listing.id });
      return ctx.panel('market', { notice: 'Listing cancelled.' });
    }

    const listings = listMarketplace(ctx.guildId);
    return ctx.reply({
      content: `There are ${listings.length} active listings.`,
      flags: MessageFlags.Ephemeral,
    });
  },
};
