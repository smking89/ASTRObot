import { MessageFlags, TextInputStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { getGiveaway, finishGiveaway, listGiveawayEntries, createGiveaway, giveawayTicketWeights } from '../db/repositories/onboarding.js';
import { enterGiveaway, giveawayButton, giveawayPayload } from '../services/onboarding-service.js';
import { ValidationError } from '../core/errors.js';
import { modal, customId } from '../ui/components.js';
import { parseIntStrict } from '../utils/parse.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { weightedDraw } from '../utils/random.js';
import { runtime } from '../core/runtime.js';
import { announceGiveawayWinners } from '../services/giveaway-service.js';
import { assertPlanLimit, countActiveGiveaways } from '../services/plan-service.js';

/** Giveaway creation, entry and early end controls. */
export default {
  id: 'giveaway',
  access: 'player',
  async execute(ctx) {
    const [action, id] = ctx.args;
    const settings = getGuildSettings(ctx.guildId);
    const config = settings.onboarding?.giveaways;

    if (action === 'create') {
      if (!ctx.grants?.has?.('restricted')) throw new ValidationError('Only staff can create giveaways.');
      if (!config?.enabled) throw new ValidationError('Giveaways are disabled.');
      assertPlanLimit(ctx.guildId, 'activeGiveaways', countActiveGiveaways(ctx.guildId), 'Active Discord giveaways');
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('giveaway', 'create'),
            title: 'Create a giveaway',
            fields: [
              { id: 'prize', label: 'Prize', required: true, maxLength: 200 },
              {
                id: 'winners',
                label: 'Winner count',
                value: String(config.defaultWinners ?? 1),
                required: false,
                maxLength: 3,
              },
              {
                id: 'hours',
                label: 'Duration (hours)',
                value: String(config.defaultHours ?? 24),
                required: false,
                maxLength: 4,
              },
            ],
          }),
        );
      }

      const prize = String(ctx.option('prize') ?? '').trim();
      if (!prize) throw new ValidationError('Prize is required.');
      const winners = parseIntStrict(ctx.option('winners') || config.defaultWinners || 1, { min: 1, max: 25, label: 'winners' });
      const hours = parseIntStrict(ctx.option('hours') || config.defaultHours || 24, { min: 1, max: 720, label: 'hours' });
      const channelId = config.channelId ?? ctx.channelId;
      const channel = await ctx.client?.channels?.fetch?.(channelId).catch(() => null);
      if (!channel?.isTextBased?.()) throw new ValidationError('Configure a giveaway channel first.');

      const giveaway = createGiveaway({
        guildId: ctx.guildId,
        channelId: channel.id,
        hostId: ctx.userId,
        prize,
        winners,
        endsAt: Date.now() + hours * 3_600_000,
      });
      const message = await channel.send({
        embeds: [giveawayPayload(giveaway, 0)],
        components: [giveawayButton(giveaway.id)],
        allowedMentions: { parse: [] },
      });
      if (message) {
        const { setGiveawayMessage } = await import('../db/repositories/onboarding.js');
        setGiveawayMessage(giveaway.id, message.id);
      }
      return ctx.panel('giveaways', { notice: `Giveaway for **${prize}** started in <#${channel.id}>.` });
    }

    if (action === 'end') {
      if (!ctx.grants?.has?.('restricted')) throw new ValidationError('Only staff can end giveaways.');
      const giveaway = getGiveaway(id);
      if (!giveaway || giveaway.guild_id !== ctx.guildId) throw new ValidationError('That giveaway no longer exists.');
      if (giveaway.status !== 'active') throw new ValidationError('That giveaway has already ended.');

      const weights = giveawayTicketWeights(giveaway.id);
      const winners = weightedDraw(
        weights.map((entry) => ({ id: entry.userId, weight: entry.weight })),
        Math.min(Math.max(1, Number(giveaway.winners) || 1), Math.max(1, weights.length)),
      );
      const finished = finishGiveaway(giveaway.id, 'ended', winners);
      const delivered = await announceGiveawayWinners({
        client: ctx.client,
        rconManager: runtime.rconManager,
        giveaway: finished ?? giveaway,
        winners,
      });
      const where = [delivered.discord ? 'the configured winner channel' : null, delivered.game ? 'the game' : null]
        .filter(Boolean)
        .join(' and ');
      return ctx.panel('giveaways', {
        notice: winners.length
          ? `Giveaway ended. Winners: ${winners.map((userId) => `<@${userId}>`).join(', ')}${
              where ? ` · announced in ${where}` : ''
            }`
          : 'Giveaway ended with no entries.',
      });
    }

    if (action === 'enter') {
      const giveaway = getGiveaway(id);
      if (!giveaway || giveaway.guild_id !== ctx.guildId) throw new ValidationError('That giveaway no longer exists.');
      if (giveaway.status !== 'active' || Number(giveaway.ends_at) <= Date.now()) throw new ValidationError('That giveaway is closed.');
      const result = await enterGiveaway(giveaway.id, ctx.guildId, ctx.userId);
      return ctx.reply({
        embeds: [
          buildEmbed({
            title: result.entered ? '🎉 You are in!' : 'Already entered',
            description: result.entered
              ? `Your entry for **${giveaway.prize}** is recorded. Good luck!`
              : `You already entered **${giveaway.prize}**.`,
            color: result.entered ? COLORS.success : COLORS.warning,
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (action === 'refresh') return ctx.panel('giveaways');
    return null;
  },
};
