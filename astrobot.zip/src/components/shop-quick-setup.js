import { getGuildSettings } from '../db/repositories/guilds.js';
import { ValidationError } from '../core/errors.js';
import {
  QUICK_TIERS,
  applyQuickSetup,
  configuredCurrencies,
  priceMultipliers,
  quickSetupState,
  resetQuickSetup,
  updateQuickSetup,
} from '../services/shop-quick-setup.js';

/** Quick setup panel controls. */
export default {
  id: 'shopqs',
  access: 'restricted',
  async execute(ctx) {
    const [action] = ctx.args;
    const settings = getGuildSettings(ctx.guildId);
    const state = quickSetupState(ctx.guildId, ctx.userId);

    if (action === 'tier') {
      const tier = String(ctx.values?.[0] ?? '');
      if (!(tier in QUICK_TIERS)) throw new ValidationError('Pick Cheap, Mid or Expensive.');
      updateQuickSetup(ctx.guildId, ctx.userId, { tier });
      return ctx.panel('shop-quick-setup');
    }

    if (action === 'currency') {
      const currency = String(ctx.values?.[0] ?? '').trim();
      if (!configuredCurrencies(settings).includes(currency)) {
        throw new ValidationError('That currency is not configured for this server.');
      }
      updateQuickSetup(ctx.guildId, ctx.userId, { currency });
      return ctx.panel('shop-quick-setup');
    }

    if (action === 'role') {
      updateQuickSetup(ctx.guildId, ctx.userId, { roleId: ctx.values?.[0] ?? null });
      return ctx.panel('shop-quick-setup');
    }

    if (action === 'clearrole') {
      updateQuickSetup(ctx.guildId, ctx.userId, { roleId: null });
      return ctx.panel('shop-quick-setup');
    }

    if (action === 'tier3') {
      updateQuickSetup(ctx.guildId, ctx.userId, { tier3: !state.tier3 });
      return ctx.panel('shop-quick-setup');
    }

    if (action === 'explosives') {
      updateQuickSetup(ctx.guildId, ctx.userId, { explosives: !state.explosives });
      return ctx.panel('shop-quick-setup');
    }

    if (action === 'create') {
      const tier = QUICK_TIERS[state.tier] ?? QUICK_TIERS.mid;
      const multipliers = priceMultipliers(settings);
      const result = applyQuickSetup({ guildId: ctx.guildId, state, actorId: ctx.userId, multipliers });

      if (result.added === 0) throw new ValidationError('Those products are already in the shop.');

      resetQuickSetup(ctx.guildId, ctx.userId);
      ctx.guildConfig = result.settings;

      return ctx.panel('shop-admin', {
        notice: `Quick setup added **${result.added}** products${result.skipped > 0 ? ` (${result.skipped} already listed)` : ''} at **${tier.label}** ×${multipliers[state.tier] ?? 1}, charged in **${state.currency}**${state.roleId ? `, buyers needing <@&${state.roleId}>` : ''}.`,
      });
    }

    return ctx.panel('shop-quick-setup');
  },
};
