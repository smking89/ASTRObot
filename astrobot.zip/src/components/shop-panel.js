import { MessageFlags } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { balances, credit, debit } from '../services/economy-service.js';
import { addItem } from '../db/repositories/inventory.js';
import { deliverItemProduct, itemProductTarget } from '../services/shop-delivery.js';
import { adjustStock, applyRestock, isSoldOut } from '../services/shop-stock.js';
import { countPurchasesSince, recordPurchase } from '../db/repositories/shop.js';
import { maybeAlertLowStock } from '../services/shop-alerts.js';
import { createLogger } from '../core/logger.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { formatCoins } from '../utils/format.js';
import { ValidationError } from '../core/errors.js';
import { modal, customId } from '../ui/components.js';

const log = createLogger('shop');

/** /shop panel buttons. */
export default {
  id: 'shop',
  access: 'player',
  async execute(ctx) {
    const [action, productId, categoryArg] = ctx.args;
    const settings = getGuildSettings(ctx.guildId);
    const products = applyRestock(ctx.guildId, settings.shop.products ?? []);

    if (action === 'cat') {
      return ctx.panel('shop', { category: ctx.values?.[0] });
    }

    if (action === 'search') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('shop', 'search'),
            title: 'Search the shop catalog',
            fields: [
              {
                id: 'query',
                label: 'Item name, shortname or category',
                placeholder: 'assault rifle, rifle.ak, explosives…',
                required: true,
                maxLength: 100,
              },
            ],
          }),
        );
      }

      const query = String(ctx.option('query') ?? '').trim();
      if (query.length < 2) throw new ValidationError('Type at least two characters to search the catalog.');
      return ctx.panel('shop', { query });
    }

    if (action === 'select') {
      return ctx.panel('shop', { selected: ctx.values?.[0], category: categoryArg || undefined });
    }

    if (action === 'buy') {
      if (!settings.shop.enabled) throw new ValidationError('The shop is currently disabled.');

      const product = products.find((entry) => String(entry.id) === String(productId));
      if (!product) throw new ValidationError('That product is no longer available.');
      if (isSoldOut(product)) throw new ValidationError('That product is sold out. Check back after a restock.');

      if (product.requiredRoleId) {
        const member = await ctx.guild.members.fetch(ctx.userId).catch(() => null);
        if (!member?.roles?.cache?.has?.(product.requiredRoleId)) {
          throw new ValidationError(`That product requires the <@&${product.requiredRoleId}> role.`);
        }
      }

      if (product.limitPerMember) {
        const windowHours = Math.max(1, Number(product.limitWindowHours) || 24);
        const used = countPurchasesSince(ctx.guildId, ctx.userId, product.id, Date.now() - windowHours * 3_600_000);
        if (used >= Number(product.limitPerMember)) {
          throw new ValidationError(
            `Purchase limit reached for **${product.name}** — ${product.limitPerMember} per ${windowHours}h. Try again later or ask an admin for a restock.`,
          );
        }
      }

      const price = Math.max(0, Number(product.price) || 0);
      const isItem = Boolean(product.shortname);

      // A gamertag link and a live server are checked before the charge, so a
      // buyer is never billed for an item that cannot be delivered.
      if (isItem) itemProductTarget(ctx.guildId, ctx.userId);

      const account = balances(ctx.guildId, ctx.userId);
      if (account.wallet < price) throw new ValidationError(`You need ${formatCoins(price - account.wallet)} more.`);

      if (price > 0) debit({ guildId: ctx.guildId, userId: ctx.userId, amount: price, kind: 'shop_purchase' });

      const delivered = [];

      if (isItem) {
        try {
          const result = await deliverItemProduct({ guildId: ctx.guildId, userId: ctx.userId, product });
          delivered.push(`**x${result.quantity} ${product.name}** to \`${result.gamertag}\` in game`);
        } catch (error) {
          if (price > 0) {
            credit({ guildId: ctx.guildId, userId: ctx.userId, amount: price, kind: 'shop_refund', respectCap: false });
          }
          log.warn(`Item delivery failed for ${ctx.userId}; refunded ${price}`, error);
          throw new ValidationError('The server rejected the delivery, so your purchase was refunded. Try again in a moment.');
        }
      }

      if (product.coins) {
        credit({ guildId: ctx.guildId, userId: ctx.userId, amount: Number(product.coins), kind: 'shop_coins', respectCap: false });
        delivered.push(formatCoins(product.coins));
      }

      if (product.kit) {
        addItem({ guildId: ctx.guildId, userId: ctx.userId, itemKey: `kit:${product.kit}`, quantity: 1, metadata: { productId: product.id } });
        delivered.push(`kit \`${product.kit}\``);
      }

      if (product.roleId) {
        const member = await ctx.guild.members.fetch(ctx.userId).catch(() => null);
        if (member) await member.roles.add(product.roleId, `Shop purchase: ${product.name}`).catch(() => null);
        delivered.push(`role <@&${product.roleId}>`);
      }

      if (delivered.length === 0) delivered.push('order recorded (no auto-delivery configured)');

      // Stock only comes off after delivery succeeds, so a failed item delivery
      // never consumes a unit.
      const remaining = adjustStock(ctx.guildId, product.id, -1);
      await maybeAlertLowStock({ client: ctx.client, guildId: ctx.guildId, product, stock: remaining });
      recordPurchase({
        guildId: ctx.guildId,
        userId: ctx.userId,
        productId: product.id,
        quantity: product.quantity ?? 1,
        price,
      });

      return ctx.reply({
        embeds: [
          buildEmbed({
            title: 'Purchase complete',
            description: `Bought **${product.name}** for ${formatCoins(price)}.\nDelivered: ${delivered.join(', ')}.`,
            color: COLORS.success,
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    return ctx.panel('shop');
  },
};
