import { AttachmentBuilder, MessageFlags } from 'discord.js';
import { mkdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { getDb } from '../db/index.js';

/** Owner hub actions that need a real file instead of a settings edit. */
export default {
  id: 'ownertools',
  access: 'admin',
  async execute(ctx) {
    const [action] = ctx.args;

    if (action === 'db-backup') {
      const dir = join('data', 'backups');
      mkdirSync(dir, { recursive: true });
      const name = `astrobot-manual-${new Date().toISOString().replace(/[:.]/g, '-')}.db`;
      const target = join(dir, name);

      // VACUUM INTO writes a consistent copy without stopping the bot.
      getDb().exec(`VACUUM INTO '${target.replaceAll("'", "''")}'`);
      const bytes = statSync(target).size;
      const size = bytes >= 1_048_576 ? `${(bytes / 1_048_576).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`;

      return ctx.reply({
        content: `💾 Database backup saved as \`${name}\` (${size}). The file stays in \`data/backups\` on the host.`,
        files: [new AttachmentBuilder(target, { name })],
        flags: MessageFlags.Ephemeral,
      });
    }

    return null;
  },
};
