import { MessageFlags } from 'discord.js';
import { wipeGuildStructure } from '../services/template-service.js';
import { captureStructure, loadSnapshot, restoreStructure, saveSnapshot } from '../services/guild-snapshot.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { ValidationError } from '../core/errors.js';
import { button, customId, row } from '../ui/components.js';
import { truncate } from '../utils/format.js';

function assertOwner(ctx) {
  if (String(ctx.guild?.ownerId) !== String(ctx.userId)) {
    throw new ValidationError('Only the server owner can nuke this server.');
  }
}

/** Confirm and restore buttons for /nuke. Both re-check the guild owner. */
export default {
  id: 'nuke',
  access: 'admin',
  async execute(ctx) {
    const [action, backupArg] = ctx.args;
    assertOwner(ctx);

    if (action === 'restore') {
      const { id, snapshot } = loadSnapshot(ctx.guildId, backupArg || 'latest');

      await ctx.reply({
        embeds: [
          buildEmbed({
            title: '↩️ Restoring backup',
            color: COLORS.info,
            description: `Rebuilding **${snapshot.roles?.length ?? 0}** roles, **${snapshot.categories?.length ?? 0}** categories and **${snapshot.channels?.length ?? 0}** channels from \`${id}\`.`,
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });

      const result = await restoreStructure(ctx.guild, snapshot, { reason: `Backup restore by ${ctx.userId}` });
      await ctx
        .edit({
          embeds: [
            buildEmbed({
              title: '✅ Backup restored',
              color: COLORS.success,
              description: [
                `Created **${result.rolesCreated}** roles (${result.rolesReused} already existed), **${result.categoriesCreated}** categories and **${result.channelsCreated}** channels.`,
                result.errors.length ? `⚠️ ${result.errors.length} failed:\n${truncate(result.errors.slice(0, 5).join('\n'), 900)}` : '',
              ]
                .filter(Boolean)
                .join('\n'),
            }),
          ],
        })
        .catch(() => null);
      return;
    }

    // Snapshot first: a wipe without a readable backup is refused.
    let backupId;
    try {
      backupId = saveSnapshot(ctx.guildId, await captureStructure(ctx.guild));
    } catch (error) {
      throw new ValidationError(`Backup failed, so nothing was deleted: ${error.message}`);
    }

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: '☢️ Nuking…',
          color: COLORS.danger,
          description: `Saved backup \`${backupId}\`, now deleting every channel, category and role.`,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });

    const result = await wipeGuildStructure(ctx.guild, { reason: `Nuke by ${ctx.userId}` });

    const lines = [
      `Deleted **${result.channelsDeleted}** channel${result.channelsDeleted === 1 ? '' : 's'} and **${result.rolesDeleted}** role${result.rolesDeleted === 1 ? '' : 's'}.`,
      `Backup \`${backupId}\` saved. Make a text channel, then run \`/nuke restore:${backupId}\` to rebuild everything.`,
      result.skipped > 0 ? `${result.skipped} role(s) above the bot could not be removed.` : '',
      '@everyone, bot and integration roles are always kept.',
      result.errors?.length ? `⚠️ ${result.errors.length} item(s) failed:\n${truncate(result.errors.slice(0, 5).map((error) => `· ${error}`).join('\n'), 900)}` : '',
    ].filter(Boolean);

    await ctx
      .edit({
        embeds: [
          buildEmbed({
            title: '☢️ Server wiped',
            color: COLORS.success,
            description: lines.join('\n'),
          }),
        ],
        components: [row(button({ id: customId('nuke', 'restore', backupId), label: 'Restore this backup', emoji: '↩️' }))],
      })
      .catch(() => null);
  },
};
