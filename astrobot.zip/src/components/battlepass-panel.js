import { getGuildSettings } from '../db/repositories/guilds.js';
import { ensureProgress, recordClaim, setPremium } from '../db/repositories/battlepass.js';
import { balances, credit, debit } from '../services/economy-service.js';
import { formatCoins } from '../utils/format.js';
import { ValidationError } from '../core/errors.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { MessageFlags } from 'discord.js';

/** /battle-pass panel buttons. */
export default {
  id: 'bp',
  access: 'player',
  async execute(ctx) {
    const [action] = ctx.args;
    const settings = getGuildSettings(ctx.guildId);

    if (action === 'open') return ctx.panel('battle-pass');

    // Premium is sold for real money. The button opens the owner's checkout page
    // (or explains the Tip4Serv product); the signed webhook grants the track.
    if (action === 'premium') {
      const progress = ensureProgress(ctx.guildId, ctx.userId);
      if (progress.premium) throw new ValidationError('Premium is already active.');

      const premium = settings.battlePass.premium ?? {};
      const checkoutUrl = String(premium.checkoutUrl ?? '').trim();
      const productId = String(premium.tip4servProductId ?? '').trim();

      if (!checkoutUrl && !productId) {
        throw new ValidationError(
          'Premium purchases are not configured yet. Staff can set a checkout URL or Tip4Serv product in /config → Battle Pass.',
        );
      }

      const description = [
        checkoutUrl
          ? `Buy the premium pass on the server store: ${checkoutUrl}`
          : `Premium is sold as Tip4Serv product \`${productId}\`.`,
        `Enter your Discord ID \`${ctx.userId}\` at checkout so delivery reaches this account.`,
        'Premium unlocks automatically after the payment is confirmed.',
      ].join('\n\n');

      return ctx.reply({
        embeds: [buildEmbed({ title: '⭐ Premium Battle Pass', description, color: COLORS.gold })],
        flags: MessageFlags.Ephemeral,
      });
    }

    // Opt-in legacy coin purchase, disabled unless the owner turns it on.
    if (action === 'premium-coins') {
      const progress = ensureProgress(ctx.guildId, ctx.userId);
      if (progress.premium) throw new ValidationError('Premium is already active.');

      const premium = settings.battlePass.premium ?? {};
      const price = Number(premium.coinPrice) || 0;
      if (!premium.enableCoinPurchase || price <= 0) {
        throw new ValidationError('Premium is sold for real money on this server.');
      }

      debit({ guildId: ctx.guildId, userId: ctx.userId, amount: price, kind: 'battlepass_premium' });
      setPremium(ctx.guildId, ctx.userId, true);

      return ctx.panel('battle-pass', { notice: `Premium unlocked for ${formatCoins(price)}.` });
    }

    if (action === 'claim') {
      const progress = ensureProgress(ctx.guildId, ctx.userId);
      const claimed = new Set(JSON.parse(progress.claimed || '[]'));
      const tier = Number(progress.tier);

      if (tier <= claimed.size) {
        return ctx.reply({
          embeds: [buildEmbed({ description: 'No unlocked tiers are waiting to be claimed.', color: COLORS.warning })],
          flags: MessageFlags.Ephemeral,
        });
      }

      const rewards = settings.battlePass.rewards ?? [];
      let coins = 0;
      let tiersClaimed = 0;

      for (let value = 1; value <= tier; value += 1) {
        if (claimed.has(value)) continue;
        const reward = rewards.find((entry) => Number(entry.tier) === value);
        coins += Number(reward?.coins ?? 100);
        recordClaim(ctx.guildId, ctx.userId, value);
        tiersClaimed += 1;
      }

      if (coins > 0) credit({ guildId: ctx.guildId, userId: ctx.userId, amount: coins, kind: 'battlepass_claim', respectCap: false });

      return ctx.panel('battle-pass', { notice: `Claimed ${tiersClaimed} tier(s) for ${formatCoins(coins)}.` });
    }

    return ctx.panel('battle-pass');
  },
};

export { balances };
