import { MessageFlags } from 'discord.js';
import { getSession, createSession } from '../core/registry.js';
import { hit, stand, double, startRound } from '../services/games/blackjack.js';
import { drawForPlayer, playCard, playableIndexes, startUno, UNO_COLORS } from '../services/games/uno.js';
import { cashOut, climb, startTower } from '../services/games/tower.js';
import { startMines, revealMine, cashOutMines } from '../services/games/mines.js';
import { startDefuse, cutWire, cashOutDefuse } from '../services/games/defuse.js';
import { startMinefield, revealMinefield, cashOutMinefield } from '../services/games/minefield.js';
import { startScratch, scratchCell } from '../services/games/scratch.js';
import { startCrash, cashOutCrash, getCrashHistory } from '../services/games/crash.js';
import { acceptChallenge, getChallenge, declineChallenge, settleChallenge } from '../services/games/challenge.js';
import { credit, debit, balances } from '../services/economy-service.js';
import { blackjackView, crashView, defuseView, minefieldView, minesView, scratchView, towerView, unoView, challengeView } from '../ui/game-views.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { formatCoins } from '../utils/format.js';
import { ValidationError } from '../core/errors.js';
import { getPref } from '../db/repositories/prefs.js';
import { applyArcadeInsurance } from '../services/voucher-service.js';
import { rollDie } from '../utils/random.js';
import { uniqueId } from '../utils/random.js';
import { settleCrashSession } from '../services/crash-settlement.js';
import { contributeJackpot } from '../services/jackpot-service.js';
import { awardGamePrize } from '../services/game-prize-service.js';
import { withGameArt } from '../ui/game-art.js';

/** Stateful game buttons. Every action re-checks session ownership. */
export default {
  id: 'game',
  access: 'player',
  async execute(ctx) {
    const [game, action, sessionId] = ctx.args;

    if (game === 'duel') return handleDuel(ctx, action, sessionId);

    const session = getSession(sessionId);
    if (!session) {
      return ctx.reply({
        embeds: [buildEmbed({ description: 'This game session expired. Start a new one with `/play`.', color: COLORS.warning })],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (session.userId !== ctx.userId) {
      return ctx.reply({ embeds: [buildEmbed({ description: 'That game belongs to someone else.', color: COLORS.danger })], flags: MessageFlags.Ephemeral });
    }

    if (session.game.startsWith('scratch-')) {
      if (action === 'again') return restart(ctx, session, session.game);

      if (String(action ?? '').startsWith('scratch')) {
        scratchCell(session.state, Number(String(action).slice(7)));
      }

      settle(session);
      return ctx.update(
        withGameArt(scratchView(session.state, sessionId), {
          guildId: ctx.guildId,
          gameId: session.game,
          outcome: session.state.status === 'playing' ? 'cover' : session.state.won ? 'win' : 'lose',
        }),
      );
    }

    if (session.game === 'blackjack') {
      if (action === 'again') return restart(ctx, session, 'blackjack');
      if (session.state.status !== 'player') {
        return ctx.update(withGameArt(await blackjackView(session.state, sessionId), { guildId: ctx.guildId, gameId: 'blackjack', outcome: session.state.payout > session.state.wager ? 'win' : 'lose' }));
      }

      if (action === 'hit') hit(session.state);
      else if (action === 'stand') stand(session.state);
      else if (action === 'double') {
        const account = balances(ctx.guildId, ctx.userId);
        if (account.wallet < session.wager) throw new ValidationError('Your wallet cannot cover the double.');
        debit({ guildId: ctx.guildId, userId: ctx.userId, amount: session.wager, kind: 'wager_blackjack_double' });
        session.wager *= 2;
        double(session.state);
      }

      settle(session);
      return ctx.update(withGameArt(await blackjackView(session.state, sessionId), { guildId: ctx.guildId, gameId: 'blackjack', outcome: session.state.payout > session.state.wager ? 'win' : 'lose' }));
    }

    if (session.game === 'uno') {
      if (action === 'again') return restart(ctx, session, 'uno');

      if (action === 'draw') {
        session.state.pendingWildIndex = null;
        drawForPlayer(session.state);
      } else if (action === 'card') {
        const index = Number(ctx.values?.[0]);
        const card = session.state.player[index];
        if (!card) throw new ValidationError('That card is no longer in your hand.');
        if (card.wild) {
          session.state.pendingWildIndex = index;
          session.state.message = 'Choose a color for your wild card.';
        } else {
          playCard(session.state, index);
        }
      } else if (String(action ?? '').startsWith('color-')) {
        const color = String(action).slice(6);
        const index = session.state.pendingWildIndex;
        if (index == null) throw new ValidationError('Choose a wild card first.');
        if (!UNO_COLORS.includes(color)) throw new ValidationError('Choose a valid UNO color.');
        session.state.pendingWildIndex = null;
        playCard(session.state, index, color);
      } else if (action === 'cancel-wild') {
        session.state.pendingWildIndex = null;
        session.state.message = 'Wild card selection cancelled. Play a card or draw.';
      } else if (action === 'playfirst') {
        const index = playableIndexes(session.state)[0];
        if (index === undefined) throw new ValidationError('No playable cards — draw instead.');
        playCard(session.state, index);
      }
      settle(session);
      return ctx.update(await unoView(session.state, sessionId, { guildId: ctx.guildId, userId: ctx.userId }));
    }

    if (session.game === 'tower') {
      if (action === 'again') return restart(ctx, session, 'tower');

      if (action === 'climb') climb(session.state);
      else if (action === 'cashout') cashOut(session.state);

      settle(session);
      return ctx.update(withGameArt(towerView(session.state, sessionId), { guildId: ctx.guildId, gameId: 'tower', outcome: session.state.payout > 0 ? 'win' : 'lose' }));
    }

    if (session.game === 'mines') {
      if (action === 'again') return restart(ctx, session, 'mines');

      if (action === 'cashout') cashOutMines(session.state);
      else if (String(action ?? '').startsWith('reveal')) {
        revealMine(session.state, Number(String(action).slice(6)));
      }

      settle(session);
      return ctx.update(withGameArt(minesView(session.state, sessionId), { guildId: ctx.guildId, gameId: 'mines', outcome: session.state.payout > 0 ? 'win' : 'lose' }));
    }

    if (session.game === 'defuse') {
      if (action === 'again') return restart(ctx, session, 'defuse');

      if (action === 'cashout') cashOutDefuse(session.state);
      else if (String(action ?? '').startsWith('cut')) {
        cutWire(session.state, Number(String(action).slice(3)));
      }

      settle(session);
      return ctx.update(
        withGameArt(defuseView(session.state, sessionId), {
          guildId: ctx.guildId,
          gameId: 'defuse',
          outcome: session.state.payout > 0 ? 'win' : 'lose',
        }),
      );
    }

    if (session.game === 'minefield') {
      if (action === 'again') return restart(ctx, session, 'minefield');

      if (action === 'cashout') cashOutMinefield(session.state);
      else if (action === 'cell-a' || action === 'cell-b') {
        revealMinefield(session.state, Number(ctx.values?.[0]));
      }

      settle(session);
      return ctx.update(
        withGameArt(minefieldView(session.state, sessionId), {
          guildId: ctx.guildId,
          gameId: 'minefield',
          outcome: session.state.payout > 0 ? 'win' : 'lose',
        }),
      );
    }

    if (session.game === 'crash') {
      if (action === 'again') return restart(ctx, session, 'crash');

      if (action === 'cashout') {
        cashOutCrash(session.state);
        settleCrashSession(session);
        session.finalized = true;
      }

      return ctx.update(
        withGameArt(
          crashView(session.state, sessionId, {
            history: getCrashHistory(session.guildId),
            jackpot: session.jackpotWin,
          }),
          { guildId: ctx.guildId, gameId: 'crash', outcome: session.state.payout > 0 ? 'win' : 'lose' },
        ),
      );
    }

    return null;
  },
};

function settle(session) {
  const { state } = session;
  if (session.settled) return;
  if (!['ended', 'fell', 'cashed_out', 'summit', 'lost', 'cleared', 'exploded', 'blown', 'matched'].includes(state.status)) return;

  session.settled = true;

  // A held arcade insurance pass refunds a collapsed Tower Climb stake.
  if (state.game === 'tower' && state.status === 'fell') {
    session.insuranceRefund = applyArcadeInsurance(session.guildId, session.userId, session.wager);
  }

  if (state.payout > 0) {
    credit({ guildId: session.guildId, userId: session.userId, amount: state.payout, kind: 'casino_win', respectCap: false });
  }

  if (isSessionWin(session)) {
    state.prize = awardGamePrize({
      guildId: session.guildId,
      userId: session.userId,
      game: session.game,
      won: true,
    });
  }
}

function isSessionWin(session) {
  const { state } = session;
  if (session.game === 'blackjack') return state.status === 'ended' && state.payout > state.wager;
  if (session.game === 'uno') return state.winner === 'player';
  if (session.game === 'tower') return state.payout > 0;
  if (session.game === 'mines') return state.payout > 0;
  if (session.game === 'defuse') return state.payout > 0;
  if (session.game === 'minefield') return state.payout > 0;
  if (session.game.startsWith('scratch-')) return state.payout > state.wager;
  return false;
}

async function restart(ctx, session, game) {
  const account = balances(ctx.guildId, ctx.userId);
  if (account.wallet < session.wager) throw new ValidationError('Your wallet cannot cover another round.');

  debit({ guildId: ctx.guildId, userId: ctx.userId, amount: session.wager, kind: `wager_${game}` });

  const sessionId = uniqueId('game');
  let payload;

  if (game === 'blackjack') {
    const state = startRound({ wager: session.wager, deckStyle: getPref(ctx.guildId, ctx.userId, 'cardBack', 'classic') });
    createSession(sessionId, { userId: ctx.userId, guildId: ctx.guildId, game, state, wager: session.wager, settled: false });
    payload = await blackjackView(state, sessionId);
  } else if (game === 'uno') {
    const state = startUno({ wager: session.wager });
    createSession(sessionId, { userId: ctx.userId, guildId: ctx.guildId, game, state, wager: session.wager, settled: false });
    payload = await unoView(state, sessionId, { guildId: ctx.guildId, userId: ctx.userId });
  } else if (game === 'mines') {
    const state = startMines({ wager: session.wager, mines: session.state.mineCount });
    createSession(sessionId, { userId: ctx.userId, guildId: ctx.guildId, game, state, wager: session.wager, settled: false });
    payload = minesView(state, sessionId);
  } else if (game === 'defuse') {
    const state = startDefuse({ wager: session.wager });
    createSession(sessionId, { userId: ctx.userId, guildId: ctx.guildId, game, state, wager: session.wager, settled: false });
    payload = defuseView(state, sessionId);
  } else if (game === 'minefield') {
    const state = startMinefield({ wager: session.wager });
    createSession(sessionId, { userId: ctx.userId, guildId: ctx.guildId, game, state, wager: session.wager, settled: false });
    payload = minefieldView(state, sessionId);
  } else if (game.startsWith('scratch-')) {
    const state = startScratch({ wager: session.wager, themeId: game });
    createSession(sessionId, { userId: ctx.userId, guildId: ctx.guildId, game, state, wager: session.wager, settled: false });
    payload = scratchView(state, sessionId);
  } else if (game === 'crash') {
    contributeJackpot({ guildId: ctx.guildId, wager: session.wager, game: 'crash', client: ctx.client });
    const state = startCrash({ wager: session.wager, autoCashout: session.state.autoCashout });
    createSession(sessionId, {
      userId: ctx.userId,
      guildId: ctx.guildId,
      game,
      state,
      wager: session.wager,
      settled: false,
      finalized: false,
      message: null,
    });
    const response = await ctx.update(
      crashView(state, sessionId, { history: getCrashHistory(ctx.guildId) }),
    );
    const next = getSession(sessionId);
    if (next) {
      next.message = ctx.interaction.message ?? response?.message ?? null;
      next.editResponse = ctx.interaction?.webhook?.editMessage
        ? (payload) => ctx.interaction.webhook.editMessage('@original', payload)
        : null;
    }
    return response;
  } else {
    const state = startTower({ wager: session.wager });
    createSession(sessionId, { userId: ctx.userId, guildId: ctx.guildId, game, state, wager: session.wager, settled: false });
    payload = towerView(state, sessionId);
  }

  return ctx.update(withGameArt(payload, { guildId: ctx.guildId, gameId: game }));
}

async function handleDuel(ctx, action, challengeId) {
  const challenge = getChallenge(challengeId);
  if (!challenge) throw new ValidationError('That challenge expired.');

  if (action === 'decline') {
    declineChallenge(challengeId, ctx.userId);
    return ctx.update({ embeds: [buildEmbed({ description: 'Challenge declined and stake refunded.', color: COLORS.neutral })], components: [] });
  }

  if (action === 'accept') {
    acceptChallenge(challengeId, ctx.userId);

    const coinflip = challenge.game === 'coinflip';
    const challengerRoll = coinflip ? rollDie(2) : rollDie(100);
    const opponentRoll = coinflip ? rollDie(2) : rollDie(100);
    const winnerId = challengerRoll >= opponentRoll ? challenge.challengerId : challenge.opponentId;
    const { pot } = settleChallenge(challengeId, winnerId);
    const prize = awardGamePrize({
      guildId: challenge.guildId,
      userId: winnerId,
      game: challenge.game,
      won: true,
    });

    const challengerResult = coinflip ? (challengerRoll === 1 ? 'Heads' : 'Tails') : `**${challengerRoll}**`;
    const opponentResult = coinflip ? (opponentRoll === 1 ? 'Heads' : 'Tails') : `**${opponentRoll}**`;

    return ctx.update({
      embeds: [
        buildEmbed({
          title: `⚔️ ${coinflip ? 'Coin flip' : 'Duel'} settled`,
          color: COLORS.success,
          description: `<@${challenge.challengerId}> ${coinflip ? 'flipped' : 'rolled'} ${challengerResult} · <@${challenge.opponentId}> ${coinflip ? 'flipped' : 'rolled'} ${opponentResult}\n\n<@${winnerId}> wins ${formatCoins(pot)}.${prize ? `\n\n🎁 **Game prize pool:** +${formatCoins(prize.amount)}` : ''}`,
        }),
      ],
      components: [],
    });
  }

  return ctx.update(challengeView(challenge));
}

export { challengeView };
