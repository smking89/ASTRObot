import { ValidationError } from '../core/errors.js';

/**
 * Entry point for the staff master panel's buttons.
 *
 * The buttons only carry a panel id and the click is gated on the admin grant,
 * so a posted staff card never exposes an admin tool to a player.
 */
const STAFF_PANELS = new Set([
  'templates',
  'shop-admin',
  'config',
  'mod',
  'staff',
  'staff-hub',
  'licenses',
  'game-setup',
  'analytics',
  'streak-admin',
  'market-admin',
  'onboarding',
  'giveaways',
  'polls',
  'giveaway-portal',
  'reaction-roles',
  'announcements',
  'admin-hub',
  'owner-hub',
  'mod-hub',
  'astro-hub',
]);

export default {
  id: 'openpanel-admin',
  access: 'player',
  async execute(ctx) {
    if (!ctx.grants?.has?.('admin')) throw new ValidationError('That panel is for staff only.');
    const panelId = String(ctx.args?.[0] ?? '').trim();
    if (!STAFF_PANELS.has(panelId)) throw new ValidationError('That panel is not available from this button.');
    return ctx.panel(panelId);
  },
};
