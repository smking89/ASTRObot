import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';

/** Back / refresh / close buttons shared by every panel. */
export default {
  id: 'nav',
  access: 'player',
  async execute(ctx) {
    const [action, ...rest] = ctx.args;

    if (action === 'close') {
      return ctx.update({ embeds: [buildEmbed({ description: 'Panel closed.', color: COLORS.neutral })], components: [] });
    }

    if (action === 'back' || action === 'refresh') {
      const panelId = rest[0];
      if (!panelId) {
        return ctx.update({
          embeds: [buildEmbed({ description: 'This panel has expired. Run the command again.', color: COLORS.warning })],
          components: [],
        });
      }
      return ctx.panel(panelId);
    }

    return null;
  },
};
