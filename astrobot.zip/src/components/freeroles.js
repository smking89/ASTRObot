import { getGuildSettings } from '../db/repositories/guilds.js';
import { ValidationError } from '../core/errors.js';

/** Toggle the member's configured free roles. */
export default {
  id: 'freeroles',
  access: 'player',
  async execute(ctx) {
    const settings = getGuildSettings(ctx.guildId);
    const config = settings.onboarding?.freeroles;
    if (!config?.enabled) throw new ValidationError('Free roles are disabled.');

    const configured = new Set((config.roleIds ?? []).map(String));
    const requested = new Set((ctx.values ?? []).map(String));
    for (const roleId of requested) {
      if (!configured.has(roleId)) throw new ValidationError('That role is not available as a free role.');
    }
    if (requested.size > Math.max(1, Number(config.maxRoles) || 1)) {
      throw new ValidationError(`You can choose at most ${config.maxRoles ?? 1} free role(s).`);
    }

    const member = await ctx.guild.members.fetch(ctx.userId).catch(() => null);
    if (!member) throw new ValidationError('Could not find your member record.');

    const current = [...configured].filter((roleId) => member.roles.cache.has(roleId));
    const toAdd = [...requested].filter((roleId) => !current.includes(roleId));
    const toRemove = current.filter((roleId) => !requested.has(roleId));

    for (const roleId of toAdd) await member.roles.add(roleId, 'Free role selection');
    for (const roleId of toRemove) await member.roles.remove(roleId, 'Free role selection');
    return ctx.panel('freeroles', { notice: `Free roles updated: ${requested.size} selected.` });
  },
};
