import { MessageFlags, TextInputStyle } from 'discord.js';
import { claimDaily, depositToBank, transfer, withdrawFromBank } from '../services/economy-service.js';
import { modal, customId } from '../ui/components.js';
import { parseUserId, parseIntStrict } from '../utils/parse.js';
import { formatCoins } from '../utils/format.js';

const amountField = {
  id: 'amount',
  label: 'Amount',
  placeholder: 'Whole number, e.g. 250',
  required: true,
};

/** /coins panel buttons. */
export default {
  id: 'eco',
  access: 'player',
  async execute(ctx) {
    const [action] = ctx.args;

    if (action === 'deposit' || action === 'withdraw') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('eco', action),
            title: action === 'deposit' ? 'Deposit into bank' : 'Withdraw from bank',
            fields: [amountField],
          }),
        );
      }

      const amount = parseIntStrict(ctx.option('amount'), { min: 1, max: 100_000_000, label: 'amount' });

      if (action === 'deposit') {
        const result = depositToBank(ctx.guildId, ctx.userId, amount);
        return ctx.panel('coins', {
          title: `Deposited ${formatCoins(result.moved)}`,
          notice: result.rejected > 0 ? `${formatCoins(result.rejected)} did not fit under the bank cap.` : null,
        });
      }

      const result = withdrawFromBank(ctx.guildId, ctx.userId, amount);
      return ctx.panel('coins', {
        title: `Withdrew ${formatCoins(result.moved)}`,
        notice: result.rejected > 0 ? `${formatCoins(result.rejected)} stayed in the bank due to the wallet cap.` : null,
      });
    }

    if (action === 'send') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('eco', 'send'),
            title: 'Send coins',
            fields: [amountField, { id: 'user', label: 'Recipient', placeholder: '@user or user ID', required: true }],
          }),
        );
      }

      const amount = parseIntStrict(ctx.option('amount'), { min: 1, max: 100_000_000, label: 'amount' });
      const targetId = parseUserId(ctx.option('user'));

      const result = transfer({ guildId: ctx.guildId, fromId: ctx.userId, toId: targetId, amount });
      return ctx.panel('coins', {
        title: 'Transfer complete',
        notice: `<@${targetId}> received ${formatCoins(result.received)}${result.fee ? ` (${formatCoins(result.fee)} fee)` : ''}.`,
      });
    }

    if (action === 'daily') {
      const result = claimDaily(ctx.guildId, ctx.userId);

      if (!result.claimed) {
        return ctx.panel('coins', {
          title: 'Daily bonus',
          notice: `Already claimed. Come back <t:${Math.floor(result.nextAt / 1000)}:R>.`,
        });
      }

      return ctx.panel('coins', {
        title: 'Daily bonus claimed',
        notice: `+${formatCoins(result.amount)} · streak **${result.streak}** · +${result.bonusXp} XP`,
      });
    }

    return ctx.reply({ content: 'Unknown action.', flags: MessageFlags.Ephemeral });
  },
};
