import { ButtonStyle, MessageFlags, TextInputStyle } from 'discord.js';
import { getGuildSettings, saveGuildSettings } from '../db/repositories/guilds.js';
import { badgeChoices, listBadges } from '../services/badge-service.js';
import { DEFAULT_GUILD_SETTINGS } from '../config/defaults.js';
import { customId, modal } from '../ui/components.js';
import { ValidationError } from '../core/errors.js';

const MAX_COINS = 100_000_000;

/** /claim-admin actions: rules, rewards per day, and the streak badge. */
export default {
  id: 'streakcfg',
  access: 'admin',
  async execute(ctx) {
    const [action, dayArg] = ctx.args;
    const settings = getGuildSettings(ctx.guildId);
    const config = { ...(settings.streak ?? {}) };
    const rewards = [...(config.rewards ?? DEFAULT_GUILD_SETTINGS.streak.rewards)];
    const day = Math.min(7, Math.max(1, Number(action === 'day' ? ctx.values?.[0] : dayArg) || 1));

    const save = (patch) => saveGuildSettings(ctx.guildId, { streak: { ...config, ...patch } }, { actorId: ctx.userId });
    const setReward = (patch) => save({ rewards: rewards.map((entry, index) => (index === day - 1 ? { ...entry, ...patch } : entry)) });

    if (action === 'toggle') {
      save({ enabled: config.enabled === false });
      return ctx.panel('streak-admin', { day });
    }

    if (action === 'reset') {
      save({
        enabled: true,
        requiredRoleId: null,
        minLevel: 0,
        badgeId: null,
        rewards: DEFAULT_GUILD_SETTINGS.streak.rewards,
      });
      return ctx.panel('streak-admin', { day });
    }

    if (action === 'minlevel') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('streakcfg', 'minlevel'),
            title: 'Daily reward requirement',
            fields: [
              {
                id: 'level',
                label: 'Minimum player level (0 = everyone)',
                required: true,
                maxLength: 4,
              },
            ],
          }),
        );
      }
      const level = Math.max(0, Math.min(1000, Number(ctx.option('level')) || 0));
      save({ minLevel: level });
      return ctx.panel('streak-admin', { day });
    }

    if (action === 'coins') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('streakcfg', 'coins', String(day)),
            title: `Day ${day} reward`,
            fields: [{ id: 'amount', label: 'Coins for this day', required: true, maxLength: 10 }],
          }),
        );
      }
      const amount = Math.max(0, Math.min(MAX_COINS, Number(ctx.option('amount')) || 0));
      setReward({ coins: amount });
      return ctx.panel('streak-admin', { day });
    }

    if (action === 'kit') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('streakcfg', 'kit', String(day)),
            title: `Day ${day} kit`,
            fields: [
              {
                id: 'kit',
                label: 'Kit name (blank to remove)',
                style: TextInputStyle.Short,
                required: false,
                maxLength: 60,
              },
            ],
          }),
        );
      }
      const kit = String(ctx.option('kit') ?? '').trim();
      setReward({ kit: kit || null });
      return ctx.panel('streak-admin', { day });
    }

    if (action === 'dayrole') {
      const roleId = String(ctx.values?.[0] ?? '').trim() || null;
      setReward({ roleId });
      return ctx.panel('streak-admin', { day });
    }

    if (action === 'roleclear') {
      setReward({ roleId: null });
      return ctx.panel('streak-admin', { day });
    }

    if (action === 'reqrole') {
      save({ requiredRoleId: String(ctx.values?.[0] ?? '').trim() || null });
      return ctx.panel('streak-admin', { day });
    }

    if (action === 'clearreq') {
      save({ requiredRoleId: null });
      return ctx.panel('streak-admin', { day });
    }

    if (action === 'badge') {
      const value = String(ctx.values?.[0] ?? '').trim();
      const badge = value && value !== 'none' ? listBadges(ctx.guildId).find((entry) => entry.id === value) : null;
      if (value && value !== 'none' && !badge) throw new ValidationError('That badge no longer exists.');
      save({ badgeId: badge?.id ?? null });
      return ctx.panel('streak-admin', { day });
    }

    return ctx.panel('streak-admin', { day });
  },
};
