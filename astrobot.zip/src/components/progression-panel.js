import { MessageFlags } from 'discord.js';
import { prestige } from '../services/progression-service.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';

/** /progression panel buttons. */
export default {
  id: 'prog',
  access: 'player',
  async execute(ctx) {
    const [action] = ctx.args;

    if (action === 'board') return ctx.panel('leaderboards');

    if (action === 'prestige') {
      const result = prestige({ guildId: ctx.guildId, userId: ctx.userId });

      if (!result.ok) {
        return ctx.reply({
          embeds: [buildEmbed({ description: 'You must reach level 1000 before prestiging.', color: COLORS.warning })],
          flags: MessageFlags.Ephemeral,
        });
      }

      return ctx.panel('progression', { notice: `Prestige **${result.prestige}** reached. Your level has reset to 1.` });
    }

    return ctx.panel('progression');
  },
};
