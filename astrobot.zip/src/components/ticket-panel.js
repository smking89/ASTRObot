import { ChannelType, MessageFlags, TextInputStyle } from 'discord.js';
import { createTicket, listOpenTickets, listTickets, openTicketsFor, setTicketChannel } from '../db/repositories/tickets.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { modal, customId } from '../ui/components.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { ValidationError } from '../core/errors.js';
import { relativeTimestamp, truncate } from '../utils/format.js';

/** Ticket intakes; the key is stored on the ticket row. */
const CATEGORIES = {
  bug: { label: 'Bug report', title: 'Bug Report', emoji: '❗' },
  appeal: { label: 'Ban appeal', title: 'Ban Appeal', emoji: '🔒' },
  refund: { label: 'Refund request', title: 'Refund', emoji: '📦' },
  tech: { label: 'Tech help', title: 'Tech Help', emoji: '🛠️' },
  general: { label: 'Support ticket', title: 'Support Ticket', emoji: '🎫' },
};

/** /support panel buttons. */
export default {
  id: 'ticket',
  access: 'player',
  async execute(ctx) {
    const [action, categoryArg] = ctx.args;
    const settings = getGuildSettings(ctx.guildId);

    if (action === 'list') {
      const tickets = listOpenTickets(ctx.guildId, 15);
      return ctx.reply({
        embeds: [
          buildEmbed({
            title: 'Support queue',
            color: COLORS.info,
            description:
              truncate(tickets.map((ticket) => `\`${ticket.id}\` · <@${ticket.owner_id}> · ${ticket.subject}`).join('\n'), 4000) ||
              'The queue is empty.',
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (action === 'closed') {
      const closed = listTickets(ctx.guildId, { status: 'closed', limit: 15 });
      return ctx.reply({
        embeds: [
          buildEmbed({
            title: '🛑 Closed tickets',
            color: COLORS.info,
            description:
              truncate(
                closed
                  .map(
                    (ticket) =>
                      `\`${ticket.id}\` · **${ticket.subject}** · <@${ticket.owner_id}> · closed ${relativeTimestamp(ticket.closed_at, 'R')}`,
                  )
                  .join('\n'),
                4000,
              ) || 'No closed tickets yet.',
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (action === 'open') {
      const category = categoryArg && categoryArg in CATEGORIES ? categoryArg : 'general';
      const meta = CATEGORIES[category];

      const existing = openTicketsFor(ctx.guildId, ctx.userId);
      if (existing.length >= Number(settings.tickets.maxOpenPerUser ?? 1)) {
        throw new ValidationError('You already have an open ticket.');
      }

      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('ticket', 'open', category),
            title: meta.title,
            fields: [
              { id: 'subject', label: 'Subject', required: true, maxLength: 80 },
              { id: 'details', label: 'Describe the issue', style: TextInputStyle.Paragraph, required: true, maxLength: 1500 },
            ],
          }),
        );
      }

      const subject = String(ctx.option('subject')).trim();
      const details = String(ctx.option('details'));
      const ticket = createTicket({ guildId: ctx.guildId, ownerId: ctx.userId, subject, category });

      const parent = settings.channels.tickets ?? settings.tickets.categoryId;
      const channel = parent ? await ctx.guild.channels.fetch(parent).catch(() => null) : null;

      if (channel?.type === ChannelType.GuildText) {
        const thread = await channel.threads
          .create({
            name: `${category}-${ticket.id.slice(-6)}`,
            type: ChannelType.PrivateThread,
            invitable: false,
            reason: `Support ticket ${ticket.id}`,
          })
          .catch(() => null);

        if (thread) {
          setTicketChannel(ticket.id, thread.id);
          await thread.members.add(ctx.userId).catch(() => null);

          await thread.send({
            content: settings.tickets.supportRoleIds.map((id) => `<@&${id}>`).join(' '),
            embeds: [
              buildEmbed({
                title: `${meta.emoji} ${meta.title} · ${subject}`,
                color: COLORS.brand,
                description: truncate(details, 4000),
                fields: [
                  { name: 'Opened by', value: `<@${ctx.userId}>`, inline: true },
                  { name: 'Category', value: meta.label, inline: true },
                ],
                footer: ticket.id,
              }),
            ],
            allowedMentions: { roles: settings.tickets.supportRoleIds },
          });
        }
      }

      return ctx.reply({
        embeds: [
          buildEmbed({
            description: `${meta.emoji} **${meta.label}** ticket \`${ticket.id}\` created${ticket.channel_id ? ` in <#${ticket.channel_id}>` : ''}.\nOnly you and ASTRO staff can see it.`,
            color: COLORS.success,
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    return ctx.panel('support');
  },
};
