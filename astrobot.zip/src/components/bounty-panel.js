import { TextInputStyle } from 'discord.js';
import { placeBounty, totalBounty } from '../db/repositories/bounties.js';
import { debit } from '../services/economy-service.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { modal, customId } from '../ui/components.js';
import { parseUserId, parseIntStrict } from '../utils/parse.js';
import { formatCoins } from '../utils/format.js';
import { ValidationError } from '../core/errors.js';
import { assertBountyAllowed } from '../services/voucher-service.js';

/** /bounty panel buttons. */
export default {
  id: 'bounty',
  access: 'player',
  async execute(ctx) {
    const [action] = ctx.args;

    if (action === 'place') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('bounty', 'place'),
            title: 'Place a bounty',
            fields: [
              { id: 'target', label: 'Target', placeholder: '@player or ID', required: true },
              { id: 'amount', label: 'Bounty amount', required: true },
              { id: 'note', label: 'Reason (optional)', style: TextInputStyle.Short, required: false, maxLength: 100 },
            ],
          }),
        );
      }

      const settings = getGuildSettings(ctx.guildId);
      const targetId = parseUserId(ctx.option('target'));
      const minimum = Number(settings.economy.bountyMinimum) || 1;
      const amount = parseIntStrict(ctx.option('amount'), { min: minimum, max: 100_000_000, label: 'bounty' });

      if (targetId === ctx.userId) throw new ValidationError('You cannot place a bounty on yourself.');

      // Throws (and spends the shield) before any escrow is taken.
      assertBountyAllowed(ctx.guildId, targetId);

      debit({ guildId: ctx.guildId, userId: ctx.userId, amount, kind: 'bounty_escrow' });
      placeBounty({ guildId: ctx.guildId, targetId, placedBy: ctx.userId, amount });

      return ctx.panel('bounty', {
        notice: `Bounty of ${formatCoins(amount)} placed on <@${targetId}> · total now ${formatCoins(totalBounty(ctx.guildId, targetId))}.`,
      });
    }

    return ctx.panel('bounty');
  },
};
