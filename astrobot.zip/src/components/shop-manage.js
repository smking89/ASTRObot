import { getGuildSettings, patchGuildSetting } from '../db/repositories/guilds.js';
import { modal, customId } from '../ui/components.js';
import { parseIntStrict } from '../utils/parse.js';
import { ValidationError } from '../core/errors.js';
import { stockOf } from '../services/shop-stock.js';
import { maybeAlertLowStock } from '../services/shop-alerts.js';
import { listStockEvents, recordStockEvent } from '../db/repositories/shop.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { MessageFlags } from 'discord.js';

function readCategory(value) {
  return String(value ?? '').trim().slice(0, 40) || 'General';
}

function readStock(value) {
  const raw = String(value ?? '').trim();
  // Blank, "unlimited", "inf" or "-1" all mean no stock limit.
  if (raw.length === 0 || ['unlimited', 'inf', 'infinite', '-1', '∞'].includes(raw.toLowerCase())) return null;
  return parseIntStrict(raw, { min: 0, max: 1_000_000, label: 'stock' });
}

/** /shop-manage panel: native role picker, purchase limits and restock. */
export default {
  id: 'shopmgr',
  access: 'restricted',
  async execute(ctx) {
    const [action, target] = ctx.args;
    const products = getGuildSettings(ctx.guildId).shop.products ?? [];

    if (action === 'back') return ctx.panel('shop-admin');

    if (action === 'role') {
      const roleId = String(ctx.values?.[0] ?? '');
      if (!/^\d{15,20}$/.test(roleId)) throw new ValidationError('Pick a role from the picker.');

      const updated = products.map((product) =>
        target === 'all' || String(product.id) === String(target) ? { ...product, requiredRoleId: roleId } : product,
      );
      const { settings } = patchGuildSetting(ctx.guildId, 'shop.products', updated, { actorId: ctx.userId });
      ctx.guildConfig = settings;
      return ctx.panel('shop-manage', { target });
    }

    if (action === 'alerts') {
      const updated = products.map((product) =>
        String(product.id) === String(target) ? { ...product, alertMuted: !product.alertMuted } : product,
      );
      const { settings } = patchGuildSetting(ctx.guildId, 'shop.products', updated, { actorId: ctx.userId });
      ctx.guildConfig = settings;
      return ctx.panel('shop-manage', { target });
    }

    if (action === 'unlimited') {
      const updated = products.map((product) =>
        String(product.id) === String(target) ? { ...product, stock: null, stockAlertAt: null } : product,
      );
      const { settings } = patchGuildSetting(ctx.guildId, 'shop.products', updated, { actorId: ctx.userId });
      ctx.guildConfig = settings;
      recordStockEvent({ guildId: ctx.guildId, productId: target, delta: 0, stockAfter: null, kind: 'unlimited', actorId: ctx.userId });
      return ctx.panel('shop-manage', { target });
    }

    if (action === 'history') {
      const events = listStockEvents(ctx.guildId, target, 10);
      await ctx.reply({
        embeds: [
          buildEmbed({
            title: '🧾 Stock history',
            color: COLORS.info,
            description:
              events
                .map((event, index) => {
                  const delta = event.delta === 0 ? '±0' : event.delta > 0 ? `+${event.delta}` : `${event.delta}`;
                  const after = event.stock_after === null ? 'unlimited' : `${event.stock_after} left`;
                  const actor = event.actor_id ? ` · <@${event.actor_id}>` : '';
                  return `${index + 1}. <t:${Math.floor(event.created_at / 1000)}:R> · **${event.kind}** · ${delta} → ${after}${actor}`;
                })
                .join('\n') || 'No stock changes recorded yet.',
            footer: 'Sales, restocks, edits and unlimited toggles are recorded',
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
      return undefined;
    }

    if (action === 'roleclear') {
      const updated = products.map((product) =>
        target === 'all' || String(product.id) === String(target) ? { ...product, requiredRoleId: null } : product,
      );
      const { settings } = patchGuildSetting(ctx.guildId, 'shop.products', updated, { actorId: ctx.userId });
      ctx.guildConfig = settings;
      return ctx.panel('shop-manage', { target });
    }

    const product = products.find((entry) => String(entry.id) === String(target));
    if (!product) throw new ValidationError('That product is no longer in the shop.');

    if (action === 'delete') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('shopmgr', 'delete', product.id),
            title: `Delete ${product.name ?? product.id}?`,
            fields: [
              {
                id: 'confirm',
                label: 'Type DELETE to confirm',
                placeholder: 'DELETE',
                required: true,
                maxLength: 10,
              },
            ],
          }),
        );
      }

      if (String(ctx.option('confirm') ?? '').trim().toUpperCase() !== 'DELETE') {
        throw new ValidationError('Type DELETE to remove this product.');
      }

      const { settings } = patchGuildSetting(
        ctx.guildId,
        'shop.products',
        products.filter((entry) => String(entry.id) !== String(product.id)),
        { actorId: ctx.userId },
      );
      ctx.guildConfig = settings;
      return ctx.panel('shop-admin', { notice: `Deleted **${product.name ?? product.id}** from the shop.` });
    }

    if (action === 'edit') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('shopmgr', 'edit', product.id),
            title: `Edit ${product.name ?? product.id}`,
            fields: [
              { id: 'price', label: 'Price in coins (0 = free)', required: true, value: String(product.price ?? 0), maxLength: 20 },
              { id: 'quantity', label: 'Quantity delivered per purchase', required: true, value: String(product.quantity ?? 1), maxLength: 10 },
              { id: 'category', label: 'Category', required: false, value: String(product.category ?? 'General'), maxLength: 40 },
              {
                id: 'stock',
                label: 'Stock (blank = unlimited)',
                required: false,
                value: product.stock === null || product.stock === undefined ? '' : String(product.stock),
                maxLength: 10,
              },
            ],
          }),
        );
      }

      const price = parseIntStrict(ctx.option('price'), { min: 0, max: 10_000_000, label: 'price' });
      const quantity = parseIntStrict(ctx.option('quantity'), { min: 1, max: 1000, label: 'quantity' });
      const category = readCategory(ctx.option('category'));
      const stock = readStock(ctx.option('stock'));
      const previousStock = stockOf(product);
      const decreased = stock !== null && (previousStock === null || stock < previousStock);
      // Raising stock above the old level clears the alert stamp so the next dip
      // is reported again.
      const resetAlert = stock !== null && previousStock !== null && stock > previousStock ? { stockAlertAt: null } : {};

      const updated = products.map((entry) =>
        String(entry.id) === String(product.id) ? { ...entry, price, quantity, category, stock, ...resetAlert } : entry,
      );
      const { settings } = patchGuildSetting(ctx.guildId, 'shop.products', updated, { actorId: ctx.userId });
      ctx.guildConfig = settings;
      recordStockEvent({
        guildId: ctx.guildId,
        productId: product.id,
        delta: stock === null ? 0 : stock - (previousStock ?? stock),
        stockAfter: stock,
        kind: 'manual',
        actorId: ctx.userId,
      });

      // A manual reduction is exactly the case a purchase-time check misses.
      if (decreased) {
        const saved = (settings.shop.products ?? []).find((entry) => String(entry.id) === String(product.id));
        await maybeAlertLowStock({ client: ctx.client, guildId: ctx.guildId, product: saved ?? product, stock, force: true });
      }

      return ctx.panel('shop-manage', { target });
    }

    if (action === 'limits') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('shopmgr', 'limits', product.id),
            title: `Limits · ${product.name ?? product.id}`,
            fields: [
              {
                id: 'limit',
                label: 'Per-member limit (blank = none)',
                required: false,
                value: product.limitPerMember ?? '',
                maxLength: 6,
              },
              {
                id: 'window',
                label: 'Limit window in hours',
                required: false,
                value: String(product.limitWindowHours ?? 24),
                maxLength: 6,
              },
              {
                id: 'restock',
                label: 'Restock every N minutes (blank = off)',
                required: false,
                value: product.restockMinutes ?? '',
                maxLength: 8,
              },
              {
                id: 'restockAmount',
                label: 'Restock amount',
                required: false,
                value: product.restockAmount ?? '',
                maxLength: 6,
              },
              {
                id: 'stockMax',
                label: 'Max stock (blank = no cap)',
                required: false,
                value: product.stockMax ?? '',
                maxLength: 8,
              },
            ],
          }),
        );
      }

      const limitPerMember = ctx.option('limit') ? parseIntStrict(ctx.option('limit'), { min: 1, max: 1000, label: 'limit' }) : null;
      const limitWindowHours = ctx.option('window')
        ? parseIntStrict(ctx.option('window'), { min: 1, max: 8760, label: 'window' })
        : 24;
      const restockMinutes = ctx.option('restock')
        ? parseIntStrict(ctx.option('restock'), { min: 1, max: 525_600, label: 'restock interval' })
        : null;
      const restockAmount = ctx.option('restockAmount')
        ? parseIntStrict(ctx.option('restockAmount'), { min: 1, max: 10_000, label: 'restock amount' })
        : null;
      const stockMax = ctx.option('stockMax') ? parseIntStrict(ctx.option('stockMax'), { min: 0, max: 1_000_000, label: 'max stock' }) : null;

      if ((restockMinutes === null) !== (restockAmount === null)) {
        throw new ValidationError('Set both the restock interval and amount, or leave both blank.');
      }

      const updated = products.map((entry) =>
        String(entry.id) === String(product.id)
          ? {
              ...entry,
              limitPerMember,
              limitWindowHours,
              restockMinutes,
              restockAmount,
              stockMax,
              restockAnchorAt: restockMinutes ? Date.now() : null,
            }
          : entry,
      );
      const { settings } = patchGuildSetting(ctx.guildId, 'shop.products', updated, { actorId: ctx.userId });
      ctx.guildConfig = settings;
      return ctx.panel('shop-manage', { target });
    }

    return ctx.panel('shop-manage', { target });
  },
};
