import { MessageFlags, TextInputStyle } from 'discord.js';
import { getGuildSettings, patchGuildSetting } from '../db/repositories/guilds.js';
import { modal, customId } from '../ui/components.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { ValidationError } from '../core/errors.js';

/** /game-forge buttons. */
export default {
  id: 'forge',
  access: 'admin',
  async execute(ctx) {
    const [action] = ctx.args;

    if (action === 'sync') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('forge', 'sync'),
            title: 'Import games from the dashboard',
            fields: [
              {
                id: 'games',
                label: 'Published games JSON',
                placeholder: '[{"name":"Lucky Dig","type":"loot","enabled":true}]',
                style: TextInputStyle.Paragraph,
                required: true,
                maxLength: 3500,
              },
            ],
          }),
        );
      }

      let games;
      try {
        games = JSON.parse(String(ctx.option('games')));
      } catch {
        throw new ValidationError('That is not valid JSON.');
      }

      if (!Array.isArray(games)) throw new ValidationError('Expected a JSON array of games.');
      const clean = games.slice(0, 25).map((game) => ({
        name: String(game.name ?? 'Untitled').slice(0, 60),
        type: String(game.type ?? 'custom').slice(0, 30),
        enabled: Boolean(game.enabled),
      }));

      const { settings } = patchGuildSetting(ctx.guildId, 'misc.customGames', clean, { actorId: ctx.userId });
      ctx.guildConfig = settings;

      return ctx.reply({
        embeds: [buildEmbed({ description: `Imported ${clean.length} game(s) from the dashboard.`, color: COLORS.success })],
        flags: MessageFlags.Ephemeral,
      });
    }

    return ctx.panel('game-forge');
  },
};

export { getGuildSettings };
