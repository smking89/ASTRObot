import { MessageFlags, TextInputStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { getPollForGuild } from '../db/repositories/polls.js';
import { COLORS } from '../config/constants.js';
import { ValidationError } from '../core/errors.js';
import { buildEmbed } from '../ui/embeds.js';
import { customId, modal } from '../ui/components.js';
import { parseIntStrict } from '../utils/parse.js';
import { createPollMessage, endPoll, parsePollOptions, pollEmbed, voteOnPoll } from '../services/poll-service.js';

const truthy = (value) => ['1', 'true', 'yes', 'on', 'multi', 'multiple'].includes(String(value ?? '').trim().toLowerCase());

/** Poll creation, voting and admin analytics controls. */
export default {
  id: 'polls',
  access: 'player',
  async execute(ctx) {
    const [action, first, second] = ctx.args;
    const settings = getGuildSettings(ctx.guildId);
    const config = settings.onboarding?.polls;

    if (action === 'vote') {
      if (!config?.enabled) throw new ValidationError('Polls are disabled.');
      const pollId = first;
      const index = Number(second);
      const result = await voteOnPoll({
        client: ctx.client,
        guildId: ctx.guildId,
        pollId,
        userId: ctx.userId,
        optionIndex: index,
      });
      return ctx.reply({
        embeds: [
          buildEmbed({
            title: result.removed ? '🗳️ Vote removed' : '🗳️ Vote recorded',
            color: result.removed ? COLORS.neutral : COLORS.success,
            description: result.removed
              ? `Your vote for **${result.poll.options[index]}** was removed.`
              : `You voted for **${result.poll.options[index]}**. Click again to remove it.`,
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (action === 'results') {
      const poll = getPollForGuild(first, ctx.guildId);
      if (!poll) throw new ValidationError('That poll no longer exists.');
      return ctx.reply({ embeds: [pollEmbed(poll)], flags: MessageFlags.Ephemeral });
    }

    if (action === 'select' || action === 'refresh') {
      if (!ctx.grants?.has?.('restricted')) throw new ValidationError('Only staff can manage polls.');
      if (action === 'select') return ctx.panel('polls', { selected: ctx.values?.[0] });
      return ctx.panel('polls', { selected: first && first !== 'none' ? first : undefined });
    }

    if (!ctx.grants?.has?.('restricted')) throw new ValidationError('Only staff can manage polls.');

    if (action === 'view') {
      return ctx.panel('polls', {
        selected: second && second !== 'none' ? second : undefined,
        view: first === 'advanced' ? 'advanced' : 'basic',
      });
    }

    if (action === 'end') {
      if (!first || first === 'none') throw new ValidationError('Select a poll first.');
      const closed = await endPoll({ client: ctx.client, guildId: ctx.guildId, pollId: first });
      return ctx.panel('polls', { selected: closed.id, notice: 'Poll closed. Results are final.' });
    }

    if (action !== 'create') return null;
    if (!config?.enabled) throw new ValidationError('Polls are disabled.');

    const channelId = first && first !== 'none' ? first : config.channelId ?? ctx.channelId;
    if (!ctx.isModal) {
      return ctx.modal(
        modal({
          id: customId('polls', 'create', channelId),
          title: 'Create an Astro poll',
          fields: [
            { id: 'question', label: 'Question', required: true, maxLength: 300 },
            {
              id: 'options',
              label: 'Answers (one per line or comma separated)',
              required: true,
              style: TextInputStyle.Paragraph,
              maxLength: 900,
            },
            { id: 'hours', label: 'Duration in hours', value: String(config.defaultHours ?? 24), required: false, maxLength: 3 },
            { id: 'multiple', label: 'Allow multiple choices? (yes/no)', value: 'no', required: false, maxLength: 8 },
          ],
        }),
      );
    }

    const question = String(ctx.option('question') ?? '').trim();
    if (!question) throw new ValidationError('A poll question is required.');
    const options = parsePollOptions(ctx.option('options'));
    const hours = parseIntStrict(ctx.option('hours') || config.defaultHours || 24, { min: 1, max: 768, label: 'hours' });
    const poll = await createPollMessage({
      client: ctx.client,
      guildId: ctx.guildId,
      channelId,
      creatorId: ctx.userId,
      question,
      options,
      hours,
      allowMultiple: truthy(ctx.option('multiple')),
    });

    return ctx.panel('polls', { selected: poll.id, notice: `Poll posted in <#${poll.channel_id}>.` });
  },
};
