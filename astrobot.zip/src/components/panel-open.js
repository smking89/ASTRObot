import { ValidationError } from '../core/errors.js';

/**
 * Public entry point for the static panel cards a template posts.
 *
 * Buttons only carry a panel id, never user data, and only public interactive
 * panels are allowed. Admin/setup panels stay behind their own commands.
 */
const PUBLIC_PANELS = new Set([
  'play',
  'jackpot',
  'team',
  'claim',
  'player-panel',
  'battle-pass',
  'leaderboards',
  'bounty',
  'shop',
  'lfg',
  'support',
  'market',
  'freeroles',
  'hub',
  'checkout',
]);

export default {
  id: 'openpanel',
  access: 'player',
  async execute(ctx) {
    const panelId = String(ctx.args?.[0] ?? '').trim();
    if (!PUBLIC_PANELS.has(panelId)) throw new ValidationError('That panel is not available from this button.');
    return ctx.panel(panelId);
  },
};
