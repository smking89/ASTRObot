import { createTemplate, deleteTemplate, findTemplateByName, getTemplate, listTemplates } from '../db/repositories/templates.js';
import { applyGuildTemplate, captureGuildTemplate, decodeTemplateSections, encodeTemplateSections } from '../services/template-service.js';
import { getPresetTemplate } from '../config/server-templates.js';
import { loadTemplateDraft, resetTemplateDraft } from '../services/template-builder.js';
import { modal, customId } from '../ui/components.js';
import { ValidationError } from '../core/errors.js';
import { guildPlan, planHasFeature } from '../services/plan-service.js';

/** Admin template actions: save a snapshot, apply it, or delete it. */
export default {
  id: 'templates',
  access: 'admin',
  async execute(ctx) {
    const [action, templateId] = ctx.args;

    if (action === 'open') return ctx.panel('templates');

    if (action === 'new') {
      if (!planHasFeature(ctx.guildId, 'customTemplates')) {
        throw new ValidationError('Building a custom template is a Max feature. Pro includes every built-in and saved template.');
      }
      resetTemplateDraft(ctx.guildId, ctx.userId);
      return ctx.panel('template-editor');
    }

    if (action === 'select') {
      return ctx.panel('templates', { selected: ctx.values?.[0] ?? templateId });
    }

    if (action === 'preview') {
      const preset = getPresetTemplate(templateId);
      if (!preset && !getTemplate(ctx.guildId, templateId)) throw new ValidationError('That template no longer exists.');
      return ctx.panel('template-preview', { selected: templateId });
    }

    if (action === 'edit') {
      if (!planHasFeature(ctx.guildId, 'customTemplates')) {
        throw new ValidationError('Editing a template from scratch is a Max feature. Pro can apply and save templates.');
      }
      if (getPresetTemplate(templateId)) {
        throw new ValidationError('Built-in layouts cannot be edited. Save the current server as a template to edit your own copy.');
      }
      const template = getTemplate(ctx.guildId, templateId);
      if (!template) throw new ValidationError('That template no longer exists.');
      loadTemplateDraft(ctx.guildId, ctx.userId, template);
      return ctx.panel('template-editor');
    }

    if (action === 'save') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('templates', 'save'),
            title: 'Save server template',
            fields: [{ id: 'name', label: 'Template name', placeholder: 'Main server layout', required: true, maxLength: 60 }],
          }),
        );
      }

      const name = String(ctx.option('name') ?? '').trim();
      if (!name) throw new ValidationError('Give the template a name.');
      const savedLimit = guildPlan(ctx.guildId).limits.savedTemplates;
      if (savedLimit !== null && listTemplates(ctx.guildId).length >= savedLimit) {
        throw new ValidationError(
          `The Basic plan allows ${savedLimit} saved template. Delete it first or upgrade to Pro for every template.`,
        );
      }
      if (findTemplateByName(ctx.guildId, name)) {
        throw new ValidationError('A template with that name already exists. Delete it first or pick another name.');
      }

      const payload = await captureGuildTemplate(ctx.guild);
      const template = createTemplate({ guildId: ctx.guildId, name, payload, createdBy: ctx.userId });
      return ctx.panel('templates', {
        selected: template.id,
        notice: `Saved **${name}** with ${payload.roles.length} roles, ${payload.categories.length} categories and ${payload.channels.length} channels.`,
      });
    }

    if (action === 'apply') {
      // Applying always goes through the confirmation page: it replaces the
      // current layout, so it must never run straight from the templates panel.
      const preset = getPresetTemplate(templateId);
      if (!preset && !getTemplate(ctx.guildId, templateId)) throw new ValidationError('That template no longer exists.');
      return ctx.panel('template-preview', { selected: templateId });
    }

    if (action === 'parts') {
      const preset = getPresetTemplate(templateId);
      if (!preset && !getTemplate(ctx.guildId, templateId)) throw new ValidationError('That template no longer exists.');
      return ctx.panel('template-preview', {
        selected: templateId,
        sections: encodeTemplateSections(ctx.values ?? []),
      });
    }

    if (action === 'confirm') {
      const preset = getPresetTemplate(templateId);
      const template = preset ?? getTemplate(ctx.guildId, templateId);
      if (!template) throw new ValidationError('That template no longer exists.');

      const sections = decodeTemplateSections(ctx.args?.[2]);

      // Deleting a layout and recreating it can take longer than Discord's
      // three-second window.
      await ctx.deferUpdate();
      const result = await applyGuildTemplate(ctx.guild, template.payload, {
        actorId: ctx.userId,
        parts: sections,
        wipe: true,
      });
      const lines = [
        `Applied ${preset ? 'built-in layout ' : ''}**${template.name}**.`,
        result.wiped
          ? `Deleted ${result.wiped.channelsDeleted} channel(s) and ${result.wiped.rolesDeleted} role(s) first.`
          : null,
        `Created ${result.rolesCreated} role(s), ${result.categoriesCreated} category(s) and ${result.channelsCreated} channel(s).`,
        result.skipped ? `Skipped ${result.skipped} duplicate entries.` : null,
        result.staffMerged ? `Added ${result.staffMerged} role(s) to staff access.` : null,
        result.kitsAdded ? `Registered ${result.kitsAdded} kit(s) in the shop.` : null,
        result.roleBackup
          ? `Role backup \`${result.roleBackup.id}\` saved for ${result.roleBackup.memberCount} member(s).`
          : null,
        result.roleRestore
          ? `Restored ${result.roleRestore.restoredAssignments} role assignment(s) across ${result.roleRestore.restoredMembers} member(s)${result.roleRestore.rolesRecreated ? ` · recreated ${result.roleRestore.rolesRecreated} role(s)` : ''}.`
          : null,
        result.roleRestore?.missingMembers
          ? `${result.roleRestore.missingMembers} member(s) from the backup are no longer in the server.`
          : null,
        result.panelsPosted ? `Deployed ${result.panelsPosted} panel(s): ${result.panels.join(', ')}.` : null,
        result.errors.length ? `Warnings: ${result.errors.slice(0, 5).join('; ')}` : null,
      ].filter(Boolean);

      return ctx.panel('templates', { selected: preset ? preset.id : template.id, notice: lines.join('\n') });
    }

    if (action === 'delete') {
      if (getPresetTemplate(templateId)) {
        throw new ValidationError('Built-in layouts cannot be deleted. Apply it, then edit your server freely.');
      }
      const template = getTemplate(ctx.guildId, templateId);
      if (!template) throw new ValidationError('That template no longer exists.');
      deleteTemplate(ctx.guildId, templateId);
      return ctx.panel('templates', { notice: `Deleted **${template.name}**.` });
    }

    return ctx.panel('templates');
  },
};
