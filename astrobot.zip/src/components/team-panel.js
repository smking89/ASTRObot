import { MessageFlags, TextInputStyle } from 'discord.js';
import {
  addMember,
  closeInvite,
  createInvite,
  createTeam,
  createWar,
  deleteTeam,
  getInvite,
  getTeamForUser,
  listMembers,
  memberCount,
  removeMember,
  updateTeam,
} from '../db/repositories/teams.js';
import { debit } from '../services/economy-service.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { modal, customId } from '../ui/components.js';
import { parseCoordinates, parseHexColor, parseUserId, parseIntStrict } from '../utils/parse.js';
import { ValidationError } from '../core/errors.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { formatCoins } from '../utils/format.js';

const requireLeader = (ctx, team) => {
  if (!team) throw new ValidationError('You are not in a team.');
  if (team.owner_id !== ctx.userId && !['leader', 'officer'].includes(team.member_rank)) {
    throw new ValidationError('Only team leaders and officers can do that.');
  }
  return team;
};

/** /team panel buttons. */
export default {
  id: 'team',
  access: 'team',
  async execute(ctx) {
    const [action, arg] = ctx.args;
    const settings = getGuildSettings(ctx.guildId);
    const team = getTeamForUser(ctx.guildId, ctx.userId);

    if (action === 'create') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('team', 'create'),
            title: 'Create a team',
            fields: [
              { id: 'name', label: 'Team name', required: true, maxLength: 32 },
              { id: 'tag', label: 'Clan tag', required: true, maxLength: settings.clan.tagMaxLength ?? 5 },
            ],
          }),
        );
      }

      if (team) throw new ValidationError('You are already in a team.');
      const name = String(ctx.option('name')).trim();
      const tag = String(ctx.option('tag')).trim().toUpperCase();

      if (!settings.clan.enabled) throw new ValidationError('Clans are disabled in this server.');
      if (tag.length > Number(settings.clan.tagMaxLength ?? 5)) throw new ValidationError('That tag is too long.');

      const cost = Number(settings.clan.createCost) || 0;
      if (cost > 0) debit({ guildId: ctx.guildId, userId: ctx.userId, amount: cost, kind: 'team_create' });

      createTeam({ guildId: ctx.guildId, name, tag, ownerId: ctx.userId });
      return ctx.panel('team');
    }

    if (action === 'invite') {
      requireLeader(ctx, team);
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('team', 'invite'),
            title: 'Invite a player',
            fields: [{ id: 'user', label: 'Player', placeholder: '@user or ID', required: true }],
          }),
        );
      }

      const inviteeId = parseUserId(ctx.option('user'));
      if (memberCount(team.id) >= Number(settings.clan.maxMembers ?? 12)) {
        throw new ValidationError('Your team is full.');
      }

      const invite = createInvite({ guildId: ctx.guildId, teamId: team.id, inviterId: ctx.userId, inviteeId });
      return ctx.reply(
        {
          embeds: [
            buildEmbed({
              title: 'Invite sent',
              description: `${'<@'}${inviteeId}> has been invited to **${team.name}**.`,
              color: COLORS.success,
            }),
          ],
          flags: MessageFlags.Ephemeral,
        },
      );
    }

    if (action === 'accept' || action === 'decline') {
      const invite = getInvite(arg);
      if (!invite || invite.invitee_id !== ctx.userId) throw new ValidationError('That invite is not yours.');

      closeInvite(invite.id, action === 'accept' ? 'accepted' : 'declined');
      if (action === 'accept') addMember(invite.team_id, ctx.guildId, ctx.userId, 'member');

      return ctx.panel('team');
    }

    if (action === 'config') {
      requireLeader(ctx, team);
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('team', 'config'),
            title: 'Team configuration',
            fields: [
              { id: 'color', label: 'Team color (hex)', placeholder: '#8b5cf6', required: false },
              { id: 'badge', label: 'Badge emoji', placeholder: '🛡️', required: false },
              { id: 'raid', label: 'RaidLink channel ID', placeholder: '123456789012345678', required: false },
            ],
          }),
        );
      }

      const colorRaw = ctx.option('color');
      const raid = ctx.option('raid');
      updateTeam(team.id, {
        color: colorRaw ? parseHexColor(colorRaw) : team.color,
        badge: ctx.option('badge') || team.badge,
        raid_channel_id: raid ? String(raid).replace(/[<#>]/g, '') : team.raid_channel_id,
      });
      return ctx.panel('team');
    }

    if (action === 'war') {
      requireLeader(ctx, team);
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('team', 'war'),
            title: 'Declare war',
            fields: [{ id: 'opponent', label: 'Opponent tag or name', required: true }],
          }),
        );
      }

      if (!settings.clan.warsEnabled) throw new ValidationError('Team wars are disabled.');
      const { getTeamByName } = await import('../db/repositories/teams.js');
      const opponent = getTeamByName(ctx.guildId, String(ctx.option('opponent')).trim());
      if (!opponent || opponent.id === team.id) throw new ValidationError('No opposing team with that tag.');

      createWar({ guildId: ctx.guildId, teamId: team.id, opponentTeamId: opponent.id });
      return ctx.panel('team');
    }

    if (action === 'orp') {
      requireLeader(ctx, team);
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('team', 'orp'),
            title: 'Register ORP zone',
            fields: [
              { id: 'center', label: 'Center (x, y, z)', placeholder: '120, 5, -890', required: true },
              { id: 'radius', label: 'Radius', placeholder: '80', required: true },
            ],
          }),
        );
      }

      const center = parseCoordinates(ctx.option('center'));
      const radius = parseIntStrict(ctx.option('radius'), { min: 1, max: 1000, label: 'radius' });
      updateTeam(team.id, { orp_zone: JSON.stringify({ type: 'circle', x: center.x, z: center.z, radius }) });
      return ctx.panel('team');
    }

    if (action === 'leave') {
      if (!team) throw new ValidationError('You are not in a team.');

      const members = listMembers(team.id).filter((member) => member.user_id !== ctx.userId);
      removeMember(team.id, ctx.userId);

      if (members.length === 0) {
        deleteTeam(team.id);
        return ctx.panel('team', { notice: 'Your team was disbanded because it had no members left.' });
      }

      if (team.owner_id === ctx.userId) {
        const { setMemberRank } = await import('../db/repositories/teams.js');
        setMemberRank(team.id, members[0].user_id, 'leader');
        await import('../db/repositories/teams.js').then(({ getDb }) => getDb());
      }

      return ctx.panel('team');
    }

    return ctx.reply({ content: 'Unknown action.', flags: MessageFlags.Ephemeral });
  },
};
