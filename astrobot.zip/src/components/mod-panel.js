import { ButtonStyle, MessageFlags, TextInputStyle } from 'discord.js';
import { createCase, deactivateCase, getCase } from '../db/repositories/moderation.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { button, customId, modal, row } from '../ui/components.js';
import { parseDuration, parseUserId } from '../utils/parse.js';
import { ValidationError } from '../core/errors.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { relativeTimestamp } from '../utils/format.js';

const ACTIONS = new Set(['warn', 'mute', 'jail', 'note']);

/** /mod panel buttons. */
export default {
  id: 'mod',
  access: 'staff',
  permissions: null,
  async execute(ctx) {
    const [action, arg] = ctx.args;

    if (ACTIONS.has(action)) {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('mod', action),
            title: `${action[0].toUpperCase()}${action.slice(1)} a member`,
            fields: [
              { id: 'user', label: 'Member', placeholder: '@user or ID', required: true },
              { id: 'reason', label: 'Reason', style: TextInputStyle.Paragraph, required: true, maxLength: 500 },
              { id: 'duration', label: 'Duration (e.g. 1h, 7d)', placeholder: '1h', required: false },
            ],
          }),
        );
      }

      const targetId = parseUserId(ctx.option('user'));
      const reason = String(ctx.option('reason')).trim();
      const durationRaw = ctx.option('duration');
      const durationMs = durationRaw ? parseDuration(durationRaw) : null;
      const settings = getGuildSettings(ctx.guildId);

      const discordAction = action === 'mute' || action === 'jail';
      if (discordAction) {
        const member = await ctx.guild.members.fetch(targetId).catch(() => null);
        if (!member) throw new ValidationError('That member is not in the server.');
        if (!member.moderatable) throw new ValidationError('I cannot moderate that member (role hierarchy).');

        await member.timeout(durationMs ?? 3_600_000, reason).catch(() => {
          throw new ValidationError('Discord rejected the timeout.');
        });
      }

      const record = createCase({
        guildId: ctx.guildId,
        targetId,
        moderatorId: ctx.userId,
        action,
        reason,
        durationMs,
      });

      const logChannel = settings.channels.modLog
        ? await ctx.guild.channels.fetch(settings.channels.modLog).catch(() => null)
        : null;

      if (logChannel?.isTextBased()) {
        await logChannel
          .send({
            embeds: [
              buildEmbed({
                title: `Case ${record.id}`,
                color: COLORS.warning,
                fields: [
                  { name: 'Action', value: action, inline: true },
                  { name: 'Target', value: `<@${targetId}>`, inline: true },
                  { name: 'Moderator', value: `<@${ctx.userId}>`, inline: true },
                  { name: 'Reason', value: reason },
                  { name: 'Expires', value: durationMs ? relativeTimestamp(record.expires_at, 'R') : 'Never', inline: true },
                ],
              }),
            ],
          })
          .catch(() => null);
      }

      return ctx.panel('mod', { targetId, notice: `Case ${record.id} recorded.` });
    }

    if (action === 'case') {
      const record = getCase(ctx.values?.[0] ?? arg);
      if (!record) throw new ValidationError('Case not found.');

      return ctx.reply({
        embeds: [
          buildEmbed({
            title: `Case ${record.id}`,
            color: record.active ? COLORS.warning : COLORS.neutral,
            fields: [
              { name: 'Action', value: record.action, inline: true },
              { name: 'Target', value: `<@${record.target_id}>`, inline: true },
              { name: 'Moderator', value: `<@${record.moderator_id}>`, inline: true },
              { name: 'Active', value: record.active ? 'Yes' : 'No', inline: true },
              { name: 'Reason', value: record.reason ?? 'No reason recorded' },
            ],
            footer: `Created ${relativeTimestamp(record.created_at, 'R')}`,
          }),
        ],
        components: record.active
          ? [
              row(
                button({
                  id: customId('mod', 'close-case', record.id),
                  label: 'Deactivate case',
                  style: ButtonStyle.Danger,
                }),
              ),
            ]
          : [],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (action === 'close-case') {
      deactivateCase(arg);
      return ctx.update({
        embeds: [buildEmbed({ description: 'Case deactivated.', color: COLORS.neutral })],
        components: [],
      });
    }

    return ctx.panel('mod');
  },
};
