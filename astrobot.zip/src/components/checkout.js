import { ValidationError } from '../core/errors.js';
import { startProTrial, trialForGuild } from '../services/plan-service.js';
import { relativeTimestamp } from '../utils/format.js';

/** Checkout buttons: the one-time Pro trial. */
export default {
  id: 'checkout',
  access: 'admin',
  async execute(ctx) {
    const [action] = ctx.args;

    if (action === 'trial') {
      if (trialForGuild(ctx.guildId)) {
        throw new ValidationError('This server has already used its 14-day Pro trial.');
      }
      const plan = startProTrial({ guildId: ctx.guildId, actorId: ctx.userId });
      return ctx.panel('checkout', {
        notice: `🎁 Pro trial started. This server has every Pro feature until ${relativeTimestamp(plan.expiresAt, 'f')}.`,
      });
    }

    return ctx.panel('checkout');
  },
};
