import { modal, customId } from '../ui/components.js';
import { ValidationError } from '../core/errors.js';
import { planHasFeature } from '../services/plan-service.js';
import {
  addDraftCategory,
  addDraftChannel,
  addDraftKit,
  addDraftOverwrite,
  addDraftRole,
  removeDraftEntry,
  removeDraftKit,
  removeDraftOverwrite,
  resetTemplateDraft,
  saveTemplateDraft,
  setDraftCategory,
  templateDraft,
  toggleDraftStaffRole,
} from '../services/template-builder.js';

/** Template editor buttons and modals (owner-authored templates). */
export default {
  id: 'template-editor',
  access: 'admin',
  async execute(ctx) {
    const [action] = ctx.args;

    if (!planHasFeature(ctx.guildId, 'customTemplates')) {
      throw new ValidationError('Building a custom template is a Max feature. Pro includes every built-in and saved template.');
    }

    if (action === 'cancel') {
      resetTemplateDraft(ctx.guildId, ctx.userId);
      return ctx.panel('templates');
    }

    if (action === 'role') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('template-editor', 'role'),
            title: 'Add a role',
            fields: [
              { id: 'name', label: 'Role name', required: true, maxLength: 100 },
              { id: 'color', label: 'Color (hex, blank = none)', placeholder: '#8b5cf6', required: false, maxLength: 7 },
              { id: 'permissions', label: 'Permissions (names or bitfield)', placeholder: 'ManageMessages, KickMembers', required: false, maxLength: 300 },
              { id: 'hoist', label: 'Show separately (yes/no)', placeholder: 'no', required: false, maxLength: 5 },
              { id: 'mentionable', label: 'Mentionable (yes/no)', placeholder: 'no', required: false, maxLength: 5 },
            ],
          }),
        );
      }

      addDraftRole(ctx.guildId, ctx.userId, {
        name: ctx.option('name'),
        color: ctx.option('color'),
        permissions: ctx.option('permissions'),
        hoist: ctx.option('hoist'),
        mentionable: ctx.option('mentionable'),
      });
      return ctx.panel('template-editor');
    }

    if (action === 'category') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('template-editor', 'category'),
            title: 'Add a category',
            fields: [{ id: 'name', label: 'Category name', required: true, maxLength: 100 }],
          }),
        );
      }

      addDraftCategory(ctx.guildId, ctx.userId, { name: ctx.option('name') });
      return ctx.panel('template-editor');
    }

    if (action === 'category-pick') {
      setDraftCategory(ctx.guildId, ctx.userId, ctx.values?.[0]);
      return ctx.panel('template-editor');
    }

    if (action === 'channel') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('template-editor', 'channel'),
            title: 'Add a channel',
            fields: [
              { id: 'name', label: 'Channel name', required: true, maxLength: 100 },
              { id: 'type', label: 'Type: text, voice, announcement, forum', placeholder: 'text', required: false, maxLength: 12 },
              { id: 'topic', label: 'Topic (text channels)', required: false, maxLength: 1024 },
            ],
          }),
        );
      }

      const draft = templateDraft(ctx.guildId, ctx.userId);
      addDraftChannel(ctx.guildId, ctx.userId, {
        name: ctx.option('name'),
        type: ctx.option('type'),
        category: draft.pendingCategory,
        topic: ctx.option('topic'),
      });
      return ctx.panel('template-editor');
    }

    if (action === 'kit') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('template-editor', 'kit'),
            title: 'Add a kit',
            fields: [
              { id: 'name', label: 'Kit name', required: true, maxLength: 60 },
              { id: 'price', label: 'Price in coins', placeholder: '2500', required: false, maxLength: 12 },
              { id: 'command', label: 'RCON command', placeholder: 'inventory.giveto %steamid% kitname 1', required: true, maxLength: 1000 },
            ],
          }),
        );
      }

      addDraftKit(ctx.guildId, ctx.userId, {
        name: ctx.option('name'),
        price: ctx.option('price'),
        command: ctx.option('command'),
      });
      return ctx.panel('template-editor');
    }

    if (action === 'staffrole') {
      toggleDraftStaffRole(ctx.guildId, ctx.userId, ctx.values?.[0]);
      return ctx.panel('template-editor');
    }

    if (action === 'permission') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('template-editor', 'permission'),
            title: 'Channel permissions',
            fields: [
              { id: 'targetType', label: 'Apply to: channel or category', placeholder: 'channel', required: false, maxLength: 8 },
              { id: 'target', label: 'Channel or category name', required: true, maxLength: 100 },
              { id: 'role', label: 'Role name (@everyone allowed)', required: true, maxLength: 100 },
              { id: 'allow', label: 'Allow permissions', placeholder: 'ViewChannel, SendMessages', required: false, maxLength: 300 },
              { id: 'deny', label: 'Deny permissions', placeholder: 'SendMessages', required: false, maxLength: 300 },
            ],
          }),
        );
      }

      addDraftOverwrite(ctx.guildId, ctx.userId, {
        targetType: ctx.option('targetType') || 'channel',
        target: ctx.option('target'),
        role: ctx.option('role'),
        allow: ctx.option('allow'),
        deny: ctx.option('deny'),
      });
      return ctx.panel('template-editor');
    }

    if (action === 'remove') {
      const value = String(ctx.values?.[0] ?? '');
      const [kind, type, entryIndex, overwriteIndex] = value.split(':');
      if (kind === 'overwrite') {
        removeDraftOverwrite(ctx.guildId, ctx.userId, type, entryIndex, overwriteIndex);
      } else if (kind === 'kit') {
        removeDraftKit(ctx.guildId, ctx.userId, type);
      } else {
        removeDraftEntry(ctx.guildId, ctx.userId, kind, type);
      }
      return ctx.panel('template-editor');
    }

    if (action === 'save') {
      if (!ctx.isModal) {
        const draft = templateDraft(ctx.guildId, ctx.userId);
        return ctx.modal(
          modal({
            id: customId('template-editor', 'save'),
            title: draft.editingId ? 'Save template changes' : 'Save template',
            fields: [
              { id: 'name', label: 'Template name', required: true, value: draft.name, maxLength: 60 },
              { id: 'description', label: 'Description (optional)', required: false, value: draft.description ?? '', maxLength: 200 },
            ],
          }),
        );
      }

      const editing = Boolean(templateDraft(ctx.guildId, ctx.userId).editingId);
      const template = saveTemplateDraft({
        guildId: ctx.guildId,
        userId: ctx.userId,
        actorId: ctx.userId,
        name: ctx.option('name'),
        description: ctx.option('description'),
      });

      return ctx.panel('templates', {
        selected: template.id,
        notice: editing
          ? `Updated **${template.name}**. Apply it to push the revised layout to the server.`
          : `Saved **${template.name}**. Apply it from this panel whenever you need the layout.`,
      });
    }

    return ctx.panel('template-editor');
  },
};
