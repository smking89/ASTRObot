import { getGuild, getGuildSettings, patchGuildSetting } from '../db/repositories/guilds.js';
import { getPartnership, updatePartnership } from '../db/repositories/partnerships.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { ValidationError } from '../core/errors.js';
import { uniqueId } from '../utils/random.js';
import { migrateLocalBalances } from '../services/economy-service.js';
import { submitPartnershipRequest } from '../commands/partner/request.js';

async function announcePartnership(ctx, request, networkId) {
  const sourceName = getGuild(request.from_guild_id)?.name ?? 'Partner server';
  const targetName = getGuild(ctx.guildId)?.name ?? 'Partner server';
  const embed = buildEmbed({
    title: '🤝 New partnership',
    color: COLORS.success,
    description: `**${sourceName}** and **${targetName}** are now official partners. Their economies are linked in a shared partner currency network.`,
    fields: [
      { name: 'Server', value: sourceName, inline: true },
      { name: 'Server', value: targetName, inline: true },
      { name: 'Duration', value: request.duration || 'Not specified', inline: true },
      { name: 'Network', value: `\`${networkId}\``, inline: true },
    ],
    footer: `Partnership ${request.id}`,
  });

  for (const guildId of new Set([request.from_guild_id, ctx.guildId])) {
    const settings = getGuildSettings(guildId);
    const channelId = settings.partnerships?.announcementChannelId || settings.channels?.broadcasts;
    if (!channelId) continue;
    try {
      const channel = await ctx.client.channels?.fetch?.(channelId);
      if (channel?.send) await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
    } catch {
      // A missing/deleted announcement channel must not undo an accepted partnership.
    }
  }
}

async function notifyRequester(ctx, request, title, description, color) {
  if (!request.requester_id) return;
  let user = null;
  try {
    user = await ctx.client?.users?.fetch?.(request.requester_id);
  } catch {
    user = null;
  }
  if (!user?.send) return;
  await user
    .send({
      embeds: [
        buildEmbed({
          title,
          color,
          description,
          footer: `Request ${request.id} · ${getGuild(request.to_guild_id)?.name ?? 'partner server'}`,
        }),
      ],
    })
    .catch(() => null);
}

export default {
  id: 'partner',
  access: 'admin',
  async execute(ctx) {
    const [action, requestId] = ctx.args;

    if (action === 'request') return submitPartnershipRequest(ctx);

    const request = getPartnership(requestId);
    if (!request) throw new ValidationError('That partnership request no longer exists.');
    if (request.to_guild_id !== ctx.guildId) {
      throw new ValidationError('This request belongs to another server.');
    }
    if (request.status !== 'pending') {
      throw new ValidationError('That partnership request has already been answered.');
    }

    if (action === 'decline') {
      updatePartnership(request.id, { status: 'declined', respondedBy: ctx.userId });
      await notifyRequester(
        ctx,
        request,
        '❌ Partnership declined',
        `**${getGuild(ctx.guildId)?.name ?? 'The target server'}** declined your partnership request.`,
        COLORS.neutral,
      );
      return ctx.update({
        embeds: [
          buildEmbed({
            title: '❌ Partnership declined',
            color: COLORS.neutral,
            description: `The request from **${request.brand_name}** was declined.`,
            footer: `Request ${request.id}`,
          }),
        ],
        components: [],
      });
    }

    if (action === 'accept') {
      const source = getGuildSettings(request.from_guild_id);
      const target = getGuildSettings(ctx.guildId);
      const sourceNetwork = source.economy?.partnerNetworkId ?? null;
      const targetNetwork = target.economy?.partnerNetworkId ?? null;
      if (sourceNetwork && targetNetwork && sourceNetwork !== targetNetwork) {
        throw new ValidationError('One of these servers is already linked to a different partner network.');
      }

      const networkId = sourceNetwork ?? targetNetwork ?? uniqueId('network');
      const partnerKey = `partner:${networkId}`;
      migrateLocalBalances(request.from_guild_id, partnerKey);
      migrateLocalBalances(ctx.guildId, partnerKey);
      patchGuildSetting(request.from_guild_id, 'economy.partnerNetworkId', networkId, { actorId: ctx.userId });
      patchGuildSetting(request.from_guild_id, 'economy.scope', 'partner', { actorId: ctx.userId });
      patchGuildSetting(ctx.guildId, 'economy.partnerNetworkId', networkId, { actorId: ctx.userId });
      patchGuildSetting(ctx.guildId, 'economy.scope', 'partner', { actorId: ctx.userId });
      updatePartnership(request.id, { status: 'accepted', networkId, respondedBy: ctx.userId });

      await announcePartnership(ctx, request, networkId);
      await notifyRequester(
        ctx,
        request,
        '🤝 Partnership established',
        `**${getGuild(ctx.guildId)?.name ?? 'The target server'}** accepted your partnership. Both servers now share a partner currency network.`,
        COLORS.success,
      );

      return ctx.update({
        embeds: [
          buildEmbed({
            title: '🤝 Partnership established',
            color: COLORS.success,
            description: `**${request.brand_name}** and **${ctx.guild?.name ?? 'this server'}** are now partners. Their partner currency network is linked.`,
            fields: [
              { name: 'Duration', value: request.duration || 'Not specified', inline: true },
              { name: 'Member count at request', value: String(request.member_count), inline: true },
              { name: 'Network', value: `\`${networkId}\``, inline: true },
            ],
            footer: `Request ${request.id} · accepted`,
          }),
        ],
        components: [],
      });
    }

    throw new ValidationError('Unknown partnership action.');
  },
};
