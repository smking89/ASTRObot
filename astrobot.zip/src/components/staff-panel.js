import { MessageFlags, TextInputStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { createTicket } from '../db/repositories/tickets.js';
import { env } from '../config/env.js';
import { modal, customId } from '../ui/components.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { ValidationError } from '../core/errors.js';

/** /staff panel buttons. */
export default {
  id: 'staff',
  access: 'staff',
  async execute(ctx) {
    const [action] = ctx.args;
    const settings = getGuildSettings(ctx.guildId);

    if (action === 'apply') {
      if (!settings.staff.applicationsOpen) throw new ValidationError('Applications are currently closed.');

      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('staff', 'apply'),
            title: 'Staff application',
            fields: [
              { id: 'timezone', label: 'Timezone and availability', required: true, maxLength: 200 },
              { id: 'experience', label: 'Relevant experience', style: TextInputStyle.Paragraph, required: true, maxLength: 800 },
              { id: 'motivation', label: 'Why should we pick you?', style: TextInputStyle.Paragraph, required: true, maxLength: 800 },
            ],
          }),
        );
      }

      const ticket = createTicket({ guildId: ctx.guildId, ownerId: ctx.userId, subject: 'Staff application' });
      const reviewChannel = settings.staff.reviewChannelId
        ? await ctx.guild.channels.fetch(settings.staff.reviewChannelId).catch(() => null)
        : null;

      if (reviewChannel?.isTextBased()) {
        await reviewChannel
          .send({
            embeds: [
              buildEmbed({
                title: `Staff application · ${ctx.user.username}`,
                color: COLORS.brand,
                fields: [
                  { name: 'Timezone', value: String(ctx.option('timezone')).slice(0, 1024) },
                  { name: 'Experience', value: String(ctx.option('experience')).slice(0, 1024) },
                  { name: 'Motivation', value: String(ctx.option('motivation')).slice(0, 1024) },
                  { name: 'Applicant', value: `<@${ctx.userId}> · ticket \`${ticket.id}\`` },
                ],
              }),
            ],
          })
          .catch(() => null);
      }

      return ctx.reply({
        embeds: [buildEmbed({ description: 'Application submitted. The team will review it shortly.', color: COLORS.success })],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (action === 'publish') {
      const channelId = settings.staff.panelChannelId;
      if (!channelId) throw new ValidationError('Set a staff panel channel in `/config staff` first.');

      const channel = await ctx.guild.channels.fetch(channelId).catch(() => null);
      if (!channel?.isTextBased()) throw new ValidationError('The staff panel channel is not writable.');

      await channel.send({
        embeds: [
          buildEmbed({
            title: 'Apply for staff',
            description: 'We are looking for active, fair-minded players to join the team. Press the button below to apply.',
            color: COLORS.brand,
          }),
        ],
        components: [
          {
            type: 1,
            components: [
              { type: 2, style: 3, label: 'Apply now', custom_id: customId('staff', 'apply'), emoji: { name: '📝' } },
            ],
          },
        ],
      });

      return ctx.reply({ embeds: [buildEmbed({ description: 'Apply panel published.', color: COLORS.success })], flags: MessageFlags.Ephemeral });
    }

    if (action === 'recruit') {
      if (!env.discord.officialGuildId) throw new ValidationError('OFFICIAL_GUILD_ID is not configured.');

      const official = await ctx.client.guilds.fetch(env.discord.officialGuildId).catch(() => null);
      const channel = official ? await official.channels.fetch(settings.channels.broadcasts).catch(() => null) : null;

      if (!channel?.isTextBased()) throw new ValidationError('No recruitment destination channel is configured.');

      await channel.send({
        embeds: [
          buildEmbed({
            title: `Staff opening · ${ctx.guild.name}`,
            description: `${ctx.guild.name} is recruiting staff. Apply in the server with \`/staff panel\`.`,
            color: COLORS.gold,
          }),
        ],
      });

      return ctx.reply({ embeds: [buildEmbed({ description: 'Listing published to the recruitment hub.', color: COLORS.success })], flags: MessageFlags.Ephemeral });
    }

    return ctx.panel('staff');
  },
};
