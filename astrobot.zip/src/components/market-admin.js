/** Refresh the marketplace analytics panel in place. */
export default {
  id: 'market-admin',
  access: 'restricted',
  async execute(ctx) {
    if (ctx.args?.[0] === 'refresh') return ctx.panel('market-admin');
    return null;
  },
};
