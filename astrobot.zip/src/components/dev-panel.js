import { MessageFlags } from 'discord.js';
import { approveGuild, getGuild, listGuilds } from '../db/repositories/guilds.js';
import { licenseCounts, listAllLicenses } from '../db/repositories/licenses.js';
import { registry } from '../core/registry.js';
import { runtime } from '../core/runtime.js';
import { modal, customId } from '../ui/components.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { codeBlock, formatDuration, formatNumber, truncate } from '../utils/format.js';
import { ValidationError } from '../core/errors.js';

/** /dev panel buttons. */
export default {
  id: 'dev',
  access: 'developer',
  async execute(ctx) {
    const [action] = ctx.args;

    if (action === 'pending') {
      const pending = listGuilds({ approved: false, limit: 20 });
      return ctx.reply({
        embeds: [
          buildEmbed({
            title: 'Pending guild approvals',
            color: COLORS.warning,
            description:
              truncate(pending.map((guild) => `\`${guild.id}\` · ${guild.name ?? 'unknown'}`).join('\n'), 4000) ||
              'No guilds waiting for approval.',
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (action === 'approve') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('dev', 'approve'),
            title: 'Approve a guild',
            fields: [{ id: 'guild', label: 'Guild ID', value: ctx.guildId ?? '', required: true }],
          }),
        );
      }

      const guildId = String(ctx.option('guild')).replaceAll(/\D/g, '');
      const guild = getGuild(guildId);
      if (!guild) throw new ValidationError('That guild has not installed AstroBot yet.');

      approveGuild(guildId, ctx.userId);
      return ctx.panel('dev', { notice: `Guild \`${guildId}\` approved.` });
    }

    if (action === 'licenses') {
      const licenses = listAllLicenses({ limit: 20 });
      const counts = licenseCounts();
      return ctx.reply({
        embeds: [
          buildEmbed({
            title: 'License inventory',
            color: COLORS.brand,
            description:
              truncate(
                licenses
                  .map((license) => `\`${license.key}\` · ${license.tier} · ${license.status} · ${license.owner_id ? `<@${license.owner_id}>` : 'unassigned'}`)
                  .join('\n'),
                4000,
              ) || 'No licenses issued.',
            fields: [{ name: 'Counts', value: counts.map((row) => `${row.status}: ${row.count}`).join(' · ') || 'none' }],
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (action === 'diagnostics') {
      const memory = process.memoryUsage();
      const connections = runtime.rconManager ? [...runtime.rconManager.connections.values()] : [];

      return ctx.reply({
        embeds: [
          buildEmbed({
            title: 'Diagnostics',
            color: COLORS.info,
            description: codeBlock(
              JSON.stringify(
                {
                  uptime: formatDuration(Date.now() - registry.startedAt),
                  guilds: ctx.client.guilds.cache.size,
                  commands: registry.commands.size,
                  components: registry.components.size,
                  panels: registry.panels.size,
                  sessions: registry.sessions.size,
                  rcon: connections.map((connection) => ({
                    label: connection.label,
                    connected: connection.connected,
                    attempts: connection.attempts,
                  })),
                  memoryMb: {
                    rss: Math.round(memory.rss / 1024 / 1024),
                    heap: Math.round(memory.heapUsed / 1024 / 1024),
                  },
                  node: process.version,
                },
                null,
                2,
              ),
              'json',
            ),
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    return ctx.panel('dev');
  },
};

export { formatNumber };
