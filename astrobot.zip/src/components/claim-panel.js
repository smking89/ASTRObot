import { claimDaily } from '../services/economy-service.js';
import { provideKit } from '../services/kit-service.js';
import { CRATE_ITEMS, VOUCHER_ITEMS, deliverCrateLoot, hasVoucher, openCrate } from '../services/voucher-service.js';
import { formatCoins } from '../utils/format.js';

/** /claim and /battle-pass buttons. */
export default {
  id: 'claim',
  access: 'player',
  async execute(ctx) {
    const [action] = ctx.args;

    if (action === 'voucher') {
      const itemKey = String(ctx.values?.[0] ?? '');
      if (!CRATE_ITEMS.includes(itemKey)) return ctx.panel('claim', { notice: 'That voucher is not a crate.' });
      const result = openCrate(ctx.guildId, ctx.userId, itemKey);
      const delivery = await deliverCrateLoot({ guildId: ctx.guildId, userId: ctx.userId, rewards: result.rewards });
      const loot = result.rewards
        .map((reward) => (reward.kind === 'coins' ? `${formatCoins(reward.quantity)} coins` : `${reward.itemKey.replace('kit:', '')} ×${reward.quantity}`))
        .join(', ');
      const shipped = delivery.delivered ? ` ${delivery.delivered} delivered in game.` : delivery.queued ? ` ${delivery.queued} waiting on a linked gamertag or live server.` : '';
      return ctx.panel('claim', { notice: `Voucher opened: ${loot || 'nothing'}.${shipped}` });
    }

    if (action === 'daily') {
      const result = claimDaily(ctx.guildId, ctx.userId, { member: ctx.member ?? null });

      if (!result.claimed) {
        const notice = result.disabled
          ? 'Daily rewards are turned off on this server.'
          : result.blocked === 'role'
            ? `You need <@&${result.roleId}> to claim daily rewards.`
            : result.blocked === 'level'
              ? `Reach level ${result.minLevel} to claim daily rewards.`
              : `Already claimed today — come back <t:${Math.floor(result.nextAt / 1000)}:R>.`;
        return ctx.panel('claim', { notice });
      }

      const extras = [];
      if (result.roleId) {
        try {
          const member = await ctx.guild.members.fetch(ctx.userId);
          if (!member.roles.cache.has(result.roleId)) await member.roles.add(result.roleId);
          extras.push(`<@&${result.roleId}>`);
        } catch {
          // Missing permission should not hide the coins that were already paid.
        }
      }
      if (result.kit) {
        try {
          await provideKit({ guildId: ctx.guildId, userId: ctx.userId, kit: { name: result.kit, price: 0 }, gamertag: null });
          extras.push(`**${result.kit}** kit`);
        } catch {
          extras.push(`**${result.kit}** kit queued`);
        }
      }

      return ctx.panel('claim', {
        notice: `Daily claimed: ${formatCoins(result.amount)} · streak **${result.streak}** · +${result.bonusXp} XP${extras.length ? ` · ${extras.join(' · ')}` : ''}`,
      });
    }

    if (action === 'crate') {
      const crate = hasVoucher(ctx.guildId, ctx.userId, VOUCHER_ITEMS.weeklyChest)
        ? VOUCHER_ITEMS.weeklyChest
        : VOUCHER_ITEMS.luckyKey;
      const result = openCrate(ctx.guildId, ctx.userId, crate);
      const delivery = await deliverCrateLoot({ guildId: ctx.guildId, userId: ctx.userId, rewards: result.rewards });
      const loot = result.rewards
        .map((reward) => (reward.kind === 'coins' ? `${formatCoins(reward.quantity)} coins` : `${reward.itemKey.replace('kit:', '')} ×${reward.quantity}`))
        .join(', ');
      const shipped = delivery.delivered ? ` ${delivery.delivered} delivered in game.` : delivery.queued ? ` ${delivery.queued} waiting on a linked gamertag or live server.` : '';
      return ctx.panel('claim', { notice: `Crate opened: ${loot || 'nothing'}.${shipped}` });
    }

    if (action === 'pass') return ctx.panel('battle-pass');
    if (action === 'kits') return ctx.panel('player-panel');

    return ctx.panel('claim');
  },
};
