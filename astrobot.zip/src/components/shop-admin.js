import { getGuildSettings, patchGuildSetting } from '../db/repositories/guilds.js';
import { modal, customId } from '../ui/components.js';
import { parseIntStrict } from '../utils/parse.js';
import { ValidationError } from '../core/errors.js';
import { getRustItem, searchRustItems } from '../services/rust-items.js';
import { resetQuickSetup } from '../services/shop-quick-setup.js';
import { formatCoins } from '../utils/format.js';
import { defaultStockValue } from '../services/shop-stock.js';
import { recordStockEvent } from '../db/repositories/shop.js';

/** Keeps the add dialog's price/category/stock while the owner picks between name matches. */
const pendingAdds = new Map();
const pendingKey = (ctx) => `${ctx.guildId}:${ctx.userId}`;

function readStock(value) {
  const raw = String(value ?? '').trim();
  if (raw.length === 0) return null;
  return parseIntStrict(raw, { min: 0, max: 1_000_000, label: 'stock' });
}

function readCategory(value) {
  return String(value ?? '').trim().slice(0, 40) || 'General';
}

function describeStock(stock) {
  return stock === null ? 'unlimited stock' : `${stock} in stock`;
}

/** /shop-panel buttons: quick setup, catalog add, manage, bulk role, remove, advanced. */
export default {
  id: 'shopadm',
  access: 'restricted',
  async execute(ctx) {
    const [action] = ctx.args;
    const products = getGuildSettings(ctx.guildId).shop.products ?? [];

    if (action === 'quick') {
      resetQuickSetup(ctx.guildId, ctx.userId);
      return ctx.panel('shop-quick-setup');
    }

    if (action === 'manage') {
      return ctx.panel('shop-manage', { target: ctx.values?.[0] });
    }

    if (action === 'roleall') {
      return ctx.panel('shop-manage', { target: 'all' });
    }

    if (action === 'add') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('shopadm', 'add'),
            title: 'Add a Rust item to the shop',
            fields: [
              { id: 'query', label: 'Search by item name', placeholder: 'assault rifle', required: true, maxLength: 100 },
              { id: 'price', label: 'Price in coins (0 = free)', placeholder: '250', required: true, maxLength: 20 },
              { id: 'quantity', label: 'Quantity delivered per purchase', placeholder: '1', required: true, maxLength: 10 },
              { id: 'category', label: 'Category', placeholder: 'Weapons', required: false, maxLength: 40 },
              { id: 'stock', label: 'Stock (blank = unlimited)', placeholder: '20', required: false, maxLength: 10 },
            ],
          }),
        );
      }

      const query = String(ctx.option('query') ?? '').trim();
      if (query.length < 2) throw new ValidationError('Type at least two characters so the catalog search can match an item.');

      const details = {
        price: parseIntStrict(ctx.option('price'), { min: 0, max: 10_000_000, label: 'price' }),
        quantity: parseIntStrict(ctx.option('quantity'), { min: 1, max: 1000, label: 'quantity' }),
        category: readCategory(ctx.option('category')),
        // A blank stock field follows the shop-wide default; "unlimited" stays unlimited.
        stock: String(ctx.option('stock') ?? '').trim()
          ? readStock(ctx.option('stock'))
          : defaultStockValue(getGuildSettings(ctx.guildId)),
      };

      const matches = searchRustItems(query, { limit: 25 });
      if (matches.length === 0) {
        throw new ValidationError(
          `No Rust item matches **${query}**. Try part of the display name, for example \`assault rifle\` or \`ak\`.`,
        );
      }

      const listed = new Set(products.map((product) => product.shortname).filter(Boolean));
      const available = matches.filter((item) => !listed.has(item.shortname));

      if (available.length === 0) throw new ValidationError('Every matching item is already in the shop.');
      if (available.length === 1) return addProduct(ctx, products, available[0], details);

      pendingAdds.set(pendingKey(ctx), { ...details, query });
      return ctx.panel('shop-admin', {
        candidates: available.map((item) => item.shortname),
        query,
        ...details,
      });
    }

    if (action === 'pick') {
      const details = pendingAdds.get(pendingKey(ctx));
      if (!details) throw new ValidationError('That item search expired. Run **Add item** again.');

      const item = getRustItem(ctx.values?.[0]);
      if (!item) throw new ValidationError('That item is no longer in the catalog. Search again.');

      pendingAdds.delete(pendingKey(ctx));
      return addProduct(ctx, products, item, details);
    }

    if (action === 'editcat') {
      return ctx.panel('shop-admin', { editCategory: ctx.values?.[0] });
    }

    if (action === 'remove') {
      if (!ctx.isModal) {
        if (products.length === 0) throw new ValidationError('The shop has no products to remove.');
        return ctx.modal(
          modal({
            id: customId('shopadm', 'remove'),
            title: 'Remove a shop product',
            fields: [
              {
                id: 'index',
                label: `Product number (1-${products.length})`,
                placeholder: '1',
                required: true,
                maxLength: 4,
              },
            ],
          }),
        );
      }

      const index = parseIntStrict(ctx.option('index'), { min: 1, max: products.length, label: 'product number' }) - 1;
      const removed = products[index];
      const { settings } = patchGuildSetting(
        ctx.guildId,
        'shop.products',
        products.filter((_, position) => position !== index),
        { actorId: ctx.userId },
      );
      ctx.guildConfig = settings;
      return ctx.panel('shop-admin', { notice: `Removed **${removed.name ?? removed.id}** from the shop.` });
    }

    if (action === 'deleteshop') {
      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('shopadm', 'deleteshop'),
            title: 'Delete this shop?',
            fields: [
              {
                id: 'confirm',
                label: 'Type DELETE to remove every product',
                placeholder: 'DELETE',
                required: true,
                maxLength: 10,
              },
            ],
          }),
        );
      }

      if (String(ctx.option('confirm') ?? '').trim().toUpperCase() !== 'DELETE') {
        throw new ValidationError('Type DELETE to clear the shop.');
      }

      const disabled = patchGuildSetting(ctx.guildId, 'shop.products', [], { actorId: ctx.userId });
      const settings = patchGuildSetting(ctx.guildId, 'shop.enabled', false, { actorId: ctx.userId }).settings;
      ctx.guildConfig = settings;
      return ctx.panel('shop-admin', {
        notice: `Deleted all **${products.length}** products and disabled the shop. Use **Quick setup** or **Add item** to rebuild it.`,
      });
    }

    if (action === 'advanced') {
      return ctx.panel('config', { section: 'shop' });
    }

    return ctx.panel('shop-admin');
  },
};

function addProduct(ctx, products, item, { price, quantity, category, stock }) {
  const product = {
    id: item.shortname,
    name: item.name,
    shortname: item.shortname,
    itemId: item.itemId,
    image: item.image,
    description: item.description,
    stackSize: item.stackSize,
    quantity,
    price,
    category,
    stock,
    requiredRoleId: null,
    coins: 0,
  };

  const { settings } = patchGuildSetting(ctx.guildId, 'shop.products', [...products, product], {
    actorId: ctx.userId,
  });
  ctx.guildConfig = settings;
  recordStockEvent({ guildId: ctx.guildId, productId: product.id, delta: 0, stockAfter: stock, kind: 'created', actorId: ctx.userId });

  return ctx.panel('shop-admin', {
    notice: `Added **${item.name}** to **${category}** — x${quantity} for ${formatCoins(price)}, ${describeStock(stock)}.`,
  });
}
