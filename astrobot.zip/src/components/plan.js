import { getGuild } from '../db/repositories/guilds.js';
import { attachGuildSeat, detachGuildSeat, transferGuildSeat } from '../services/plan-service.js';
import { ValidationError } from '../core/errors.js';

/** Subscription seat buttons and the source-server picker. */
export default {
  id: 'plan',
  access: 'restricted',
  async execute(ctx) {
    const [action] = ctx.args;
    const guild = getGuild(ctx.guildId);
    const isGuildOwner = ctx.guild?.ownerId === ctx.userId;
    const isBillingOwner = guild?.plan_owner_id === ctx.userId;

    if (!isGuildOwner && !isBillingOwner) {
      throw new ValidationError('Only the server owner can manage this subscription.');
    }

    if (action === 'attach') {
      if (!isGuildOwner) throw new ValidationError('Only the server owner can attach a subscription to this server.');
      const result = attachGuildSeat({ guildId: ctx.guildId, userId: ctx.userId });
      return ctx.panel('plan', {
        notice: `✅ **${result.plan.label}** is now active on this server. **${result.summary.used}/${result.summary.seatLimit}** seats are in use.`,
      });
    }

    if (action === 'detach') {
      const summary = detachGuildSeat({ guildId: ctx.guildId, userId: ctx.userId });
      return ctx.panel('plan', {
        notice: `Seat released. This server is back on Basic. **${summary.used}/${summary.seatLimit}** seats are in use.`,
      });
    }

    if (action === 'transfer') {
      if (!isGuildOwner) throw new ValidationError('Only the server owner can move a subscription to this server.');
      return ctx.panel('plan', { transferPicker: true });
    }

    if (action === 'transfer-select') {
      if (!isGuildOwner) throw new ValidationError('Only the server owner can move a subscription to this server.');
      const fromGuildId = String(ctx.values?.[0] ?? '').trim();
      if (!fromGuildId) throw new ValidationError('Choose the server to move the subscription from.');

      const result = transferGuildSeat({ guildId: ctx.guildId, userId: ctx.userId, fromGuildId });
      return ctx.panel('plan', {
        notice: `✅ Moved **${result.plan.label}** from **${result.source.name || result.source.id}** to this server. **${result.summary.used}/${result.summary.seatLimit}** seats are in use.`,
      });
    }

    return ctx.panel('plan');
  },
};
