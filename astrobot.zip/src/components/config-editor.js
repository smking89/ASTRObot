import { TextInputStyle } from 'discord.js';
import { CONFIG_SECTIONS, sectionById } from '../config/settings-schema.js';
import { QUICK_SECTIONS } from '../panels/set.js';
import { patchGuildSetting } from '../db/repositories/guilds.js';
import { getPath } from '../utils/object.js';
import { parseHexColor, parseIntStrict } from '../utils/parse.js';
import { ValidationError } from '../core/errors.js';
import { modal, customId } from '../ui/components.js';
import { formatSettingValue } from '../ui/settings-view.js';
import { economyScopeKey, migrateLocalBalances } from '../services/economy-service.js';
import { formatNumber } from '../utils/format.js';

function resolveSection(panelId, sectionId) {
  if (panelId === 'set') return QUICK_SECTIONS[sectionId] ? { id: sectionId, ...QUICK_SECTIONS[sectionId] } : null;
  const section = sectionById(sectionId);
  return section ? { id: sectionId, ...section } : null;
}

async function refresh(ctx, panelId, sectionId, notice = null) {
  return ctx.panel(panelId, { section: sectionId, notice });
}

export default {
  id: 'cfg',
  access: 'restricted',
  async execute(ctx) {
    const [action, panelId = 'config', sectionId, pathArg] = ctx.args;

    if (action === 'section') {
      return ctx.panel(panelId === 'set' ? 'set' : 'config', { section: sectionId });
    }

    const section = resolveSection(panelId, sectionId);
    if (!section) throw new ValidationError('That settings section no longer exists.');

    const pathValue = pathArg ?? ctx.values?.[0];
    const field = section.fields.find((entry) => entry.path === pathValue);
    if (!field) throw new ValidationError('Unknown setting.');

    if (action === 'field') {
      const current = getPath(ctx.guildConfig, field.path);

      // Channel settings get a native picker instead of a free-text modal, so
      // staff choose from the server's real channels and categories.
      if (field.type === 'channel') {
        return ctx.panel(panelId === 'set' ? 'set' : 'config', { section: sectionId, channelField: field.path });
      }

      if (field.type === 'select') {
        return ctx.panel(panelId === 'set' ? 'set' : 'config', { section: sectionId, choiceField: field.path });
      }

      if (field.type === 'boolean') {
        const { settings } = patchGuildSetting(ctx.guildId, field.path, !current, { actorId: ctx.userId });
        ctx.guildConfig = settings;
        return refresh(ctx, panelId, sectionId, `${field.label} is now ${!current ? 'enabled' : 'disabled'}.`);
      }

      const isLong = field.type === 'json' || field.type === 'text';
      const value = Array.isArray(current) ? current.join(',') : current ?? '';

      return ctx.modal(
        modal({
          id: customId('cfg', 'save', panelId, sectionId, field.path),
          title: `Edit ${field.label}`,
          fields: [
            {
              id: 'value',
              label: field.label,
              style: isLong ? TextInputStyle.Paragraph : TextInputStyle.Short,
              value: typeof value === 'object' ? JSON.stringify(value) : String(value ?? ''),
              placeholder:
                field.type === 'channel'
                  ? 'Channel mention or ID'
                  : field.type === 'role'
                    ? 'Role mentions or IDs, comma separated'
                    : field.type === 'json'
                      ? 'Valid JSON'
                      : field.help ?? 'New value',
              required: field.type !== 'text',
              maxLength: isLong ? 4000 : 100,
            },
          ],
        }),
      );
    }

    if (action === 'choicesave') {
      const selected = String(ctx.values?.[0] ?? '');
      if (!(field.options ?? []).some((option) => option.value === selected)) {
        throw new ValidationError('Choose a value from the dropdown.');
      }
      const { settings } = patchGuildSetting(ctx.guildId, field.path, selected, { actorId: ctx.userId });
      ctx.guildConfig = settings;
      if (field.path === 'economy.scope') migrateLocalBalances(ctx.guildId, economyScopeKey(ctx.guildId, settings));
      return refresh(ctx, panelId, sectionId, `${field.label} saved.`);
    }

    if (action === 'channelsave') {
      const id = String(ctx.values?.[0] ?? '');
      if (!/^\d{17,20}$/.test(id)) throw new ValidationError('Pick a channel from the dropdown.');

      const channel = await ctx.guild.channels.fetch(id).catch(() => null);
      if (!channel) throw new ValidationError('That channel no longer exists.');

      const { settings } = patchGuildSetting(ctx.guildId, field.path, id, { actorId: ctx.userId });
      ctx.guildConfig = settings;
      return refresh(ctx, panelId, sectionId, `${field.label} set to <#${id}>.`);
    }

    if (action === 'cancel') {
      return refresh(ctx, panelId, sectionId);
    }

    if (action === 'save') {
      const raw = ctx.option('value') ?? '';
      const value = coerce(field, raw);
      const { settings } = patchGuildSetting(ctx.guildId, field.path, value, { actorId: ctx.userId });
      ctx.guildConfig = settings;

      return refresh(ctx, panelId, sectionId, `${field.label} saved: ${formatSettingValue(value, field)}`);
    }

    return null;
  },
};

function coerce(field, raw) {
  const value = String(raw ?? '').trim();

  switch (field.type) {
    case 'number': {
      const parsed = parseIntStrict(value, { min: field.min ?? 0, max: field.max ?? Number.MAX_SAFE_INTEGER, label: field.label });
      return parsed;
    }
    case 'boolean':
      return ['true', '1', 'yes', 'on', 'enabled'].includes(value.toLowerCase());
    case 'channel': {
      const id = value.replace(/[<#>]/g, '');
      if (!/^\d{17,20}$/.test(id)) throw new ValidationError('Provide a channel mention or ID.');
      return id;
    }
    case 'role': {
      const ids = value
        .split(/[,\s]+/)
        .map((entry) => entry.replace(/[<@&>]/g, ''))
        .filter(Boolean);
      if (field.multiple) {
        if (ids.some((id) => !/^\d{17,20}$/.test(id))) throw new ValidationError('Provide role mentions or IDs, comma separated.');
        return ids;
      }
      if (!/^\d{17,20}$/.test(ids[0] ?? '')) throw new ValidationError('Provide a role mention or ID.');
      return ids[0];
    }
    case 'color':
      parseHexColor(value);
      return value.startsWith('#') ? value : `#${value}`;
    case 'json':
      try {
        return JSON.parse(value);
      } catch {
        throw new ValidationError('That value is not valid JSON.');
      }
    case 'text':
      return value.slice(0, 4000);
    default:
      return value;
  }
}

export { formatNumber };
