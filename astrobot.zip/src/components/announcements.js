import { TextInputStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import {
  createAnnouncement,
  getAnnouncement,
  removeAnnouncement,
  setAnnouncementChannel,
  setAnnouncementEnabled,
  setAnnouncementTimeZone,
} from '../db/repositories/announcements.js';
import { announcementTimeZone, deliverAnnouncement, nextRunFor, scheduleLabel } from '../services/announcement-service.js';
import { ValidationError } from '../core/errors.js';
import { customId, modal } from '../ui/components.js';
import { runtime } from '../core/runtime.js';
import { formatTimeZone, weekdayOf, zonedParts, zonedTimeToUtc } from '../utils/timezone.js';
import { timeZoneOptions } from '../config/timezones.js';

function parseScheduleDate(value, timeZone = 'UTC') {
  const match = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{1,2}):(\d{2})$/.exec(String(value ?? '').trim());
  if (!match) throw new ValidationError('Use the format YYYY-MM-DD HH:MM, for example 2026-11-14 20:30.');

  const hours = Number(match[4]);
  const minutes = Number(match[5]);
  if (hours > 23 || minutes > 59) throw new ValidationError('That clock time is not valid.');

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const zone = formatTimeZone(timeZone);
  const runAt = zonedTimeToUtc({ year, month, day, hour: hours, minute: minutes }, zone);
  if (!Number.isFinite(runAt)) throw new ValidationError('That date is not valid.');

  // Reject rolled-over dates such as 2026-02-30 instead of silently scheduling
  // the announcement for March, and verify the zone conversion round-trips.
  const check = zonedParts(runAt, zone);
  if (check.year !== year || check.month !== month || check.day !== day || check.hour !== hours || check.minute !== minutes) {
    throw new ValidationError('That calendar date does not exist.');
  }
  if (runAt <= Date.now()) throw new ValidationError('Pick a date and time in the future.');
  return runAt;
}

const plainText = (value) =>
  String(value ?? '')
    .replace(/[*_`~#>]/g, '')
    .replace(/\s+/g, ' ')
    .trim();

/** Announcement scheduler controls. */
export default {
  id: 'announcements',
  access: 'admin',
  async execute(ctx) {
    const [action, id] = ctx.args;

    if (action === 'create') {
      const settings = getGuildSettings(ctx.guildId);
      const guildZone = formatTimeZone(settings.announcements?.timezone);

      if (!ctx.isModal) {
        return ctx.modal(
          modal({
            id: customId('announcements', 'create'),
            title: 'Schedule an announcement',
            fields: [
              {
                id: 'message',
                label: 'Message',
                required: true,
                style: TextInputStyle.Paragraph,
                maxLength: 1800,
                placeholder: 'Double XP weekend starts now — join the server!',
              },
              {
                id: 'datetime',
                label: 'Date & time (YYYY-MM-DD HH:MM)',
                required: true,
                maxLength: 16,
                placeholder: '2026-11-14 20:30',
              },
              {
                type: 'select',
                id: 'repeat',
                label: 'Repeat',
                value: 'once',
                options: [
                  { label: 'Once', value: 'once', description: 'Run this announcement a single time' },
                  { label: 'Every day', value: 'daily', description: 'Repeat at the same clock time each day' },
                  { label: 'Every week', value: 'weekly', description: 'Repeat on the same weekday each week' },
                ],
              },
              {
                type: 'select',
                id: 'target',
                label: 'Deliver to',
                value: 'discord',
                options: [
                  { label: 'Discord only', value: 'discord' },
                  { label: 'In game only', value: 'game', description: 'Send through RCON' },
                  { label: 'Discord and game', value: 'both' },
                ],
              },
              {
                type: 'select',
                id: 'timezone',
                label: 'Time zone',
                value: '__guild__',
                options: timeZoneOptions(guildZone),
              },
            ],
          }),
        );
      }

      const message = String(ctx.option('message') ?? '').trim();
      if (!message) throw new ValidationError('An announcement needs a message.');
      const repeat = String(ctx.option('repeat') ?? 'once').trim().toLowerCase();
      if (!['once', 'daily', 'weekly'].includes(repeat)) {
        throw new ValidationError('Repeat must be once, daily or weekly.');
      }
      const schedule = repeat;
      const target = String(ctx.option('target') ?? 'discord').trim().toLowerCase();
      if (!['discord', 'game', 'both'].includes(target)) {
        throw new ValidationError('Deliver to must be discord, game or both.');
      }
      const inGame = target === 'game' || target === 'both';
      const toDiscord = target === 'discord' || target === 'both';

      const selectedZone = String(ctx.option('timezone') ?? '__guild__');
      const timezone = selectedZone === '__guild__' ? guildZone : formatTimeZone(selectedZone);
      const resolvedZone = timezone;
      const runAt = parseScheduleDate(ctx.option('datetime'), resolvedZone);
      const channelId = toDiscord
        ? settings.announcements?.channelId ?? settings.channels?.broadcasts ?? ctx.channelId ?? null
        : null;

      const announcement = createAnnouncement({
        guildId: ctx.guildId,
        name: message.replace(/\s+/g, ' ').slice(0, 80),
        message,
        channelId,
        inGame,
        rconMessage: inGame ? plainText(message) : null,
        schedule,
        runAt,
        weekdays: schedule === 'weekly' ? [weekdayOf(zonedParts(runAt, resolvedZone))] : [],
        timezone,
        createdBy: ctx.userId,
      });

      const when = `<t:${Math.floor(runAt / 1000)}:F>`;
      return ctx.panel('announcements', {
        selected: announcement.id,
        notice: `Scheduled **${announcement.name}** for ${when} (${scheduleLabel(announcement)} · ${resolvedZone}) to ${
          [toDiscord ? 'Discord' : null, inGame ? 'the game' : null].filter(Boolean).join(' and ') || 'Discord'
        }.`,
      });
    }

    if (action === 'select') {
      return ctx.panel('announcements', { selected: ctx.values?.[0] });
    }

    if (action === 'timezone') {
      const announcement = getAnnouncement(id);
      if (!announcement || announcement.guild_id !== ctx.guildId) throw new ValidationError('That announcement no longer exists.');
      const requested = String(ctx.values?.[0] ?? '');
      const zone =
        requested === '__guild__'
          ? formatTimeZone(getGuildSettings(ctx.guildId).announcements?.timezone)
          : formatTimeZone(requested);

      // Reinterpret the original wall-clock time in the new zone instead of
      // keeping the old UTC instant.
      const wall = zonedParts(Number(announcement.run_at), announcementTimeZone(announcement));
      const runAt = zonedTimeToUtc(wall, zone);
      const updated = { ...announcement, timezone: zone, run_at: runAt };
      const next = announcement.enabled ? nextRunFor(updated) : announcement.next_run_at;
      setAnnouncementTimeZone(announcement.id, zone, runAt, next);

      return ctx.panel('announcements', {
        selected: announcement.id,
        notice: `Time zone set to **${zone}**; the wall-clock time was kept.`,
      });
    }

    if (action === 'channel') {
      const announcement = getAnnouncement(id);
      if (!announcement || announcement.guild_id !== ctx.guildId) throw new ValidationError('That announcement no longer exists.');
      const channelId = ctx.values?.[0];
      if (!channelId) throw new ValidationError('Choose a channel.');
      setAnnouncementChannel(announcement.id, channelId);
      return ctx.panel('announcements', { selected: announcement.id, notice: `Discord channel set to <#${channelId}>.` });
    }

    if (action === 'toggle') {
      const announcement = getAnnouncement(id);
      if (!announcement || announcement.guild_id !== ctx.guildId) throw new ValidationError('That announcement no longer exists.');
      const enabled = !announcement.enabled;
      setAnnouncementEnabled(announcement.id, enabled, enabled ? nextRunFor(announcement) : null);
      return ctx.panel('announcements', {
        selected: announcement.id,
        notice: enabled ? 'Announcement resumed.' : 'Announcement paused.',
      });
    }

    if (action === 'send') {
      const announcement = getAnnouncement(id);
      if (!announcement || announcement.guild_id !== ctx.guildId) throw new ValidationError('That announcement no longer exists.');
      const result = await deliverAnnouncement({
        client: ctx.client,
        rconManager: runtime.rconManager,
        announcement,
        preview: true,
      });
      const targets = [result.discord ? 'Discord' : null, result.game ? 'the game' : null].filter(Boolean);
      return ctx.panel('announcements', {
        selected: announcement.id,
        notice: targets.length > 0 ? `Sent now to ${targets.join(' and ')}.` : 'Nothing was delivered. Check the channel and RCON connection.',
      });
    }

    if (action === 'remove') {
      const announcement = getAnnouncement(id);
      if (!announcement || announcement.guild_id !== ctx.guildId) throw new ValidationError('That announcement no longer exists.');
      removeAnnouncement(announcement.id);
      return ctx.panel('announcements', { notice: `Deleted **${announcement.name}**.` });
    }

    if (action === 'refresh') return ctx.panel('announcements', { selected: id !== 'none' ? id : undefined });
    return ctx.panel('announcements');
  },
};
