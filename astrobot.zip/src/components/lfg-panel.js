import { MessageFlags, TextInputStyle } from 'discord.js';
import { closePost, countOpenByOwner, createPost, getPost, joinPost, leavePost } from '../db/repositories/lfg.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { modal, customId } from '../ui/components.js';
import { parseIntStrict } from '../utils/parse.js';
import { ValidationError } from '../core/errors.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';

/** /lfg panel buttons. */
export default {
  id: 'lfg',
  access: 'player',
  async execute(ctx) {
    const [action, arg] = ctx.args;
    const settings = getGuildSettings(ctx.guildId);
    if (settings.lfg.enabled === false) throw new ValidationError('Looking for Group is disabled in this server.');

    if (action === 'browse') return ctx.panel('lfg');

    if (action === 'view') {
      return ctx.panel('lfg', { postId: ctx.values?.[0] ?? arg });
    }

    if (action === 'create') {
      if (!ctx.isModal) {
        const open = countOpenByOwner(ctx.guildId, ctx.userId);
        if (open >= Number(settings.lfg.maxActivePerUser ?? 3)) {
          throw new ValidationError(`You already have ${open} open listing(s). Close one first.`);
        }

        return ctx.modal(
          modal({
            id: customId('lfg', 'create'),
            title: 'Create a looking-for-group post',
            fields: [
              { id: 'title', label: 'Title', required: true, maxLength: 80 },
              { id: 'description', label: 'Details', style: TextInputStyle.Paragraph, required: false, maxLength: 500 },
              { id: 'players', label: 'Party size (including you)', placeholder: '4', required: true },
              { id: 'platform', label: 'Platform (any/xbox/playstation)', placeholder: 'any', required: false },
            ],
          }),
        );
      }

      const players = parseIntStrict(ctx.option('players'), { min: 2, max: 20, label: 'party size' });
      const platform = ['any', 'xbox', 'playstation'].includes(String(ctx.option('platform')).toLowerCase())
        ? String(ctx.option('platform')).toLowerCase()
        : 'any';

      const post = createPost({
        guildId: ctx.guildId,
        ownerId: ctx.userId,
        title: String(ctx.option('title')).trim(),
        description: ctx.option('description') ?? null,
        platform,
        playersNeeded: players,
      });

      return ctx.panel('lfg', { postId: post.id });
    }

    if (action === 'join') {
      const post = joinPost(arg, ctx.userId);
      return ctx.panel('lfg', { postId: post.id });
    }

    if (action === 'leave') {
      const post = leavePost(arg, ctx.userId);
      return ctx.panel('lfg', { postId: post.id });
    }

    if (action === 'close') {
      const post = getPost(arg);
      if (!post) throw new ValidationError('That listing no longer exists.');
      if (post.owner_id !== ctx.userId) throw new ValidationError('Only the owner can close this listing.');

      closePost(post.id);
      return ctx.panel('lfg');
    }

    return ctx.reply({ content: 'Unknown action.', flags: MessageFlags.Ephemeral });
  },
};

export { buildEmbed, COLORS };
