import { ValidationError } from '../core/errors.js';
import { hasAccess } from '../core/permissions.js';
import { HUB_SETS } from '../config/panel-hub.js';

// Older hub cards pass 'player' or 'admin' as the first argument.
const LEGACY_HUBS = { player: 'hub', admin: 'admin-hub' };

/** Hub dropdown: opens a destination that belongs to this hub at its tier. */
export default {
  id: 'hub',
  access: 'player',
  async execute(ctx) {
    const target = String(ctx.values?.[0] ?? ctx.args?.[0] ?? '').trim();
    const raw = String(ctx.args?.[1] ?? 'hub');
    const hubId = HUB_SETS[raw] ? raw : LEGACY_HUBS[raw] ?? 'hub';
    const hub = HUB_SETS[hubId];

    if (!hub.destinations.some((entry) => entry.id === target)) {
      throw new ValidationError('That panel is not available from this menu.');
    }
    if (!hasAccess(ctx.grants, hub.tier)) throw new ValidationError('That menu is for a higher staff tier.');

    return ctx.panel(target);
  },
};
