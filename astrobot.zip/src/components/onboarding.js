import { MessageFlags } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { getVerification, markVerified } from '../db/repositories/onboarding.js';
import { ValidationError } from '../core/errors.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';

/** Borderwall verification and reaction-role toggles. */
export default {
  id: 'onboarding',
  access: 'player',
  async execute(ctx) {
    const [action, id] = ctx.args;

    if (action === 'verify') {
      const settings = getGuildSettings(ctx.guildId);
      const verification = getVerification(id);
      if (!verification || verification.guild_id !== ctx.guildId || verification.user_id !== ctx.userId) {
        throw new ValidationError('That verification challenge is not yours.');
      }
      if (verification.verified_at) throw new ValidationError('This challenge was already completed.');
      if (Number(verification.expires_at) <= Date.now()) throw new ValidationError('This verification challenge expired. Ask staff for help.');

      const roleId = Array.isArray(settings.onboarding?.borderwall?.verifiedRoleId)
        ? settings.onboarding.borderwall.verifiedRoleId[0]
        : settings.onboarding?.borderwall?.verifiedRoleId;
      if (!roleId) throw new ValidationError('No verified role is configured.');
      const member = await ctx.guild.members.fetch(ctx.userId).catch(() => null);
      if (!member) throw new ValidationError('Could not find your member record.');

      await member.roles.add(roleId, 'Borderwall verification completed').catch(() => {
        throw new ValidationError('The bot cannot give the verified role. Ask staff to check its role position.');
      });
      markVerified(verification.id);
      return ctx.reply({
        embeds: [buildEmbed({ title: '✅ Verified', description: 'You have unlocked the server. Welcome in!', color: COLORS.success })],
        flags: MessageFlags.Ephemeral,
      });
    }

    if (action === 'roles') {
      const settings = getGuildSettings(ctx.guildId);
      const config = settings.onboarding?.reactionRoles;
      if (!config?.enabled) throw new ValidationError('Reaction roles are disabled.');
      const entries = Array.isArray(config.entries) ? config.entries : [];
      const allowed = new Map(entries.map((entry) => [String(entry.roleId), entry]));
      const member = await ctx.guild.members.fetch(ctx.userId).catch(() => null);
      if (!member) throw new ValidationError('Could not find your member record.');

      const requested = new Set((ctx.values ?? []).map(String));
      for (const roleId of requested) {
        if (!allowed.has(roleId)) throw new ValidationError('That role is not part of the role menu.');
      }
      const current = entries.map((entry) => String(entry.roleId)).filter((roleId) => member.roles.cache.has(roleId));
      const toAdd = [...requested].filter((roleId) => !current.includes(roleId));
      const toRemove = current.filter((roleId) => !requested.has(roleId));

      for (const roleId of toAdd) await member.roles.add(roleId, 'Reaction role menu');
      for (const roleId of toRemove) await member.roles.remove(roleId, 'Reaction role menu');
      return ctx.reply({
        embeds: [buildEmbed({ description: `Roles updated: **${requested.size}** selected.`, color: COLORS.success })],
        flags: MessageFlags.Ephemeral,
      });
    }

    return null;
  },
};
