import { AttachmentBuilder } from 'discord.js';
import { basename } from 'node:path';
import { getGameAsset } from '../services/game-asset-service.js';

/**
 * Adds a panel-uploaded game image to a view. A result-specific image wins,
 * falling back to the game cover. Generated attachments (such as the UNO board)
 * are preserved and de-duplicated by filename.
 */
export function withGameArt(payload, { guildId, gameId, outcome = 'cover' } = {}) {
  if (!payload?.embeds?.length || !guildId || !gameId) return payload;

  const asset = getGameAsset(guildId, gameId, outcome) ?? getGameAsset(guildId, gameId, 'cover');
  if (!asset?.file) return payload;

  const name = basename(asset.file);
  const embed = payload.embeds[0];
  // Generated boards (for example the UNO table) own the image slot; their
  // uploaded art becomes the thumbnail instead of replacing the board.
  if (embed.data?.image?.url) embed.setThumbnail(`attachment://${name}`);
  else embed.setImage(`attachment://${name}`);

  const existing = payload.files ?? [];
  const alreadyAttached = existing.some((file) => file?.name === name);
  return {
    ...payload,
    files: alreadyAttached ? existing : [...existing, new AttachmentBuilder(asset.file, { name })],
  };
}
