import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  RoleSelectMenuBuilder,
  LabelBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
} from 'discord.js';
import { COMPONENT_PREFIX } from '../config/constants.js';

// Discord rejects symbols such as `↺` that are not emoji at all. Validate
// locally so a bad panel fails at render time, not as a 50035 API error.
const EMOJI_PATTERN = /\p{Emoji}|\p{Extended_Pictographic}/u;
function assertEmoji(emoji) {
  if (typeof emoji !== 'string' || emoji.length === 0 || emoji.startsWith('<')) return;
  if (!EMOJI_PATTERN.test(emoji)) throw new Error(`Invalid Discord emoji: ${emoji}`);
}

/** Component ids are `ab:<handler>:<args...>`; handlers are loaded from src/components. */
export function customId(handler, ...args) {
  const id = [COMPONENT_PREFIX, handler, ...args.map((arg) => String(arg).replaceAll(':', '-'))].join(':');
  if (id.length > 100) throw new Error(`customId too long (${id.length}): ${id}`);
  return id;
}

export function parseCustomId(raw) {
  const parts = String(raw ?? '').split(':');
  if (parts[0] !== COMPONENT_PREFIX || parts.length < 2) return null;
  const [, handler, ...args] = parts;
  if (!/^[a-z0-9-]{1,20}$/.test(handler)) return null;
  return { handler, args };
}

export function button({ id, label, style = ButtonStyle.Secondary, emoji = null, disabled = false, url = null }) {
  const builder = new ButtonBuilder().setStyle(url ? ButtonStyle.Link : style).setDisabled(disabled);
  if (label) builder.setLabel(String(label).slice(0, 80));
  if (emoji) {
    assertEmoji(emoji);
    builder.setEmoji(emoji);
  }
  if (url) builder.setURL(url);
  else builder.setCustomId(id);
  return builder;
}

export function linkButton({ label, url, emoji = null }) {
  return button({ label, url, emoji });
}

export function row(...components) {
  return new ActionRowBuilder().addComponents(...components.flat().filter(Boolean));
}

export function stringSelect({ id, placeholder, options, min = 1, max = 1, disabled = false }) {
  return new StringSelectMenuBuilder()
    .setCustomId(id)
    .setPlaceholder(placeholder.slice(0, 150))
    .setMinValues(min)
    .setMaxValues(max)
    .setDisabled(disabled)
    .addOptions(
      options.slice(0, 25).map((option) => {
        if (option.emoji) assertEmoji(option.emoji);
        return {
          label: String(option.label).slice(0, 100),
          value: String(option.value).slice(0, 100),
          description: option.description ? String(option.description).slice(0, 100) : undefined,
          emoji: option.emoji || undefined,
          default: option.default ?? false,
        };
      }),
    );
}

export function channelSelect({ id, placeholder, channelTypes = [ChannelType.GuildText], min = 1, max = 1 }) {
  return new ChannelSelectMenuBuilder()
    .setCustomId(id)
    .setPlaceholder(placeholder.slice(0, 150))
    .setMinValues(min)
    .setMaxValues(max)
    .addChannelTypes(...channelTypes);
}

export function roleSelect({ id, placeholder, min = 1, max = 1 }) {
  return new RoleSelectMenuBuilder().setCustomId(id).setPlaceholder(placeholder.slice(0, 150)).setMinValues(min).setMaxValues(max);
}

export function modal({ id, title, fields }) {
  const builder = new ModalBuilder().setCustomId(id).setTitle(title.slice(0, 45));
  for (const field of fields.slice(0, 5)) {
    // Modal select menus must be wrapped in a label component; Discord counts
    // the label as one of the five modal components.
    if (field.type === 'select') {
      const select = new StringSelectMenuBuilder()
        .setCustomId(field.id)
        .setPlaceholder(String(field.placeholder ?? 'Choose an option').slice(0, 150))
        .setMinValues(1)
        .setMaxValues(1)
        .addOptions(
          field.options.slice(0, 25).map((option) => ({
            label: String(option.label).slice(0, 100),
            value: String(option.value).slice(0, 100),
            description: option.description ? String(option.description).slice(0, 100) : undefined,
            default: option.value === field.value,
          })),
        );
      builder.addComponents(new LabelBuilder().setLabel(field.label.slice(0, 45)).setStringSelectMenuComponent(select));
      continue;
    }

    const input = new TextInputBuilder()
      .setCustomId(field.id)
      .setLabel(field.label.slice(0, 45))
      .setStyle(field.style ?? TextInputStyle.Short)
      .setRequired(field.required ?? false);

    if (field.placeholder) input.setPlaceholder(String(field.placeholder).slice(0, 100));
    if (field.value !== undefined && field.value !== null && field.value !== '') input.setValue(String(field.value).slice(0, 4000));
    if (field.maxLength) input.setMaxLength(field.maxLength);
    if (field.minLength) input.setMinLength(field.minLength);

    builder.addComponents(new ActionRowBuilder().addComponents(input));
  }
  return builder;
}

/** Standard navigation row: back / refresh / close. */
export function navRow({ backPanel = null, refreshArgs = [], showRefresh = true, showClose = true, extra = [] } = {}) {
  const buttons = [...extra];
  const refreshTarget = refreshArgs.length > 0 ? refreshArgs : backPanel ? [backPanel] : [];
  if (backPanel) buttons.push(button({ id: customId('nav', 'back', backPanel), label: 'Back', emoji: '↩️' }));
  if (showRefresh) buttons.push(button({ id: customId('nav', 'refresh', ...refreshTarget), label: 'Refresh', emoji: '🔄' }));
  if (showClose) buttons.push(button({ id: customId('nav', 'close'), label: 'Close', emoji: '✖️', style: ButtonStyle.Danger }));
  return row(...buttons);
}

export function paginationRow({ page, pages, handler = 'nav', args = [], id = 'page' }) {
  return row(
    button({ id: customId(handler, 'prev', ...args), emoji: '◀️', disabled: page <= 1 }),
    button({ id: customId(id, 'indicator', `${page}/${pages}`), label: `${page}/${pages}`, disabled: true }),
    button({ id: customId(handler, 'next', ...args), emoji: '▶️', disabled: page >= pages }),
  );
}

export const styles = ButtonStyle;
