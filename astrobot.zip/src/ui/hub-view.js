import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';

/** Shared renderer for every role-specific master hub (owner, admin, mod…). */
export function hubView({
  id,
  title,
  description,
  destinations = [],
  highlights = '',
  footer = 'AstroBot panel',
  color = COLORS.brand,
  buttons = [],
  buttonHandler = 'openpanel-admin',
  backPanel = 'staff-hub',
  refreshArgs = [],
  extraRows = [],
}) {
  const components = [];

  if (destinations.length > 0) {
    components.push(
      row(
        stringSelect({
          id: customId('hub', 'menu', id),
          placeholder: `${title} — choose a destination`,
          options: destinations.slice(0, 25).map((entry) => ({
            label: entry.label,
            value: entry.id,
            description: entry.description,
            emoji: entry.emoji,
          })),
        }),
      ),
    );
  }

  if (buttons.length > 0) {
    components.push(
      row(
        ...buttons.slice(0, 5).map((entry) =>
          button({
            id: customId(buttonHandler, entry.panel),
            label: entry.label,
            emoji: entry.emoji,
            style: entry.style,
          }),
        ),
      ),
    );
  }

  components.push(...extraRows);
  components.push(navRow({ backPanel, refreshArgs: refreshArgs.length > 0 ? refreshArgs : [id] }));

  return {
    embeds: [
      buildEmbed({
        title,
        color,
        description,
        fields: highlights ? [{ name: 'Included', value: highlights, inline: false }] : [],
        footer,
      }),
    ],
    components,
  };
}
