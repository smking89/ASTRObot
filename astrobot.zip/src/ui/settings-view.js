import { ButtonStyle, ChannelType } from 'discord.js';
import { COLORS } from '../config/constants.js';
import { getPath } from '../utils/object.js';
import { truncate, formatNumber } from '../utils/format.js';
import { buildEmbed } from './embeds.js';
import { button, channelSelect, customId, navRow, row, stringSelect } from './components.js';

/** Renders a settings section and its editable field picker. */

export function formatSettingValue(value, field = null) {
  if (value === null || value === undefined || value === '') return '`not set`';
  if (typeof value === 'boolean') return value ? '✅ Enabled' : '❌ Disabled';
  if (typeof value === 'number') return `\`${formatNumber(value)}\``;
  if (Array.isArray(value)) {
    if (value.length === 0) return '`none`';
    if (value.every((entry) => typeof entry === 'string' && /^\d{17,20}$/.test(entry))) {
      const prefix = field?.type === 'role' ? '@&' : '#';
      return value.map((id) => `<${prefix}${id}>`).join(', ');
    }
    return truncate(value.map((entry) => (typeof entry === 'object' ? JSON.stringify(entry) : String(entry))).join(', '), 200);
  }
  if (typeof value === 'object') return `\`${truncate(JSON.stringify(value), 200)}\``;
  return `\`${truncate(String(value), 200)}\``;
}

export function settingsPanelPayload({ ctx, panelId, section, backPanel = null, intro = null, channelField = null, choiceField = null }) {
  const settings = ctx.guildConfig;
  const fields = section.fields.map((field) => ({
    name: field.label,
    value: formatSettingValue(getPath(settings, field.path), field),
    inline: true,
  }));

  const activeField = channelField ? section.fields.find((field) => field.path === channelField) ?? null : null;
  const choice = choiceField ? section.fields.find((field) => field.path === choiceField) ?? null : null;
  const wantsCategory = activeField ? /category/i.test(activeField.path) : false;

  const embed = buildEmbed({
    title: `${section.emoji ?? '⚙️'} ${section.label}`,
    description:
      intro ??
      (activeField
        ? `Choose a ${wantsCategory ? 'category' : 'channel or category'} for **${activeField.label}** from the dropdown.`
        : choice
          ? `Choose a value for **${choice.label}** from the dropdown.`
          : section.description ?? 'Select a setting to edit it.'),
    color: COLORS.brand,
    fields,
    footer: activeField
      ? 'The dropdown lists live server channels — no IDs to type'
      : `${section.fields.length} setting(s) · changes are saved immediately`,
  });

  const controls = [];

  if (choice) {
    controls.push(
      row(
        stringSelect({
          id: customId('cfg', 'choicesave', panelId, section.id, choice.path),
          placeholder: `Choose ${choice.label}`,
          options: (choice.options ?? []).map((option) => ({
            label: option.label,
            value: option.value,
            description: option.description,
          })),
        }),
      ),
      row(
        button({ id: customId('cfg', 'cancel', panelId, section.id), label: 'Cancel', emoji: '↩️' }),
        button({ id: customId('nav', 'close'), label: 'Close', style: ButtonStyle.Danger }),
      ),
    );
    return { embeds: [embed], components: controls };
  }

  if (activeField) {
    controls.push(
      row(
        channelSelect({
          id: customId('cfg', 'channelsave', panelId, section.id, activeField.path),
          placeholder: `Pick a ${wantsCategory ? 'category' : 'channel or category'}`,
          channelTypes: wantsCategory
            ? [ChannelType.GuildCategory]
            : [ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildForum, ChannelType.GuildCategory],
        }),
      ),
      row(
        button({ id: customId('cfg', 'cancel', panelId, section.id), label: 'Cancel', emoji: '↩️' }),
        button({ id: customId('nav', 'close'), label: 'Close', style: ButtonStyle.Danger }),
      ),
    );
    return { embeds: [embed], components: controls };
  }

  controls.push(
    row(
      stringSelect({
        id: customId('cfg', 'field', panelId, section.id),
        placeholder: 'Choose a setting to edit',
        options: section.fields.map((field) => ({
          label: field.label,
          value: field.path,
          description:
            field.type === 'boolean'
              ? `${getPath(settings, field.path) ? 'On' : 'Off'} · click to switch`
              : truncate(`${field.type} · ${getPath(settings, field.path) ?? 'unset'}`, 100),
        })),
      }),
    ),
  );

  if (panelId === 'set') {
    controls.push(
      row(
        button({ id: customId('cfg', 'section', 'set'), label: 'All quick settings', emoji: '⚡' }),
        button({ id: customId('nav', 'close'), label: 'Close', style: ButtonStyle.Danger }),
      ),
    );
  } else {
    controls.push(navRow({ backPanel: backPanel ?? panelId }));
  }

  return { embeds: [embed], components: controls };
}

/** Root panel listing every section. */
export function sectionListPayload({ sections, panelId, title, description, footer, extraRows = [] }) {
  const embed = buildEmbed({
    title,
    description,
    color: COLORS.brand,
    fields: sections.map((section) => ({
      name: `${section.emoji ?? '•'} ${section.label}`,
      value: truncate(section.description ?? `Open ${section.label}`, 200),
      inline: true,
    })),
    footer,
  });

  const controls = [
    row(
      stringSelect({
        id: customId('cfg', 'section', panelId),
        placeholder: 'Open a settings category',
        options: sections.map((section) => ({
          label: section.label,
          value: section.id,
          description: truncate(section.description ?? '', 100),
          emoji: section.emoji,
        })),
      }),
    ),
    ...extraRows,
    navRow({ backPanel: panelId === 'config' ? null : panelId, showRefresh: false }),
  ];

  return { embeds: [embed], components: controls };
}
