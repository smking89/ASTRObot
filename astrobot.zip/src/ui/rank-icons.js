/**
 * Rank icon styles.
 *
 * Style v1 is the clan badge set used by /team. Style v2 is the personal set
 * used by /progression for the level rank and earned badges. Both styles point
 * at real PNG assets (see ui/badge-assets.js), never emoji.
 */
export const RANK_ICON_STYLES = Object.freeze({
  v1: Object.freeze({
    leader: 'leader',
    officer: 'officer',
    member: 'member',
  }),
  v2: Object.freeze({
    stone: 'stone',
    bronze: 'bronze',
    silver: 'silver',
    gold: 'gold',
    diamond: 'diamond',
    elite: 'elite',
    first_blood: 'first_blood',
    hunter: 'hunter',
    survivor: 'survivor',
    banker: 'banker',
    prestige: 'prestige',
  }),
});

export const PERSONAL_RANKS = Object.freeze([
  { key: 'stone', label: 'Stone', minLevel: 1 },
  { key: 'bronze', label: 'Bronze', minLevel: 10 },
  { key: 'silver', label: 'Silver', minLevel: 25 },
  { key: 'gold', label: 'Gold', minLevel: 50 },
  { key: 'diamond', label: 'Diamond', minLevel: 75 },
  { key: 'elite', label: 'Elite', minLevel: 100 },
]);

/** Clan ranks always use style v1; the result is an icon asset key. */
export function clanRankIcon(rank) {
  return RANK_ICON_STYLES.v1[String(rank ?? '').toLowerCase()] ?? RANK_ICON_STYLES.v1.member;
}

/** Personal ranks always use style v2; `icon` is an icon asset key. */
export function personalRank(level) {
  const value = Number(level) || 0;
  const tier = [...PERSONAL_RANKS].reverse().find((entry) => value >= entry.minLevel) ?? PERSONAL_RANKS[0];
  return { ...tier, icon: RANK_ICON_STYLES.v2[tier.key] };
}

export function personalBadgeIcon(badgeId) {
  return RANK_ICON_STYLES.v2[String(badgeId ?? '')] ?? 'member';
}
