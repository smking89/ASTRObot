import { AttachmentBuilder } from 'discord.js';
import { basename, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/**
 * Real PNG rank and badge icons.
 *
 * Discord does not render emoji or SVG inside embed images, so every icon is a
 * PNG that is uploaded with the message and referenced through
 * `attachment://`. Icons live in assets/badges and are imported from the
 * outlined RhosGFX Vector Ranks pack by scripts/import-rank-badges.js.
 */

const ASSET_DIR = fileURLToPath(new URL('../../assets/badges/', import.meta.url));

export const BADGE_ICONS = Object.freeze({
  stone: 'Stone',
  bronze: 'Bronze',
  silver: 'Silver',
  gold: 'Gold',
  diamond: 'Diamond',
  elite: 'Elite',
  first_blood: 'First Blood',
  hunter: 'Hunter',
  survivor: 'Survivor',
  banker: 'Banker',
  prestige: 'Prestige',
  leader: 'Leader',
  officer: 'Officer',
  member: 'Member',
  recruit: 'Recruit',
  veteran: 'Veteran',
  raider: 'Raider',
  scout: 'Scout',
  builder: 'Builder',
  medic: 'Medic',
});

export const BADGE_ICON_KEYS = Object.freeze(Object.keys(BADGE_ICONS));

/** Icons a clan leader may attach to a custom rank. */
export const CLAN_RANK_ICONS = Object.freeze([
  'leader',
  'officer',
  'member',
  'recruit',
  'veteran',
  'raider',
  'scout',
  'builder',
  'medic',
]);

export function hasBadgeIcon(key) {
  return Object.hasOwn(BADGE_ICONS, String(key ?? ''));
}

export function badgeIconPath(key) {
  const name = hasBadgeIcon(key) ? key : 'member';
  return join(ASSET_DIR, `${name}.png`);
}

export function iconAttachment(key) {
  const name = hasBadgeIcon(key) ? key : 'member';
  return new AttachmentBuilder(badgeIconPath(name), { name: `${name}.png` });
}

export function iconUrl(key) {
  const name = hasBadgeIcon(key) ? key : 'member';
  return `attachment://${name}.png`;
}

/** Attachment for a badge definition: a built-in icon or an uploaded file. */
export function badgeAttachment(definition) {
  if (definition?.file) return new AttachmentBuilder(definition.file, { name: basename(definition.file) });
  return iconAttachment(definition?.icon);
}

export function badgeImage(definition) {
  if (definition?.file) return `attachment://${basename(definition.file)}`;
  return iconUrl(definition?.icon);
}

export function iconChoices(keys = BADGE_ICON_KEYS) {
  return keys.map((key) => ({ name: BADGE_ICONS[key], value: key }));
}
