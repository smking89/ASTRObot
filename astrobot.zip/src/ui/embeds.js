import { EmbedBuilder } from 'discord.js';
import { COLORS } from '../config/constants.js';
import { brandFooter, getBrandColor, getBrandLogoUrl } from '../config/branding.js';
import { truncate } from '../utils/format.js';

/** Single source of truth for embed styling across panes, feeds and alerts. */

// Installed by the client on ready: channel name -> channel id. Kept as a
// callback so embeds stay usable before login and in tests.
let channelLookup = null;

export function setEmbedChannelLookup(lookup) {
  channelLookup = typeof lookup === 'function' ? lookup : null;
}

// Marks a slash command, unless it is already inside code, part of a URL or
// wrapped in a Discord mention.
const COMMAND_PATTERN = /(?<![`\w/<>:])\/([a-z][a-z0-9-]{1,31})(?![\w/])/g;
// Matches #channel-name, including emoji and separator characters. Only names
// that exist in the guild are replaced, so #1 and hex colours stay untouched.
const CHANNEL_PATTERN = /(?<![\w<`#])(#[\p{L}\p{N}\p{Extended_Pictographic}\uFE0F・｜_-]{1,80})/gu;

function mapOutsideInlineCode(text, transform) {
  return String(text ?? '')
    .split(/(`[^`]*`)/g)
    .map((part, index) => (index % 2 === 1 ? part : transform(part)))
    .join('');
}

/**
 * Normalises user-facing embed text: slash commands become inline code (the
 * grey boxes Discord uses for commands) and known #channel-name references
 * become clickable channel mentions.
 */
export function formatEmbedText(text) {
  if (text == null) return text;
  // A broken or unavailable channel cache must never stop an embed being sent.
  let channels = null;
  try {
    channels = channelLookup?.() ?? null;
  } catch {
    channels = null;
  }

  return mapOutsideInlineCode(text, (chunk) => {
    let output = chunk.replace(COMMAND_PATTERN, '`/$1`');
    if (channels?.size) {
      output = output.replace(CHANNEL_PATTERN, (match, name) => {
        const id = channels.get(name.slice(1).toLowerCase());
        return id ? `<#${id}>` : match;
      });
    }
    return output;
  });
}

export function buildEmbed({ title = null, description = null, color = COLORS.brand, fields = [], footer = null, thumbnail = null, image = null, author = null, timestamp = true } = {}) {
  const embed = new EmbedBuilder();
  const resolvedColor = color === COLORS.brand ? getBrandColor() : color;
  if (title) embed.setTitle(truncate(formatEmbedText(title), 256));
  if (description) embed.setDescription(truncate(formatEmbedText(description), 4096));
  if (resolvedColor !== null) embed.setColor(resolvedColor);

  if (fields.length > 0) {
    embed.addFields(
      fields.slice(0, 25).map((field) => ({
        name: truncate(formatEmbedText(field.name), 256),
        value: truncate(formatEmbedText(field.value ?? '—'), 1024),
        inline: field.inline ?? false,
      })),
    );
  }

  // Every footer carries the copyright, and the icon is the configured logo
  // (or the bot avatar, which is set once the client is ready).
  const footerText = footer === false ? null : brandFooter(footer);
  const iconURL = getBrandLogoUrl();
  if (footerText) {
    embed.setFooter(iconURL ? { text: truncate(footerText, 2048), iconURL } : { text: truncate(footerText, 2048) });
  }

  // The footer is the one place the brand logo belongs. Some older panels pass
  // the same logo as a thumbnail or author icon; that showed two or three
  // logos on one embed, so suppress the duplicate and keep the footer mark.
  const sameBrand = (url) => Boolean(iconURL && url && String(url).split('?')[0] === String(iconURL).split('?')[0]);
  if (thumbnail && !sameBrand(thumbnail)) embed.setThumbnail(thumbnail);
  if (image && !sameBrand(image)) embed.setImage(image);
  if (author) {
    const nextAuthor = { ...author };
    if (sameBrand(nextAuthor.iconURL)) delete nextAuthor.iconURL;
    embed.setAuthor(nextAuthor);
  }
  if (timestamp) embed.setTimestamp(new Date());
  return embed;
}

export function successEmbed(description, options = {}) {
  return buildEmbed({ description, color: COLORS.success, ...options });
}

export function errorEmbed(description, options = {}) {
  return buildEmbed({ description, color: COLORS.danger, ...options });
}

export function warningEmbed(description, options = {}) {
  return buildEmbed({ description, color: COLORS.warning, ...options });
}

export function infoEmbed(description, options = {}) {
  return buildEmbed({ description, color: COLORS.info, ...options });
}

/** Standard panel shell: title, description and an optional footnote. */
export function panelEmbed({ title, description, fields = [], color = COLORS.brand, footer = null, ...rest }) {
  return buildEmbed({ title, description, fields, color, footer, ...rest });
}

export function statFields(entries, inline = true) {
  return entries.map(([name, value]) => ({ name, value: String(value), inline }));
}
