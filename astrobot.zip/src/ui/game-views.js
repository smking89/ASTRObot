import { AttachmentBuilder, ButtonStyle } from 'discord.js';
import { COLORS, EMOJI } from '../config/constants.js';
import { buildEmbed } from './embeds.js';
import { button, customId, row, stringSelect } from './components.js';
import { formatCoins } from '../utils/format.js';
import { TOWER_FLOORS, currentMultiplier, nextFloor } from '../services/games/tower.js';
import { handValue } from '../services/games/cards.js';
import { playableIndexes, topCard, UNO_COLORS } from '../services/games/uno.js';
import { DEFUSE_SAFE_WIRES, DEFUSE_WIRES } from '../services/games/defuse.js';
import { MINEFIELD_COLUMNS, MINEFIELD_SIZE } from '../services/games/minefield.js';
import { MINES_TILES } from '../services/games/mines.js';
import { SCRATCH_COLUMNS, SCRATCH_SIZE, SCRATCH_THEMES } from '../services/games/scratch.js';
import { PLINKO_MULTIPLIERS, PLINKO_ROWS } from '../services/games/plinko.js';
import { renderUnoImage } from '../services/uno-image.js';
import { cardBackPath as cardBackArtPath, renderBlackjackImage } from '../services/blackjack-image.js';
import { getPref } from '../db/repositories/prefs.js';
import { assetAttachment, assetUrl, gameAssetPath, getGameAsset } from '../services/game-asset-service.js';
import { prizeLine } from '../services/game-prize-service.js';

/** Renders engine state to Discord payloads. Engines stay free of Discord imports. */

const gameId = (...args) => customId('game', ...args);

export async function blackjackView(state, sessionId) {
  const player = handValue(state.player);
  const dealer = handValue(state.dealer);
  const ended = state.status === 'ended';
  const board = await renderBlackjackImage(state).catch(() => null);

  const dealerCards =
    state.status === 'player'
      ? `${state.dealer[0].rank}${state.dealer[0].symbol} 🎴`
      : state.dealer.map((card) => `${card.rank}${card.symbol}`).join(' ');

  const embed = buildEmbed({
    title: `${EMOJI.game} Blackjack`,
    color: ended ? (state.payout > state.wager ? COLORS.success : state.payout === state.wager ? COLORS.info : COLORS.danger) : COLORS.brand,
    fields: [
      { name: `Your hand · ${player.total}${player.soft ? ' soft' : ''}`, value: state.player.map((card) => `${card.rank}${card.symbol}`).join(' '), inline: true },
      { name: `Dealer · ${state.status === 'player' ? `${dealer.total - state.dealer[1].value}+` : dealer.total}`, value: dealerCards, inline: true },
      { name: 'Wager', value: formatCoins(state.wager), inline: true },
    ],
    description: `${state.message ?? 'Hit or stand?'}${prizeLine(state.prize)}`,
    footer: ended ? (state.payout > 0 ? `Paid ${state.payout}` : 'No payout') : 'Aces count as 11 until they bust',
    image: board ? 'attachment://blackjack-board.png' : null,
  });

  const controls = ended
    ? row(button({ id: gameId('bj', 'again', sessionId), label: 'Play again', style: ButtonStyle.Success, emoji: '🔁' }))
    : row(
        button({ id: gameId('bj', 'hit', sessionId), label: 'Hit', style: ButtonStyle.Primary }),
        button({ id: gameId('bj', 'stand', sessionId), label: 'Stand', style: ButtonStyle.Secondary }),
        button({
          id: gameId('bj', 'double', sessionId),
          label: 'Double',
          style: ButtonStyle.Danger,
          disabled: state.player.length !== 2,
        }),
      );

  return {
    embeds: [embed],
    components: [controls],
    files: board ? [new AttachmentBuilder(board, { name: 'blackjack-board.png' })] : [],
  };
}

export function diceView(result) {
  const embed = buildEmbed({
    title: `${EMOJI.game} Dice · ${result.choiceLabel}`,
    color: result.won ? COLORS.success : COLORS.danger,
    description: `${result.dice.map((die) => `🎲 **${die}**`).join(' + ')} = **${result.total}**\n\n${
      result.won ? `You won ${formatCoins(result.payout)}!` : `You lost ${formatCoins(result.wager)}.`
    }${prizeLine(result.prize)}`,
    footer: `${result.multiplier}x payout`,
  });
  return { embeds: [embed], components: [] };
}

export function slotsView(result) {
  const embed = buildEmbed({
    title: `${EMOJI.game} Treasure Slots`,
    color: result.won ? COLORS.gold : COLORS.danger,
    description: `## ${result.reels.join('  ')}\n\n${
      result.won ? `**${result.kind === 'triple' ? 'Three of a kind' : 'Pair'}** · ${result.multiplier}x → ${formatCoins(result.payout)}` : `No match · lost ${formatCoins(result.wager)}`
    }${jackpotLine(result.jackpot)}${prizeLine(result.prize)}`,
    footer: `Wager ${result.wager}`,
  });
  return { embeds: [embed], components: [] };
}

export function wheelView(result) {
  const wheel = '🎡';
  const embed = buildEmbed({
    title: `${EMOJI.game} Spin Wheel`,
    color: result.multiplier > 1 ? COLORS.success : COLORS.danger,
    description: `${wheel} Landed on **${result.segment}**\n\n${
      result.multiplier > 1 ? `You won ${formatCoins(result.payout)}!` : `Returned ${formatCoins(result.payout)}.`
    }${jackpotLine(result.jackpot)}${prizeLine(result.prize)}`,
    footer: `Wager ${result.wager}`,
  });
  return { embeds: [embed], components: [] };
}

export function towerView(state, sessionId) {
  const next = nextFloor(state);
  const multiplier = currentMultiplier(state);
  const climbing = state.status === 'climbing';

  const trail = state.trail.length
    ? state.trail.map((step) => `${step.survived ? '✅' : '💥'} Floor ${step.floor} (${step.survival}%)`).join('\n')
    : 'No floors climbed yet.';

  const embed = buildEmbed({
    title: `${EMOJI.game} Tower Climb`,
    color: state.status === 'fell' ? COLORS.danger : state.status === 'summit' ? COLORS.gold : COLORS.brand,
    description: climbing
      ? `Floor **${state.floor}/${TOWER_FLOORS.length}** · multiplier **${multiplier}x**\nNext floor: **${next?.survival ?? 0}%** survival for **${next?.multiplier ?? 0}x**`
      : state.status === 'fell'
        ? `You fell on floor ${state.floor + 1}. Lost ${formatCoins(state.wager)}.`
        : `Cashed out at **${multiplier}x** for ${formatCoins(state.payout)}.${prizeLine(state.prize)}`,
    fields: [
      { name: 'Climb', value: trail, inline: true },
      { name: 'Wager', value: formatCoins(state.wager), inline: true },
    ],
  });

  const controls = climbing
    ? row(
        button({ id: gameId('tower', 'climb', sessionId), label: next ? `Climb (${next.survival}%)` : 'Climb', style: ButtonStyle.Primary, disabled: !next }),
        button({
          id: gameId('tower', 'cashout', sessionId),
          label: `Cash out ${multiplier}x`,
          style: ButtonStyle.Success,
          disabled: state.floor === 0,
        }),
      )
    : row(button({ id: gameId('tower', 'again', sessionId), label: 'Climb again', style: ButtonStyle.Secondary, emoji: '🔁' }));

  return { embeds: [embed], components: [controls] };
}

function unoCardLabel(card) {
  const value = card.value === 'wild' ? 'WILD' : card.value === 'draw4' ? '+4' : card.value === 'draw2' ? '+2' : card.value === 'skip' ? 'Skip' : card.value === 'reverse' ? 'Reverse' : card.value;
  return card.wild ? `Wild ${value === 'WILD' ? '' : value}`.trim() : `${card.color[0].toUpperCase()}${card.color.slice(1)} ${value}`;
}

export async function unoView(state, sessionId, { guildId = null, userId = null } = {}) {
  const top = topCard(state);
  const playable = playableIndexes(state);
  const pendingWild = state.pendingWildIndex;
  // A guild upload wins; otherwise the player's chosen real card back is used.
  const selectedDeck = guildId && userId ? getPref(guildId, userId, 'cardBack', 'classic') : 'classic';
  const cardBackPath =
    (guildId ? gameAssetPath(guildId, 'uno', 'uno_back') : null) ??
    (selectedDeck === 'custom' ? null : cardBackArtPath(selectedDeck));
  const tablePath = guildId ? gameAssetPath(guildId, 'uno', 'uno_table') : null;
  const cover = guildId ? getGameAsset(guildId, 'uno', 'cover') : null;

  let board = null;
  try {
    board = await renderUnoImage(state, { cardBackPath, tablePath });
  } catch {
    // A canvas failure must not prevent the player from finishing the hand.
  }

  const embed = buildEmbed({
    title: `${EMOJI.game} UNO`,
    color: COLORS.brand,
    description:
      `${state.message ?? ''}\n\n**Pile:** ${top.wild ? '🌈' : top.color === 'red' ? '🔴' : top.color === 'yellow' ? '🟡' : top.color === 'green' ? '🟢' : '🔵'} ${top.value}` +
      `\n**Active color:** ${state.activeColor}\n**Your cards:** ${state.player.length} · **Bot:** ${state.bot.length}${prizeLine(state.prize)}`,
    fields: [
      {
        name: 'Your hand',
        value: state.player.map((card, index) => `${index + 1}. ${unoCardLabel(card)}`).join('\n') || '—',
      },
    ],
    footer: state.status === 'ended'
      ? (state.winner === 'player' ? 'You won!' : 'Bot won')
      : pendingWild != null
        ? 'Choose a color for your wild card'
        : `${playable.length} playable card(s)`,
    image: board ? 'attachment://uno-board.png' : null,
  });

  if (cover) embed.setThumbnail(assetUrl(cover));

  const files = [];
  if (board) files.push(new AttachmentBuilder(board, { name: 'uno-board.png' }));
  if (cover) files.push(assetAttachment(cover));

  if (state.status === 'ended') {
    return {
      embeds: [embed],
      components: [row(button({ id: gameId('uno', 'again', sessionId), label: 'Rematch', style: ButtonStyle.Success }))],
      files,
    };
  }

  const controls = [];
  if (pendingWild != null) {
    controls.push(
      row(
        button({ id: gameId('uno', 'color-red', sessionId), label: 'Red', style: ButtonStyle.Danger }),
        button({ id: gameId('uno', 'color-yellow', sessionId), label: 'Yellow', style: ButtonStyle.Secondary }),
        button({ id: gameId('uno', 'color-green', sessionId), label: 'Green', style: ButtonStyle.Success }),
        button({ id: gameId('uno', 'color-blue', sessionId), label: 'Blue', style: ButtonStyle.Primary }),
        button({ id: gameId('uno', 'cancel-wild', sessionId), label: 'Cancel', style: ButtonStyle.Secondary }),
      ),
    );
  } else if (state.turn === 'player') {
    if (playable.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: gameId('uno', 'card', sessionId),
            placeholder: 'Choose a card to play',
            options: playable.slice(0, 25).map((index) => ({
              label: `${index + 1}. ${unoCardLabel(state.player[index])}`,
              value: String(index),
              description: state.player[index].wild ? 'Choose a color next' : 'Play this card',
            })),
          }),
        ),
      );
    }
    controls.push(row(button({ id: gameId('uno', 'draw', sessionId), label: 'Draw card', style: ButtonStyle.Secondary })));
  }

  return { embeds: [embed], components: controls, files };
}

export function minesView(state, sessionId) {
  const playing = state.status === 'playing';
  const safeTotal = MINES_TILES - state.mineCount;
  const statusText =
    state.status === 'lost'
      ? `💥 You hit a mine on tile **${state.hitIndex + 1}**. Lost ${formatCoins(state.wager)}.`
      : state.status === 'cleared'
        ? `🏆 You cleared every safe tile and won ${formatCoins(state.payout)}.`
        : state.status === 'cashed_out'
          ? `✅ Cashed out at **${state.multiplier.toFixed(2)}x** for ${formatCoins(state.payout)}.`
          : 'Pick a tile. Safe tiles raise the multiplier; cash out whenever you want.';

  const embed = buildEmbed({
    title: `${EMOJI.game} Mines`,
    color: state.status === 'lost' ? COLORS.danger : state.status === 'cleared' ? COLORS.gold : state.status === 'cashed_out' ? COLORS.success : COLORS.brand,
    description: `${statusText}${prizeLine(state.prize)}`,
    fields: [
      { name: 'Mines', value: String(state.mineCount), inline: true },
      { name: 'Safe tiles', value: `${state.safeRevealed}/${safeTotal}`, inline: true },
      { name: 'Multiplier', value: `${state.multiplier.toFixed(2)}x`, inline: true },
      { name: 'Wager', value: formatCoins(state.wager), inline: true },
      { name: 'Payout', value: state.payout > 0 ? formatCoins(state.payout) : '—', inline: true },
    ],
    footer: '20 tiles · 3% house edge · cash out before a mine',
  });

  const tiles = [];
  for (let index = 0; index < MINES_TILES; index += 1) {
    const revealed = state.revealed.includes(index);
    const isMine = state.minePositions.includes(index);
    const isHit = state.hitIndex === index;
    const showMine = isMine && (revealed || state.status === 'lost');
    const emoji = isHit ? '💥' : showMine ? '💣' : revealed ? '💎' : '⬜';
    const style = isHit
      ? ButtonStyle.Danger
      : showMine
        ? ButtonStyle.Danger
        : revealed
          ? ButtonStyle.Success
          : ButtonStyle.Secondary;

    tiles.push(
      button({
        id: gameId('mines', `reveal${index}`, sessionId),
        emoji,
        style,
        disabled: !playing || revealed,
      }),
    );
  }

  const rows = [];
  for (let index = 0; index < tiles.length; index += 5) {
    rows.push(row(tiles.slice(index, index + 5)));
  }

  const action = playing
    ? row(
        button({
          id: gameId('mines', 'cashout', sessionId),
          label: `Cash out ${state.multiplier.toFixed(2)}x`,
          style: ButtonStyle.Success,
          disabled: state.safeRevealed === 0,
        }),
      )
    : row(button({ id: gameId('mines', 'again', sessionId), label: 'Play again', style: ButtonStyle.Secondary, emoji: '🔁' }));

  return { embeds: [embed], components: [...rows, action] };
}

export function defuseView(state, sessionId) {
  const live = state.status === 'live';
  const statusText =
    state.status === 'exploded'
      ? `💥 The bomb was wire **${state.bombIndex + 1}**. Lost ${formatCoins(state.wager)}.`
      : state.status === 'cleared'
        ? `🏆 You cut every safe wire and won ${formatCoins(state.payout)}.`
        : state.status === 'cashed_out'
          ? `✅ Cashed out at **${state.multiplier.toFixed(2)}x** for ${formatCoins(state.payout)}.`
          : 'Cut one wire. The bomb is hidden; safe clips raise the multiplier. Cash out whenever you want.';

  const embed = buildEmbed({
    title: `${EMOJI.game} The Defuse Wire`,
    color: state.status === 'exploded' ? COLORS.danger : state.status === 'cleared' ? COLORS.gold : state.status === 'cashed_out' ? COLORS.success : COLORS.brand,
    description: `${statusText}${prizeLine(state.prize)}`,
    fields: [
      { name: 'Wires left', value: String(DEFUSE_WIRES - state.cuts.length), inline: true },
      { name: 'Safe cuts', value: `${state.safeCuts}/${DEFUSE_SAFE_WIRES}`, inline: true },
      { name: 'Multiplier', value: `${state.multiplier.toFixed(2)}x`, inline: true },
      { name: 'Wager', value: formatCoins(state.wager), inline: true },
      { name: 'Payout', value: state.payout > 0 ? formatCoins(state.payout) : '—', inline: true },
    ],
    footer: '6 wires · 1 bomb · cash out before you cut the wrong one',
  });

  const wires = [];
  for (let index = 0; index < DEFUSE_WIRES; index += 1) {
    const cut = state.cuts.includes(index);
    const exploded = state.explodedIndex === index;
    const revealedBomb = state.status !== 'live' && state.bombIndex === index;
    wires.push(
      button({
        id: gameId('defuse', `cut${index}`, sessionId),
        label: `Wire ${index + 1}`,
        emoji: exploded ? '💥' : revealedBomb ? '💣' : cut ? '🟩' : '🔌',
        style: exploded || revealedBomb ? ButtonStyle.Danger : cut ? ButtonStyle.Success : ButtonStyle.Secondary,
        disabled: !live || cut,
      }),
    );
  }

  const action = live
    ? row(
        button({
          id: gameId('defuse', 'cashout', sessionId),
          label: `Cash out ${state.multiplier.toFixed(2)}x`,
          style: ButtonStyle.Success,
          disabled: state.safeCuts === 0,
        }),
      )
    : row(button({ id: gameId('defuse', 'again', sessionId), label: 'Play again', style: ButtonStyle.Secondary, emoji: '🔁' }));

  return { embeds: [embed], components: [row(wires.slice(0, 3)), row(wires.slice(3)), action] };
}

export function minefieldView(state, sessionId) {
  const playing = state.status === 'playing';
  const safeTotal = MINEFIELD_SIZE - state.mineCount;
  const statusText =
    state.status === 'blown'
      ? `💥 You hit a trap on cell **${state.hitIndex + 1}**. Lost ${formatCoins(state.wager)}.`
      : state.status === 'cleared'
        ? `🏆 You cleared every safe cell and won ${formatCoins(state.payout)}.`
        : state.status === 'cashed_out'
          ? `✅ Cashed out at **${state.multiplier.toFixed(2)}x** for ${formatCoins(state.payout)}.`
          : 'Reveal cells on the 6x6 grid. Stars grow the multiplier; cash out before a trap.';

  const embed = buildEmbed({
    title: `${EMOJI.game} The Grid Minefield`,
    color: state.status === 'blown' ? COLORS.danger : state.status === 'cleared' ? COLORS.gold : state.status === 'cashed_out' ? COLORS.success : COLORS.brand,
    description: `${statusText}${prizeLine(state.prize)}`,
    fields: [
      { name: 'Grid', value: gridText(state), inline: false },
      { name: 'Traps', value: String(state.mineCount), inline: true },
      { name: 'Safe cells', value: `${state.safeRevealed}/${safeTotal}`, inline: true },
      { name: 'Multiplier', value: `${state.multiplier.toFixed(2)}x`, inline: true },
      { name: 'Wager', value: formatCoins(state.wager), inline: true },
      { name: 'Payout', value: state.payout > 0 ? formatCoins(state.payout) : '—', inline: true },
    ],
    footer: '36 cells · 3 hidden traps · 3% house edge',
  });

  const controls = [];
  if (playing) {
    const unrevealed = [...Array(MINEFIELD_SIZE).keys()].filter((index) => !state.revealed.includes(index));
    const first = unrevealed
      .filter((index) => index < 18)
      .map((index) => ({ label: `Cell ${index + 1}`, value: String(index), emoji: '⬜' }));
    const second = unrevealed
      .filter((index) => index >= 18)
      .map((index) => ({ label: `Cell ${index + 1}`, value: String(index), emoji: '⬜' }));

    if (first.length) {
      controls.push(row(stringSelect({ id: gameId('minefield', 'cell-a', sessionId), placeholder: 'Reveal a cell (1–18)', options: first })));
    }
    if (second.length) {
      controls.push(row(stringSelect({ id: gameId('minefield', 'cell-b', sessionId), placeholder: 'Reveal a cell (19–36)', options: second })));
    }
    controls.push(
      row(
        button({
          id: gameId('minefield', 'cashout', sessionId),
          label: `Cash out ${state.multiplier.toFixed(2)}x`,
          style: ButtonStyle.Success,
          disabled: state.safeRevealed === 0,
        }),
      ),
    );
  } else {
    controls.push(row(button({ id: gameId('minefield', 'again', sessionId), label: 'Play again', style: ButtonStyle.Secondary, emoji: '🔁' })));
  }

  return { embeds: [embed], components: controls };
}

function gridText(state) {
  const cells = [];
  for (let index = 0; index < MINEFIELD_SIZE; index += 1) {
    const revealed = state.revealed.includes(index);
    const isMine = state.minePositions.includes(index);
    const showMine = isMine && (revealed || state.status === 'blown');
    cells.push(index === state.hitIndex ? '💥' : showMine ? '💣' : revealed ? '💎' : '⬜');
  }
  return Array.from({ length: MINEFIELD_SIZE / MINEFIELD_COLUMNS }, (_, rowIndex) =>
    cells.slice(rowIndex * MINEFIELD_COLUMNS, (rowIndex + 1) * MINEFIELD_COLUMNS).join(' '),
  ).join('\n');
}

export function crashView(state, sessionId, { history = [], jackpot = null } = {}) {
  const running = state.status === 'running';
  const multiplier = Number(state.multiplier || 1);
  const historyText =
    history.length > 0
      ? history
          .slice(0, 8)
          .map((entry) => `${entry.status === 'crashed' ? '💥' : '🚀'} ${Number(entry.crashPoint).toFixed(2)}x`)
          .join(' · ')
      : 'No rounds yet.';

  const statusText = running
    ? `## 🚀 ${multiplier.toFixed(2)}x\nCash out before the rocket crashes.`
    : state.status === 'cashed_out'
      ? `✅ Cashed out at **${Number(state.cashoutMultiplier ?? multiplier).toFixed(2)}x** for ${formatCoins(state.payout)}.`
      : `💥 Rocket crashed at **${Number(state.crashPoint).toFixed(2)}x**. Lost ${formatCoins(state.wager)}.`;

  const embed = buildEmbed({
    title: `${EMOJI.game} Astro Crash`,
    color: state.status === 'crashed' ? COLORS.danger : state.status === 'cashed_out' ? COLORS.success : COLORS.brand,
    description: `${statusText}${jackpotLine(jackpot)}${prizeLine(state.prize)}`,
    fields: [
      { name: 'Wager', value: formatCoins(state.wager), inline: true },
      { name: 'Auto cash out', value: state.autoCashout ? `${state.autoCashout.toFixed(2)}x` : 'Off', inline: true },
      { name: 'Recent crashes', value: historyText, inline: false },
    ],
    footer: '30-second max round · 3% house edge',
  });

  const controls = running
    ? row(
        button({
          id: gameId('crash', 'cashout', sessionId),
          label: `Cash out ${multiplier.toFixed(2)}x`,
          style: ButtonStyle.Success,
        }),
      )
    : row(button({ id: gameId('crash', 'again', sessionId), label: 'Launch again', style: ButtonStyle.Secondary, emoji: '🔁' }));

  return { embeds: [embed], components: [controls] };
}

export function rouletteView(result) {
  const icon = result.color === 'red' ? '🔴' : result.color === 'black' ? '⚫' : '🟢';
  const embed = buildEmbed({
    title: `${EMOJI.game} Roulette · ${result.betLabel}`,
    color: result.won ? COLORS.success : COLORS.danger,
    description: `The wheel landed on **${result.number}** ${icon}.\n\n${
      result.won
        ? `You won ${formatCoins(result.payout)} on **${result.betLabel}**.`
        : `No win on **${result.betLabel}** · lost ${formatCoins(result.wager)}.`
    }${prizeLine(result.prize)}`,
    footer: `${result.betLabel} · ${result.multiplier}x payout · single-zero wheel`,
  });

  return { embeds: [embed], components: [] };
}

export function plinkoView(result) {
  const path = result.path.map((step) => (step ? '↘️' : '↙️')).join(' ');
  const buckets = PLINKO_MULTIPLIERS.map((value, index) =>
    index === result.bucket ? `**${value}x**` : `${value}x`,
  ).join(' · ');

  const embed = buildEmbed({
    title: `${EMOJI.game} Plinko`,
    color: result.payout > result.wager ? COLORS.success : result.payout > 0 ? COLORS.info : COLORS.danger,
    description: `## ${path}\n\nBucket **${result.multiplier}x**\n\n${buckets}\n\n${
      result.payout > 0 ? `You won ${formatCoins(result.payout)}.` : `No payout · lost ${formatCoins(result.wager)}.`
    }${prizeLine(result.prize)}`,
    footer: `${PLINKO_ROWS} rows · 9 buckets · 2% house edge`,
  });

  return { embeds: [embed], components: [] };
}

export function lootboxView(result) {
  const reward = result.loot;
  const embed = buildEmbed({
    title: `${EMOJI.game} Lootbox`,
    color: result.payout > result.wager ? COLORS.gold : result.payout > 0 ? COLORS.info : COLORS.danger,
    description: `## ${reward.emoji} ${reward.label}\n\n${
      result.payout > 0
        ? `**${result.multiplier}x** → ${formatCoins(result.payout)}`
        : `The crate was empty · lost ${formatCoins(result.wager)}`
    }${prizeLine(result.prize)}`,
    fields: [
      { name: 'Wager', value: formatCoins(result.wager), inline: true },
      { name: 'Drop', value: reward.key, inline: true },
      { name: 'Payout', value: result.payout > 0 ? formatCoins(result.payout) : '—', inline: true },
    ],
    footer: 'Random crate · rare drops can pay up to 100x',
  });
  return { embeds: [embed], components: [] };
}

export function recyclerView(result) {
  const embed = buildEmbed({
    title: `${EMOJI.game} The Recycler Roulette`,
    color: result.won ? COLORS.gold : result.payout > 0 ? COLORS.info : COLORS.danger,
    description: `## ${result.reels.join('   ')}\n\n${
      result.kind === 'triple'
        ? `**Three of a kind** · ${result.multiplier}x → ${formatCoins(result.payout)}`
        : result.kind === 'pair'
          ? `**Pair** · ${result.multiplier}x → ${formatCoins(result.payout)}`
          : `No match · lost ${formatCoins(result.wager)}`
    }${prizeLine(result.prize)}`,
    fields: [
      { name: 'Wager', value: formatCoins(result.wager), inline: true },
      { name: 'Multiplier', value: `${result.multiplier}x`, inline: true },
      { name: 'Payout', value: result.payout > 0 ? formatCoins(result.payout) : '—', inline: true },
    ],
    footer: 'Scrap reels · three cores pay 100x',
  });
  return { embeds: [embed], components: [] };
}

export function rangeView(result) {
  const impacts = new Set(result.impacts);
  const targets = Array.from({ length: 5 }, (_, row) =>
    Array.from({ length: 5 }, (_, column) => (impacts.has(row * 5 + column) ? '🎯' : '⬜')).join(' '),
  ).join('\n');
  const shots = result.shots.map((hit) => (hit ? '✅' : '❌')).join(' ');

  const embed = buildEmbed({
    title: `${EMOJI.game} The Target Range · ${result.weaponLabel}`,
    color: result.hits > 0 ? COLORS.success : COLORS.danger,
    description: `## ${result.hits}/${result.shots.length} hits\n\n**${result.multiplier}x** → ${
      result.payout > 0 ? formatCoins(result.payout) : 'no payout'
    }${prizeLine(result.prize)}`,
    fields: [
      { name: 'Target', value: targets, inline: true },
      { name: 'Shots', value: shots, inline: true },
      { name: 'Wager', value: formatCoins(result.wager), inline: true },
      { name: 'Weapon', value: `${result.weaponLabel} · ${result.accuracy}% accuracy`, inline: true },
    ],
    footer: '5 shots · each hit adds a score multiple',
  });
  return { embeds: [embed], components: [] };
}

export function scratchView(state, sessionId) {
  const theme = SCRATCH_THEMES[state.themeId] ?? SCRATCH_THEMES['scratch-radiation'];
  const playing = state.status === 'playing';
  const remaining = state.maxClicks - state.clickCount;
  const cells = Array.from({ length: SCRATCH_SIZE }, (_, index) =>
    state.revealed[index] ? state.grid[index] : '🔲',
  );
  const card = Array.from({ length: SCRATCH_SIZE / SCRATCH_COLUMNS }, (_, rowIndex) =>
    cells.slice(rowIndex * SCRATCH_COLUMNS, (rowIndex + 1) * SCRATCH_COLUMNS).join(' '),
  ).join('\n');

  const statusText = playing
    ? `Scratch a square and find all three ${theme.target} **${theme.targetLabel}**. The third target ends the card — the earlier you find it, the bigger the multiplier.\n\n**${remaining}** scratch${remaining === 1 ? '' : 'es'} left.`
    : state.status === 'matched'
      ? `## ${theme.target} Match 3\n\nFound all three on scratch **${state.clickCount}** · **${state.multiplier}x** → ${formatCoins(state.payout)}.\n\n${state.won ? 'You beat the house.' : 'The third target came late — this card only returns part of the stake.'}${prizeLine(state.prize)}`
      : `The card ran out before all three ${theme.target} were found. Lost ${formatCoins(state.wager)}.`;

  const embed = buildEmbed({
    title: `${theme.emoji} ${theme.label}`,
    color: state.status === 'lost' ? COLORS.danger : state.won ? COLORS.gold : state.status === 'matched' ? COLORS.info : COLORS.brand,
    description: statusText,
    fields: [
      { name: 'Target', value: `${theme.target} ${theme.targetLabel}`, inline: true },
      { name: 'Scratches', value: `${state.clickCount}/${state.maxClicks}`, inline: true },
      { name: 'Multiplier', value: state.multiplier > 0 ? `${state.multiplier}x` : '—', inline: true },
      { name: 'Card', value: card, inline: false },
      { name: 'Wager', value: formatCoins(state.wager), inline: true },
      { name: 'Payout', value: state.payout > 0 ? formatCoins(state.payout) : '—', inline: true },
    ],
    footer: `${theme.setting} · 9 scratches · earlier match pays more`,
  });

  const controls = [];
  for (let rowIndex = 0; rowIndex < SCRATCH_SIZE / SCRATCH_COLUMNS; rowIndex += 1) {
    const buttons = [];
    for (let column = 0; column < SCRATCH_COLUMNS; column += 1) {
      const index = rowIndex * SCRATCH_COLUMNS + column;
      const revealed = state.revealed[index];
      const target = state.grid[index] === theme.target;
      buttons.push(
        button({
          id: gameId('scratch', `scratch${index}`, sessionId),
          label: String(index + 1),
          emoji: revealed ? state.grid[index] : '🔲',
          style: revealed ? (target ? ButtonStyle.Success : ButtonStyle.Secondary) : ButtonStyle.Primary,
          disabled: !playing || revealed,
        }),
      );
    }
    controls.push(row(buttons));
  }

  if (!playing) {
    controls.push(row(button({ id: gameId('scratch', 'again', sessionId), label: 'New card', style: ButtonStyle.Success, emoji: '🔁' })));
  }

  return { embeds: [embed], components: controls };
}

function jackpotLine(jackpot) {
  return jackpot ? `\n\n💎 **Progressive jackpot!** +${formatCoins(jackpot.amount)}` : '';
}

export function challengeView(challenge, status = 'pending') {
  const label = challenge.game === 'coinflip' ? 'Coin Flip' : 'Dice Duel';
  const embed = buildEmbed({
    title: '⚔️ 1v1 Challenge',
    color: status === 'accepted' ? COLORS.success : COLORS.warning,
    description: `<@${challenge.challengerId}> challenged <@${challenge.opponentId}> to **${label}** for ${formatCoins(challenge.wager)} each.`,
    footer: status === 'pending' ? 'Expires in 15 minutes · winner takes the pot' : status,
  });

  const controls =
    status === 'pending'
      ? [
          row(
            button({ id: gameId('duel', 'accept', challenge.id), label: 'Accept', style: ButtonStyle.Success }),
            button({ id: gameId('duel', 'decline', challenge.id), label: 'Decline', style: ButtonStyle.Danger }),
          ),
        ]
      : [];

  return { embeds: [embed], components: controls };
}
