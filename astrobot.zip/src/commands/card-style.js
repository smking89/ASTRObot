import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('card-style')
    .setDescription('Choose Blackjack/Uno deck artwork or upload your own deck.')
    .setDMPermission(false),
  access: 'player',
  async execute(ctx) {
    await ctx.panel('card-style');
  },
};
