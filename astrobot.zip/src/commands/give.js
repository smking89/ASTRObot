import { SlashCommandBuilder } from 'discord.js';
import { getTeamByName, listMembers } from '../db/repositories/teams.js';
import { assertManualMintAllowed, credit } from '../services/economy-service.js';
import { parseUserId } from '../utils/parse.js';
import { ValidationError } from '../core/errors.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { MessageFlags } from 'discord.js';
import { formatCoins } from '../utils/format.js';

export default {
  data: new SlashCommandBuilder()
    .setName('give')
    .setDescription('Grant coins to a player or an entire clan.')
    .setDMPermission(false)
    .addStringOption((option) =>
      option.setName('target').setDescription('Player @mention, or clan tag with clan enabled').setRequired(true).setMaxLength(40),
    )
    .addIntegerOption((option) =>
      option.setName('amount').setDescription('Coins to grant (per member for clans)').setRequired(true).setMinValue(1).setMaxValue(100_000_000),
    )
    .addBooleanOption((option) => option.setName('clan').setDescription('Treat target as a clan tag instead of a player'))
    .addStringOption((option) => option.setName('reason').setDescription('Audit note').setMaxLength(100)),
  access: 'admin',
  defer: 'ephemeral',
  async execute(ctx) {
    assertManualMintAllowed(ctx.guildId);
    const target = ctx.option('target').trim();
    const amount = ctx.option('amount');
    const reason = ctx.option('reason');
    const clanTarget = Boolean(ctx.option('clan'));

    if (clanTarget) {
      const team = getTeamByName(ctx.guildId, target);
      if (!team) throw new ValidationError('No clan with that tag.');

      const members = listMembers(team.id);
      if (members.length === 0) throw new ValidationError('That clan has no members.');

      let total = 0;
      for (const member of members) {
        total += credit({ guildId: ctx.guildId, userId: member.user_id, amount, kind: 'give_clan', respectCap: false }).credited;
      }

      await ctx.edit({
        embeds: [
          buildEmbed({
            description: `Granted ${formatCoins(amount)} to each of **${members.length}** members of **${team.name}** (${formatCoins(total)} total).${reason ? `\nReason: ${reason}` : ''}`,
            color: COLORS.success,
          }),
        ],
      });
      return;
    }

    // Keep the command user-facing: a mention is unambiguous, while a pasted ID
    // is easy to mistype and is not what the option advertises.
    if (/^\d{15,20}$/.test(target)) {
      throw new ValidationError('Mention the player with @ instead of pasting a user ID.');
    }

    const userId = parseUserId(target);
    const result = credit({ guildId: ctx.guildId, userId, amount, kind: 'give', respectCap: false });

    await ctx.edit({
      embeds: [
        buildEmbed({
          description: `Granted ${formatCoins(result.credited)} to <@${userId}>.${reason ? `\nReason: ${reason}` : ''}`,
          color: COLORS.success,
        }),
      ],
    });
  },
};

export { MessageFlags };
