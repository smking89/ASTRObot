import { SlashCommandBuilder } from 'discord.js';
import { runtime } from '../core/runtime.js';
import { getLinkByGamertag, upsertLink } from '../db/repositories/links.js';
import { ValidationError } from '../core/errors.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { MessageFlags } from 'discord.js';
import { sleep } from '../utils/async.js';

/**
 * /link stays a single standalone command (no platform subcommands).
 * The player must be online on a connected server so the gamertag can be verified
 * against the live playerlist before it is stored.
 */
export default {
  data: new SlashCommandBuilder()
    .setName('link')
    .setDescription('Link your Xbox Gamertag or PlayStation Online ID. Must be online on the server.')
    .setDMPermission(false)
    .addStringOption((option) =>
      option
        .setName('platform')
        .setDescription('Console platform')
        .setRequired(true)
        .addChoices(
          { name: 'Xbox', value: 'xbox' },
          { name: 'PlayStation', value: 'playstation' },
        ),
    )
    .addStringOption((option) =>
      option.setName('gamertag').setDescription('Your exact in-game name').setRequired(true).setMaxLength(32),
    ),
  access: 'player',
  defer: 'ephemeral',
  async execute(ctx) {
    const platform = ctx.option('platform');
    const gamertag = ctx.option('gamertag').trim();

    if (!/^[\w .\-[\]]{2,32}$/.test(gamertag)) throw new ValidationError('That gamertag contains unsupported characters.');

    const existing = getLinkByGamertag(ctx.guildId, gamertag);
    if (existing && existing.user_id !== ctx.userId) {
      throw new ValidationError('That gamertag is already linked to another Discord account.');
    }

    const manager = runtime.rconManager;
    const connection = manager?.connectionFor(ctx.guildId);
    if (!connection) throw new ValidationError('No Rust server is connected to this Discord right now. Try again later.');

    await connection.send('playerlist').catch(() => null);
    await sleep(1500);

    const online = manager.online.get(connection.serverId) ?? new Set();
    if (online.size === 0) throw new ValidationError('Could not verify the playerlist — try again in a moment.');
    if (!online.has(gamertag.toLowerCase())) {
      throw new ValidationError(`**${gamertag}** is not online on the server. Join the server first, then run \`/link\`.`);
    }

    upsertLink({ guildId: ctx.guildId, userId: ctx.userId, platform, gamertag });

    await ctx.edit({
      embeds: [
        buildEmbed({
          title: 'Console account linked',
          color: COLORS.success,
          fields: [
            { name: 'Platform', value: platform, inline: true },
            { name: 'Gamertag', value: gamertag, inline: true },
            { name: 'Verified', value: 'Online on server', inline: true },
          ],
          footer: 'Killfeed attribution and playtime rewards are now active',
        }),
      ],
    });
  },
};

export { MessageFlags };
