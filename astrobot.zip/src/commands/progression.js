import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('progression')
    .setDescription('View XP, level, prestige, Astro Score and badges.')
    .setDMPermission(false),
  access: 'player',
  async execute(ctx) {
    await ctx.panel('progression');
  },
};
