import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('shop')
    .setDescription('Browse and purchase from the shop.')
    .setDMPermission(false),
  access: 'player',
  async execute(ctx) {
    await ctx.panel('shop');
  },
};
