import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Open the Games Panel: Blackjack, Crash, Mines, Roulette, Slots and more.')
    .setDMPermission(false),
  access: 'player',
  async execute(ctx) {
    await ctx.panel('play');
  },
};
