import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('astro-panel')
    .setDescription('Open the Astro staff hub: licenses, fleet status, analytics, campaigns and polls.')
    .setDMPermission(false),
  access: 'official',
  async execute(ctx) {
    await ctx.panel('astro-hub');
  },
};
