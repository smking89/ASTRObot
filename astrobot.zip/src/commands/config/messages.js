export default {
  name: 'messages',
  description: 'Configure rotating messages by category.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('config', { section: 'messages' });
  },
};
