export default {
  name: 'template',
  description: 'Set up, save, apply or export server templates.',
  access: 'admin',
  async execute(ctx) {
    await ctx.panel('templates');
  },
};
