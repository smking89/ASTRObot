export default {
  name: 'staff',
  description: 'Configure staff applications, recurring broadcasts and sessions.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('config', { section: 'staff' });
  },
};
