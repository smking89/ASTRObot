export default {
  name: 'battle-pass',
  description: 'Configure Battle Pass levels and rewards.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('config', { section: 'battle-pass' });
  },
};
