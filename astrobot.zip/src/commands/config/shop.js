export default {
  name: 'shop',
  description: 'Configure shops, currencies, products and sales.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('config', { section: 'shop' });
  },
};
