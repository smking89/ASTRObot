export default {
  name: 'killfeed',
  description: 'Configure killfeed display channel and currency rewards.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('config', { section: 'killfeed' });
  },
};
