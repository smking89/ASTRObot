import { SlashCommandStringOption, SlashCommandSubcommandBuilder, AttachmentBuilder } from 'discord.js';
import { exportGuild, importGuild } from '../../services/backup-service.js';

export default {
  name: 'backup',
  description: 'Export or restore server settings and Discord structure.',
  access: 'restricted',
  defer: 'ephemeral',
  configure(sub) {
    sub.addStringOption(
      new SlashCommandStringOption()
        .setName('restore')
        .setDescription('Paste a previously exported configuration JSON to restore it.')
        .setRequired(false)
        .setMaxLength(6000),
    );
  },
  async execute(ctx) {
    const restore = ctx.option('restore');

    if (restore) {
      const result = importGuild(ctx.guildId, restore, { actorId: ctx.userId });
      await ctx.edit({
        content: `Configuration restored${result.exportedAt ? ` from backup exported ${result.exportedAt}` : ''}.`,
        embeds: [],
        components: [],
      });
      return;
    }

    const data = exportGuild(ctx.guildId);
    const file = new AttachmentBuilder(Buffer.from(JSON.stringify(data, null, 2)), {
      name: `astrobot-config-${ctx.guildId}.json`,
    });

    await ctx.edit({
      content: 'Server configuration export. Keep this file safe — it contains channel and role IDs, not RCON passwords.',
      files: [file],
    });
  },
};

export { SlashCommandSubcommandBuilder };
