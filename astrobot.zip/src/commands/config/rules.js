export default {
  name: 'rules',
  description: 'Edit this server’s rules title, text, support channel and footer.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('config', { section: 'rules' });
  },
};
