export default {
  name: 'events',
  description: 'Configure recurring gifts.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('config', { section: 'events' });
  },
};
