export default {
  name: 'features',
  description: 'Turn major bot features on or off with a dropdown.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('config', { section: 'features' });
  },
};
