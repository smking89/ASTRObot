export default {
  name: 'frank',
  description: "Manage Frank's keyword-triggered FAQ answers.",
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('config', { section: 'frank' });
  },
};
