export default {
  name: 'clan',
  description: 'Configure clan tags, rules, ranks and badges.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('config', { section: 'clan' });
  },
};
