export default {
  name: 'economy',
  description: 'Configure auctions, marketplace, referrals and tradeable roles.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('config', { section: 'economy' });
  },
};
