export default {
  name: 'config',
  label: 'Server Configuration',
  description: 'Server configuration: battle pass, shop, economy, staff, killfeed and more.',
  access: 'restricted',
  panel: { id: 'config' },
};
