export default {
  name: 'misc',
  description: 'Configure auto-kits, leaderboards, ORP appearance and playtime coins.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('config', { section: 'misc' });
  },
};
