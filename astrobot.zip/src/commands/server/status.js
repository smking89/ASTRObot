export default {
  name: 'status',
  description: 'Server status and 7-day uptime.',
  access: 'admin',
  async execute(ctx) {
    await ctx.panel('status');
  },
};
