export default {
  name: 'server',
  label: 'Server Management',
  description: 'Server management: connected Rust servers, backups and templates.',
  access: 'admin',
  panel: { id: 'server' },
};
