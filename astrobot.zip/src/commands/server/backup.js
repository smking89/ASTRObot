import { AttachmentBuilder } from 'discord.js';
import { exportGuild, importGuild } from '../../services/backup-service.js';

export default {
  name: 'backup',
  description: 'Export or restore server backups.',
  access: 'admin',
  defer: 'ephemeral',
  configure(sub) {
    sub.addStringOption((option) =>
      option.setName('restore').setDescription('Paste an exported backup JSON to restore it.').setMaxLength(6000),
    );
  },
  async execute(ctx) {
    const restore = ctx.option('restore');

    if (restore) {
      const result = importGuild(ctx.guildId, restore, { actorId: ctx.userId });
      await ctx.edit({ content: `Restored configuration${result.exportedAt ? ` from ${result.exportedAt}` : ''}.`, embeds: [], components: [] });
      return;
    }

    const data = exportGuild(ctx.guildId);
    const file = new AttachmentBuilder(Buffer.from(JSON.stringify(data, null, 2)), {
      name: `astrobot-server-${ctx.guildId}.json`,
    });

    await ctx.edit({ content: 'Server backup export (settings + structure metadata, no RCON passwords).', files: [file] });
  },
};
