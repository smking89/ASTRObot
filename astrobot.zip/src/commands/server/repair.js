import { MessageFlags } from 'discord.js';
import { COLORS } from '../../config/constants.js';
import { buildEmbed } from '../../ui/embeds.js';
import { truncate } from '../../utils/format.js';
import { repairGuildLayout, repairLayoutChoices, resolveRepairLayout, scanGuildLayout } from '../../services/repair-service.js';

/** /server repair: check a layout and re-add anything missing. */
export default {
  name: 'repair',
  description: 'Check and restore missing roles, categories, channels and panels.',
  access: 'admin',
  configure(builder) {
    builder
      .addStringOption((option) =>
        option
          .setName('layout')
          .setDescription('Layout ID or saved template name. Leave empty to list layouts.')
          .setRequired(false),
      )
      .addBooleanOption((option) =>
        option.setName('check_only').setDescription('Only report what is missing; do not repair.').setRequired(false),
      );
  },
  async execute(ctx) {
    const value = String(ctx.option('layout') ?? '').trim();
    const checkOnly = Boolean(ctx.option('check_only'));

    if (!value) {
      const choices = repairLayoutChoices(ctx.guildId);
      const text =
        choices
          .slice(0, 20)
          .map((entry) => `**${entry.id}** · ${entry.name} · ${entry.kind} · ${entry.summary}`)
          .join('\n') || 'No layouts available.';
      return ctx.reply({
        embeds: [
          buildEmbed({
            title: '🧰 Repair a server layout',
            color: COLORS.brand,
            description: `\`/server repair layout:<id>\` checks the layout and restores missing roles, categories, channels and panels.\n\`/server repair layout:<id> check_only:true\` only reports.\n\n${truncate(text, 3500)}`,
            footer: 'Additive repair · nothing is deleted or renamed',
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    const layout = resolveRepairLayout(ctx.guildId, value);
    if (!layout) {
      return ctx.reply({
        content: `No layout matches **${value}**. Run \`/server repair\` without a layout to list the available IDs.`,
        flags: MessageFlags.Ephemeral,
      });
    }

    // Scanning history and creating dozens of roles/channels easily exceeds
    // Discord's three-second acknowledgement window. Acknowledge first, then
    // edit the deferred reply once the work is done.
    await ctx.defer({ ephemeral: true });

    if (checkOnly) {
      const scan = await scanGuildLayout(ctx.guild, layout.template);
      return ctx.reply({
        embeds: [renderScan(layout, scan, null)],
        flags: MessageFlags.Ephemeral,
      });
    }

    const { before, after, result } = await repairGuildLayout({
      guild: ctx.guild,
      template: layout.template,
      actorId: ctx.userId,
    });

    return ctx.reply({
      embeds: [renderScan(layout, before, { after, result })],
      flags: MessageFlags.Ephemeral,
    });
  },
};

function renderScan(layout, before, repaired) {
  const details = [];
  if (before.roles.length) details.push(`**Roles (${before.roles.length})**: ${before.roles.join(', ')}`);
  if (before.categories.length) details.push(`**Categories (${before.categories.length})**: ${before.categories.join(', ')}`);
  if (before.channels.length) {
    details.push(
      `**Channels (${before.channels.length})**: ${before.channels
        .map((channel) => `${channel.parentName ? `${channel.parentName} / ` : ''}${channel.name}`)
        .join(', ')}`,
    );
  }
  if (before.panels.length) {
    details.push(
      `**Panels (${before.panels.length})**: ${before.panels
        .map((panel) => `${panel.type} → ${panel.channelName} (${panel.issue})`)
        .join(', ')}`,
    );
  }

  const fields = [
    {
      name: repaired ? 'Missing before repair' : 'Missing',
      value: truncate(details.join('\n') || 'Nothing missing — every role, category, channel and panel is present.', 1024),
    },
  ];

  if (repaired) {
    const { after, result } = repaired;
    fields.push(
      {
        name: 'Repair result',
        value: truncate(
          [
            `Created ${result.rolesCreated} role(s), ${result.categoriesCreated} category(s) and ${result.channelsCreated} channel(s).`,
            result.panelsPosted ? `Posted or restored ${result.panelsPosted} panel(s).` : 'No panels needed posting.',
            `${after.missing} item(s) still missing.`,
          ].join('\n'),
          1024,
        ),
      },
    );
    if (after.missing > 0) {
      const remaining = [
        ...after.roles.map((name) => `role ${name}`),
        ...after.categories.map((name) => `category ${name}`),
        ...after.channels.map((channel) => `channel ${channel.name}`),
        ...after.panels.map((panel) => `${panel.type} panel (${panel.issue})`),
      ];
      fields.push({ name: 'Still missing', value: truncate(remaining.join(', '), 1024) });
    }
    if (result.errors.length) {
      fields.push({ name: 'Warnings', value: truncate(result.errors.slice(0, 8).join('\n'), 1024) });
    }
  }

  return buildEmbed({
    title: `${repaired ? '🧰 Repaired' : '🔎 Repair check'} · ${layout.name}`,
    color: before.missing === 0 && !repaired ? COLORS.success : COLORS.brand,
    description:
      before.missing === 0
        ? 'This layout is complete.'
        : repaired
          ? 'Missing structure and panels were re-added. Nothing was deleted or renamed.'
          : 'These items are missing. Run the command without `check_only` to restore them.',
    fields,
    footer: 'Additive repair · matched by name, duplicates are skipped',
  });
}
