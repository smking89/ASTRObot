export default {
  name: 'manage',
  description: 'Manage connected Rust Console servers.',
  access: 'admin',
  async execute(ctx) {
    await ctx.panel('server');
  },
};
