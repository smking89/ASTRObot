export default {
  name: 'template',
  description: 'Manage server layouts and templates.',
  access: 'admin',
  async execute(ctx) {
    await ctx.panel('templates');
  },
};
