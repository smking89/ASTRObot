export default {
  name: 'wipe',
  description: 'Schedule BP/full wipes with countdowns, restarts and map rotation.',
  access: 'admin',
  async execute(ctx) {
    await ctx.panel('wipe');
  },
};
