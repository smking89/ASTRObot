import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('checkout')
    .setDescription('Open Astro Pro checkout and see your membership status.')
    .setDMPermission(false),
  access: 'player',
  async execute(ctx) {
    await ctx.panel('checkout');
  },
};
