import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('kit-panel')
    .setDescription('Register kits and manage deliveries from one panel.')
    .setDMPermission(false),
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('kit-panel');
  },
};
