import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('shop-mint')
    .setDescription('Manage currency supply, minting, burning and wallet balance caps.')
    .setDMPermission(false),
  access: 'admin',
  async execute(ctx) {
    await ctx.panel('shop-mint');
  },
};
