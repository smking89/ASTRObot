import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('reaction-roles')
    .setDescription('Post and manage a button/role self-assignment message.')
    .setDMPermission(false),
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('reaction-roles');
  },
};
