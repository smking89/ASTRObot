import { MessageFlags, SlashCommandBuilder } from 'discord.js';
import { registry } from '../core/registry.js';
import { ACCESS_LABELS, hasAccess, resolveGrants } from '../core/permissions.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { getTeamForUser } from '../db/repositories/teams.js';
import { ValidationError } from '../core/errors.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { truncate } from '../utils/format.js';

const LADDER = ['player', 'team', 'staff', 'admin', 'restricted', 'developer'];

/** Lists every command the selected member's roles can actually run. */
export default {
  data: new SlashCommandBuilder()
    .setName('commands')
    .setDescription('List every command your roles can use.')
    .setDMPermission(false)
    .addUserOption((option) =>
      option.setName('member').setDescription('Staff only: preview another member\'s available commands').setRequired(false),
    ),
  access: 'player',
  async execute(ctx) {
    const targetId = ctx.option('member') ?? ctx.userId;
    const self = targetId === ctx.userId;

    if (!self && !ctx.grants?.has?.('staff')) {
      throw new ValidationError('Only staff can preview another member\'s commands.');
    }

    const member = self ? ctx.member : await ctx.guild.members.fetch(targetId).catch(() => null);
    if (!member) throw new ValidationError('That member is no longer in this server.');

    const guildConfig = ctx.guildConfig ?? getGuildSettings(ctx.guildId) ?? null;
    const inTeam = self ? Boolean(ctx.team) : Boolean(getTeamForUser(ctx.guildId, member.id));
    const grants = self && ctx.grants ? ctx.grants : resolveGrants({ member, guild: ctx.guild, guildConfig, inTeam });

    const byTier = new Map();
    for (const command of registry.commands.values()) {
      if (command.name === 'commands') continue;

      const subcommands = command.subcommands ? [...command.subcommands.values()].filter((sub) => hasAccess(grants, sub.access)) : [];
      if (!hasAccess(grants, command.access) && subcommands.length === 0) continue;

      const tier = command.access ?? 'player';
      const lines = byTier.get(tier) ?? [];
      const description = truncate(String(command.data?.description ?? ''), 90);
      if (subcommands.length > 0) {
        lines.push(`\`/${command.name}\`${description ? ` — ${description}` : ''}\n↳ ${subcommands.map((sub) => `**${sub.name}**`).join(', ')}`);
      } else {
        lines.push(`\`/${command.name}\`${description ? ` — ${description}` : ''}`);
      }
      byTier.set(tier, lines);
    }

    const orderedTiers = [...byTier.keys()].sort((a, b) => LADDER.indexOf(a) - LADDER.indexOf(b));
    const fields = orderedTiers.slice(0, 24).map((tier) => ({
      name: ACCESS_LABELS[tier] ?? tier,
      value: truncate(byTier.get(tier).join('\n'), 1024),
    }));

    fields.push({
      name: 'Your access',
      value: [...LADDER, 'official'].filter((tier) => grants.has(tier)).map((tier) => ACCESS_LABELS[tier] ?? tier).join(' · ') || 'Player',
    });

    return ctx.reply({
      embeds: [
        buildEmbed({
          title: `📜 Commands for ${member.user?.username ?? member.displayName ?? 'this member'}`,
          color: COLORS.brand,
          description: self
            ? 'Only commands your current roles unlock are listed. Staff-only tools stay hidden.'
            : `Showing the commands **${member.user?.username ?? 'this member'}** can use from their current roles.`,
          fields: fields.length > 0 ? fields : [{ name: 'No commands', value: 'No commands are available for this member.' }],
          footer: self ? 'Tip: /commands member:<user> lets staff check another role set' : 'Staff preview',
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
