import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('superadmin-panel')
    .setDescription('Open the superadmin hub: developer tools, licenses, fleet, templates and analytics.')
    .setDMPermission(false),
  access: 'developer',
  async execute(ctx) {
    await ctx.panel('superadmin-hub');
  },
};
