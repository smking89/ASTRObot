import { SlashCommandBuilder } from 'discord.js';
import { createChallenge } from '../services/games/challenge.js';
import { challengeView } from '../ui/game-views.js';
import { assertMultiplayerGame, getGameConfig } from '../services/games/game-config.js';
import { ValidationError } from '../core/errors.js';

export default {
  data: new SlashCommandBuilder()
    .setName('challenge')
    .setDescription('Send a 1v1 wagered challenge.')
    .setDMPermission(false)
    .addUserOption((option) => option.setName('player').setDescription('Opponent').setRequired(true))
    .addIntegerOption((option) =>
      option.setName('wager').setDescription('Wager amount').setRequired(true).setMinValue(1).setMaxValue(100_000_000),
    )
    .addStringOption((option) =>
      option
        .setName('game')
        .setDescription('Game to play')
        .addChoices(
          { name: 'Dice duel', value: 'dice' },
          { name: 'Coin flip', value: 'coinflip' },
        ),
    ),
  access: 'player',
  async execute(ctx) {
    const opponent = ctx.option('player');
    const wager = ctx.option('wager');
    const game = ctx.option('game') ?? 'dice';
    const config = getGameConfig(ctx.guildId);

    assertMultiplayerGame(config, game);

    if (wager < config.minWager || wager > config.maxWager) {
      throw new ValidationError(
        `Wager must be between ${config.minWager} and ${config.maxWager} coins.`,
      );
    }

    if (opponent.bot) throw new ValidationError('You cannot challenge a bot.');
    if (String(opponent.id) === String(ctx.userId)) throw new ValidationError('You cannot challenge yourself.');

    const challenge = createChallenge({
      guildId: ctx.guildId,
      channelId: ctx.channelId,
      challengerId: ctx.userId,
      opponentId: opponent.id,
      wager,
      game,
    });

    await ctx.reply({ ...challengeView(challenge), allowedMentions: { users: [opponent.id] } });
  },
};
