import { activateUserLicense, licensePlanLabel, licenseServerLimit } from '../../services/license-service.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';

export default {
  name: 'activate',
  description: 'Activate an AstroBot license.',
  access: 'player',
  configure(sub) {
    sub.addStringOption((option) => option.setName('key').setDescription('License key').setRequired(true).setMaxLength(30));
  },
  async execute(ctx) {
    const license = activateUserLicense({
      key: ctx.option('key').trim().toUpperCase(),
      userId: ctx.userId,
    });

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: 'License activated',
          color: COLORS.success,
          fields: [
            { name: 'Plan', value: licensePlanLabel(license), inline: true },
            { name: 'Status', value: license.status, inline: true },
            { name: 'Server seats', value: String(licenseServerLimit(license)), inline: true },
            { name: 'Where it works', value: 'Any server you own. Run `/plan` to attach one.', inline: false },
          ],
          footer: `${license.key} · owned by ${ctx.userId}`,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
