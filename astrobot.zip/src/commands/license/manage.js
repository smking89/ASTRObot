export default {
  name: 'manage',
  description: 'Manage your license.',
  access: 'player',
  async execute(ctx) {
    await ctx.panel('license');
  },
};
