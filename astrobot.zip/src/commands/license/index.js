export default {
  name: 'license',
  label: 'License Management',
  description: 'License management: activate, manage and transfer AstroBot licenses.',
  access: 'player',
  panel: { id: 'license' },
};
