import { getLicenseByKey } from '../../db/repositories/licenses.js';
import { transferUserLicense } from '../../services/license-service.js';
import { ValidationError } from '../../core/errors.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';

export default {
  name: 'transfer',
  description: 'Transfer your license.',
  access: 'player',
  configure(sub) {
    sub.addStringOption((option) => option.setName('key').setDescription('License key').setRequired(true).setMaxLength(30));
    sub.addUserOption((option) => option.setName('user').setDescription('New owner').setRequired(true));
  },
  async execute(ctx) {
    const key = ctx.option('key').trim().toUpperCase();
    const license = getLicenseByKey(key);

    if (!license) throw new ValidationError('License not found.');
    if (license.owner_id !== ctx.userId) throw new ValidationError('You do not own that license.');
    if (license.status === 'revoked') throw new ValidationError('That license was revoked.');

    const target = ctx.option('user');
    if (target.id === ctx.userId) throw new ValidationError('Choose a different Discord account.');
    transferUserLicense({ licenseId: license.id, newOwnerId: target.id, actorId: ctx.userId });

    await ctx.reply({
      embeds: [
        buildEmbed({
          description: `License transferred to <@${target.id}>. The plan and its server seats now follow their Discord account. They can attach a server with \`/plan\`.`,
          color: COLORS.success,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
