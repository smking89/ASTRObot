import { ChannelType, MessageFlags, SlashCommandBuilder } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { ValidationError } from '../core/errors.js';

export default {
  data: new SlashCommandBuilder()
    .setName('rules')
    .setDescription('Post the server rules embed.')
    .setDMPermission(false)
    .addChannelOption((option) =>
      option
        .setName('channel')
        .setDescription('Channel to post in (default: the configured rules channel or this one)')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
        .setRequired(false),
    )
    .addStringOption((option) =>
      option.setName('text').setDescription('Override the configured rules text').setMaxLength(4000).setRequired(false),
    ),
  access: 'restricted',
  async execute(ctx) {
    const settings = getGuildSettings(ctx.guildId);
    const rules = settings.messages.rules ?? {};

    // A dedicated support channel keeps {support} on the ticket-creation channel
    // without reusing channels.tickets, which is the parent for new tickets.
    const supportChannelId = rules.supportChannelId ?? settings.channels.tickets ?? settings.tickets.categoryId ?? null;
    const support = supportChannelId ? `<#${supportChannelId}>` : '#support';
    const title = String(rules.title || 'Rules').trim();
    const text = String(ctx.option('text') ?? rules.text ?? '')
      .replaceAll('{support}', support)
      .trim();

    if (!text) throw new ValidationError('Set a rules text in /config → Rotating Messages first.');

    const targetId =
      ctx.option('channel') ?? rules.channelId ?? ctx.channel?.id ?? ctx.interaction?.channelId ?? ctx.interaction?.channel?.id ?? null;
    if (!targetId) throw new ValidationError('Choose a channel for the rules embed.');

    const channel = await ctx.client?.channels?.fetch?.(targetId).catch(() => null);
    if (!channel?.isTextBased?.()) throw new ValidationError('That channel cannot receive the rules embed.');

    // The footer carries the copyright and its brand icon. Discord renders
    // that icon at a fixed ~20px regardless of the source image size.
    const embed = buildEmbed({
      title,
      description: text,
      color: COLORS.brand,
      footer: rules.footer || null,
    });

    await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
    return ctx.reply({ content: `Rules posted in <#${channel.id}>.`, flags: MessageFlags.Ephemeral });
  },
};
