import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('bounty')
    .setDescription("Place a currency bounty on a player's head.")
    .setDMPermission(false),
  access: 'player',
  async execute(ctx) {
    await ctx.panel('bounty');
  },
};
