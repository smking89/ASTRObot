import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('giveaway-portal')
    .setDescription('Open the Astro Pro giveaway portal builder and preview links.')
    .setDMPermission(false),
  access: 'admin',
  async execute(ctx) {
    await ctx.panel('giveaway-portal');
  },
};
