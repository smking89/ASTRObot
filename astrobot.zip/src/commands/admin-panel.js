import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('admin-panel')
    .setDescription('Open the administrator hub: announcements, giveaways, polls, config and shop.')
    .setDMPermission(false),
  access: 'admin',
  async execute(ctx) {
    await ctx.panel('admin-hub');
  },
};
