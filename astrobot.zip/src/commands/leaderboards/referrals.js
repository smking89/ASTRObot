export default {
  name: 'referrals',
  description: 'View referral rankings.',
  access: 'player',
  async execute(ctx) {
    await ctx.panel('leaderboards', { metric: 'referrals' });
  },
};
