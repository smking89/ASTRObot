export default {
  name: 'leaderboards',
  label: 'Leaderboards',
  description: 'Competitive rankings: referrals and official AstroBot standings.',
  access: 'player',
  panel: { id: 'leaderboards' },
};
