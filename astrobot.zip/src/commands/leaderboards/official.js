import { METRICS } from '../../panels/leaderboards.js';

export default {
  name: 'official',
  description: 'View official AstroBot competitive leaderboards.',
  access: 'official',
  configure(sub) {
    sub.addStringOption((option) =>
      option
        .setName('metric')
        .setDescription('Leaderboard metric')
        .addChoices(...METRICS.slice(0, 25).map((entry) => ({ name: entry.label, value: entry.id }))),
    );
  },
  async execute(ctx) {
    await ctx.panel('leaderboards', { metric: ctx.option('metric') ?? 'astro_score' });
  },
};
