import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('support')
    .setDescription('Open a support ticket.')
    .setDMPermission(false),
  access: 'player',
  async execute(ctx) {
    await ctx.panel('support');
  },
};
