import { SlashCommandBuilder, MessageFlags } from 'discord.js';
import { getLink, removeLink } from '../db/repositories/links.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { ValidationError } from '../core/errors.js';

export default {
  data: new SlashCommandBuilder()
    .setName('unlink')
    .setDescription('Unlink your gaming account from your Discord account.')
    .setDMPermission(false),
  access: 'player',
  async execute(ctx) {
    const link = getLink(ctx.guildId, ctx.userId);
    if (!link) throw new ValidationError('You do not have a linked console account.');

    removeLink(ctx.guildId, ctx.userId);

    await ctx.reply({
      embeds: [
        buildEmbed({
          description: `Unlinked **${link.gamertag}** (${link.platform}). Playtime rewards and killfeeds will pause until you link again.`,
          color: COLORS.neutral,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
