import { MessageFlags, SlashCommandBuilder } from 'discord.js';
import { featuresPayload } from '../services/panel-deploy.js';

/** Player-facing catalogue of every AstroBot system. */
export default {
  data: new SlashCommandBuilder()
    .setName('features')
    .setDescription('List every AstroBot feature in one place.')
    .setDMPermission(false),
  access: 'player',
  async execute(ctx) {
    return ctx.reply({ ...featuresPayload(), flags: MessageFlags.Ephemeral });
  },
};