export default {
  name: 'channel',
  description: 'Change designated channels.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('set', { section: 'channel' });
  },
};
