export default {
  name: 'style',
  description: 'Change message appearance.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('set', { section: 'style' });
  },
};
