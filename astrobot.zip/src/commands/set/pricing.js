export default {
  name: 'pricing',
  description: 'Change pricing.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('set', { section: 'pricing' });
  },
};
