export default {
  name: 'lfg',
  description: 'Change LFG scope.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('set', { section: 'lfg' });
  },
};
