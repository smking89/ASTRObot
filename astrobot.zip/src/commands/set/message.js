export default {
  name: 'message',
  description: 'Change message content.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('set', { section: 'message' });
  },
};
