export default {
  name: 'set',
  label: 'Quick Settings',
  description: 'Quick settings: pricing, channels, messages, style, roles and LFG scope.',
  access: 'restricted',
  panel: { id: 'set' },
};
