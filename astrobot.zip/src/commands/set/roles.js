export default {
  name: 'roles',
  description: 'Change assigned roles.',
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('set', { section: 'roles' });
  },
};
