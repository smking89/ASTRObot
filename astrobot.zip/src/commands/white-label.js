import { SlashCommandBuilder } from 'discord.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { getBranding, saveBranding } from '../db/repositories/branding.js';
import { createDatabaseBackup } from '../services/database-backup-service.js';

const HEX = /^#[0-9a-f]{6}$/i;

function brandFields(branding) {
  return [
    { name: 'Brand name', value: branding.name, inline: true },
    { name: 'Brand colour', value: branding.colors.brand, inline: true },
    { name: 'Accent colour', value: branding.colors.accent, inline: true },
    {
      name: 'Favicon',
      value: branding.faviconUrl ? `\`${branding.faviconUrl}\`` : 'not set',
      inline: false,
    },
    {
      name: 'Wordmark',
      value: branding.wordmarkUrl ? `\`${branding.wordmarkUrl}\`` : 'not set',
      inline: false,
    },
  ];
}

export default {
  data: new SlashCommandBuilder()
    .setName('white-label')
    .setDescription('Back up the database and rebrand AstroBot (superadmin only).')
    .setDMPermission(false)
    .addStringOption((option) =>
      option.setName('brand-name').setDescription('Display name shown across the bot and dashboard.').setMaxLength(40),
    )
    .addStringOption((option) =>
      option.setName('favicon-url').setDescription('Public https URL (or /path) for the browser favicon.').setMaxLength(500),
    )
    .addStringOption((option) =>
      option.setName('wordmark-url').setDescription('Public https URL (or /path) for the logo/wordmark.').setMaxLength(500),
    )
    .addStringOption((option) =>
      option.setName('brand-color').setDescription('Primary colour as a six-digit hex value, e.g. #e62127.').setMaxLength(7),
    )
    .addStringOption((option) =>
      option.setName('accent-color').setDescription('Accent colour as a six-digit hex value, e.g. #ff4d4d.').setMaxLength(7),
    )
    .addStringOption((option) =>
      option.setName('background-color').setDescription('Dashboard background colour, e.g. #07070d.').setMaxLength(7),
    )
    .addStringOption((option) =>
      option.setName('text-color').setDescription('Dashboard text colour, e.g. #eef0f8.').setMaxLength(7),
    )
    .addBooleanOption((option) => option.setName('reset').setDescription('Reset global branding to the AstroBot defaults.')),
  access: 'developer',
  defer: 'ephemeral',
  async execute(ctx) {
    const current = getBranding();
    const reset = Boolean(ctx.option('reset'));
    const optionValues = {
      brandName: ctx.option('brand-name'),
      faviconUrl: ctx.option('favicon-url'),
      wordmarkUrl: ctx.option('wordmark-url'),
      brandColor: ctx.option('brand-color'),
      accentColor: ctx.option('accent-color'),
      backgroundColor: ctx.option('background-color'),
      textColor: ctx.option('text-color'),
    };
    const supplied = Object.values(optionValues).some((value) => value != null && String(value).trim() !== '');
    if (!reset && !supplied) {
      await ctx.edit({
        embeds: [
          buildEmbed({
            title: '🎨 White-label branding',
            description:
              'Set any of the options below to update the brand. A database backup is created before the first change.',
            fields: brandFields(current),
            footer: 'Superadmin · white-label',
            color: COLORS.brand,
          }),
        ],
      });
      return;
    }

    const patch = {};
    if (optionValues.brandName != null && String(optionValues.brandName).trim()) {
      const name = String(optionValues.brandName).trim();
      if (name.length < 2) throw new Error('Brand name must be at least two characters.');
      patch.name = name;
    }
    for (const [key, value] of [
      ['faviconUrl', optionValues.faviconUrl],
      ['wordmarkUrl', optionValues.wordmarkUrl],
    ]) {
      if (value == null || !String(value).trim()) continue;
      const text = String(value).trim();
      if (!/^(?:https?:\/\/|\/|data:image\/)/i.test(text)) {
        throw new Error(`${key === 'faviconUrl' ? 'Favicon' : 'Wordmark'} must be a public URL or a /path.`);
      }
      patch[key] = text;
    }
    const colors = {};
    for (const [key, value] of [
      ['brand', optionValues.brandColor],
      ['accent', optionValues.accentColor],
      ['background', optionValues.backgroundColor],
      ['text', optionValues.textColor],
    ]) {
      if (value == null || !String(value).trim()) continue;
      const text = String(value).trim();
      if (!HEX.test(text)) throw new Error('Colours must be six-digit hex values such as #e62127.');
      colors[key] = text;
    }
    if (Object.keys(colors).length) patch.colors = colors;
    if (reset) {
      patch.name = 'AstroBot';
      patch.faviconUrl = '';
      patch.wordmarkUrl = '';
      patch.colors = {
        brand: '#e62127',
        accent: '#ff4d4d',
        background: '#07070d',
        text: '#eef0f8',
      };
    }

    const backup = createDatabaseBackup('white-label');
    const next = saveBranding(patch, ctx.userId);
    await ctx.edit({
      embeds: [
        buildEmbed({
          title: '🎨 Branding updated',
          description: `Backup created: \`${backup.name}\` (${Math.max(1, Math.round(backup.bytes / 1024))} KiB).`,
          fields: brandFields(next),
          footer: 'Superadmin · white-label',
          color: COLORS.success,
        }),
      ],
    });
  },
};
