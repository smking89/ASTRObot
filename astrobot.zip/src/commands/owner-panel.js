import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('owner-panel')
    .setDescription('Open the server owner hub: announcements, giveaways, portal, checkout and config.')
    .setDMPermission(false),
  access: 'admin',
  async execute(ctx) {
    await ctx.panel('owner-hub');
  },
};
