import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('onboarding')
    .setDescription('Welcome, verification, auto roles, giveaways and onboarding analytics.')
    .setDMPermission(false),
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('onboarding');
  },
};
