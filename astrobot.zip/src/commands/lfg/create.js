import { countOpenByOwner, createPost } from '../../db/repositories/lfg.js';
import { getGuildSettings } from '../../db/repositories/guilds.js';
import { ValidationError } from '../../core/errors.js';
import { parseIntStrict } from '../../utils/parse.js';

export default {
  name: 'create',
  description: 'Create a Looking for Group post.',
  access: 'player',
  configure(sub) {
    sub.addStringOption((option) => option.setName('title').setDescription('Listing title').setRequired(true).setMaxLength(80));
    sub.addStringOption((option) => option.setName('description').setDescription('Details').setMaxLength(500));
    sub.addIntegerOption((option) => option.setName('players').setDescription('Players needed').setMinValue(2).setMaxValue(20));
    sub.addStringOption((option) =>
      option
        .setName('platform')
        .setDescription('Platform')
        .addChoices(
          { name: 'Any', value: 'any' },
          { name: 'Xbox', value: 'xbox' },
          { name: 'PlayStation', value: 'playstation' },
        ),
    );
    sub.addStringOption((option) =>
      option
        .setName('region')
        .setDescription('Region')
        .addChoices(
          { name: 'Any', value: 'any' },
          { name: 'EU', value: 'eu' },
          { name: 'NA', value: 'na' },
          { name: 'OCE', value: 'oce' },
          { name: 'Asia', value: 'asia' },
        ),
    );
  },
  async execute(ctx) {
    const settings = getGuildSettings(ctx.guildId);
    if (settings.lfg.enabled === false) throw new ValidationError('Looking for Group is disabled in this server.');
    const open = countOpenByOwner(ctx.guildId, ctx.userId);

    if (open >= settings.lfg.maxActivePerUser) {
      throw new ValidationError(`You already have ${open} open listing(s). Close one first.`);
    }

    const players = parseIntStrict(ctx.option('players') ?? settings.lfg.defaultPlayers, {
      min: 2,
      max: 20,
      label: 'players',
    });

    const post = createPost({
      guildId: ctx.guildId,
      ownerId: ctx.userId,
      title: ctx.option('title').trim(),
      description: ctx.option('description') ?? null,
      platform: ctx.option('platform') ?? 'any',
      region: ctx.option('region') ?? 'any',
      playersNeeded: players,
    });

    await ctx.panel('lfg', { postId: post.id });
  },
};
