export default {
  name: 'lfg',
  label: 'Looking for Group',
  description: 'Looking for group: create, browse, manage and close party listings.',
  access: 'player',
  panel: { id: 'lfg' },
};
