import { closePost, getPost, listByOwner } from '../../db/repositories/lfg.js';
import { ValidationError } from '../../core/errors.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';

export default {
  name: 'close',
  description: 'Close your active LFG post.',
  access: 'player',
  configure(sub) {
    sub.addStringOption((option) => option.setName('post').setDescription('Listing id (defaults to your newest)').setMaxLength(40));
  },
  async execute(ctx) {
    const id = ctx.option('post');
    let post = id ? getPost(id.trim()) : listByOwner(ctx.guildId, ctx.userId)[0];

    if (!post) throw new ValidationError('You have no open listing to close.');
    if (post.owner_id !== ctx.userId) throw new ValidationError('That listing is not yours.');

    closePost(post.id);
    await ctx.reply({
      embeds: [buildEmbed({ description: `Closed **${post.title}**.`, color: COLORS.neutral })],
      flags: MessageFlags.Ephemeral,
    });
  },
};
