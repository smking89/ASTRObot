export default {
  name: 'browse',
  description: 'Browse available LFG posts.',
  access: 'player',
  async execute(ctx) {
    await ctx.panel('lfg');
  },
};
