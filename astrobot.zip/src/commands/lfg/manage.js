import { listByOwner } from '../../db/repositories/lfg.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';
import { relativeTimestamp, truncate } from '../../utils/format.js';

export default {
  name: 'manage',
  description: 'Manage your existing LFG posts.',
  access: 'player',
  async execute(ctx) {
    const posts = listByOwner(ctx.guildId, ctx.userId);

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: 'Your LFG listings',
          color: COLORS.brand,
          description:
            truncate(
              posts
                .map((post) => `\`${post.id}\` · **${post.title}** · ${post.filled}/${post.players_needed} · ${relativeTimestamp(post.created_at, 'R')}`)
                .join('\n'),
              4000,
            ) || 'You have no open listings. Create one with `/lfg create`.',
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
