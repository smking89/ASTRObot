import { getTeamForUser, updateTeam } from '../../db/repositories/teams.js';
import { parseHexColor } from '../../utils/parse.js';
import { ValidationError } from '../../core/errors.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';

export default {
  name: 'config',
  description: 'Configure team tags, rules, ranks and badges.',
  access: 'team',
  configure(sub) {
    sub.addStringOption((option) => option.setName('tag').setDescription('New clan tag').setMaxLength(5));
    sub.addStringOption((option) => option.setName('color').setDescription('Hex color, e.g. #8b5cf6').setMaxLength(7));
    sub.addRoleOption((option) => option.setName('role').setDescription('Discord role representing the team'));
  },
  async execute(ctx) {
    const team = getTeamForUser(ctx.guildId, ctx.userId);
    if (!team) throw new ValidationError('You are not in a team.');
    if (team.owner_id !== ctx.userId) throw new ValidationError('Only the team leader can change team settings.');

    const tag = ctx.option('tag');
    const color = ctx.option('color');
    const role = ctx.option('role');

    if (!tag && !color && !role) return ctx.panel('team');

    updateTeam(team.id, {
      tag: tag ? tag.toUpperCase() : team.tag,
      color: color ? parseHexColor(color) : team.color,
      role_id: role?.id ?? team.role_id,
    });

    await ctx.reply({
      embeds: [buildEmbed({ description: 'Team settings updated.', color: COLORS.success })],
      flags: MessageFlags.Ephemeral,
    });
  },
};
