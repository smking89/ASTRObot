export default {
  name: 'team',
  label: 'Team Management',
  description: 'Team management: create, invite, wars and ORP protection zones.',
  access: 'player',
  panel: { id: 'team' },
};
