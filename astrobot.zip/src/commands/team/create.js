import { getGuildSettings } from '../../db/repositories/guilds.js';
import { createTeam, getTeamByName, getTeamForUser } from '../../db/repositories/teams.js';
import { debit } from '../../services/economy-service.js';
import { ValidationError } from '../../core/errors.js';
import { formatCoins } from '../../utils/format.js';

export default {
  name: 'create',
  description: 'Create a team.',
  access: 'player',
  configure(sub) {
    sub.addStringOption((option) => option.setName('name').setDescription('Team name').setRequired(true).setMaxLength(32));
    sub.addStringOption((option) => option.setName('tag').setDescription('Clan tag shown in killfeeds').setRequired(true).setMaxLength(5));
  },
  async execute(ctx) {
    const settings = getGuildSettings(ctx.guildId);
    if (!settings.clan.enabled) throw new ValidationError('Clans are disabled in this server.');
    if (getTeamForUser(ctx.guildId, ctx.userId)) throw new ValidationError('You are already in a team.');

    const name = ctx.option('name').trim();
    const tag = ctx.option('tag').trim().toUpperCase();

    if (tag.length > settings.clan.tagMaxLength) throw new ValidationError(`Tags are limited to ${settings.clan.tagMaxLength} characters.`);
    if (getTeamByName(ctx.guildId, name) || getTeamByName(ctx.guildId, tag)) {
      throw new ValidationError('That name or tag is already taken.');
    }

    const cost = Number(settings.clan.createCost) || 0;
    if (cost > 0) debit({ guildId: ctx.guildId, userId: ctx.userId, amount: cost, kind: 'team_create' });

    const team = createTeam({ guildId: ctx.guildId, name, tag, ownerId: ctx.userId });
    await ctx.panel('team', { notice: `Team **${team.name}** created${cost ? ` for ${formatCoins(cost)}` : ''}.` });
  },
};
