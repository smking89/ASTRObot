import { MessageFlags } from 'discord.js';
import { listClanBadges } from '../../../services/badge-service.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';
import { inlineCode, truncate } from '../../../utils/format.js';

/** /team badge list — uploaded clan badge icons. */
export default {
  name: 'list',
  description: 'List uploaded clan badge icons.',
  access: 'team',
  async execute(ctx) {
    const badges = listClanBadges(ctx.guildId);
    await ctx.reply({
      embeds: [
        buildEmbed({
          title: 'Clan badges',
          color: COLORS.brand,
          description:
            truncate(badges.map((badge) => `${inlineCode(badge.id)} · **${badge.label}**`).join('\n'), 4000) ||
            'No clan badges uploaded yet. Leaders can add one with `/team badge upload`.',
          footer: 'PNG, JPEG or WebP · up to 512 KB',
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
