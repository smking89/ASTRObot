export default {
  description: 'Upload and manage clan badge icons.',
};
