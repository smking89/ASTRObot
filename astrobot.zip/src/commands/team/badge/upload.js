import { MessageFlags } from 'discord.js';
import { addClanBadge, validateBadgeUpload } from '../../../services/badge-service.js';
import { assertClanLeader } from '../../../services/clan-service.js';
import { badgeAttachment, badgeImage } from '../../../ui/badge-assets.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';
import { updateTeam } from '../../../db/repositories/teams.js';
import { ValidationError } from '../../../core/errors.js';

/** /team badge upload — the clan leader uploads the clan's own badge icon. */
export default {
  name: 'upload',
  description: 'Upload a badge icon for your clan.',
  access: 'team',
  configure(sub) {
    sub.addStringOption((option) => option.setName('name').setDescription('Badge name').setRequired(true).setMaxLength(40));
    sub.addAttachmentOption((option) =>
      option.setName('image').setDescription('PNG, JPEG or WebP icon up to 512 KB').setRequired(true),
    );
  },
  async execute(ctx) {
    const team = assertClanLeader(ctx);
    const attachment = ctx.option('image');
    if (!attachment) throw new ValidationError('Attach the badge image.');

    validateBadgeUpload({ contentType: attachment.contentType, size: attachment.size });
    const buffer = Buffer.from(await attachment.fetch());
    const badge = addClanBadge({
      guildId: ctx.guildId,
      label: ctx.option('name'),
      buffer,
      contentType: attachment.contentType,
      actorId: ctx.userId,
    });

    updateTeam(team.id, { badge: badge.id });

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: 'Clan badge uploaded',
          description: `**${badge.label}** is now the badge for **${team.name}**.\nStaff can award it with \`/badge give\`.`,
          thumbnail: badgeImage(badge),
          color: COLORS.success,
        }),
      ],
      files: [badgeAttachment(badge)],
      flags: MessageFlags.Ephemeral,
    });
  },
};
