import { MessageFlags } from 'discord.js';
import { listClanBadges, removeClanBadge } from '../../../services/badge-service.js';
import { assertClanLeader } from '../../../services/clan-service.js';
import { updateTeam } from '../../../db/repositories/teams.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';

/** /team badge remove — delete an uploaded clan badge icon. */
export default {
  name: 'remove',
  description: 'Delete an uploaded clan badge icon.',
  access: 'team',
  configure(sub) {
    sub.addStringOption((option) =>
      option.setName('id').setDescription('Pick a clan badge').setRequired(true).setMaxLength(40).setAutocomplete(true),
    );
  },
  /** Dropdown of this server's uploaded clan badges. */
  async autocomplete(ctx) {
    const focused = ctx.interaction.options.getFocused(true);
    const needle = String(focused?.value ?? '').trim().toLowerCase();
    const choices = listClanBadges(ctx.guildId)
      .filter((badge) => !needle || badge.id.toLowerCase().includes(needle) || badge.label.toLowerCase().includes(needle))
      .slice(0, 25)
      .map((badge) => ({ name: `${badge.label} · ${badge.id}`.slice(0, 100), value: badge.id }));
    await ctx.interaction.respond(choices);
  },
  async execute(ctx) {
    const team = assertClanLeader(ctx);
    const badge = removeClanBadge(ctx.guildId, ctx.option('id'), { actorId: ctx.userId });
    if (team.badge === badge.id) updateTeam(team.id, { badge: null });

    await ctx.reply({
      embeds: [
        buildEmbed({
          description: `Deleted the **${badge.label}** clan badge${
            badge.awardsRemoved ? ` and cleared it from ${badge.awardsRemoved} member${badge.awardsRemoved === 1 ? '' : 's'}` : ''
          }.`,
          color: COLORS.success,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
