export default {
  name: 'manage',
  description: 'Manage your team.',
  access: 'team',
  async execute(ctx) {
    await ctx.panel('team');
  },
};
