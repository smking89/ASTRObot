import { MessageFlags } from 'discord.js';
import { assertClanLeader, clanRanks, RANK_ICON_CHOICES, updateClanRank } from '../../../services/clan-service.js';
import { iconAttachment, iconUrl } from '../../../ui/badge-assets.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';
import { ValidationError } from '../../../core/errors.js';

/** /team rank edit — rename a rank or change its badge icon. */
export default {
  name: 'edit',
  description: 'Rename a clan rank or change its badge icon.',
  access: 'team',
  configure(sub) {
    sub.addStringOption((option) => option.setName('rank').setDescription('Rank key or name').setRequired(true).setMaxLength(24));
    sub.addStringOption((option) => option.setName('name').setDescription('New rank name').setMaxLength(24));
    sub.addStringOption((option) =>
      option.setName('icon').setDescription('New badge icon').addChoices(...RANK_ICON_CHOICES),
    );
  },
  async execute(ctx) {
    const team = assertClanLeader(ctx);
    const name = ctx.option('name');
    const icon = ctx.option('icon');
    if (!name && !icon) throw new ValidationError('Provide a new name, a new icon, or both.');

    const value = String(ctx.option('rank') ?? '').trim().toLowerCase();
    const match = clanRanks(ctx.guildId).find((rank) => rank.key === value || rank.label.toLowerCase() === value);
    if (!match) throw new ValidationError('No clan rank with that key.');

    const rank = updateClanRank(
      ctx.guildId,
      match.key,
      { label: name ?? undefined, icon: icon ?? undefined },
      { actorId: ctx.userId },
    );

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: 'Clan rank updated',
          description: `**${rank.label}** in **${team.name}** now uses the ${rank.icon} badge.`,
          thumbnail: iconUrl(rank.icon),
          color: COLORS.success,
        }),
      ],
      files: [iconAttachment(rank.icon)],
      flags: MessageFlags.Ephemeral,
    });
  },
};
