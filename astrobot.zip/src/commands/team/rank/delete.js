import { MessageFlags } from 'discord.js';
import { assertClanLeader, clanRanks, deleteClanRank } from '../../../services/clan-service.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';

/** /team rank delete — removes a custom rank; the leader rank is protected. */
export default {
  name: 'delete',
  description: 'Delete a clan rank.',
  access: 'team',
  configure(sub) {
    sub.addStringOption((option) => option.setName('rank').setDescription('Rank key or name').setRequired(true).setMaxLength(24));
  },
  async execute(ctx) {
    const team = assertClanLeader(ctx);
    const value = String(ctx.option('rank') ?? '').trim().toLowerCase();
    const match = clanRanks(ctx.guildId).find((rank) => rank.key === value || rank.label.toLowerCase() === value);
    const rank = deleteClanRank(ctx.guildId, match?.key ?? value, { actorId: ctx.userId });

    await ctx.reply({
      embeds: [
        buildEmbed({
          description: `Deleted the **${rank.label}** rank from **${team.name}**.`,
          color: COLORS.success,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
