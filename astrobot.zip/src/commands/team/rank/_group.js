export default {
  description: 'Create, edit or delete clan ranks.',
};
