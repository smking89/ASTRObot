import { MessageFlags } from 'discord.js';
import { clanRanks } from '../../../services/clan-service.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';
import { truncate } from '../../../utils/format.js';

/** /team rank list — the clan's rank ladder. */
export default {
  name: 'list',
  description: 'List the clan rank ladder.',
  access: 'team',
  async execute(ctx) {
    const ranks = clanRanks(ctx.guildId);
    await ctx.reply({
      embeds: [
        buildEmbed({
          title: 'Clan ranks',
          color: COLORS.brand,
          description: truncate(
            ranks.map((rank, index) => `${index + 1}. **${rank.label}** · ${rank.icon} · \`${rank.key}\``).join('\n'),
            4000,
          ),
          footer: 'Leaders manage ranks with /team rank create, edit and delete',
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
