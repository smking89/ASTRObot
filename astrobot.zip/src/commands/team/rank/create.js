import { MessageFlags } from 'discord.js';
import { assertClanLeader, createClanRank, RANK_ICON_CHOICES } from '../../../services/clan-service.js';
import { iconAttachment, iconUrl } from '../../../ui/badge-assets.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';

/** /team rank create — leader-only custom clan rank with a real badge icon. */
export default {
  name: 'create',
  description: 'Create a clan rank with its own badge icon.',
  access: 'team',
  configure(sub) {
    sub.addStringOption((option) => option.setName('name').setDescription('Rank name').setRequired(true).setMaxLength(24));
    sub.addStringOption((option) =>
      option.setName('icon').setDescription('Badge icon for this rank').setRequired(true).addChoices(...RANK_ICON_CHOICES),
    );
  },
  async execute(ctx) {
    const team = assertClanLeader(ctx);
    const rank = createClanRank(
      ctx.guildId,
      { label: ctx.option('name'), icon: ctx.option('icon') },
      { actorId: ctx.userId },
    );

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: 'Clan rank created',
          description: `**${rank.label}** is now available in **${team.name}** as ${rank.key}.`,
          thumbnail: iconUrl(rank.icon),
          color: COLORS.success,
        }),
      ],
      files: [iconAttachment(rank.icon)],
      flags: MessageFlags.Ephemeral,
    });
  },
};
