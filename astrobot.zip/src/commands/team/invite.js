import { getGuildSettings } from '../../db/repositories/guilds.js';
import { createInvite, getTeamForUser, memberCount } from '../../db/repositories/teams.js';
import { ValidationError } from '../../core/errors.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';

export default {
  name: 'invite',
  description: 'Invite a player to your team.',
  access: 'player',
  configure(sub) {
    sub.addUserOption((option) => option.setName('player').setDescription('Player to invite').setRequired(true));
  },
  async execute(ctx) {
    const team = getTeamForUser(ctx.guildId, ctx.userId);
    if (!team) throw new ValidationError('You are not in a team.');
    if (team.owner_id !== ctx.userId && !['leader', 'officer'].includes(team.member_rank)) {
      throw new ValidationError('Only leaders and officers can invite.');
    }

    const settings = getGuildSettings(ctx.guildId);
    if (memberCount(team.id) >= settings.clan.maxMembers) throw new ValidationError('Your team is full.');

    const target = ctx.option('player');
    if (getTeamForUser(ctx.guildId, target.id)) throw new ValidationError('That player is already in a team.');

    createInvite({ guildId: ctx.guildId, teamId: team.id, inviterId: ctx.userId, inviteeId: target.id });

    await ctx.reply({
      embeds: [
        buildEmbed({
          description: `<@${target.id}> invited to **${team.name}** [${team.tag}]. They can accept from \`/team\`.`,
          color: COLORS.success,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
