import { deleteTeam, getTeamForUser, listMembers, removeMember, setMemberRank } from '../../db/repositories/teams.js';
import { ValidationError } from '../../core/errors.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';

export default {
  name: 'leave',
  description: 'Leave your current team.',
  access: 'player',
  async execute(ctx) {
    const team = getTeamForUser(ctx.guildId, ctx.userId);
    if (!team) throw new ValidationError('You are not in a team.');

    const remaining = listMembers(team.id).filter((member) => member.user_id !== ctx.userId);
    removeMember(team.id, ctx.userId);

    let detail = `You left **${team.name}**.`;

    if (remaining.length === 0) {
      deleteTeam(team.id);
      detail = `You left **${team.name}**; the team was disbanded.`;
    } else if (team.owner_id === ctx.userId) {
      setMemberRank(team.id, remaining[0].user_id, 'leader');
      detail += ` Leadership passed to <@${remaining[0].user_id}>.`;
    }

    await ctx.reply({ embeds: [buildEmbed({ description: detail, color: COLORS.neutral })], flags: MessageFlags.Ephemeral });
  },
};
