import { getTeamForUser, updateTeam } from '../../db/repositories/teams.js';
import { parseCoordinates, parseIntStrict } from '../../utils/parse.js';
import { ValidationError } from '../../core/errors.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';

export default {
  name: 'orp',
  description: "Register or manage your team's ORP protection zone.",
  access: 'team',
  configure(sub) {
    sub.addStringOption((option) =>
      option.setName('center').setDescription('Zone center as x, y, z').setRequired(true).setMaxLength(60),
    );
    sub.addIntegerOption((option) =>
      option.setName('radius').setDescription('Zone radius in meters').setRequired(true).setMinValue(1).setMaxValue(1000),
    );
    sub.addBooleanOption((option) => option.setName('clear').setDescription('Remove the registered zone instead'));
  },
  async execute(ctx) {
    const team = getTeamForUser(ctx.guildId, ctx.userId);
    if (!team) throw new ValidationError('You are not in a team.');
    if (team.owner_id !== ctx.userId) throw new ValidationError('Only the team leader can change ORP settings.');

    if (ctx.option('clear')) {
      updateTeam(team.id, { orp_zone: null });
      return ctx.reply({ embeds: [buildEmbed({ description: 'ORP zone cleared.', color: COLORS.neutral })], flags: MessageFlags.Ephemeral });
    }

    const center = parseCoordinates(ctx.option('center'));
    const radius = parseIntStrict(ctx.option('radius'), { min: 1, max: 1000, label: 'radius' });

    updateTeam(team.id, { orp_zone: JSON.stringify({ type: 'circle', x: center.x, z: center.z, radius }) });

    await ctx.reply({
      embeds: [
        buildEmbed({
          description: `ORP zone registered at **${center.x}, ${center.z}** with radius **${radius}m**. ZORP applies while every member is offline.`,
          color: COLORS.success,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
