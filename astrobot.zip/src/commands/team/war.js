import { getGuildSettings } from '../../db/repositories/guilds.js';
import { activeWarFor, createWar, getTeamByName, getTeamForUser } from '../../db/repositories/teams.js';
import { ValidationError } from '../../core/errors.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';

export default {
  name: 'war',
  description: 'Declare or end a war with another team.',
  access: 'team',
  configure(sub) {
    sub.addStringOption((option) => option.setName('team').setDescription('Opponent tag or name').setRequired(true).setMaxLength(32));
    sub.addBooleanOption((option) => option.setName('end').setDescription('End the current war instead of declaring one'));
  },
  async execute(ctx) {
    const team = getTeamForUser(ctx.guildId, ctx.userId);
    if (!team) throw new ValidationError('You are not in a team.');
    if (team.owner_id !== ctx.userId) throw new ValidationError('Only the team leader can manage wars.');

    const settings = getGuildSettings(ctx.guildId);
    if (!settings.clan.warsEnabled) throw new ValidationError('Team wars are disabled.');

    const war = activeWarFor(team.id);

    if (ctx.option('end')) {
      if (!war) throw new ValidationError('Your team has no active war.');
      const { endWar } = await import('../../db/repositories/teams.js');
      endWar(war.id);
      return ctx.reply({ embeds: [buildEmbed({ description: 'War ended.', color: COLORS.neutral })], flags: MessageFlags.Ephemeral });
    }

    if (war) throw new ValidationError('Your team is already at war.');

    const opponent = getTeamByName(ctx.guildId, ctx.option('team').trim());
    if (!opponent || opponent.id === team.id) throw new ValidationError('No opposing team with that tag.');

    createWar({ guildId: ctx.guildId, teamId: team.id, opponentTeamId: opponent.id });

    await ctx.panel('team', { notice: `War declared against **${opponent.name}** [${opponent.tag}].` });
  },
};
