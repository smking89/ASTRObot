import { ButtonStyle, MessageFlags, SlashCommandBuilder } from 'discord.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { button, customId, row } from '../ui/components.js';
import { ValidationError } from '../core/errors.js';
import { loadSnapshot, restoreStructure } from '../services/guild-snapshot.js';
import { relativeTimestamp, truncate } from '../utils/format.js';

/**
 * /nuke — server owner only.
 *
 * The command never wipes on its own: it answers with a red confirm button so a
 * mistyped slash command cannot flatten a live server. A snapshot of every
 * role, category and channel is taken right before the wipe, and
 * `/nuke restore:latest` puts it back.
 */
export default {
  data: new SlashCommandBuilder()
    .setName('nuke')
    .setDescription('Server owner only: wipe the server, or restore a pre-nuke backup.')
    .setDMPermission(false)
    .addStringOption((option) =>
      option
        .setName('restore')
        .setDescription('Backup id to restore — use "latest" for the newest one')
        .setRequired(false)
        .setMaxLength(40),
    ),
  access: 'admin',
  async execute(ctx) {
    if (String(ctx.guild?.ownerId) !== String(ctx.userId)) {
      throw new ValidationError('Only the server owner can use /nuke.');
    }

    const restoreId = String(ctx.option('restore') ?? '').trim();

    if (restoreId) {
      const { id, snapshot } = loadSnapshot(ctx.guildId, restoreId);
      await ctx.reply({
        embeds: [
          buildEmbed({
            title: '↩️ Restoring backup',
            color: COLORS.info,
            description: `Rebuilding **${snapshot.roles?.length ?? 0}** roles, **${snapshot.categories?.length ?? 0}** categories and **${snapshot.channels?.length ?? 0}** channels from \`${id}\` (${relativeTimestamp(Date.parse(snapshot.capturedAt), 'R')}).`,
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });

      const result = await restoreStructure(ctx.guild, snapshot, { reason: `Backup restore by ${ctx.userId}` });

      await ctx
        .edit({
          embeds: [
            buildEmbed({
              title: '✅ Backup restored',
              color: COLORS.success,
              description: [
                `Created **${result.rolesCreated}** roles (${result.rolesReused} already existed), **${result.categoriesCreated}** categories and **${result.channelsCreated}** channels.`,
                result.errors.length ? `⚠️ ${result.errors.length} failed:\n${truncate(result.errors.slice(0, 5).join('\n'), 900)}` : '',
              ]
                .filter(Boolean)
                .join('\n'),
            }),
          ],
        })
        .catch(() => null);
      return;
    }

    return ctx.reply({
      embeds: [
        buildEmbed({
          title: '☢️ Nuke this server?',
          color: COLORS.danger,
          description:
            'This permanently deletes **every channel, category and role** the bot can remove, including the channel you are in. Members keep their accounts, but every role assignment is lost.\n\nA full backup is saved first. After the wipe you can run `/nuke restore:latest` to rebuild it.',
          footer: 'Only the server owner can confirm',
        }),
      ],
      components: [
        row(
          button({
            id: customId('nuke', 'confirm'),
            label: 'NUKE SERVER',
            emoji: '☢️',
            style: ButtonStyle.Danger,
          }),
        ),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
