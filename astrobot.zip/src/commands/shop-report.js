import { MessageFlags, SlashCommandBuilder } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { salesTotals, topSellers } from '../db/repositories/shop.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { formatCoins, formatNumber, truncate } from '../utils/format.js';

/** /shop-report — staff sales summary from recorded purchases. */
export default {
  data: new SlashCommandBuilder()
    .setName('shop-report')
    .setDescription('Show the shop sales report: revenue, units and best sellers.')
    .setDMPermission(false)
    .addIntegerOption((option) =>
      option.setName('days').setDescription('Window in days (default 30)').setMinValue(1).setMaxValue(365),
    ),
  access: 'staff',
  defer: 'ephemeral',
  async execute(ctx) {
    const days = Number(ctx.option('days')) || 30;
    const since = Date.now() - days * 86_400_000;
    const settings = getGuildSettings(ctx.guildId);

    const totals = salesTotals(ctx.guildId, since);
    const top = topSellers(ctx.guildId, since, 8);
    const products = new Map((settings.shop.products ?? []).map((product) => [String(product.id), product]));

    const rows = top.map((row, index) => {
      const product = products.get(String(row.product_id));
      const name = product?.name ?? row.product_id;
      return `${index + 1}. **${name}** · ${formatNumber(row.purchases)} sale(s) · ${formatNumber(row.units)} unit(s) · ${formatCoins(row.revenue, settings.economy.currency)}`;
    });

    await ctx.edit({
      embeds: [
        buildEmbed({
          title: '📊 Shop sales report',
          color: COLORS.gold,
          description: `Purchases recorded in the last **${days}** day(s).`,
          fields: [
            { name: 'Revenue', value: formatCoins(totals.revenue, settings.economy.currency), inline: true },
            { name: 'Purchases', value: formatNumber(totals.purchases), inline: true },
            { name: 'Units', value: formatNumber(totals.units), inline: true },
            { name: 'Best sellers', value: truncate(rows.join('\n'), 1024) || 'No purchases in this window.' },
          ],
          footer: 'Revenue counts the price paid at checkout, including free items',
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
