import { MessageFlags, SlashCommandBuilder } from 'discord.js';
import { addPlayerStat } from '../db/repositories/players.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { ValidationError } from '../core/errors.js';

/** Staff: record a competition win and feed the competition leaderboard. */
export default {
  data: new SlashCommandBuilder()
    .setName('competition')
    .setDescription('Record a competition win for a player and announce it.')
    .setDMPermission(false)
    .addUserOption((option) => option.setName('player').setDescription('Competition winner').setRequired(true))
    .addStringOption((option) => option.setName('name').setDescription('Competition name').setMaxLength(80)),
  access: 'staff',
  async execute(ctx) {
    const user = ctx.option('player');
    if (!user?.id) throw new ValidationError('Choose the player who won.');

    const label = String(ctx.option('name') ?? '').trim();
    const account = addPlayerStat(ctx.guildId, user.id, 'competition_wins', 1);
    const wins = Number(account.competition_wins ?? 0);

    const channel = [...(ctx.guild?.channels?.cache?.values?.() ?? [])].find(
      (entry) => entry?.isTextBased?.() && /competition/i.test(entry.name ?? ''),
    );

    if (channel) {
      await channel
        .send({
          embeds: [
            buildEmbed({
              title: '🏅 Competition result',
              color: COLORS.gold,
              description: `${user} won${label ? ` **${label}**` : ' a competition'}.\nThat is **${wins}** competition win(s) on the board.`,
            }),
          ],
          allowedMentions: { parse: [] },
        })
        .catch(() => null);
    }

    await ctx.reply({
      embeds: [
        buildEmbed({
          description: `Recorded a competition win for ${user}. They now have **${wins}**.`,
          color: COLORS.success,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
