import { MessageFlags, SlashCommandBuilder } from 'discord.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import {
  GAME_ASSET_GAMES,
  GAME_ASSET_SLOTS,
  assertGameAssetSlot,
  assetAttachment,
  assetUrl,
  listGameAssets,
  removeGameAsset,
  saveGameAsset,
  validateGameAssetUpload,
} from '../services/game-asset-service.js';
import { ValidationError } from '../core/errors.js';

const gameLabel = (id) => GAME_ASSET_GAMES.find((game) => game.id === id)?.label ?? id;
const slotLabel = (id) => GAME_ASSET_SLOTS.find((slot) => slot.id === id)?.label ?? id;

/** /game-asset — staff uploads, lists or removes artwork for any game. */
export default {
  data: new SlashCommandBuilder()
    .setName('game-asset')
    .setDescription('Upload, list or remove custom artwork for casino games.')
    .setDMPermission(false)
    .addStringOption((option) =>
      option
        .setName('game')
        .setDescription('Game to manage (leave empty to list all)')
        .setRequired(false)
        .addChoices(...GAME_ASSET_GAMES.map((game) => ({ name: game.label.slice(0, 100), value: game.id }))),
    )
    .addStringOption((option) =>
      option
        .setName('slot')
        .setDescription('Artwork slot')
        .setRequired(false)
        .addChoices(...GAME_ASSET_SLOTS.map((slot) => ({ name: slot.label, value: slot.id }))),
    )
    .addAttachmentOption((option) =>
      option
        .setName('image')
        .setDescription('PNG, JPEG or WebP up to 4 MB')
        .setRequired(false),
    )
    .addStringOption((option) =>
      option
        .setName('label')
        .setDescription('Optional label shown in the asset list')
        .setRequired(false)
        .setMaxLength(80),
    )
    .addBooleanOption((option) =>
      option
        .setName('remove')
        .setDescription('Remove the artwork in this game and slot')
        .setRequired(false),
    ),
  access: 'admin',
  async execute(ctx) {
    const gameId = String(ctx.option('game') ?? '').trim();
    const slot = String(ctx.option('slot') ?? '').trim();
    const image = ctx.option('image');
    const remove = Boolean(ctx.option('remove'));
    const label = ctx.option('label');

    if (!image && !remove) return listAssets(ctx, gameId);

    if (!gameId || !slot) throw new ValidationError('Choose both a game and an artwork slot.');
    assertGameAssetSlot(gameId, slot);

    if (remove) {
      removeGameAsset({ guildId: ctx.guildId, gameId, slot });
      return ctx.reply({
        embeds: [
          buildEmbed({
            title: 'Game artwork removed',
            description: `Removed **${slotLabel(slot)}** for **${gameLabel(gameId)}**.`,
            color: COLORS.success,
          }),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    validateGameAssetUpload({ contentType: image.contentType, size: image.size });
    await ctx.defer({ ephemeral: true });
    const buffer = Buffer.from(await image.fetch());
    const asset = saveGameAsset({
      guildId: ctx.guildId,
      gameId,
      slot,
      label,
      buffer,
      contentType: image.contentType,
      actorId: ctx.userId,
    });

    return ctx.reply({
      embeds: [
        buildEmbed({
          title: 'Game artwork uploaded',
          description: `**${slotLabel(slot)}** is now live for **${gameLabel(gameId)}**${asset.label ? ` · ${asset.label}` : ''}.`,
          color: COLORS.success,
          thumbnail: assetUrl(asset),
          footer: 'Use /game-asset to list or replace artwork',
        }),
      ],
      files: [assetAttachment(asset)],
      flags: MessageFlags.Ephemeral,
    });
  },
};

function listAssets(ctx, gameId = '') {
  if (gameId) assertGameAssetSlot(gameId, 'cover');
  const assets = listGameAssets(ctx.guildId, gameId || null);
  const fields = assets.length
    ? assets.map((asset) => ({
        name: `${gameLabel(asset.gameId)} · ${slotLabel(asset.slot)}`,
        value: `${asset.label ? `**${asset.label}** · ` : ''}\`${asset.slot}\``,
        inline: true,
      }))
    : [{ name: 'No artwork uploaded', value: 'Use `/game-asset` with a game, slot and image to add one.' }];

  return ctx.reply({
    embeds: [
      buildEmbed({
        title: '🎨 Game artwork',
        color: COLORS.brand,
        description:
          'Uploaded art is shown on the game result as a cover or win/loss image. UNO also uses `uno_back` and `uno_table` in its generated card board.',
        fields: fields.slice(0, 25),
        footer: 'PNG, JPEG or WebP · up to 4 MB · per server',
      }),
    ],
    flags: MessageFlags.Ephemeral,
  });
}
