import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('market-panel')
    .setDescription('Marketplace analytics, treasury, fees and seller controls.')
    .setDMPermission(false),
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('market-admin');
  },
};
