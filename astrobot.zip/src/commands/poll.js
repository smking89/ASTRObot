import { ChannelType, MessageFlags, SlashCommandBuilder } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { ValidationError } from '../core/errors.js';
import { parseIntStrict } from '../utils/parse.js';
import { createPollMessage, parsePollOptions } from '../services/poll-service.js';

export default {
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Create a durable poll or open the poll analytics panel.')
    .setDMPermission(false)
    .addStringOption((option) =>
      option.setName('question').setDescription('The poll question (leave blank to open the admin panel)').setRequired(false).setMaxLength(300),
    )
    .addStringOption((option) =>
      option
        .setName('options')
        .setDescription('Two to ten answers, separated by commas or new lines')
        .setRequired(false)
        .setMaxLength(900),
    )
    .addChannelOption((option) =>
      option
        .setName('channel')
        .setDescription('Where to post the poll (default: configured poll channel or this channel)')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
        .setRequired(false),
    )
    .addIntegerOption((option) =>
      option.setName('hours').setDescription('How long the poll stays open').setMinValue(1).setMaxValue(768).setRequired(false),
    )
    .addBooleanOption((option) =>
      option.setName('multiple').setDescription('Allow voters to choose more than one answer').setRequired(false),
    ),
  access: 'restricted',
  async execute(ctx) {
    const settings = getGuildSettings(ctx.guildId);
    if (!settings.onboarding?.polls?.enabled) throw new ValidationError('Polls are disabled in /config → Onboarding Roles & Events.');

    const question = String(ctx.option('question') ?? '').trim();
    if (!question) {
      await ctx.panel('polls');
      return;
    }

    const options = parsePollOptions(ctx.option('options'));
    const channelId = ctx.option('channel') ?? settings.onboarding.polls.channelId ?? ctx.channelId;
    const hours = parseIntStrict(ctx.option('hours') ?? settings.onboarding.polls.defaultHours ?? 24, {
      min: 1,
      max: 768,
      label: 'hours',
    });

    const poll = await createPollMessage({
      client: ctx.client,
      guildId: ctx.guildId,
      channelId,
      creatorId: ctx.userId,
      question,
      options,
      hours,
      allowMultiple: Boolean(ctx.option('multiple')),
    });

    return ctx.reply({
      embeds: [
        {
          color: 0x00f0ff,
          description: `Poll posted in <#${poll.channel_id}>. Run \`/poll\` with no question to open **basic** and **advanced** analytics.`,
        },
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
