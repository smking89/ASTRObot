import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('battle-pass')
    .setDescription('View your Battle Pass tier and claim unlocked rewards.')
    .setDMPermission(false),
  access: 'player',
  async execute(ctx) {
    await ctx.panel('battle-pass');
  },
};
