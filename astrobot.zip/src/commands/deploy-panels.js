import { MessageFlags, SlashCommandBuilder } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import {
  PANEL_DEFINITIONS,
  findPanelChannel,
  inspectPanelMessage,
  planTemplatePanels,
} from '../services/panel-deploy.js';

/** Configured fallbacks when a guild has no channel matching the name rule. */
const FALLBACKS = Object.freeze({ support: 'tickets', lfg: 'lfg' });

export default {
  data: new SlashCommandBuilder()
    .setName('deploy-panels')
    .setDescription('Check every panel and deploy any that are missing.')
    .setDMPermission(false),
  access: 'restricted',
  async execute(ctx) {
    const guild = ctx.guild;
    const settings = getGuildSettings(ctx.guildId);
    const plan = planTemplatePanels({
      channels: [...guild.channels.cache.values()].map((channel) => ({ name: channel.name })),
    });

    const lines = [];
    let deployed = 0;
    let repaired = 0;
    let present = 0;
    let unreadable = 0;
    let noChannel = 0;

    for (const [type, definition] of Object.entries(PANEL_DEFINITIONS)) {
      const entry = plan.find((item) => item.type === type);
      const fallbackId = FALLBACKS[type] ? settings.channels?.[FALLBACKS[type]] : null;
      const channel =
        (entry?.channelName ? findPanelChannel(guild, entry.channelName) : null) ??
        (fallbackId ? guild.channels.cache.get(fallbackId) : null);

      if (!channel) {
        noChannel += 1;
        lines.push(`⚠️ **${type}** — no matching channel`);
        continue;
      }

      const state = await inspectPanelMessage(channel, definition);
      if (state.found && state.hasButtons && !state.stale) {
        present += 1;
        continue;
      }
      if (state.unknown) {
        unreadable += 1;
        lines.push(`❔ **${type}** — cannot read <#${channel.id}>`);
        continue;
      }

      try {
        if (state.found && state.message) {
          await state.message.edit({ ...definition.payload(), allowedMentions: { parse: [] } });
          repaired += 1;
          lines.push(`🔧 **${type}** — buttons restored in <#${channel.id}>`);
        } else {
          await channel.send({ ...definition.payload(), allowedMentions: { parse: [] } });
          deployed += 1;
          lines.push(`✅ **${type}** — deployed in <#${channel.id}>`);
        }
      } catch (error) {
        lines.push(`❌ **${type}** — ${error.message}`);
      }
    }

    const summary = [
      `${deployed} deployed`,
      `${repaired} repaired`,
      `${present} already present`,
      noChannel ? `${noChannel} channel(s) missing` : null,
      unreadable ? `${unreadable} unreadable` : null,
    ]
      .filter(Boolean)
      .join(' · ');

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: '📦 Panel deployment',
          description: `${summary}\n\n${lines.slice(0, 18).join('\n') || 'Every panel is already in place.'}`,
          color: noChannel || unreadable ? COLORS.warning : COLORS.success,
          footer: 'AstroBot · panel deployment',
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
