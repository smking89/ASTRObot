import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Create and manage giveaways with automatic winner draws.')
    .setDMPermission(false),
  access: 'restricted',
  async execute(ctx) {
    await ctx.panel('giveaways');
  },
};
