import { MessageFlags, TextInputStyle } from 'discord.js';
import { getGuildSettings } from '../../db/repositories/guilds.js';
import { createPartnershipRequest } from '../../db/repositories/partnerships.js';
import { customId, modal, button, row } from '../../ui/components.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { ValidationError } from '../../core/errors.js';

function inviteCode(raw) {
  const value = String(raw ?? '').trim();
  const match = value.match(/(?:discord\.gg|discord(?:app)?\.com\/invite)\/([\w-]+)/i);
  if (match) return match[1];
  return /^[\w-]{2,32}$/.test(value) && !/^\d{15,20}$/.test(value) ? value : null;
}

async function resolveTarget(client, raw) {
  const value = String(raw ?? '').trim().replace(/^<#(\d+)>$/, '$1');

  if (/^\d{15,20}$/.test(value)) {
    // A channel ID gives the requester a direct delivery target; a guild ID
    // falls back to that server's configured partnership inbox.
    let channel = null;
    try {
      channel = await client.channels?.fetch?.(value);
    } catch {
      channel = null;
    }
    if (channel?.guild) return { guild: channel.guild, channel };

    try {
      const guild = client.guilds.cache.get(value) ?? (await client.guilds.fetch(value));
      return { guild, channel: null };
    } catch {
      return { guild: null, channel: null };
    }
  }

  const code = inviteCode(value);
  if (!code) throw new ValidationError('Enter a guild ID, invite link or channel.');

  let invite = null;
  try {
    invite = await client.fetchInvite?.(code);
  } catch {
    invite = null;
  }
  const guildId = invite?.guild?.id ?? null;
  if (!guildId) throw new ValidationError('That invite could not be inspected. Use the target guild ID instead.');

  try {
    const guild = client.guilds.cache.get(guildId) ?? (await client.guilds.fetch(guildId));
    return { guild, channel: null };
  } catch {
    return { guild: null, channel: null };
  }
}

async function destinationFor(ctx, guild, settings, preferredChannel = null) {
  if (preferredChannel?.send) return { send: (payload) => preferredChannel.send(payload) };

  const channelId = settings.partnerships?.requestChannelId;
  if (channelId) {
    try {
      const channel = await ctx.client.channels.fetch(channelId);
      if (channel?.send) return { send: (payload) => channel.send(payload) };
    } catch {
      // Fall through to the owner DM.
    }
  }

  if (guild.ownerId) {
    try {
      const owner = await ctx.client.users?.fetch?.(guild.ownerId);
      if (owner?.send) return { send: (payload) => owner.send(payload) };
    } catch {
      // Fall through to the error below.
    }
  }

  throw new ValidationError('That server has no partnership inbox channel and its owner cannot be DMed.');
}

export default {
  name: 'request',
  description: 'Send a partnership request to another server.',
  access: 'admin',
  async execute(ctx) {
    const source = getGuildSettings(ctx.guildId);
    if (source.partnerships?.enabled === false) {
      throw new ValidationError('Partnership requests are disabled in this server.');
    }

    if (!ctx.isModal) {
      return ctx.modal(
        modal({
          id: customId('partner', 'request'),
          title: 'Partnership request',
          fields: [
            { id: 'brand', label: 'Brand / server name', required: true, maxLength: 80 },
            { id: 'duration', label: 'Partnership duration', placeholder: 'Permanent, 1-month trial…', required: true, maxLength: 40 },
            { id: 'description', label: 'What you offer', style: TextInputStyle.Paragraph, required: true, maxLength: 800 },
            { id: 'target', label: 'Target guild ID, invite link or channel', required: true, maxLength: 200 },
          ],
        }),
      );
    }

    return submitPartnershipRequest(ctx);
  },
};

export async function submitPartnershipRequest(ctx) {
    const source = getGuildSettings(ctx.guildId);
    if (source.partnerships?.enabled === false) {
      throw new ValidationError('Partnership requests are disabled in this server.');
    }
    const targetInput = String(ctx.option('target') ?? '').trim();
    const resolved = await resolveTarget(ctx.client, targetInput);
    const targetGuild = resolved.guild;
    if (!targetGuild) throw new ValidationError('AstroBot is not in that server, or the guild/invite/channel is invalid.');
    if (targetGuild.id === ctx.guildId) throw new ValidationError('You cannot partner a server with itself.');

    const target = getGuildSettings(targetGuild.id);
    if (target.partnerships?.enabled === false) {
      throw new ValidationError('That server has partnership requests disabled.');
    }

    const memberCount = Number(ctx.guild.memberCount ?? 0);
    const minimum = Math.max(Number(source.partnerships?.minMembers ?? 0), Number(target.partnerships?.minMembers ?? 0));
    if (minimum > 0 && memberCount < minimum) {
      throw new ValidationError(`Your server needs at least ${minimum} members before requesting a partnership.`);
    }

    const request = createPartnershipRequest({
      fromGuildId: ctx.guildId,
      toGuildId: targetGuild.id,
      requesterId: ctx.userId,
      brandName: String(ctx.option('brand') ?? '').trim().slice(0, 80),
      duration: String(ctx.option('duration') ?? '').trim().slice(0, 40),
      description: String(ctx.option('description') ?? '').trim().slice(0, 800),
      memberCount,
    });

    const destination = await destinationFor(ctx, targetGuild, target, resolved.channel);
    const sourceName = ctx.guild?.name ?? 'Server';
    const embed = buildEmbed({
      title: '🤝 Partnership request',
      color: COLORS.warning,
      description: `**${request.brand_name}** wants to partner with **${targetGuild.name}**.`,
      fields: [
        { name: 'From', value: `${sourceName}\n\`${ctx.guildId}\``, inline: true },
        { name: 'Live member count', value: String(memberCount), inline: true },
        { name: 'Duration', value: request.duration || 'Not specified', inline: true },
        { name: 'What they offer', value: request.description || 'No description provided.' },
        { name: 'Requested by', value: `<@${ctx.userId}>`, inline: true },
      ],
      footer: `Request ${request.id} · pending review`,
    });

    await destination.send({
      embeds: [embed],
      components: [
        row(
          button({ id: customId('partner', 'accept', request.id), label: 'Accept', emoji: '✅', style: 3 }),
          button({ id: customId('partner', 'decline', request.id), label: 'Decline', emoji: '❌', style: 4 }),
        ),
      ],
      allowedMentions: { parse: [] },
    });

    return ctx.reply({
      content: `Partnership request sent to **${targetGuild.name}**. They will receive it in their partnership inbox.`,
      flags: MessageFlags.Ephemeral,
    });
}
