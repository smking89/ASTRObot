import { MessageFlags } from 'discord.js';
import { getGuild } from '../../db/repositories/guilds.js';
import { listPartnershipsForGuild } from '../../db/repositories/partnerships.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { truncate } from '../../utils/format.js';

const STATUS_ICON = { pending: '⏳', accepted: '🤝', declined: '❌' };

export default {
  name: 'status',
  description: 'View incoming and accepted partnerships for this server.',
  access: 'admin',
  async execute(ctx) {
    const rows = listPartnershipsForGuild(ctx.guildId, 15);
    const embed = buildEmbed({
      title: '🤝 Partnerships',
      color: COLORS.brand,
      description: rows.length
        ? 'Requests and established partnerships involving this server.'
        : 'No partnership requests yet. Use `/partner request` to contact another server.',
      fields: [
        {
          name: 'Requests',
          value:
            truncate(
              rows
                .map((row) => {
                  const otherId = row.from_guild_id === ctx.guildId ? row.to_guild_id : row.from_guild_id;
                  const other = getGuild(otherId)?.name ?? otherId;
                  return `${STATUS_ICON[row.status] ?? '•'} **${row.brand_name}** · ${other} · ${row.status}`;
                })
                .join('\n'),
              1024,
            ) || 'None',
        },
      ],
      footer: 'Accepting a request links both servers into a partner currency network',
    });

    return ctx.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
  },
};
