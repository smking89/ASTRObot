export default {
  name: 'partner',
  label: 'Partnerships',
  description: 'Request, review and manage cross-server partnerships.',
  access: 'admin',
};
