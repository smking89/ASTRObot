import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('announcements')
    .setDescription('Schedule Discord and in-game announcements on a calendar date and clock time.')
    .setDMPermission(false),
  access: 'admin',
  async execute(ctx) {
    await ctx.panel('announcements');
  },
};
