import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('claim')
    .setDescription('Open the panel for kits, Dial-a-Ride, winnings and gifts.')
    .setDMPermission(false),
  access: 'player',
  async execute(ctx) {
    await ctx.panel('claim');
  },
};
