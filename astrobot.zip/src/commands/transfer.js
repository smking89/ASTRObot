import { MessageFlags, SlashCommandBuilder } from 'discord.js';
import { transferGuildSeat } from '../services/plan-service.js';
import { ValidationError } from '../core/errors.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { relativeTimestamp } from '../utils/format.js';

export default {
  data: new SlashCommandBuilder()
    .setName('transfer')
    .setDescription('Move your Astro subscription from another server to this one.')
    .setDMPermission(false)
    .addStringOption((option) =>
      option
        .setName('from')
        .setDescription('Source server ID (leave blank to pick from your attached servers)')
        .setMaxLength(22),
    ),
  access: 'restricted',
  async execute(ctx) {
    if (ctx.guild?.ownerId !== ctx.userId) {
      throw new ValidationError('Only the server owner can move a subscription to this server.');
    }

    const fromGuildId = String(ctx.option('from') ?? '').trim();
    if (!fromGuildId) return ctx.panel('plan', { transferPicker: true });
    if (!/^\d{15,22}$/.test(fromGuildId)) throw new ValidationError('Enter a valid source server ID.');

    const result = transferGuildSeat({ guildId: ctx.guildId, userId: ctx.userId, fromGuildId });
    const sourceName = result.source.name || `server \`${result.source.id}\``;

    await ctx.reply({
      embeds: [
        buildEmbed({
          description: `Moved **${result.plan.label}** from ${sourceName} to this server. Your seat is now in use here.`,
          color: COLORS.success,
          fields: [
            { name: 'Seats in use', value: `${result.summary.used}/${result.summary.seatLimit}`, inline: true },
            {
              name: 'Expires',
              value: result.summary.lifetime
                ? 'Never'
                : result.summary.expiresAt
                  ? relativeTimestamp(result.summary.expiresAt, 'R')
                  : 'No expiry',
              inline: true,
            },
          ],
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
