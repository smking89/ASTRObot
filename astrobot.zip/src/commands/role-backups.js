import { MessageFlags, SlashCommandBuilder } from 'discord.js';
import { COLORS } from '../config/constants.js';
import { getRoleBackup, listRoleBackups, restoreRoleBackup } from '../services/role-backup-service.js';
import { buildEmbed } from '../ui/embeds.js';
import { relativeTimestamp, truncate } from '../utils/format.js';

const PAGE_SIZE = 5;

export default {
  data: new SlashCommandBuilder()
    .setName('role-backups')
    .setDescription('List role backups, inspect assignments, or restore missing roles.')
    .setDMPermission(false)
    .addStringOption((option) =>
      option
        .setName('backup')
        .setDescription('Backup ID to inspect or restore; leave empty to list recent backups.')
        .setMaxLength(64),
    )
    .addIntegerOption((option) =>
      option.setName('page').setDescription('Member page when viewing a backup.').setMinValue(1),
    )
    .addBooleanOption((option) =>
      option
        .setName('restore')
        .setDescription('Restore the selected backup now; existing roles are kept and missing roles are added.'),
    ),
  access: 'staff',
  async execute(ctx) {
    const requested = String(ctx.option('backup') ?? '').trim();
    const restore = Boolean(ctx.option('restore'));
    const backup = requested ? getRoleBackup(ctx.guildId, requested) : null;

    if (requested && !backup) {
      await ctx.reply({
        embeds: [
          buildEmbed({
            title: '🗂️ Role backup not found',
            description: `No backup matches \`${truncate(requested.replaceAll('`', ''), 64)}\`.`,
            color: COLORS.warning,
            footer: 'AstroBot · role backups',
          }),
        ],
        flags: MessageFlags.Ephemeral,
        allowedMentions: { parse: [] },
      });
      return;
    }

    if (restore) {
      if (!backup) {
        await ctx.reply({
          embeds: [
            buildEmbed({
              title: '🗂️ Choose a backup',
              description:
                'Set `backup:<id>` to the backup you want to restore. Use `/role-backups` without options to list IDs.',
              color: COLORS.warning,
              footer: 'AstroBot · role backups',
            }),
          ],
          flags: MessageFlags.Ephemeral,
          allowedMentions: { parse: [] },
        });
        return;
      }

      // A restore can touch every member and recreate roles; acknowledge first.
      await ctx.defer({ ephemeral: true });

      let result;
      try {
        result = await restoreRoleBackup(ctx.guild, backup.id, {
          reason: `Role backup restore by ${ctx.userId}`,
        });
      } catch (error) {
        await ctx.edit({
          embeds: [
            buildEmbed({
              title: '❌ Role backup restore failed',
              description: truncate(error.message, 1000),
              color: COLORS.danger,
              footer: 'AstroBot · role backups',
            }),
          ],
          allowedMentions: { parse: [] },
        });
        return;
      }

      const lines = [
        `Restored **${result.restoredAssignments}** role assignment(s) across **${result.restoredMembers}** member(s).`,
        result.rolesRecreated
          ? `Recreated **${result.rolesRecreated}** role(s) that were missing from the server.`
          : null,
        result.missingMembers
          ? `**${result.missingMembers}** member(s) from the backup are no longer in the server.`
          : null,
        'Existing roles were kept; this only adds missing roles.',
        result.errors.length
          ? `⚠️ ${result.errors.length} warning(s):\n${truncate(result.errors.slice(0, 5).join('\n'), 900)}`
          : null,
      ].filter(Boolean);

      await ctx.edit({
        embeds: [
          buildEmbed({
            title: '✅ Role backup restored',
            description: lines.join('\n'),
            color: result.errors.length ? COLORS.warning : COLORS.success,
            footer: `AstroBot · role backups · ${backup.id}`,
          }),
        ],
        allowedMentions: { parse: [] },
      });
      return;
    }

    if (!backup) {
      const backups = listRoleBackups(ctx.guildId, 10);
      const description = backups.length
        ? backups
            .map((entry) => {
              const template = entry.template_name
                ? ` · ${truncate(String(entry.template_name).replaceAll('`', ''), 40)}`
                : '';
              return `**\`${entry.id}\`** — ${relativeTimestamp(entry.created_at)} · ${entry.member_count} member(s) · ${entry.role_count} role(s)${template}`;
            })
            .join('\n')
        : 'No role backups yet. One is saved automatically whenever a template is confirmed and replaces the server.';

      await ctx.reply({
        embeds: [
          buildEmbed({
            title: '🗂️ Role backups',
            description: backups.length
              ? `${description}\n\nUse \`/role-backups backup:<id>\` to inspect assignments, then add \`restore:true\` to restore missing roles.`
              : description,
            color: COLORS.info,
            footer: 'AstroBot · role backups',
          }),
        ],
        flags: MessageFlags.Ephemeral,
        allowedMentions: { parse: [] },
      });
      return;
    }

    const members = backup.members
      .map((entry) => ({
        ...entry,
        label: ctx.guild.members.cache.get(entry.userId)?.displayName ?? `<@${entry.userId}>`,
      }))
      .sort((a, b) => a.label.localeCompare(b.label));

    const pages = Math.max(1, Math.ceil(members.length / PAGE_SIZE));
    const page = Math.min(Math.max(1, Math.trunc(Number(ctx.option('page')) || 1)), pages);
    const visible = members.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
    const assignments = visible.length
      ? visible
          .map((entry) =>
            truncate(
              `**${entry.label}** — ${entry.roles.map((role) => role.name).join(', ') || 'No roles'}`,
              190,
            ),
          )
          .join('\n')
      : 'No member held a role in this backup.';

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: '🗂️ Role backup',
          color: COLORS.info,
          fields: [
            { name: 'Backup', value: `\`${backup.id}\``, inline: true },
            { name: 'Created', value: relativeTimestamp(backup.created_at), inline: true },
            { name: 'Saved by', value: backup.actor_id ? `<@${backup.actor_id}>` : 'Unknown', inline: true },
            {
              name: 'Template',
              value: backup.template_name ? truncate(backup.template_name, 100) : 'Unknown',
              inline: true,
            },
            {
              name: 'Size',
              value: `${backup.member_count} member(s) · ${backup.role_count} role(s)`,
              inline: true,
            },
            {
              name: `Assignments · page ${page}/${pages}`,
              value: truncate(assignments, 1024),
            },
          ],
          footer: 'AstroBot · role backups · restore:true to restore',
        }),
      ],
      flags: MessageFlags.Ephemeral,
      allowedMentions: { parse: [] },
    });
  },
};
