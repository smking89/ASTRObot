export default {
  name: 'analytics',
  description: 'Retention, activity and staff workload analytics.',
  access: 'staff',
  async execute(ctx) {
    await ctx.panel('analytics');
  },
};
