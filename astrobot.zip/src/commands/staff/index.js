export default {
  name: 'staff',
  label: 'Staff Management',
  description: 'Staff management: application panels and cross-server recruitment.',
  access: 'restricted',
  panel: { id: 'staff' },
};
