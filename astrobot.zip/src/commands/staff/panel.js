import { getGuildSettings, patchGuildSetting } from '../../db/repositories/guilds.js';
import { publishApplyPanel } from '../../services/staff-service.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';

export default {
  name: 'panel',
  description: 'Publish the staff application Apply Now panel.',
  access: 'restricted',
  configure(sub) {
    sub.addChannelOption((option) => option.setName('channel').setDescription('Channel to publish into'));
  },
  async execute(ctx) {
    const channel = ctx.option('channel') ?? null;
    const settings = getGuildSettings(ctx.guildId);
    const channelId = channel?.id ?? settings.staff.panelChannelId;

    await publishApplyPanel(ctx.guild, channelId);

    if (!settings.staff.applicationsOpen) {
      const { settings: updated } = patchGuildSetting(ctx.guildId, 'staff.applicationsOpen', true, { actorId: ctx.userId });
      ctx.guildConfig = updated;
    }
    if (channel && settings.staff.panelChannelId !== channel.id) {
      patchGuildSetting(ctx.guildId, 'staff.panelChannelId', channel.id, { actorId: ctx.userId });
    }

    await ctx.reply({
      embeds: [buildEmbed({ description: 'Apply Now panel published. Applications are open.', color: COLORS.success })],
      flags: MessageFlags.Ephemeral,
    });
  },
};
