import { env } from '../../config/env.js';
import { getGuildSettings } from '../../db/repositories/guilds.js';
import { publishRecruitment } from '../../services/staff-service.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';

export default {
  name: 'recruit',
  description: 'Publish an open staff position to the cross-server AstroBot hub.',
  access: 'restricted',
  configure(sub) {
    sub.addStringOption((option) => option.setName('role').setDescription('Role title').setMaxLength(60));
  },
  async execute(ctx) {
    const settings = getGuildSettings(ctx.guildId);
    const title = ctx.option('role');

    await publishRecruitment(ctx.client, ctx.guild, env.discord.officialGuildId, settings.channels.broadcasts);

    await ctx.reply({
      embeds: [
        buildEmbed({
          description: `Recruitment listing${title ? ` for **${title}**` : ''} published to the AstroBot hub.`,
          color: COLORS.success,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
