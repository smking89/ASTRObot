import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('game-forge')
    .setDescription('Build and manage custom mini-games for this server on the AstroBot website.')
    .setDMPermission(false),
  access: 'admin',
  async execute(ctx) {
    await ctx.panel('game-forge');
  },
};
