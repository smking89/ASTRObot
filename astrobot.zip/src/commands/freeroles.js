import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('freeroles')
    .setDescription('Choose the self-assignable roles enabled by this server.')
    .setDMPermission(false),
  access: 'player',
  async execute(ctx) {
    await ctx.panel('freeroles');
  },
};
