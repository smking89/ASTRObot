/** Self-serve subscription and Discord-server seat manager. */
export default {
  name: 'plan',
  description: 'Manage your Astro subscription and Discord-server seats.',
  access: 'restricted',
  panel: { id: 'plan' },
  async execute(ctx) {
    return ctx.panel('plan');
  },
};
