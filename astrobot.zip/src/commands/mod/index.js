export default {
  name: 'mod',
  label: 'Moderation',
  description: 'Open the moderation panel: active punishments, tracking and logs.',
  access: 'staff',
  panel: { id: 'mod' },
};
