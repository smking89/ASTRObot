import { MessageFlags, SlashCommandBuilder } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { listGiveaways } from '../db/repositories/onboarding.js';
import { issueGiveawayEntryToken } from '../db/repositories/giveaway-portals.js';
import { env } from '../config/env.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { linkButton, row } from '../ui/components.js';
import { ValidationError } from '../core/errors.js';
import { relativeTimestamp } from '../utils/format.js';

/** Personal portal entry link for the giveaway that is open right now. */
export default {
  data: new SlashCommandBuilder()
    .setName('giveaway-entry')
    .setDescription('Get your personal link to enter the open giveaway on the Astro portal.')
    .setDMPermission(false),
  access: 'player',
  async execute(ctx) {
    const settings = getGuildSettings(ctx.guildId);
    if (settings.onboarding?.giveaways?.enabled === false) throw new ValidationError('Giveaways are disabled.');
    if (settings.onboarding?.giveaways?.portalEntries === false) {
      throw new ValidationError('Portal entries are switched off. Use the Enter button on the giveaway message instead.');
    }

    const giveaway = listGiveaways(ctx.guildId, 25).find(
      (entry) => entry.status === 'active' && Number(entry.ends_at) > Date.now(),
    );
    if (!giveaway) throw new ValidationError('No giveaway is open right now. Check the giveaway channel.');

    const token = issueGiveawayEntryToken({
      guildId: ctx.guildId,
      userId: ctx.userId,
      giveawayId: giveaway.id,
    });
    const base = String(settings.giveawayPortal?.publicUrl || env.dashboard.publicUrl).replace(/\/+$/, '');
    const url = `${base}/giveaway-portal/?guild=${encodeURIComponent(ctx.guildId)}&entry=${encodeURIComponent(token)}`;

    return ctx.reply({
      embeds: [
        buildEmbed({
          title: '🎟️ Your portal entry link',
          color: COLORS.brand,
          description: `Enter **${giveaway.prize}** from the Astro portal. The link is tied to your Discord account and expires ${relativeTimestamp(
            Date.now() + 7 * 86_400_000,
            'R',
          )}.`,
          fields: [{ name: 'Closes', value: relativeTimestamp(giveaway.ends_at, 'R'), inline: true }],
          footer: 'AstroBot · portal entries',
        }),
      ],
      components: [row(linkButton({ label: 'Open my entry link', url, emoji: '🎁' }))],
      flags: MessageFlags.Ephemeral,
    });
  },
};
