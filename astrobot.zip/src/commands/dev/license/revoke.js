import { getLicenseByKey } from '../../../db/repositories/licenses.js';
import { revokeUserLicense } from '../../../services/license-service.js';
import { ValidationError } from '../../../core/errors.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';
import { MessageFlags } from 'discord.js';

export default {
  name: 'revoke',
  description: "Revoke a Discord account's granted licenses.",
  access: 'developer',
  configure(sub) {
    sub.addStringOption((option) => option.setName('key').setDescription('License key').setRequired(true).setMaxLength(30));
    sub.addStringOption((option) => option.setName('reason').setDescription('Reason').setMaxLength(200));
  },
  async execute(ctx) {
    const license = getLicenseByKey(ctx.option('key').trim().toUpperCase());
    if (!license) throw new ValidationError('License not found.');

    revokeUserLicense({ licenseId: license.id, actorId: ctx.userId });

    await ctx.reply({
      embeds: [
        buildEmbed({
          description: `License \`${license.key}\` revoked${ctx.option('reason') ? `: ${ctx.option('reason')}` : '.'}`,
          color: COLORS.warning,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
