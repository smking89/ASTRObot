import { listAllLicenses, listLicensesFor } from '../../../db/repositories/licenses.js';
import { licensePlanLabel, licenseServerLimit } from '../../../services/license-service.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';
import { MessageFlags } from 'discord.js';
import { truncate } from '../../../utils/format.js';

export default {
  name: 'list',
  description: 'List licenses granted to a Discord account.',
  access: 'developer',
  configure(sub) {
    sub.addUserOption((option) => option.setName('user').setDescription('Discord account'));
  },
  async execute(ctx) {
    const target = ctx.option('user');
    const licenses = target ? listLicensesFor(target.id) : listAllLicenses({ limit: 25 });

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: target ? `Licenses · ${target.username}` : 'All licenses',
          color: COLORS.brand,
          description:
            truncate(
              licenses
                .map(
                  (license) =>
                    `\`${license.key}\` · ${licensePlanLabel(license)} · ${licenseServerLimit(license)} seats · ${license.status} · ${license.owner_id ? `<@${license.owner_id}>` : 'unassigned'}`,
                )
                .join('\n'),
              4000,
            ) || 'No licenses found.',
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
