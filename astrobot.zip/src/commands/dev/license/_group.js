export default {
  description: 'Inspect and revoke issued licenses.',
};
