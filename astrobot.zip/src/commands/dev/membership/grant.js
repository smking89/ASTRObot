import { grantMembership } from '../../../db/repositories/memberships.js';
import { parseIntStrict } from '../../../utils/parse.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';
import { MessageFlags } from 'discord.js';
import { relativeTimestamp } from '../../../utils/format.js';

export default {
  name: 'grant',
  description: 'Grant a Discord user Astro Pro membership.',
  access: 'developer',
  configure(sub) {
    sub.addUserOption((option) => option.setName('user').setDescription('Recipient').setRequired(true));
    sub.addStringOption((option) =>
      option
        .setName('tier')
        .setDescription('Membership tier')
        .addChoices(
          { name: 'Pro', value: 'pro' },
          { name: 'Lifetime', value: 'lifetime' },
        ),
    );
    sub.addIntegerOption((option) => option.setName('days').setDescription('Duration in days (blank = permanent)').setMinValue(1).setMaxValue(3650));
  },
  async execute(ctx) {
    const target = ctx.option('user');
    const days = ctx.option('days');
    const expiresAt = days ? Date.now() + parseIntStrict(days, { min: 1, max: 3650, label: 'days' }) * 86_400_000 : null;

    grantMembership({ userId: target.id, tier: ctx.option('tier') ?? 'pro', grantedBy: ctx.userId, expiresAt });

    await ctx.reply({
      embeds: [
        buildEmbed({
          description: `<@${target.id}> now has **${ctx.option('tier') ?? 'pro'}** membership${expiresAt ? ` until ${relativeTimestamp(expiresAt, 'D')}` : ''}.`,
          color: COLORS.success,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
