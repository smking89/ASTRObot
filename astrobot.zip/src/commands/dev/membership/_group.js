export default {
  description: 'Grant or revoke Astro Pro membership.',
};
