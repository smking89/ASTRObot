import { revokeMembership } from '../../../db/repositories/memberships.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';
import { MessageFlags } from 'discord.js';
import { ValidationError } from '../../../core/errors.js';

export default {
  name: 'revoke',
  description: "Revoke a Discord user's Astro Pro membership.",
  access: 'developer',
  configure(sub) {
    sub.addUserOption((option) => option.setName('user').setDescription('Member').setRequired(true));
  },
  async execute(ctx) {
    const target = ctx.option('user');
    if (!revokeMembership(target.id)) throw new ValidationError('That user has no membership.');

    await ctx.reply({
      embeds: [buildEmbed({ description: `Membership revoked for <@${target.id}>.`, color: COLORS.warning })],
      flags: MessageFlags.Ephemeral,
    });
  },
};
