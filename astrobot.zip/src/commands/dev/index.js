export default {
  name: 'dev',
  label: 'Developer Administration',
  description: 'Developer administration: guild approvals, memberships, licenses and ads.',
  access: 'developer',
  panel: { id: 'dev' },
};
