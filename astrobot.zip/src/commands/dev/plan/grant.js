import { MessageFlags } from 'discord.js';
import { grantMembership } from '../../../db/repositories/memberships.js';
import { PLAN_CATALOG, DAY_MS, normalizePlanId } from '../../../config/plans.js';
import { syncOwnedGuildPlans } from '../../../services/plan-service.js';
import { ValidationError } from '../../../core/errors.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';
import { relativeTimestamp } from '../../../utils/format.js';

export default {
  name: 'grant',
  description: 'Give a player a free Pro or Max trial with a chosen seat count.',
  access: 'developer',
  configure(sub) {
    sub.addUserOption((option) => option.setName('user').setDescription('Recipient').setRequired(true));
    sub.addStringOption((option) =>
      option
        .setName('plan')
        .setDescription('Plan to grant')
        .setRequired(true)
        .addChoices(
          { name: 'Pro — $12/mo or $120/yr', value: 'pro' },
          { name: 'Max — $29/mo or $290/yr', value: 'max' },
        ),
    );
    sub.addStringOption((option) =>
      option
        .setName('duration')
        .setDescription('Free trial length')
        .setRequired(true)
        .addChoices(
          { name: 'Lifetime — free for life', value: 'lifetime' },
          { name: '2 weeks — 14 days', value: '14' },
          { name: '30 days', value: '30' },
          { name: 'Custom days', value: 'custom' },
        ),
    );
    sub.addIntegerOption((option) =>
      option.setName('servers').setDescription('How many Discord servers the grant covers').setMinValue(1).setMaxValue(50),
    );
    sub.addIntegerOption((option) =>
      option.setName('days').setDescription('Custom duration in days (only used with Custom days)').setMinValue(1).setMaxValue(3650),
    );
  },
  async execute(ctx) {
    const target = ctx.option('user');
    const tier = normalizePlanId(ctx.option('plan'));
    if (tier === 'basic') throw new ValidationError('Choose Pro or Max.');
    if (!target?.id) throw new ValidationError('Choose a recipient.');

    const duration = String(ctx.option('duration') ?? '');
    let days = null;
    if (duration === 'lifetime') {
      days = null;
    } else if (duration === 'custom') {
      const customDays = Number(ctx.option('days'));
      if (!Number.isInteger(customDays) || customDays < 1) {
        throw new ValidationError('Enter the custom duration in days.');
      }
      days = customDays;
    } else if (duration === '14' || duration === '30') {
      days = Number(duration);
    } else {
      throw new ValidationError('Choose a duration.');
    }

    const baseSeats = PLAN_CATALOG[tier].limits.discordServers;
    const seats = Math.max(1, Math.trunc(Number(ctx.option('servers') || baseSeats)));
    if (!Number.isFinite(seats) || seats > 50) throw new ValidationError('Choose between 1 and 50 server seats.');

    const expiresAt = days ? Date.now() + days * DAY_MS : null;
    const membership = grantMembership({
      userId: target.id,
      tier,
      grantedBy: `dev:${ctx.userId}`,
      expiresAt,
      serverLimit: seats,
    });
    // Use the membership's actual expiry: granting the same tier again adds the
    // new days on top of any time the player already had left.
    const effectiveExpiry = membership?.expires_at ? Number(membership.expires_at) : null;
    const synced = syncOwnedGuildPlans({ ownerId: target.id, tier, expiresAt: effectiveExpiry, seatLimit: seats });

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: '🎁 Free trial granted',
          description: `<@${target.id}> received **${PLAN_CATALOG[tier].label}** ${days ? `for **${days} days**` : '**for life**'}.`,
          color: COLORS.success,
          fields: [
            { name: 'Plan', value: PLAN_CATALOG[tier].label, inline: true },
            { name: 'Duration', value: days ? `${days} days` : 'Lifetime', inline: true },
            { name: 'Server seats', value: String(seats), inline: true },
            { name: 'Already attached', value: String(synced), inline: true },
            {
              name: 'Expires',
              value: effectiveExpiry ? relativeTimestamp(effectiveExpiry, 'f') : 'Never',
              inline: true,
            },
            {
              name: 'Next step',
              value: 'The recipient runs `/plan` in each server they own to use a seat. Extra seats are $6/mo or $60/yr.',
              inline: false,
            },
          ],
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
