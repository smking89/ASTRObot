export default {
  description: 'Assign plans to a guild or grant free trials to a player.',
};
