import { MessageFlags } from 'discord.js';
import { setManualPlan, assertGuildSeatAvailable } from '../../../services/plan-service.js';
import { DAY_MS } from '../../../config/plans.js';
import { ValidationError } from '../../../core/errors.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';
import { relativeTimestamp } from '../../../utils/format.js';

export default {
  name: 'assign',
  description: 'Assign a Basic, Pro or Max plan to a guild.',
  access: 'developer',
  configure(sub) {
    sub.addStringOption((option) => option.setName('guild').setDescription('Discord guild ID').setRequired(true));
    sub.addStringOption((option) =>
      option
        .setName('plan')
        .setDescription('Plan to apply')
        .setRequired(true)
        .addChoices(
          { name: 'Basic — free', value: 'basic' },
          { name: 'Pro — $12/mo or $120/yr', value: 'pro' },
          { name: 'Max — $29/mo or $290/yr', value: 'max' },
        ),
    );
    sub.addUserOption((option) => option.setName('owner').setDescription('Billing owner (required for Pro and Max seats)'));
    sub.addIntegerOption((option) =>
      option.setName('days').setDescription('Days until the plan expires (blank = no expiry)').setMinValue(1).setMaxValue(3650),
    );
  },
  async execute(ctx) {
    const guildId = String(ctx.option('guild') ?? '').trim();
    if (!/^\d{15,22}$/.test(guildId)) throw new ValidationError('Enter a valid Discord guild ID.');
    const planId = String(ctx.option('plan') ?? 'basic');
    const ownerId = ctx.option('owner')?.id ?? null;
    const days = ctx.option('days');

    if (planId !== 'basic' && !ownerId) {
      throw new ValidationError('Pro and Max need an owner so the Discord-server seat count can be enforced.');
    }

    assertGuildSeatAvailable({ ownerId, tier: planId, guildId });
    const expiresAt = days ? Date.now() + Number(days) * DAY_MS : null;
    const plan = setManualPlan({ guildId, tier: planId, expiresAt, ownerId });

    await ctx.reply({
      embeds: [
        buildEmbed({
          description: `Guild \`${guildId}\` is now on **${plan.label}**${
            plan.expiresAt ? ` until ${relativeTimestamp(plan.expiresAt, 'D')}` : ''
          }.`,
          color: COLORS.success,
          fields: [
            { name: 'RCON servers', value: String(plan.limits.rconServers), inline: true },
            { name: 'Hosted pages', value: String(plan.limits.hostedGiveawayPages), inline: true },
            { name: 'Analytics', value: `${plan.limits.analyticsDays} days`, inline: true },
          ],
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
