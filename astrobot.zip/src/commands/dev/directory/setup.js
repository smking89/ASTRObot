import { env } from '../../../config/env.js';
import { listGuilds } from '../../../db/repositories/guilds.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS, WEB_BASE_URL } from '../../../config/constants.js';
import { MessageFlags } from 'discord.js';
import { ValidationError } from '../../../core/errors.js';

export default {
  name: 'setup',
  description: 'Set up the cross-server AstroBot Directory hub.',
  access: 'developer',
  configure(sub) {
    sub.addChannelOption((option) => option.setName('channel').setDescription('Channel in the official guild').setRequired(true));
  },
  async execute(ctx) {
    if (!env.discord.officialGuildId) throw new ValidationError('OFFICIAL_GUILD_ID is not configured.');
    if (ctx.guildId !== env.discord.officialGuildId) throw new ValidationError('Run this inside the official guild.');

    const channel = ctx.option('channel');
    const approved = listGuilds({ approved: true, limit: 50 });

    const embed = buildEmbed({
      title: '🌐 AstroBot Directory',
      color: COLORS.brand,
      description:
        `Approved communities running AstroBot.\n\n${approved.map((guild) => `• ${guild.name ?? guild.id}`).join('\n') || 'No approved servers yet.'}`,
      fields: [{ name: 'List your server', value: `${WEB_BASE_URL}/directory` }],
      footer: `${approved.length} communities`,
    });

    await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });

    await ctx.reply({
      embeds: [buildEmbed({ description: `Directory published in <#${channel.id}>.`, color: COLORS.success })],
      flags: MessageFlags.Ephemeral,
    });
  },
};
