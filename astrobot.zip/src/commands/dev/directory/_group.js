export default {
  description: 'Configure the cross-server AstroBot directory hub.',
};
