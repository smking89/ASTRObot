import { patchGuildSetting } from '../../db/repositories/guilds.js';
import { parseHexColor, parseIntStrict } from '../../utils/parse.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';

export default {
  name: 'ads',
  description: 'Configure global recurring in-game advertisements, colors and sizes.',
  access: 'developer',
  configure(sub) {
    sub.addStringOption((option) => option.setName('line').setDescription('Advertisement text').setMaxLength(200));
    sub.addStringOption((option) => option.setName('color').setDescription('Hex color, e.g. #8b5cf6').setMaxLength(7));
    sub.addIntegerOption((option) => option.setName('size').setDescription('Font size').setMinValue(8).setMaxValue(48));
    sub.addIntegerOption((option) => option.setName('interval').setDescription('Seconds between ads').setMinValue(30).setMaxValue(86_400));
    sub.addBooleanOption((option) => option.setName('enabled').setDescription('Enable or disable ads'));
  },
  async execute(ctx) {
    const updates = {};
    const line = ctx.option('line');
    const color = ctx.option('color');
    const size = ctx.option('size');
    const interval = ctx.option('interval');
    const enabled = ctx.option('enabled');

    if (line) updates.lines = [...(ctx.guildConfig.ads.lines ?? []), line];
    if (color) updates.color = `#${parseHexColor(color).toString(16).padStart(6, '0')}`;
    if (size !== null) updates.size = parseIntStrict(size, { min: 8, max: 48, label: 'size' });
    if (interval !== null) updates.intervalSeconds = parseIntStrict(interval, { min: 30, max: 86_400, label: 'interval' });
    if (enabled !== null) updates.enabled = enabled;

    if (Object.keys(updates).length === 0) {
      return ctx.reply({
        embeds: [buildEmbed({ title: 'Ad settings', color: COLORS.brand, fields: Object.entries(ctx.guildConfig.ads).map(([key, value]) => ({ name: key, value: String(typeof value === 'object' ? JSON.stringify(value) : value), inline: true })) })],
        flags: MessageFlags.Ephemeral,
      });
    }

    const { settings } = patchGuildSetting(ctx.guildId, 'ads', { ...ctx.guildConfig.ads, ...updates }, { actorId: ctx.userId });
    ctx.guildConfig = settings;

    await ctx.reply({
      embeds: [buildEmbed({ description: 'Ad settings updated.', color: COLORS.success })],
      flags: MessageFlags.Ephemeral,
    });
  },
};
