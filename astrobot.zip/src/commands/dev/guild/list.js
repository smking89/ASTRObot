import { listGuilds } from '../../../db/repositories/guilds.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';
import { MessageFlags } from 'discord.js';
import { truncate } from '../../../utils/format.js';

export default {
  name: 'list',
  description: 'View approved servers.',
  access: 'developer',
  configure(sub) {
    sub.addBooleanOption((option) => option.setName('pending').setDescription('List pending guilds instead'));
  },
  async execute(ctx) {
    const pending = Boolean(ctx.option('pending'));
    const guilds = listGuilds({ approved: !pending, limit: 25 });

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: pending ? 'Pending guilds' : 'Approved guilds',
          color: pending ? COLORS.warning : COLORS.success,
          description:
            truncate(
              guilds
                .map((guild) => `\`${guild.id}\` · ${guild.name ?? 'unknown'} · plan ${guild.plan}`)
                .join('\n'),
              4000,
            ) || 'Nothing here.',
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
