import { approveGuild, getGuild } from '../../../db/repositories/guilds.js';
import { ValidationError } from '../../../core/errors.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';
import { MessageFlags } from 'discord.js';

export default {
  name: 'approve',
  description: 'Approve a server to install AstroBot.',
  access: 'developer',
  configure(sub) {
    sub.addStringOption((option) => option.setName('guild').setDescription('Guild ID').setRequired(true).setMaxLength(25));
  },
  async execute(ctx) {
    const guildId = ctx.option('guild').replaceAll(/\D/g, '');
    const guild = getGuild(guildId);
    if (!guild) throw new ValidationError('That guild has not installed AstroBot.');

    approveGuild(guildId, ctx.userId);

    await ctx.reply({
      embeds: [buildEmbed({ description: `Guild \`${guildId}\` approved.`, color: COLORS.success })],
      flags: MessageFlags.Ephemeral,
    });
  },
};
