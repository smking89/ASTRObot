export default {
  description: 'Approve, revoke and list guild installations.',
};
