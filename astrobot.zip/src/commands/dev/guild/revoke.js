import { getGuild, revokeGuild } from '../../../db/repositories/guilds.js';
import { ValidationError } from '../../../core/errors.js';
import { buildEmbed } from '../../../ui/embeds.js';
import { COLORS } from '../../../config/constants.js';
import { MessageFlags } from 'discord.js';

export default {
  name: 'revoke',
  description: 'Revoke server installation approval.',
  access: 'developer',
  configure(sub) {
    sub.addStringOption((option) => option.setName('guild').setDescription('Guild ID').setRequired(true).setMaxLength(25));
  },
  async execute(ctx) {
    const guildId = ctx.option('guild').replaceAll(/\D/g, '');
    if (!getGuild(guildId)) throw new ValidationError('Unknown guild.');

    revokeGuild(guildId, ctx.userId);

    await ctx.reply({
      embeds: [buildEmbed({ description: `Guild \`${guildId}\` revoked.`, color: COLORS.warning })],
      flags: MessageFlags.Ephemeral,
    });
  },
};
