import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('mod-panel')
    .setDescription('Open the moderator hub: cases, appeals, staff tools, wipes and status.')
    .setDMPermission(false),
  access: 'staff',
  async execute(ctx) {
    await ctx.panel('mod-hub');
  },
};
