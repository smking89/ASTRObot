import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('player-panel')
    .setDescription('Open the player kit-claiming panel.')
    .setDMPermission(false),
  access: 'player',
  async execute(ctx) {
    await ctx.panel('player-panel');
  },
};
