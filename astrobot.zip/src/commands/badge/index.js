export default {
  name: 'badge',
  label: 'Badges',
  description: 'Staff badge tools: award, revoke and list player badges.',
  access: 'staff',
};
