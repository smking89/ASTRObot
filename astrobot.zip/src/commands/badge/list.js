import { MessageFlags } from 'discord.js';
import { listBadges } from '../../services/badge-service.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { inlineCode, truncate } from '../../utils/format.js';

/** /badge list — the catalogue staff can award, including clan uploads. */
export default {
  name: 'list',
  description: 'List every badge that can be awarded in this server.',
  access: 'staff',
  async execute(ctx) {
    const badges = listBadges(ctx.guildId);
    const builtin = badges.filter((badge) => badge.requirement !== 'Clan badge');
    const clan = badges.filter((badge) => badge.requirement === 'Clan badge');

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: 'Badge catalogue',
          color: COLORS.brand,
          description: 'Award one with `/badge give`, take one back with `/badge remove`.',
          fields: [
            {
              name: `Server badges · ${builtin.length}`,
              value: truncate(
                builtin.map((badge) => `${inlineCode(badge.id)} · **${badge.label}** · ${badge.requirement}`).join('\n'),
                1024,
              ),
            },
            {
              name: `Clan badges · ${clan.length}`,
              value: clan.length
                ? truncate(clan.map((badge) => `${inlineCode(badge.id)} · **${badge.label}**`).join('\n'), 1024)
                : 'None yet. Clan leaders upload icons with `/team badge upload`.',
            },
          ],
          footer: 'Badges render with their real icon, never an emoji',
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
