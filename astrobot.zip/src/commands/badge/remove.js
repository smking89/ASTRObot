import { MessageFlags } from 'discord.js';
import { badgeChoices, badgeDefinition, ownedBadgeIds, revokeBadge } from '../../services/badge-service.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { ValidationError } from '../../core/errors.js';
import { parseUserId } from '../../utils/parse.js';

/** /badge remove — staff revoke a badge from a member. */
export default {
  name: 'remove',
  description: 'Revoke a badge from a member.',
  access: 'staff',
  configure(sub) {
    sub.addUserOption((option) => option.setName('member').setDescription('Member losing the badge').setRequired(true));
    sub.addStringOption((option) =>
      option.setName('badge').setDescription('Pick a badge they own').setRequired(true).setMaxLength(40).setAutocomplete(true),
    );
  },
  /**
   * Only the selected member's badges appear. Without a member the full
   * catalogue is shown, because Discord may focus this field first.
   */
  async autocomplete(ctx) {
    const focused = ctx.interaction.options.getFocused(true);
    const member = String(ctx.option('member') ?? '');
    const owns = /^\d{15,20}$/.test(member) ? ownedBadgeIds(ctx.guildId, member) : null;
    await ctx.interaction.respond(badgeChoices(ctx.guildId, focused?.value, { onlyIds: owns }));
  },
  async execute(ctx) {
    const raw = String(ctx.option('member') ?? '');
    const userId = /^\d{15,20}$/.test(raw) ? raw : parseUserId(raw);
    if (!userId) throw new ValidationError('Choose a member to remove the badge from.');

    const definition = badgeDefinition(ctx.guildId, ctx.option('badge'));
    if (!definition) throw new ValidationError('Unknown badge. Run `/badge list` to see the available badges.');

    const removed = revokeBadge({ guildId: ctx.guildId, userId, badgeId: definition.id });

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: removed ? 'Badge revoked' : 'Badge not owned',
          description: removed
            ? `<@${userId}> no longer has **${definition.label}**.`
            : `<@${userId}> does not have **${definition.label}**.`,
          color: removed ? COLORS.success : COLORS.warning,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
