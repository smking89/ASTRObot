import { MessageFlags } from 'discord.js';
import { awardBadge, badgeChoices, badgeDefinition } from '../../services/badge-service.js';
import { badgeAttachment, badgeImage } from '../../ui/badge-assets.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { ValidationError } from '../../core/errors.js';
import { parseUserId } from '../../utils/parse.js';

/** /badge give — staff award any built-in or clan badge. */
export default {
  name: 'give',
  description: 'Award a badge to a member.',
  access: 'staff',
  configure(sub) {
    sub.addUserOption((option) => option.setName('member').setDescription('Member who receives the badge').setRequired(true));
    sub.addStringOption((option) =>
      option.setName('badge').setDescription('Pick a badge').setRequired(true).setMaxLength(40).setAutocomplete(true),
    );
  },
  /** Dropdown of every badge staff can award, including clan uploads. */
  async autocomplete(ctx) {
    const focused = ctx.interaction.options.getFocused(true);
    await ctx.interaction.respond(badgeChoices(ctx.guildId, focused?.value));
  },
  async execute(ctx) {
    const raw = String(ctx.option('member') ?? '');
    const userId = /^\d{15,20}$/.test(raw) ? raw : parseUserId(raw);
    if (!userId) throw new ValidationError('Choose a member to award the badge to.');

    const definition = badgeDefinition(ctx.guildId, ctx.option('badge'));
    if (!definition) throw new ValidationError('Unknown badge. Run `/badge list` to see the available badges.');

    const { created } = awardBadge({
      guildId: ctx.guildId,
      userId,
      badgeId: definition.id,
      awardedBy: ctx.userId,
    });

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: created ? 'Badge awarded' : 'Badge already owned',
          description: `<@${userId}> ${created ? 'now has' : 'already has'} **${definition.label}**.`,
          thumbnail: badgeImage(definition),
          color: created ? COLORS.success : COLORS.info,
        }),
      ],
      files: [badgeAttachment(definition)],
      flags: MessageFlags.Ephemeral,
    });
  },
};
