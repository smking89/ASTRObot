import { SlashCommandBuilder } from 'discord.js';

export default {
  data: new SlashCommandBuilder()
    .setName('market')
    .setDescription('Buy, sell and bid on player-owned items, kits and roles.')
    .setDMPermission(false),
  access: 'player',
  async execute(ctx) {
    await ctx.panel('market');
  },
};
