import { randomInt } from 'node:crypto';
import { createReferralCode, getReferral } from '../../db/repositories/referrals.js';
import { getGuildSettings } from '../../db/repositories/guilds.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';
import { formatCoins } from '../../utils/format.js';

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function generateCode() {
  let suffix = '';
  for (let index = 0; index < 6; index += 1) suffix += ALPHABET[randomInt(0, ALPHABET.length)];
  return `ASTRO${suffix}`;
}

export default {
  name: 'create',
  description: 'Generate a referral code.',
  access: 'player',
  configure(sub) {
    sub.addStringOption((option) => option.setName('code').setDescription('Custom code (optional)').setMinLength(3).setMaxLength(16));
    sub.addIntegerOption((option) => option.setName('uses').setDescription('Max redemptions').setMinValue(1).setMaxValue(10_000));
  },
  async execute(ctx) {
    const requested = ctx.option('code');
    let code = requested ? requested.trim().toUpperCase().replaceAll(/[^A-Z0-9_-]/g, '') : generateCode();

    if (requested && code.length < 3) throw new (await import('../../core/errors.js')).ValidationError('Code must be at least 3 characters.');

    let attempts = 0;
    while (getReferral(code) && attempts < 5) {
      code = generateCode();
      attempts += 1;
    }

    const maxUses = ctx.option('uses') ?? null;

    if (getReferral(code)) {
      throw new (await import('../../core/errors.js')).ValidationError('That code is taken. Try another.');
    }

    createReferralCode({ guildId: ctx.guildId, ownerId: ctx.userId, code, maxUses });

    const settings = getGuildSettings(ctx.guildId);

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: 'Referral code created',
          color: COLORS.success,
          description: `Share **${code}** with new players. You earn ${formatCoins(settings.economy.referralBonus)} per verified redemption.`,
          footer: maxUses ? `Limited to ${maxUses} redemption(s)` : 'Unlimited redemptions',
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
