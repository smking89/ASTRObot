export default {
  name: 'referral',
  label: 'Referral Program',
  description: 'Referral program: create codes, redeem invites and view standings.',
  access: 'player',
  panel: { id: 'referral' },
};
