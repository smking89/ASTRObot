import { claimReferral } from '../../db/repositories/referrals.js';
import { getGuildSettings } from '../../db/repositories/guilds.js';
import { credit } from '../../services/economy-service.js';
import { ValidationError } from '../../core/errors.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';
import { formatCoins } from '../../utils/format.js';

export default {
  name: 'redeem',
  description: 'Redeem a referral code.',
  access: 'player',
  configure(sub) {
    sub.addStringOption((option) => option.setName('code').setDescription('Referral code').setRequired(true).setMaxLength(16));
  },
  async execute(ctx) {
    const settings = getGuildSettings(ctx.guildId);
    const reward = Number(settings.economy.referralBonus) || 0;

    const result = claimReferral({
      guildId: ctx.guildId,
      code: ctx.option('code').trim().toUpperCase(),
      invitedId: ctx.userId,
      reward,
    });

    const reasons = {
      invalid: 'That code is not valid in this server.',
      self: 'You cannot redeem your own code.',
      exhausted: 'That code has reached its limit.',
      already_claimed: 'You have already redeemed a referral code here.',
    };

    if (!result.ok) throw new ValidationError(reasons[result.reason] ?? 'That code could not be redeemed.');

    const signupBonus = Math.floor(reward / 2);
    credit({ guildId: ctx.guildId, userId: result.referral.owner_id, amount: reward, kind: 'referral_bonus' });
    credit({ guildId: ctx.guildId, userId: ctx.userId, amount: signupBonus, kind: 'referral_signup' });

    await ctx.reply({
      embeds: [
        buildEmbed({
          description: `Code redeemed. <@${result.referral.owner_id}> earned ${formatCoins(reward)} and you received ${formatCoins(signupBonus)}.`,
          color: COLORS.success,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
