export default {
  name: 'leaderboard',
  description: 'View referral standings.',
  access: 'player',
  async execute(ctx) {
    await ctx.panel('leaderboards', { metric: 'referrals' });
  },
};
