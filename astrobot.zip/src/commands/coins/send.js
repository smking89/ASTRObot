import { transfer } from '../../services/economy-service.js';
import { parseIntStrict } from '../../utils/parse.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';
import { formatCoins } from '../../utils/format.js';

export default {
  name: 'send',
  description: 'Send coins to another player.',
  access: 'player',
  configure(sub) {
    sub.addUserOption((option) => option.setName('player').setDescription('Recipient').setRequired(true));
    sub.addIntegerOption((option) =>
      option.setName('amount').setDescription('Amount to send').setRequired(true).setMinValue(1).setMaxValue(1_000_000_000),
    );
  },
  async execute(ctx) {
    const target = ctx.option('player');
    const amount = parseIntStrict(ctx.option('amount'), { min: 1, max: 1_000_000_000, label: 'amount' });

    const result = transfer({ guildId: ctx.guildId, fromId: ctx.userId, toId: target.id, amount });

    await ctx.reply({
      embeds: [
        buildEmbed({
          description: `Sent ${formatCoins(result.received)} to <@${target.id}>${result.fee ? ` (${formatCoins(result.fee)} fee burned)` : ''}.`,
          color: COLORS.success,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
