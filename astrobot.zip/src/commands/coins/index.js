export default {
  name: 'coins',
  label: 'Currency',
  description: 'Currency management: wallet, safe bank, transfers and daily bonuses.',
  access: 'player',
  panel: { id: 'coins' },
};
