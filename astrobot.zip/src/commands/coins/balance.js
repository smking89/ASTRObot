import { balances } from '../../services/economy-service.js';
import { buildEmbed } from '../../ui/embeds.js';
import { COLORS, EMOJI } from '../../config/constants.js';
import { MessageFlags } from 'discord.js';
import { formatCoins } from '../../utils/format.js';

export default {
  name: 'balance',
  description: 'View your currency balance.',
  access: 'player',
  configure(sub) {
    sub.addUserOption((option) => option.setName('player').setDescription('View another member’s balance'));
  },
  async execute(ctx) {
    const target = ctx.option('player') ?? ctx.user;
    const account = balances(ctx.guildId, target.id);

    await ctx.reply({
      embeds: [
        buildEmbed({
          title: `${EMOJI.wallet} ${target.id === ctx.userId ? 'Your wallet' : `${target.username}'s wallet`}`,
          color: COLORS.gold,
          fields: [
            { name: 'Wallet', value: formatCoins(account.wallet, account.currency), inline: true },
            { name: 'Safe bank', value: formatCoins(account.bank, account.currency), inline: true },
            { name: 'Total', value: formatCoins(account.total, account.currency), inline: true },
          ],
          footer: 'Wallet cash is lost on death; bank storage is safe',
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
  },
};
