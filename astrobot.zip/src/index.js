import { env, assertRuntimeEnv } from './config/env.js';
import { logger } from './core/logger.js';
import { initDatabase, closeDatabase } from './db/index.js';
import { loadRegistry } from './core/loader.js';
import { registerLoaded } from './core/registry.js';
import { createClient } from './core/client.js';
import { startJobs } from './services/jobs.js';
import { runtime } from './core/runtime.js';

/**
 * AstroBot bootstrap.
 *
 * 1. validate env
 * 2. open + migrate SQLite
 * 3. load every command / component / panel file
 * 4. attach gateway events and log in
 * 5. start background loops (RCON, scheduler, playtime, Tip4Serv webhook)
 */
async function main() {
  assertRuntimeEnv();
  initDatabase();

  const loaded = await loadRegistry();
  registerLoaded(loaded);

  const client = createClient();
  runtime.client = client;

  const jobs = startJobs(client);
  runtime.jobs = jobs;
  runtime.rconManager = jobs.rconManager;

  const shutdown = async (signal) => {
    logger.info(`Received ${signal}; shutting down.`);
    try {
      await jobs.stop();
      await client.destroy();
      closeDatabase();
    } finally {
      process.exit(0);
    }
  };

  process.once('SIGINT', () => void shutdown('SIGINT'));
  process.once('SIGTERM', () => void shutdown('SIGTERM'));
  process.on('unhandledRejection', (reason) => logger.error('Unhandled promise rejection', reason));
  process.on('uncaughtException', (error) => {
    logger.error('Uncaught exception', error);
    // Keep the process alive for non-fatal faults; the reporter records the stack.
  });

  await client.login(env.discord.token);
  logger.info(`AstroBot online in ${env.nodeEnv} mode.`);
}

main().catch((error) => {
  logger.error('Fatal startup error', error);
  process.exit(1);
});
