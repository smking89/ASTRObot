import { HUB_MOD_DESTINATIONS } from '../config/panel-hub.js';
import { hubView } from '../ui/hub-view.js';
import { COLORS } from '../config/constants.js';

/** Moderator hub: cases, staff tools, wipes and live server state. */
export default {
  id: 'mod-hub',
  async render({ params = {} }) {
    return hubView({
      id: 'mod-hub',
      title: '🔨 Moderator Panel',
      description:
        params.notice ??
        'Moderator tools: moderation cases, appeals, staff reports, wipe countdowns and the live RCON fleet state.',
      destinations: HUB_MOD_DESTINATIONS,
      highlights: 'Moderation cases · appeals · staff reports · wipes · server status',
      footer: 'AstroBot panel · moderator',
      color: COLORS.info,
      buttons: [
        { panel: 'mod', label: 'Moderation', emoji: '🔨' },
        { panel: 'staff', label: 'Staff', emoji: '🛡️' },
        { panel: 'wipe', label: 'Wipes', emoji: '🧨' },
        { panel: 'status', label: 'Status', emoji: '📡' },
      ],
    });
  },
};
