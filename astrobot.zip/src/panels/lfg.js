import { ButtonStyle } from 'discord.js';
import { getPost, isMember, listByOwner, listMembers, listOpen, listOpenGlobal } from '../db/repositories/lfg.js';
import { getAccount } from '../db/repositories/players.js';
import { personalRank } from '../ui/rank-icons.js';
import { iconAttachment, iconUrl } from '../ui/badge-assets.js';
import { getGuild, getGuildSettings } from '../db/repositories/guilds.js';
import { COLORS, EMOJI } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { relativeTimestamp, truncate } from '../utils/format.js';

/** /lfg fallback panel: create, browse, manage and close listings. */
export default {
  id: 'lfg',
  async render({ ctx, params }) {
    const settings = getGuildSettings(ctx.guildId);

    if (params.postId) {
      const post = getPost(params.postId);
      if (!post) return this.render({ ctx, params: {} });

      const members = listMembers(post.id);
      const isOwner = post.owner_id === ctx.userId;
      const joined = isMember(post.id, ctx.userId);
      const full = Number(post.filled) >= Number(post.players_needed);
      const canJoin = !isOwner && !joined && post.status === 'open' && !full;
      const canLeave = !isOwner && joined && post.status === 'open';
      const memberText = members.length
        ? truncate(members.map((member) => `<@${member.user_id}>`).join(', '), 1024)
        : 'None';
      const ownerRank = personalRank(getAccount(ctx.guildId, post.owner_id)?.level ?? 1);

      const embed = buildEmbed({
        title: post.title,
        color: COLORS.brand,
        description: post.description || 'No description.',
        thumbnail: iconUrl(ownerRank.icon),
        fields: [
          { name: 'Owner', value: `<@${post.owner_id}>`, inline: true },
          { name: 'Owner rank', value: `**${ownerRank.label}**`, inline: true },
          { name: 'Platform', value: post.platform, inline: true },
          { name: 'Region', value: post.region, inline: true },
          { name: 'Party', value: `${post.filled}/${post.players_needed}`, inline: true },
          { name: 'Members', value: memberText, inline: false },
          { name: 'Created', value: relativeTimestamp(post.created_at, 'R'), inline: true },
        ],
        footer: `Status: ${post.status}`,
      });

      const controls = [
        row(
          button({
            id: customId('lfg', canLeave ? 'leave' : 'join', post.id),
            label: canLeave ? 'Leave' : 'Join',
            emoji: canLeave ? '👋' : '🙋',
            style: canLeave ? ButtonStyle.Secondary : ButtonStyle.Success,
            disabled: isOwner || (!canJoin && !canLeave),
          }),
          button({
            id: customId('lfg', 'close', post.id),
            label: 'Close',
            style: ButtonStyle.Danger,
            disabled: !isOwner || post.status !== 'open',
          }),
          button({ id: customId('lfg', 'browse'), label: 'Browse all' }),
        ),
        navRow({ backPanel: 'lfg' }),
      ];

      return { embeds: [embed], components: controls, files: [iconAttachment(ownerRank.icon)] };
    }

    const enabled = settings.lfg.enabled !== false;
    const global = enabled && settings.lfg.scope === 'global';
    const posts = enabled ? (global ? listOpenGlobal({ limit: 8 }) : listOpen(ctx.guildId, { limit: 8 })) : [];
    const mine = listByOwner(ctx.guildId, ctx.userId);

    const embed = buildEmbed({
      title: `${EMOJI.lfg} Looking for Group`,
      color: enabled ? COLORS.brand : COLORS.warning,
      description: !enabled
        ? 'Looking for Group is switched off in this server. Staff can enable it in /config → Feature switches.'
        : posts.length === 0
          ? global
            ? 'No global listings yet. Create one and every LFG-enabled server can see it.'
            : 'No open listings yet. Create one and it will be visible to everyone in the server.'
          : global
            ? 'Open parties recruiting across every LFG-enabled server.'
            : 'Open parties currently recruiting.',
      fields: [
        {
          name: 'Open listings',
          value: truncate(
            posts
              .map((post) => {
                const origin = global ? ` · ${truncate(getGuild(post.guild_id)?.name ?? post.guild_id, 28)}` : '';
                return `**${truncate(post.title, 60)}** · <@${post.owner_id}> · ${post.filled}/${post.players_needed}${origin}`;
              })
              .join('\n'),
            1024,
          ) || '—',
        },
        { name: 'Your listings', value: truncate(mine.map((post) => `\`${post.id}\` · ${post.title}`).join('\n'), 1024) || 'None' },
      ],
      footer: `Scope: ${global ? 'global' : 'local'} · max ${settings.lfg.maxActivePerUser} active per member`,
    });

    const controls = [];
    if (posts.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('lfg', 'view'),
            placeholder: 'Open a listing',
            options: posts.map((post) => ({
              label: truncate(post.title, 100),
              value: post.id,
              description: `Owner ${post.owner_id} · ${post.platform} · ${post.filled}/${post.players_needed}`,
            })),
          }),
        ),
      );
    }

    controls.push(
      row(
        button({
          id: customId('lfg', 'create'),
          label: 'Create listing',
          emoji: '➕',
          style: ButtonStyle.Success,
          disabled: !enabled,
        }),
        button({ id: customId('lfg', 'browse'), label: 'Browse', emoji: '🔎' }),
      ),
      navRow({ backPanel: 'lfg' }),
    );

    return { embeds: [embed], components: controls };
  },
};
