import { CONFIG_SECTIONS, sectionById } from '../config/settings-schema.js';
import { settingsPanelPayload, sectionListPayload } from '../ui/settings-view.js';

/**
 * /config fallback panel. Also the target of `/config panel` and the nav
 * "Back" button from every section panel.
 */
export default {
  id: 'config',
  async render({ ctx, params }) {
    if (params.section) {
      const section = sectionById(params.section);
      if (!section) return sectionListPayload(rootPayload(ctx));
      return settingsPanelPayload({
        ctx,
        panelId: 'config',
        section: { id: params.section, ...section },
        channelField: params.channelField ?? null,
        choiceField: params.choiceField ?? null,
      });
    }
    return sectionListPayload(rootPayload(ctx));
  },
};

function rootPayload(ctx) {
  const sections = Object.entries(CONFIG_SECTIONS).map(([id, section]) => ({ id, ...section }));
  return {
    sections,
    panelId: 'config',
    title: '⚙️ Server Configuration',
    description:
      'Everything the bot does in this server is configured here. Pick a category to edit its settings; every change is applied and audited immediately.',
    footer: `${sections.length} categories · ${ctx.guild?.name ?? 'this server'}`,
  };
}
