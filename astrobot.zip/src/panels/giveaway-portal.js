import { getGuildSettings } from '../db/repositories/guilds.js';
import { isActive } from '../db/repositories/memberships.js';
import { planHasFeature } from '../services/plan-service.js';
import { getPortalConfig, issuePortalToken, savePortalConfig } from '../db/repositories/giveaway-portals.js';
import { DEFAULT_PORTAL_CONFIG, normalizePortalConfig } from '../config/giveaway-portal.js';
import { env } from '../config/env.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { linkButton, navRow, row } from '../ui/components.js';
import { relativeTimestamp } from '../utils/format.js';

function hasPortalAccess(ctx, settings) {
  if (isActive(ctx.userId)) return true;
  if (planHasFeature(ctx.guildId, 'hostedPages')) return true;
  const proRoleId = settings.giveawayPortal?.proRoleId;
  if (proRoleId && ctx.member?.roles?.cache?.has?.(proRoleId)) return true;
  // The paid role is named ASTRO PRO in the official layout; honour it even
  // before the owner copies its id into the config field.
  return [...(ctx.member?.roles?.cache?.values?.() ?? [])].some((role) => /astro\s*pro/i.test(String(role?.name ?? '')));
}

/** Astro Pro giveaway page builder entry point. */
export default {
  id: 'giveaway-portal',
  async render({ ctx, params = {} }) {
    const settings = getGuildSettings(ctx.guildId);
    const config = settings.giveawayPortal ?? {};
    const allowed = hasPortalAccess(ctx, settings);

    if (!config.enabled) {
      return {
        embeds: [
          buildEmbed({
            title: '⭐ Astro Pro Giveaway Portal',
            color: COLORS.warning,
            description: 'The giveaway portal is switched off. An administrator can enable it in `/config` → **Astro Pro Giveaway Portal**.',
            footer: 'AstroBot panel · giveaway portal',
          }),
        ],
        components: [navRow({ backPanel: 'onboarding' })],
      };
    }

    if (!allowed) {
      return {
        embeds: [
          buildEmbed({
            title: '⭐ Astro Pro Giveaway Portal',
            color: COLORS.gold,
            description:
              'This portal is a **Pro or Max feature**. Ask the owner to activate a Pro/Max plan for this server, assign the configured Pro role, or grant a membership with `/dev membership grant`.',
            fields: [
              { name: 'What subscribers get', value: 'A branded giveaway landing page, prize/task editor, live countdown, custom colours and a public URL.', inline: false },
              { name: 'Branding', value: DEFAULT_PORTAL_CONFIG.brand, inline: true },
              { name: 'Palette', value: 'Cyan · Magenta · Lime', inline: true },
            ],
            footer: 'AstroBot panel · giveaway portal · Pro only',
          }),
        ],
        components: [navRow({ backPanel: 'onboarding' })],
      };
    }

    const raw = getPortalConfig(ctx.guildId);
    if (!raw) savePortalConfig(ctx.guildId, normalizePortalConfig(DEFAULT_PORTAL_CONFIG), ctx.userId);
    let saved = DEFAULT_PORTAL_CONFIG;
    if (raw) {
      try {
        saved = JSON.parse(raw.config);
      } catch {
        saved = DEFAULT_PORTAL_CONFIG;
      }
    }
    const portal = normalizePortalConfig(saved);
    const token = issuePortalToken({ guildId: ctx.guildId, userId: ctx.userId });
    const base = String(config.publicUrl || env.dashboard.publicUrl).replace(/\/+$/, '');
    const builderUrl = `${base}/giveaway-portal/admin?guild=${encodeURIComponent(ctx.guildId)}&token=${encodeURIComponent(token)}`;
    const publicUrl = `${base}/giveaway-portal/?guild=${encodeURIComponent(ctx.guildId)}`;

    return {
      embeds: [
        buildEmbed({
          title: '⭐ Astro Pro Giveaway Portal',
          color: COLORS.brand,
          description:
            params.notice ??
            'Customize your public giveaway page, then share the preview link. The builder link is private and expires in 24 hours.',
          fields: [
            { name: 'Brand', value: portal.brand, inline: true },
            { name: 'Status', value: '🟢 Published', inline: true },
            { name: 'Prize', value: `${portal.prize.title} · ${portal.prize.value}`, inline: false },
            { name: 'Ends', value: relativeTimestamp(new Date(portal.endTimestamp).getTime(), 'R'), inline: true },
            { name: 'Tasks', value: String(portal.tasks.length), inline: true },
            { name: 'Public URL', value: config.publicUrl || env.dashboard.publicUrl, inline: false },
            {
              name: 'Palette (fixed)',
              value: `\`${portal.colors.cyan}\` cyan · \`${portal.colors.magenta}\` magenta · \`${portal.colors.lime}\` lime`,
              inline: false,
            },
          ],
          footer: 'AstroBot panel · giveaway portal · Pro',
        }),
      ],
      components: [
        row(
          linkButton({ label: 'Open builder', url: builderUrl, emoji: '🎨' }),
          linkButton({ label: 'Preview public page', url: publicUrl, emoji: '👁️' }),
        ),
        navRow({ backPanel: 'onboarding', refreshArgs: ['giveaway-portal'] }),
      ],
    };
  },
};
