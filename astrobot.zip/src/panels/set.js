import { settingsPanelPayload, sectionListPayload } from '../ui/settings-view.js';

/**
 * /set fallback panel: a flatter, task-oriented view over the same settings
 * store. Each quick setting points at the same dotted paths as /config.
 */
export const QUICK_SECTIONS = {
  pricing: {
    id: 'pricing',
    label: 'Pricing',
    emoji: '💰',
    description: 'Shop prices, wager limits, transfer fees and caps.',
    fields: [
      { path: 'economy.walletCap', label: 'Wallet cap', type: 'number' },
      { path: 'economy.bankCap', label: 'Bank cap', type: 'number' },
      { path: 'economy.transferFeePercent', label: 'Transfer fee %', type: 'number' },
      { path: 'battlePass.premium.priceLabel', label: 'Premium price label', type: 'text' },
      { path: 'battlePass.premium.checkoutUrl', label: 'Premium checkout URL', type: 'text' },
    ],
  },
  channel: {
    id: 'channel',
    label: 'Channels',
    emoji: '📺',
    description: 'Designated channels for feeds, logs and panels.',
    fields: [
      { path: 'channels.killfeed', label: 'Killfeed channel', type: 'channel' },
      { path: 'channels.globalKillfeed', label: 'Global killfeed channel', type: 'channel' },
      { path: 'channels.telemetry', label: 'Telemetry channel', type: 'channel' },
      { path: 'channels.joins', label: 'Join/leave channel', type: 'channel' },
      { path: 'channels.raids', label: 'Raid alert channel', type: 'channel' },
      { path: 'channels.modLog', label: 'Mod log channel', type: 'channel' },
      { path: 'channels.broadcasts', label: 'Broadcast channel', type: 'channel' },
      { path: 'games.jackpot.milestoneChannelId', label: 'Jackpot milestone channel', type: 'channel' },
    ],
  },
  message: {
    id: 'message',
    label: 'Messages',
    emoji: '💬',
    description: 'Killfeed layout and rotating message content.',
    fields: [
      { path: 'killfeed.layout', label: 'Killfeed layout', type: 'text' },
      { path: 'killfeed.globalLayout', label: 'Global killfeed layout', type: 'text' },
      { path: 'messages.rotating', label: 'Rotating messages', type: 'json' },
      { path: 'frank.answers', label: 'Frank answers', type: 'json' },
    ],
  },
  style: {
    id: 'style',
    label: 'Appearance',
    emoji: '🎨',
    description: 'Killfeed toggles and ORP map appearance.',
    fields: [
      { path: 'killfeed.enabled', label: 'Killfeed enabled', type: 'boolean' },
      { path: 'killfeed.globalEnabled', label: 'Global killfeed enabled', type: 'boolean' },
      { path: 'killfeed.showNpc', label: 'Show NPC kills', type: 'boolean' },
      { path: 'misc.orpAppearance.shieldColor', label: 'ORP shield color', type: 'color' },
      { path: 'misc.orpAppearance.showOnMap', label: 'ORP on map', type: 'boolean' },
    ],
  },
  roles: {
    id: 'roles',
    label: 'Roles',
    emoji: '🎭',
    description: 'Role gates for staff, admins, restricted config access and teams.',
    fields: [
      { path: 'access.staffRoleIds', label: 'Staff roles', type: 'role' },
      { path: 'access.adminRoleIds', label: 'Admin roles', type: 'role' },
      { path: 'access.restrictedRoleIds', label: 'Restricted roles', type: 'role' },
      { path: 'access.teamRoleIds', label: 'Team roles', type: 'role' },
      { path: 'access.strictRestricted', label: 'Require explicit restricted role', type: 'boolean' },
    ],
  },
  lfg: {
    id: 'lfg',
    label: 'LFG scope',
    emoji: '📣',
    description: 'Who can see listings and how many can stay open.',
    fields: [
      { path: 'lfg.enabled', label: 'LFG enabled', type: 'boolean' },
      {
        path: 'lfg.scope',
        label: 'Scope',
        type: 'select',
        options: [
          { label: 'Local — this server only', value: 'local' },
          { label: 'Global — all LFG-enabled servers', value: 'global' },
        ],
      },
      { path: 'lfg.maxActivePerUser', label: 'Max active per user', type: 'number' },
      { path: 'lfg.defaultPlayers', label: 'Default party size', type: 'number' },
      { path: 'lfg.channelId', label: 'LFG channel', type: 'channel' },
    ],
  },
};

export default {
  id: 'set',
  async render({ ctx, params }) {
    if (params.section) {
      const section = QUICK_SECTIONS[params.section];
      if (section) return settingsPanelPayload({ ctx, panelId: 'set', section, channelField: params.channelField ?? null, choiceField: params.choiceField ?? null });
    }

    return sectionListPayload({
      sections: Object.values(QUICK_SECTIONS),
      panelId: 'set',
      title: '⚡ Quick Settings',
      description: 'High-traffic settings, one click away. Changes save immediately and are written to the settings audit trail.',
      footer: 'For everything else use /config',
    });
  },
};
