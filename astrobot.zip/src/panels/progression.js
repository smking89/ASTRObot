import { ButtonStyle } from 'discord.js';
import { summary, MAX_LEVEL } from '../services/progression-service.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row } from '../ui/components.js';
import { formatNumber, progressBar, relativeTimestamp } from '../utils/format.js';
import { personalRank } from '../ui/rank-icons.js';
import { badgeAttachment, badgeImage, iconAttachment, iconUrl } from '../ui/badge-assets.js';
import { badgeDefinition, badgesFor } from '../services/badge-service.js';

const BADGES = [
  { id: 'first_blood', label: 'First Blood', requirement: '1 kill' },
  { id: 'hunter', label: 'Hunter', requirement: '100 kills' },
  { id: 'survivor', label: 'Survivor', requirement: '7 day streak' },
  { id: 'banker', label: 'Banker', requirement: '1M banked' },
  { id: 'prestige', label: 'Prestige', requirement: 'Reach level 1000' },
];

/** /progression panel. */
export default {
  id: 'progression',
  async render({ ctx }) {
    const data = summary(ctx.guildId, ctx.userId);
    const { account } = data;
    const rank = personalRank(data.level);

    const badges = BADGES.filter((badge) => {
      if (badge.id === 'first_blood') return account.kills >= 1;
      if (badge.id === 'hunter') return account.kills >= 100;
      if (badge.id === 'survivor') return account.streak >= 7;
      if (badge.id === 'banker') return account.bank >= 1_000_000;
      if (badge.id === 'prestige') return account.prestige > 0;
      return false;
    });

    // Staff and clan leaders award badges; each one renders as its real icon.
    const awarded = badgesFor(ctx.guildId, ctx.userId)
      .map((row) => badgeDefinition(ctx.guildId, row.badge_id))
      .filter(Boolean);
    const badgeLabels = [...new Set([...badges.map((badge) => badge.label), ...awarded.map((badge) => badge.label)])];
    const badgeEmbeds = awarded
      .slice(0, 4)
      .map((badge) =>
        buildEmbed({ title: badge.label, description: 'Awarded badge', thumbnail: badgeImage(badge), color: COLORS.brand }),
      );
    const files = [iconAttachment(rank.icon), ...awarded.slice(0, 4).map((badge) => badgeAttachment(badge))];

    const embed = buildEmbed({
      title: '📈 Progression',
      color: COLORS.brand,
      thumbnail: iconUrl(rank.icon),
      description: `Level **${formatNumber(data.level)}** · Prestige **${formatNumber(account.prestige)}** · Astro Score **${formatNumber(account.astro_score)}**`,
      fields: [
        { name: 'XP', value: `${formatNumber(data.intoLevel)} / ${formatNumber(data.needed)}`, inline: true },
        { name: 'Personal rank', value: `**${rank.label}**`, inline: true },
        { name: 'Server rank', value: `#${formatNumber(data.rank ?? 0)}`, inline: true },
        { name: 'Wallet rank', value: `#${formatNumber(data.walletRank ?? 0)}`, inline: true },
        { name: 'Progress to next level', value: progressBar(data.intoLevel, data.needed) },
        {
          name: 'Combat',
          value: `${formatNumber(account.kills)} kills · ${formatNumber(account.deaths)} deaths · K/D ${(account.kills / Math.max(1, account.deaths)).toFixed(2)}`,
        },
        { name: 'Playtime', value: `${formatNumber(Math.round(account.playtime_seconds / 3600))} hours`, inline: true },
        { name: 'Last activity', value: account.last_playtime_at ? relativeTimestamp(account.last_playtime_at, 'R') : 'Never', inline: true },
        { name: 'Badges', value: badgeLabels.join(' · ') || 'None yet' },
      ],
      footer: data.level >= MAX_LEVEL ? 'Prestige is available' : 'Earn XP from kills, playtime and games',
    });

    const controls = [
      row(
        button({ id: customId('bp', 'open'), label: 'Battle pass', emoji: '🎖️' }),
        button({ id: customId('prog', 'prestige'), label: 'Prestige', emoji: '🌟', style: ButtonStyle.Success, disabled: data.level < MAX_LEVEL }),
        button({ id: customId('prog', 'board'), label: 'Leaderboards', emoji: '🏆' }),
      ),
      navRow({ backPanel: 'progression' }),
    ];

    return { embeds: [embed, ...badgeEmbeds], components: controls, files };
  },
};
