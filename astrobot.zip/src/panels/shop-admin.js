import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { runtime } from '../core/runtime.js';
import { COLORS, EMOJI } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { formatCoins, inlineCode, truncate } from '../utils/format.js';
import { applyRestock, groupByCategory, stockLabel } from '../services/shop-stock.js';
import { allRustItems, getRustItem } from '../services/rust-items.js';

/** /shop-panel: add Rust catalog items, organize categories, stock, limits and roles. */
export default {
  id: 'shop-admin',
  async render({ ctx, params }) {
    const settings = getGuildSettings(ctx.guildId);
    const products = applyRestock(ctx.guildId, settings.shop.products ?? []);
    const connected = Boolean(runtime.rconManager?.connectionFor(ctx.guildId));

    if (params.candidates?.length > 0) {
      const candidates = params.candidates.map((shortname) => getRustItem(shortname)).filter(Boolean);
      const price = Number(params.price) || 0;
      const quantity = Number(params.quantity) || 1;
      const category = String(params.category ?? 'General');
      const stock = params.stock === null || params.stock === undefined ? 'unlimited' : `${params.stock} in stock`;

      const embed = buildEmbed({
        title: `${EMOJI.shop} Choose an item`,
        color: COLORS.gold,
        description: `**${candidates.length}** matches for **${truncate(params.query ?? '', 80)}**. Pick the exact item to add: ${formatCoins(price)} · x${quantity} · **${category}** · ${stock}.`,
        thumbnail: candidates[0]?.image ?? null,
        fields: [
          {
            name: 'Matches',
            value: truncate(
              candidates.map((item, index) => `${index + 1}. **${item.name}** · ${inlineCode(item.shortname)}`).join('\n'),
              1024,
            ),
          },
        ],
        footer: 'The shortname is filled in automatically',
      });

      const controls = [
        row(
          stringSelect({
            id: customId('shopadm', 'pick'),
            placeholder: 'Pick the item to sell',
            options: candidates.map((item) => ({
              label: truncate(item.name, 100),
              value: item.shortname,
              description: truncate(item.shortname, 100),
            })),
          }),
        ),
        navRow({ backPanel: 'shop-admin' }),
      ];

      return { embeds: [embed], components: controls };
    }

    const catalogSize = allRustItems().length;
    const groups = groupByCategory(products);
    const editGroup = groups.find((group) => group.category === params.editCategory) ?? groups[0] ?? null;
    const editEntries = editGroup?.entries ?? [];

    // Category summaries only: a quick setup can create hundreds of products,
    // and listing them turns the admin panel into an unreadable wall. The
    // category and product menus below are the browser.
    const fields = groups.slice(0, 9).map(({ category, entries }) => {
      const prices = entries.map(({ product }) => Number(product.price) || 0);
      return {
        name: `${category} · ${entries.length}`,
        value: truncate(`${formatCoins(Math.min(...prices))}–${formatCoins(Math.max(...prices))} · pick a product below to manage it`, 1024),
      };
    });

    if (groups.length > 9) {
      fields.push({
        name: 'More categories',
        value: `${groups.length - 9} more categories are hidden. Remove or recategorize a product to see them.`,
      });
    }

    fields.push({
      name: 'Manage',
      value: editGroup
        ? `Editing **${editGroup.category}** — pick a product below for price, limits, restock and role.`
        : 'No products yet. Use **Quick setup** or **Add item**.',
    });

    fields.push({
      name: 'Delivery',
      value: connected
        ? `RCON connected · ${inlineCode(settings.shop.itemCommand)}`
        : `RCON offline · item purchases are paused until a server connects\n${inlineCode(settings.shop.itemCommand)}`,
    });

    const embed = buildEmbed({
      title: `${EMOJI.shop} ${ctx.guild?.name ?? 'Server'} Shop Admin`,
      color: COLORS.gold,
      description:
        params.notice ??
        `Search **${catalogSize.toLocaleString('en-US')}** Rust items by display name — shortnames, item IDs and images are filled in automatically. ${groups.length} categor${groups.length === 1 ? 'y' : 'ies'} in use.`,
      fields,
      footer: settings.shop.enabled ? 'Shop enabled' : 'Shop disabled — buyers cannot check out',
    });

    const controls = [];

    if (groups.length > 1) {
      controls.push(
        row(
          stringSelect({
            id: customId('shopadm', 'editcat'),
            placeholder: `Editing: ${editGroup.category}`,
            options: groups.slice(0, 25).map((group) => ({
              label: truncate(group.category, 100),
              value: group.category,
              description: `${group.entries.length} product${group.entries.length === 1 ? '' : 's'}`,
              default: group.category === editGroup.category,
            })),
          }),
        ),
      );
    }

    if (editEntries.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('shopadm', 'manage'),
            placeholder: 'Manage a product (price, stock, limits, role)',
            options: editEntries.slice(0, 25).map(({ product }) => ({
              label: truncate(product.name ?? product.id, 100),
              value: String(product.id),
              description: truncate(
                `${stockLabel(product)} · ${product.price ?? 0} · ${product.requiredRoleId ? 'role required' : 'no role'}`,
                100,
              ),
            })),
          }),
        ),
      );
    }

    controls.push(
      row(
        button({ id: customId('shopadm', 'quick'), label: 'Quick setup', emoji: '⚡', style: ButtonStyle.Primary }),
        button({ id: customId('shopadm', 'add'), label: 'Add item', emoji: '➕', style: ButtonStyle.Success }),
        button({
          id: customId('shopadm', 'remove'),
          label: 'Remove',
          emoji: '🗑️',
          style: ButtonStyle.Danger,
          disabled: products.length === 0,
        }),
        button({
          id: customId('shopadm', 'roleall'),
          label: 'Role for all',
          emoji: '🔐',
          disabled: products.length === 0,
        }),
        button({ id: customId('shopadm', 'advanced'), label: 'Advanced', emoji: '⚙️' }),
      ),
      row(
        button({
          id: customId('shopadm', 'deleteshop'),
          label: 'Delete shop',
          emoji: '🧨',
          style: ButtonStyle.Danger,
        }),
      ),
      navRow({ backPanel: 'shop-admin' }),
    );

    return { embeds: [embed], components: controls };
  },
};

function describeProduct(product) {
  const shortname = product.shortname ? ` · ${inlineCode(product.shortname)}` : '';
  const quantity = product.shortname ? ` · x${product.quantity ?? 1}` : '';
  const stock = ` · ${stockLabel(product)}`;
  const role = product.requiredRoleId ? ' · 🔐' : '';
  return `**${product.name ?? product.id}** · ${formatCoins(product.price ?? 0)}${shortname}${quantity}${stock}${role}`;
}
