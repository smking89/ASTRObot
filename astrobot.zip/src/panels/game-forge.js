import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { WEB_BASE_URL, COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, linkButton, navRow, row } from '../ui/components.js';
import { truncate } from '../utils/format.js';

/** /game-forge: entry point to the dashboard game builder. */
export default {
  id: 'game-forge',
  async render({ ctx }) {
    const games = getGuildSettings(ctx.guildId).misc.customGames ?? [];

    const embed = buildEmbed({
      title: '🛠️ Game Forge',
      color: COLORS.brand,
      description:
        'Build custom mini-games with wagers, rewards and custom rules in the AstroBot dashboard. Published games appear in `/play` automatically.',
      fields: [
        {
          name: `This server's games (${games.length})`,
          value: truncate(games.map((game) => `**${game.name}** · ${game.type ?? 'custom'} · ${game.enabled ? 'live' : 'draft'}`).join('\n'), 1024) || 'None yet.',
        },
        { name: 'Dashboard', value: `${WEB_BASE_URL}/dashboard/games`, inline: false },
      ],
      footer: 'Greens are validated server-side before a game can pay out',
    });

    const controls = [
      row(
        linkButton({ label: 'Open Game Forge', url: `${WEB_BASE_URL}/dashboard/games` }),
        button({ id: customId('forge', 'sync'), label: 'Sync from dashboard', emoji: '🔄' }),
      ),
      navRow({ backPanel: 'game-forge' }),
    ];

    return { embeds: [embed], components: controls };
  },
};
