import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { listItems } from '../db/repositories/inventory.js';
import { balances } from '../services/economy-service.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { formatCoins, truncate } from '../utils/format.js';

/** /player-panel: the player-facing kit claim surface. */
export default {
  id: 'player-panel',
  async render({ ctx, params }) {
    const settings = getGuildSettings(ctx.guildId);
    const kits = settings.misc.kits ?? [];
    const inventory = listItems(ctx.guildId, ctx.userId);
    const account = balances(ctx.guildId, ctx.userId);

    const embed = buildEmbed({
      title: '🎒 Kit Claim',
      color: COLORS.brand,
      description: params.notice ?? 'Claim free kits, buy registered kits or open a kit from your inventory.',
      fields: [
        {
          name: `Available kits (${kits.length})`,
          value:
            truncate(kits.map((kit) => `**${kit.name}** ${kit.price ? `· ${formatCoins(kit.price)}` : '· free'}`).join('\n'), 1024) ||
            'No kits registered.',
        },
        { name: 'Your wallet', value: formatCoins(account.wallet, account.currency), inline: true },
        {
          name: 'Inventory',
          value: truncate(inventory.map((item) => `${item.item_key} ×${item.quantity}`).join('\n'), 1024) || 'Empty',
          inline: true,
        },
      ],
      footer: 'Kits are delivered through RCON instantly',
    });

    const controls = [];

    if (kits.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('ppanel', 'select'),
            placeholder: 'Choose a kit',
            options: kits.slice(0, 25).map((kit, index) => ({
              label: kit.name,
              value: String(index),
              description: kit.price ? formatCoins(kit.price) : 'free',
            })),
          }),
        ),
        row(
          button({
            id: customId('ppanel', 'claim', params.selectedIndex ?? '0'),
            label:
              params.selectedIndex !== undefined
                ? `Claim ${kits[Number(params.selectedIndex)]?.name ?? 'selected'}`
                : 'Select a kit first',
            emoji: '📦',
            style: ButtonStyle.Success,
            disabled: params.selectedIndex === undefined,
          }),
        ),
      );
    }

    controls.push(navRow({ backPanel: 'player-panel' }));
    return { embeds: [embed], components: controls };
  },
};
