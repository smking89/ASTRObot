import { ButtonStyle } from 'discord.js';
import { listWipeProfiles } from '../db/repositories/wipes.js';
import { getServer } from '../db/repositories/servers.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import {
  WIPE_TYPES,
  minutesUntil,
  parseCountdowns,
  parseMapRotation,
  parseWipeMessages,
  restartCommandFor,
  restartDelayFor,
} from '../services/wipe-service.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { truncate } from '../utils/format.js';
import { formatTimeZone } from '../utils/timezone.js';

/** Wipe schedules are per server row, so a network can wipe one map at a time. */
export default {
  id: 'wipe',
  async render({ ctx, params }) {
    const profiles = listWipeProfiles(ctx.guildId);
    const selected = params.selected ? profiles.find((profile) => profile.id === params.selected) ?? null : null;

    const rows = profiles.map((profile) => {
      const server = getServer(profile.server_id);
      const left = minutesUntil(profile);
      const when = left > 0 ? `in ${Math.ceil(left / 60)}h` : 'due now';
      const map = Number(profile.rotate_map) && parseMapRotation(profile.map_rotation).length ? ' · map rotation' : '';
      return `**${truncate(profile.name, 60)}** · ${server?.label ?? profile.server_id} · ${WIPE_TYPES[profile.wipe_type] ?? profile.wipe_type} · ${when}${map}`;
    });

    const fields = [
      {
        name: `Wipe profiles · ${profiles.length}`,
        value: truncate(rows.join('\n'), 1024) || 'No wipe profiles yet. Create one to schedule countdowns, restarts and map rotation.',
      },
    ];

    if (selected) {
      const server = getServer(selected.server_id);
      const rotation = parseMapRotation(selected.map_rotation);
      const messages = parseWipeMessages(selected.wipe_messages);
      fields.push(
        { name: 'Selected', value: `**${selected.name}** · ${server?.label ?? selected.server_id}`, inline: true },
        { name: 'Type', value: WIPE_TYPES[selected.wipe_type] ?? selected.wipe_type, inline: true },
        { name: 'Every', value: `${selected.interval_hours}h`, inline: true },
        { name: 'Next wipe', value: `<t:${Math.floor(selected.next_wipe_at / 1000)}:F>`, inline: true },
        { name: 'Countdowns', value: parseCountdowns(selected.countdowns).map((stage) => `${stage}m`).join(' · '), inline: true },
        {
          name: 'Automation',
          value: [
            Number(selected.auto_restart)
              ? `restart \`${restartCommandFor(selected)}\` · ${restartDelayFor(selected)}s delay`
              : 'no restart',
            Number(selected.rotate_map) ? `${rotation.length} map(s) in rotation` : 'no map rotation',
          ].join(' · '),
          inline: true,
        },
        { name: 'In-game', value: Number(selected.announce_in_game) ? '`global.say` warnings on' : 'Discord only', inline: true },
        {
          name: 'Status',
          value: Number(selected.awaiting_online)
            ? 'Waiting for the server to come back'
            : selected.online_announced_at
              ? `Back online <t:${Math.floor(selected.online_announced_at / 1000)}:R>`
              : Number(selected.auto_restart)
                ? 'Scheduled'
                : 'Restart off',
          inline: true,
        },
        { name: '1st warning', value: truncate(messages.first.replace(/\n/g, ' '), 140), inline: false },
      );
    }

    const embed = buildEmbed({
      title: '🧨 Wipe Controller',
      color: COLORS.brand,
      description:
        params.notice ??
        'Each profile belongs to one connected server. Countdowns post at the configured stages, then the wipe runs the map rotation and optional restart.',
      fields,
      footer: `Schedule times use ${formatTimeZone(getGuildSettings(ctx.guildId).announcements?.timezone)} · plain text or HTML messages`,
    });

    const controls = [];

    if (profiles.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('wipe', 'select'),
            placeholder: 'Select a wipe profile',
            options: profiles.slice(0, 25).map((profile) => ({
              label: truncate(profile.name, 100),
              value: profile.id,
              description: truncate(`${getServer(profile.server_id)?.label ?? profile.server_id} · ${profile.wipe_type} · ${profile.interval_hours}h`, 100),
              default: profile.id === params.selected,
            })),
          }),
        ),
      );
    }

    controls.push(
      row(
        button({ id: customId('wipe', 'create'), label: 'New profile', emoji: '➕', style: ButtonStyle.Success }),
        button({
          id: customId('wipe', 'settime', selected?.id ?? 'none'),
          label: 'Set time',
          emoji: '🕒',
          disabled: !selected,
        }),
        button({
          id: customId('wipe', 'messages', selected?.id ?? 'none'),
          label: 'Messages',
          emoji: '✍️',
          disabled: !selected,
        }),
        button({
          id: customId('wipe', 'ingame', selected?.id ?? 'none'),
          label: selected && Number(selected.announce_in_game) ? 'In-game on' : 'In-game off',
          emoji: '🎮',
          disabled: !selected,
        }),
        button({
          id: customId('wipe', 'map', selected?.id ?? 'none'),
          label: 'Set map',
          emoji: '🗺️',
          disabled: !selected,
        }),
      ),
      row(
        button({
          id: customId('wipe', 'run', selected?.id ?? 'none'),
          label: 'Run now',
          emoji: '▶️',
          style: ButtonStyle.Primary,
          disabled: !selected,
        }),
        button({
          id: customId('wipe', 'restart', selected?.id ?? 'none'),
          label: 'Restart setup',
          emoji: '🔁',
          disabled: !selected,
        }),
        button({
          id: customId('wipe', 'toggle', selected?.id ?? 'none'),
          label: 'Toggle restart',
          emoji: '🔄',
          disabled: !selected,
        }),
        button({
          id: customId('wipe', 'delete', selected?.id ?? 'none'),
          label: 'Delete',
          emoji: '🗑️',
          style: ButtonStyle.Danger,
          disabled: !selected,
        }),
      ),
      navRow({ backPanel: 'server' }),
    );

    return { embeds: [embed], components: controls };
  },
};
