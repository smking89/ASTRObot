import { HUB_OWNER_DESTINATIONS } from '../config/panel-hub.js';
import { hubView } from '../ui/hub-view.js';
import { COLORS } from '../config/constants.js';
import { button, customId, row } from '../ui/components.js';

/** Server-owner hub: everything the owner can configure in one place. */
export default {
  id: 'owner-hub',
  async render({ params = {} }) {
    return hubView({
      id: 'owner-hub',
      title: '👑 Server Owner Panel',
      description:
        params.notice ??
        'Owner controls: scheduled announcements, giveaways and winner destinations, polls, checkout, onboarding, configuration and economy operations.',
      destinations: HUB_OWNER_DESTINATIONS,
      highlights:
        'Announcements · giveaways · portal · polls · checkout · onboarding · config · licenses · analytics · shop · wipes',
      footer: 'AstroBot panel · server owner',
      color: COLORS.gold,
      buttons: [
        { panel: 'announcements', label: 'Announcements', emoji: '📣' },
        { panel: 'giveaways', label: 'Giveaways', emoji: '🎁' },
        { panel: 'giveaway-portal', label: 'Portal', emoji: '⭐' },
        { panel: 'checkout', label: 'Checkout', emoji: '💳' },
        { panel: 'config', label: 'Config', emoji: '⚙️' },
      ],
      extraRows: [
        row(
          button({ id: customId('ownertools', 'db-backup'), label: 'Backup database', emoji: '💾', style: 2 }),
        ),
      ],
    });
  },
};
