import { buildEmbed } from '../ui/embeds.js';
import { COLORS, EMOJI } from '../config/constants.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { LEADERBOARD_METRICS, leaderboardBoard } from '../services/leaderboard-service.js';
import { periodLabel } from '../services/leaderboard-prizes.js';

/** /leaderboards panel: a picture board that refreshes, plus a metric picker. */
export default {
  id: 'leaderboards',
  public: true,
  async render({ ctx, params }) {
    const metric =
      params.metric && LEADERBOARD_METRICS.some((entry) => entry.id === params.metric) ? params.metric : 'wallet';

    const { label, rows, attachment, prizes, period } = await leaderboardBoard({
      guild: ctx.guild ?? null,
      guildId: ctx.guildId,
      metric,
      limit: 15,
      // Every board carries the same AstroBot branding and logo.
      theme: 'brand',
      eyebrow: 'ASTROBOT',
    });

    const embed = buildEmbed({
      title: `${EMOJI.trophy} ${label} Leaderboard`,
      color: metric === 'wallet' || metric === 'bank' ? COLORS.gold : COLORS.brand,
      description: rows.length
        ? 'The picture below is the live board — it updates on its own, no refresh needed.'
        : 'No data yet — play a round or link an account to appear here.',
      fields: prizes?.some((amount) => amount > 0)
        ? [
            {
              name: `Prizes · ${periodLabel(period)}`,
              value: prizes
                .map((amount, index) => `${['🥇', '🥈', '🥉'][index]} ${amount.toLocaleString('en-US')} coins`)
                .join(' · '),
            },
          ]
        : [],
      footer: 'Top 15 · picture refreshes automatically',
    }).setImage('attachment://leaderboard.png');

    const controls = [
      row(
        stringSelect({
          id: customId('lb', 'metric'),
          placeholder: 'Switch leaderboard',
          options: LEADERBOARD_METRICS.map((entry) => ({ label: entry.label, value: entry.id, default: entry.id === metric })),
        }),
      ),
      navRow({ backPanel: 'leaderboards' }),
    ];

    return { embeds: [embed], files: [attachment], components: controls };
  },
};

export { LEADERBOARD_METRICS as METRICS } from '../services/leaderboard-service.js';
