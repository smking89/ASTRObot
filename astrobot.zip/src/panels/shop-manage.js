import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, roleSelect, row } from '../ui/components.js';
import { formatCoins } from '../utils/format.js';
import { restockAt, stockLabel, stockOf } from '../services/shop-stock.js';

/** Manage one product (or every product's role) from /shop-panel. */
export default {
  id: 'shop-manage',
  async render({ ctx, params }) {
    const products = getGuildSettings(ctx.guildId).shop.products ?? [];

    if (params.target === 'all') {
      const roles = [...new Set(products.map((product) => product.requiredRoleId).filter(Boolean))];

      const embed = buildEmbed({
        title: '🔐 Required role · all products',
        color: COLORS.brand,
        description:
          'Pick a role with the picker below and every product will require it. **Clear role** opens the shop to everyone again.',
        fields: [
          { name: 'Products', value: `${products.length}`, inline: true },
          { name: 'Current roles', value: roles.length > 0 ? roles.map((role) => `<@&${role}>`).join(', ') : 'None', inline: true },
        ],
        footer: 'Updates every product at once',
      });

      return {
        embeds: [embed],
        components: [
          row(roleSelect({ id: customId('shopmgr', 'role', 'all'), placeholder: 'Role required for every product' })),
          row(
            button({
              id: customId('shopmgr', 'roleclear', 'all'),
              label: 'Clear role',
              emoji: '🚫',
              style: ButtonStyle.Danger,
              disabled: products.length === 0,
            }),
            button({ id: customId('shopmgr', 'back'), label: 'Back', emoji: '↩️' }),
          ),
          navRow({ backPanel: 'shop-manage' }),
        ],
      };
    }

    const product = products.find((entry) => String(entry.id) === String(params.target));

    if (!product) {
      return {
        embeds: [
          buildEmbed({
            title: 'Product not found',
            description: 'That product was removed. Open the shop admin again.',
            color: COLORS.warning,
          }),
        ],
        components: [row(button({ id: customId('shopmgr', 'back'), label: 'Back', emoji: '↩️' }))],
      };
    }

    const limit = product.limitPerMember
      ? `${product.limitPerMember} per ${product.limitWindowHours ?? 24}h`
      : 'None';
    const nextRestockAt = restockAt(product);
    const restock = product.restockMinutes
      ? `+${product.restockAmount} every ${product.restockMinutes}m${
          nextRestockAt === null ? '' : ` · next <t:${Math.floor(nextRestockAt / 1000)}:R>`
        }${product.stockMax === null || product.stockMax === undefined ? '' : ` · max ${product.stockMax}`}`
      : 'None';

    const embed = buildEmbed({
      title: `🛠️ ${product.name ?? product.id}`,
      color: COLORS.gold,
      description: product.description ?? undefined,
      thumbnail: product.image ?? null,
      fields: [
        { name: 'Price', value: formatCoins(product.price ?? 0), inline: true },
        { name: 'Quantity', value: `x${product.quantity ?? 1}`, inline: true },
        { name: 'Stock', value: stockLabel(product), inline: true },
        { name: 'Stock alerts', value: product.alertMuted ? 'Muted' : 'On', inline: true },
        { name: 'Category', value: String(product.category ?? 'General'), inline: true },
        { name: 'Required role', value: product.requiredRoleId ? `<@&${product.requiredRoleId}>` : 'None', inline: true },
        { name: 'Purchase limit', value: limit, inline: true },
        { name: 'Restock', value: restock, inline: true },
      ],
      footer: 'Limits and restock are enforced on every purchase',
    });

    return {
      embeds: [embed],
      components: [
        row(
          button({ id: customId('shopmgr', 'edit', product.id), label: 'Edit details', emoji: '✏️', style: ButtonStyle.Primary }),
          button({ id: customId('shopmgr', 'limits', product.id), label: 'Limits & restock', emoji: '⏱️' }),
          button({
            id: customId('shopmgr', 'alerts', product.id),
            label: product.alertMuted ? 'Unmute alerts' : 'Mute alerts',
            emoji: '🔔',
          }),
          button({ id: customId('shopmgr', 'history', product.id), label: 'Stock history', emoji: '🧾' }),
        ),
        row(
          roleSelect({
            id: customId('shopmgr', 'role', product.id),
            placeholder: product.requiredRoleId ? 'Change the required role' : 'Optional: role required to buy',
          }),
        ),
        row(
          button({
            id: customId('shopmgr', 'roleclear', product.id),
            label: 'Clear role',
            emoji: '🚫',
            disabled: !product.requiredRoleId,
          }),
          button({
            id: customId('shopmgr', 'unlimited', product.id),
            label: 'Unlimited stock',
            emoji: '♾️',
            disabled: stockOf(product) === null,
          }),
          button({ id: customId('shopmgr', 'back'), label: 'Back', emoji: '↩️' }),
        ),
        row(
          button({
            id: customId('shopmgr', 'delete', product.id),
            label: 'Delete product',
            emoji: '🗑️',
            style: ButtonStyle.Danger,
          }),
        ),
        navRow({ backPanel: 'shop-manage' }),
      ],
    };
  },
};
