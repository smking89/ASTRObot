import { ButtonStyle } from 'discord.js';
import { countDailyClaims, getOrCreateAccount } from '../db/repositories/players.js';
import { listItems } from '../db/repositories/inventory.js';
import { ensureProgress } from '../db/repositories/battlepass.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { formatCoins, relativeTimestamp, truncate } from '../utils/format.js';
import { CRATE_ITEMS, VOUCHER_ITEMS, hasVoucher } from '../services/voucher-service.js';
import { CLAIM_MILESTONES, STREAK_REWARDS } from '../services/economy-service.js';

const DAY_MS = 86_400_000;

const describeReward = (reward) =>
  [
    Number(reward?.coins) > 0 ? `🪙 ${formatCoins(Number(reward.coins))}` : null,
    reward?.kit ? `🎒 ${reward.kit}` : null,
    reward?.roleId ? '🎭 role' : null,
  ]
    .filter(Boolean)
    .join(' · ') || 'nothing extra';

/**
 * Builds the reward-flow rail: a start node, then one node per streak day.
 * Claimed days are ticks, the day you can claim now is the lit gift, later
 * days are locks and day 7 is the star jackpot.
 */
function streakRail(streak, canClaim, rewards) {
  const cycleDay = streak > 0 ? ((streak - 1) % 7) + 1 : 0;
  const nextDay = streak === 0 ? 1 : (cycleDay % 7) + 1;

  const nodes = rewards.slice(0, 7).map(({ day }, index) => {
    const number = Number(day) || index + 1;
    if (cycleDay > 0 && number <= cycleDay) return '✅';
    if (canClaim && number === nextDay) return '🎁';
    return number === 7 ? '⭐' : '🔒';
  });

  return { rail: ['▶️', ...nodes].join(' ━ '), nodes, cycleDay, nextDay };
}

/** /claim panel: the server's daily reward flow, battle pass, vouchers and inventory. */
export default {
  id: 'claim',
  async render({ ctx, params }) {
    const account = getOrCreateAccount(ctx.guildId, ctx.userId);
    const settings = getGuildSettings(ctx.guildId);
    const config = settings.streak ?? {};
    const rewards = Array.isArray(config.rewards) && config.rewards.length ? config.rewards : STREAK_REWARDS;
    const items = listItems(ctx.guildId, ctx.userId);
    const pass = ensureProgress(ctx.guildId, ctx.userId);
    const lastDaily = account.last_daily ? Number(account.last_daily) : 0;
    const ready = !lastDaily || Date.now() - lastDaily > DAY_MS;
    const streak = Number(account.streak ?? 0);

    const requiredRoleId = config.requiredRoleId || null;
    const minLevel = Number(config.minLevel ?? 0);
    const hasRole = requiredRoleId ? Boolean(ctx.member?.roles?.cache?.has?.(requiredRoleId)) : true;
    const meetsLevel = Number(account.level ?? 0) >= minLevel;
    const blocked = config.enabled === false ? 'off' : !hasRole ? 'role' : !meetsLevel ? 'level' : null;
    const canClaimDaily = ready && !blocked;

    const { rail, nodes, cycleDay, nextDay } = streakRail(streak, canClaimDaily, rewards);
    const nextReward = rewards[nextDay - 1] ?? STREAK_REWARDS[nextDay - 1];
    const nextPayout = Number(nextReward?.coins) || Number(settings.economy.dailyStreakBase) || 100;

    const crate = hasVoucher(ctx.guildId, ctx.userId, VOUCHER_ITEMS.weeklyChest)
      ? VOUCHER_ITEMS.weeklyChest
      : hasVoucher(ctx.guildId, ctx.userId, VOUCHER_ITEMS.luckyKey)
        ? VOUCHER_ITEMS.luckyKey
        : null;
    const vouchers = items.filter((item) => item.item_key.startsWith('streak_') || item.item_key.startsWith('milestone_'));
    const crates = vouchers.filter((item) => CRATE_ITEMS.includes(item.item_key));

    const lifetime = countDailyClaims(ctx.guildId, ctx.userId);
    const milestoneTrack = CLAIM_MILESTONES.map((entry) => `${lifetime >= entry.at ? '✅' : '◻️'} ${Math.min(lifetime, entry.at)}/${entry.at}`).join(' · ');
    const milestoneIcons = CLAIM_MILESTONES.map((entry) => (lifetime >= entry.at ? '✅' : '◻️')).join(' ━ ');
    const nextMilestone = CLAIM_MILESTONES.find((entry) => lifetime < entry.at) ?? null;

    const requirementText =
      blocked === 'off'
        ? 'Daily rewards are turned off on this server.'
        : blocked === 'role'
          ? `You need <@&${requiredRoleId}> to claim.`
          : blocked === 'level'
            ? `You need level ${minLevel} to claim (you are level ${Number(account.level ?? 0)}).`
            : blocked === null && (requiredRoleId || minLevel > 0)
              ? [requiredRoleId ? `<@&${requiredRoleId}>` : null, minLevel > 0 ? `level ${minLevel}+` : null].filter(Boolean).join(' · ')
              : null;

    const embed = buildEmbed({
      title: '🎁 Daily reward flow',
      color: COLORS.success,
      description:
        params.notice ??
        (blocked
          ? 'This server runs its own login rewards. Meet the requirements below, then claim once a day.'
          : 'Claim once a day to move along the track. Miss a day and the flow resets — day 7 pays the jackpot box.'),
      fields: [
        {
          name: canClaimDaily ? `Day ${nextDay} of 7 · ready` : `Day ${cycleDay} of 7 · claimed`,
          value: [
            rail,
            ...nodes.map((mark, index) => {
              const reward = rewards[index] ?? STREAK_REWARDS[index];
              const today = canClaimDaily && index + 1 === nextDay ? ' ← today' : '';
              return `${mark} **${index + 1}** · ${reward.label ?? STREAK_REWARDS[index].label} · ${describeReward(reward)}${today}`;
            }),
            canClaimDaily
              ? `**Payout:** ${formatCoins(nextPayout)} · +${50 * (streak + 1)} XP`
              : blocked
                ? '**Payout:** locked until you meet the requirements'
                : `**Next claim** ${relativeTimestamp(lastDaily + DAY_MS, 'R')} · streak ${streak}`,
          ].join('\n'),
        },
        ...(requirementText ? [{ name: 'Requirements', value: requirementText }] : []),
        {
          name: 'Lifetime claim track',
          value: `${milestoneIcons}\n${milestoneTrack}${nextMilestone ? `\nNext crate: **${nextMilestone.label}** at ${nextMilestone.at} claims` : '\nEvery milestone crate unlocked'}`,
        },
        { name: 'Battle pass', value: `Tier ${pass.tier}${pass.premium ? ' · premium' : ''}`, inline: true },
        { name: 'Unclaimed tiers', value: `${Math.max(0, Number(pass.tier) - JSON.parse(pass.claimed || '[]').length)}`, inline: true },
        { name: 'Streak', value: `${streak} day${streak === 1 ? '' : 's'}`, inline: true },
        {
          name: `Streak vouchers (${vouchers.length})`,
          value: truncate(
            vouchers.map((item) => `${item.item_key.replace('streak_', '').replaceAll('_', ' ')} ×${item.quantity}`).join('\n'),
            1024,
          ) || 'None held — claim a few days in a row.',
        },
        {
          name: `Inventory (${items.length})`,
          value: truncate(items.map((item) => `${item.item_key} ×${item.quantity}`).join('\n'), 1024) || 'Empty',
        },
      ],
      footer: 'Streak rewards are set by this server — coins, kits, roles and a badge',
    });

    const controls = [
      row(
        button({
          id: customId('claim', 'daily'),
          label: canClaimDaily ? `Claim day ${nextDay}` : blocked ? 'Locked' : 'Claimed today',
          emoji: '🎁',
          style: ButtonStyle.Success,
          disabled: !canClaimDaily,
        }),
        button({ id: customId('claim', 'pass'), label: 'Battle pass', emoji: '🎖️' }),
        button({ id: customId('claim', 'kits'), label: 'Claim kit', emoji: '🎒', disabled: items.length === 0 }),
        button({ id: customId('claim', 'crate'), label: crate ? 'Open crate' : 'No crate', emoji: '🔑', disabled: !crate }),
      ),
      ...(crates.length > 0
        ? [
            row(
              stringSelect({
                id: customId('claim', 'voucher'),
                placeholder: 'Open a specific streak voucher…',
                options: crates.slice(0, 25).map((item) => ({
                  label: `${item.item_key.replace('streak_', '').replaceAll('_', ' ')} ×${item.quantity}`,
                  value: item.item_key,
                  description: item.item_key === VOUCHER_ITEMS.weeklyChest ? 'Three rolls plus 1,000 coins' : 'Open this crate',
                  emoji: '🔑',
                })),
              }),
            ),
          ]
        : []),
      navRow({ backPanel: 'claim' }),
    ];

    return { embeds: [embed], components: controls };
  },
};
