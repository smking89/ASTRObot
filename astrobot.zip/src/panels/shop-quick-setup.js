import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { COLORS, EMOJI } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, roleSelect, row, stringSelect } from '../ui/components.js';
import { truncate } from '../utils/format.js';
import { defaultStockValue } from '../services/shop-stock.js';
import {
  QUICK_TIERS,
  configuredCurrencies,
  priceMultipliers,
  quickSetupPreview,
  quickSetupState,
} from '../services/shop-quick-setup.js';

/** Quick setup: price profile, currency, optional role, optional Tier 3 / explosives. */
export default {
  id: 'shop-quick-setup',
  async render({ ctx }) {
    const settings = getGuildSettings(ctx.guildId);
    const state = quickSetupState(ctx.guildId, ctx.userId);
    const currencies = configuredCurrencies(settings);

    if (!currencies.includes(state.currency)) state.currency = currencies[0] ?? 'coins';

    const multipliers = priceMultipliers(settings);
    const tier = QUICK_TIERS[state.tier] ?? QUICK_TIERS.mid;
    const defaultStock = defaultStockValue(settings);
    const preview = quickSetupPreview(state, multipliers, defaultStock);
    const itemCount = preview.products.length;

    const embed = buildEmbed({
      title: `${EMOJI.shop} Quick shop setup`,
      color: COLORS.brand,
      description:
        'Pick a price profile and a currency, then let AstroBot build the whole shop: every category, item, shortname, image and price is generated from the Rust item catalog.',
      fields: [
        { name: 'Price tier', value: `**${tier.label}** · ×${multipliers[state.tier] ?? 1} — ${tier.description}`, inline: true },
        { name: 'Currency', value: `**${state.currency}**`, inline: true },
        { name: 'Required role', value: state.roleId ? `<@&${state.roleId}>` : 'None — open to everyone', inline: true },
        {
          name: 'Coverage',
          value: '🧱 Every Rust item with artwork — weapons, ammo, attachments, explosives, armor, food, resources, building, deployables and vehicles.',
        },
        {
          name: 'Starting stock',
          value: defaultStock === null ? 'Unlimited' : `${defaultStock} per item`,
          inline: true,
        },
        { name: 'Tier 3 items', value: state.tier3 ? '🟢 Included' : '🔴 Hidden', inline: true },
        { name: 'Explosives', value: state.explosives ? '🟢 Included' : '🔴 Hidden', inline: true },
        {
          name: `Preview · ${itemCount} items`,
          value:
            truncate(
              preview.categories
                .map((entry) => `**${entry.category}** · ${entry.count} items · ${entry.from}–${entry.to} ${state.currency}`)
                .join('\n'),
              1024,
            ) || 'No items resolved.',
        },
      ],
      footer: 'Prices come from item rarity, stack size and the configured tier multipliers',
    });

    const controls = [
      row(
        stringSelect({
          id: customId('shopqs', 'tier'),
          placeholder: 'Price tier (required)',
          options: Object.entries(QUICK_TIERS).map(([value, entry]) => ({
            label: entry.label,
            value,
            description: entry.description,
            default: value === state.tier,
          })),
        }),
      ),
      row(
        stringSelect({
          id: customId('shopqs', 'currency'),
          placeholder: 'Currency to charge',
          options: currencies.map((currency) => ({
            label: truncate(currency, 100),
            value: currency,
            description: currency === settings.economy.currency ? 'Current guild currency' : 'Configured currency',
            default: currency === state.currency,
          })),
        }),
      ),
      row(
        roleSelect({
          id: customId('shopqs', 'role'),
          placeholder: state.roleId ? 'Change the required role' : 'Optional: role required to buy',
        }),
      ),
      row(
        button({
          id: customId('shopqs', 'tier3'),
          label: state.tier3 ? 'Hide Tier 3' : 'Include Tier 3',
          emoji: '🧪',
        }),
        button({
          id: customId('shopqs', 'explosives'),
          label: state.explosives ? 'Hide explosives' : 'Include explosives',
          emoji: '💥',
        }),
        button({
          id: customId('shopqs', 'clearrole'),
          label: 'No role',
          emoji: '🚫',
          disabled: !state.roleId,
        }),
        button({
          id: customId('shopqs', 'create'),
          label: 'Create shop',
          emoji: '⚡',
          style: ButtonStyle.Success,
          disabled: itemCount === 0,
        }),
      ),
      navRow({ backPanel: 'shop-admin' }),
    ];

    return { embeds: [embed], components: controls };
  },
};
