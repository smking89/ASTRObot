import { HUB_ADMIN_DESTINATIONS } from '../config/panel-hub.js';
import { hubView } from '../ui/hub-view.js';

/** Admin master hub: every administrator tool behind one menu. */
export default {
  id: 'admin-hub',
  async render({ params = {} }) {
    return hubView({
      id: 'admin-hub',
      title: '🛡️ Admin Panel',
      description:
        params.notice ??
        'Administrator tools: scheduled announcements, giveaways, polls, configuration, shop and server operations. Every destination re-checks your role before opening.',
      destinations: HUB_ADMIN_DESTINATIONS,
      highlights:
        'Announcements · giveaways · polls & analytics · portal · config · shop · kits · templates · game setup · licenses · analytics · wipes · status',
      footer: 'AstroBot panel · admin',
      buttons: [
        { panel: 'announcements', label: 'Announcements', emoji: '📣' },
        { panel: 'giveaways', label: 'Giveaways', emoji: '🎁' },
        { panel: 'polls', label: 'Polls', emoji: '📊' },
        { panel: 'config', label: 'Config', emoji: '⚙️' },
      ],
    });
  },
};
