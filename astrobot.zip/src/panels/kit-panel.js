import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row } from '../ui/components.js';
import { formatCoins, truncate } from '../utils/format.js';

/** /kit-panel admin surface for registering kits and RCON delivery commands. */
export default {
  id: 'kit-panel',
  async render({ ctx, params }) {
    const kits = getGuildSettings(ctx.guildId).misc.kits ?? [];

    const embed = buildEmbed({
      title: '🎒 Kit Builder',
      color: COLORS.gold,
      description:
        params.notice ?? 'Register kits once, then sell them in the shop, grant them with /give, or bind them to purchases and auto-kits.',
      fields: [
        {
          name: `Registered kits (${kits.length})`,
          value:
            truncate(
              kits
                .map(
                  (kit, index) =>
                    `\`${index + 1}\` **${kit.name}** · ${kit.price ? formatCoins(kit.price) : 'free'} · \`${kit.rconCommand ?? 'no command'}\``,
                )
                .join('\n'),
              1024,
            ) || 'No kits registered yet.',
        },
      ],
      footer: 'Kit contents are defined in game, AstroBot only calls the command',
    });

    const controls = [
      row(
        button({ id: customId('kit', 'add'), label: 'Register kit', emoji: '➕', style: ButtonStyle.Success }),
        button({ id: customId('kit', 'remove'), label: 'Remove kit', style: ButtonStyle.Danger, disabled: kits.length === 0 }),
        button({ id: customId('ppanel', 'open'), label: 'Player view', emoji: '👤' }),
      ),
      navRow({ backPanel: 'kit-panel' }),
    ];

    return { embeds: [embed], components: controls };
  },
};
