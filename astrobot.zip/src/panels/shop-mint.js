import { ButtonStyle } from 'discord.js';
import { economyTotals, recentTransactions } from '../db/repositories/players.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row } from '../ui/components.js';
import { formatCoins, formatNumber, relativeTimestamp, truncate } from '../utils/format.js';
import { economyScopeKey } from '../services/economy-service.js';

/** /shop-mint: supply, burn and wallet caps. */
export default {
  id: 'shop-mint',
  async render({ ctx }) {
    const settings = ctx.guildConfig;
    const totals = economyTotals(ctx.guildId, economyScopeKey(ctx.guildId, settings));
    const supply = Number(totals.wallet) + Number(totals.bank);
    const minted = Boolean(settings.economy.minted);

    const embed = buildEmbed({
      title: '🏦 Currency Supply',
      color: COLORS.gold,
      description: minted
        ? 'This server uses minted currency. Manual minting is locked; configure which games and events may mint in /config → Shop.'
        : 'Mint new currency into circulation, burn it back, or inspect circulation health.',
      fields: [
        { name: 'Total supply', value: formatCoins(supply, settings.economy.currency), inline: true },
        { name: 'In wallets', value: formatCoins(totals.wallet, settings.economy.currency), inline: true },
        { name: 'In banks', value: formatCoins(totals.bank, settings.economy.currency), inline: true },
        { name: 'Tracked players', value: formatNumber(totals.players), inline: true },
        { name: 'Wallet cap', value: formatCoins(settings.economy.walletCap), inline: true },
        { name: 'Bank cap', value: formatCoins(settings.economy.bankCap), inline: true },
      ],
      footer: minted ? 'Minted mode: only configured sources create currency' : 'Minting bypasses caps only when you confirm the override',
    });

    const controls = [
      row(
        button({ id: customId('mint', 'mint'), label: 'Mint', emoji: '🪙', style: ButtonStyle.Success, disabled: minted }),
        button({ id: customId('mint', 'burn'), label: 'Burn', emoji: '🔥', style: ButtonStyle.Danger }),
        button({ id: customId('mint', 'setcap'), label: 'Set cap', emoji: '📏' }),
        button({ id: customId('mint', 'history'), label: 'Recent flow', emoji: '📜' }),
      ),
      navRow({ backPanel: 'shop-mint' }),
    ];

    return { embeds: [embed], components: controls };
  },
};
