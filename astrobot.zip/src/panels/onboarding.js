import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { onboardingSnapshot } from '../services/onboarding-service.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row } from '../ui/components.js';
import { truncate } from '../utils/format.js';

const STATUS = (value) => (value ? '✅ On' : '❌ Off');

/** Admin overview for the onboarding suite. */
export default {
  id: 'onboarding',
  async render({ ctx, params = {} }) {
    const settings = getGuildSettings(ctx.guildId);
    const snapshot = onboardingSnapshot(ctx.guildId, settings);
    const features = snapshot.features;
    const active = Object.values(features).filter(Boolean).length;

    const embed = buildEmbed({
      title: '👋 Onboarding & Community',
      color: COLORS.brand,
      description:
        params.notice ??
        'Welcome members, verify accounts, assign auto roles, reward tenure, run giveaways and keep an eye on joins and leaves. Every feature can be switched on or off independently.',
      fields: [
        { name: 'Enabled', value: `${active}/10 features`, inline: true },
        { name: 'Joins · 30d', value: String(snapshot.growth.joins), inline: true },
        { name: 'Leaves · 30d', value: String(snapshot.growth.leaves), inline: true },
        {
          name: 'Welcome & leaver',
          value: `${STATUS(features.welcome)} Welcomer · ${STATUS(features.leaver)} Leaver`,
          inline: true,
        },
        { name: 'Roles', value: `${STATUS(features.autoroles)} Auto roles · ${STATUS(features.freeroles)} Free roles · ${STATUS(features.reactionRoles)} Reaction roles`, inline: false },
        { name: 'Security', value: `${STATUS(features.borderwall)} Borderwall · ${STATUS(features.timeRoles)} Time roles`, inline: true },
        { name: 'Community', value: `${STATUS(features.giveaways)} Giveaways · ${STATUS(features.polls)} Polls · ${STATUS(features.tempChannels)} Temp channels`, inline: false },
        {
          name: 'Growth · recent days',
          value:
            truncate(
              snapshot.growth.daily
                .slice(-10)
                .map((entry) => `${entry.day.slice(5)} · +${entry.joins} / -${entry.leaves}`)
                .join(' · '),
              1024,
            ) || 'No join/leave events recorded yet.',
        },
      ],
      footer: 'Configure every onboarding feature from /config',
    });

    return {
      embeds: [embed],
      components: [
        row(
          button({ id: customId('cfg', 'section', 'config', 'onboarding'), label: 'Welcome & security', emoji: '⚙️' }),
          button({ id: customId('cfg', 'section', 'config', 'onboarding-security'), label: 'Leaver & channels', emoji: '🚪' }),
          button({ id: customId('cfg', 'section', 'config', 'onboarding-roles'), label: 'Roles & events', emoji: '🎭' }),
          button({ id: customId('openpanel-admin', 'reaction-roles'), label: 'Post role menu', emoji: '📌' }),
          button({ id: customId('openpanel-admin', 'giveaways'), label: 'Giveaways', emoji: '🎁', style: ButtonStyle.Success }),
        ),
        row(
          button({ id: customId('openpanel-admin', 'polls'), label: 'Polls & analytics', emoji: '📊', style: ButtonStyle.Success }),
          button({ id: customId('openpanel-admin', 'announcements'), label: 'Announcements', emoji: '📣' }),
        ),
        navRow({ backPanel: 'onboarding' }),
      ],
    };
  },
};
