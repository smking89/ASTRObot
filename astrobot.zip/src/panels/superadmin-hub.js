import { HUB_SUPERADMIN_DESTINATIONS } from '../config/panel-hub.js';
import { hubView } from '../ui/hub-view.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';

/** Superadmin hub: developer-only tools for the platform operator. */
export default {
  id: 'superadmin-hub',
  async render({ ctx, params = {} }) {
    if (!ctx.grants?.has?.('developer')) {
      return {
        embeds: [
          buildEmbed({
            title: '🛠️ Superadmin Panel',
            color: COLORS.warning,
            description: 'This panel is limited to the bot developer and the guild owner.',
            footer: 'AstroBot panel · superadmin',
          }),
        ],
        components: [],
      };
    }

    return hubView({
      id: 'superadmin-hub',
      title: '🛠️ Superadmin Panel',
      description:
        params.notice ??
        'Platform-operator tools: developer commands, licenses, the global RCON fleet, templates, announcements and platform analytics.',
      destinations: HUB_SUPERADMIN_DESTINATIONS,
      highlights: 'Developer tools · licenses · RCON fleet · templates · announcements · analytics · marketplace · status',
      footer: 'AstroBot panel · superadmin',
      color: COLORS.danger,
      buttonHandler: 'openpanel-dev',
      buttons: [
        { panel: 'dev', label: 'Developer', emoji: '🛠️' },
        { panel: 'license', label: 'Licenses', emoji: '🔑' },
        { panel: 'announcements', label: 'Announcements', emoji: '📣' },
        { panel: 'server', label: 'Servers', emoji: '🗄️' },
      ],
    });
  },
};
