import { ButtonStyle } from 'discord.js';
import { recentCases, activeCasesFor, appealQueue, staffCaseStats } from '../db/repositories/moderation.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { relativeTimestamp, truncate } from '../utils/format.js';

/** /mod opens this panel: punishment tracking, active cases and log routing. */
export default {
  id: 'mod',
  async render({ ctx, params }) {
    const settings = getGuildSettings(ctx.guildId);
    const cases = recentCases(ctx.guildId, 10);
    const targetId = params.targetId ?? null;
    const active = targetId ? activeCasesFor(ctx.guildId, targetId) : [];
    const staff = staffCaseStats(ctx.guildId, Date.now() - 30 * 86_400_000);
    const appeals = appealQueue(ctx.guildId, 10);

    const embed = buildEmbed({
      title: '🔨 Moderation',
      color: COLORS.warning,
      description: targetId
        ? `Active punishments for <@${targetId}>.`
        : 'Active punishment tracking, case history and log routing.',
      fields: [
        {
          name: 'Recent cases',
          value:
            truncate(
              cases
                .map(
                  (entry) =>
                    `\`${entry.id}\` · **${entry.action}** · <@${entry.target_id}> · <@${entry.moderator_id}> · ${relativeTimestamp(entry.created_at, 'R')}`,
                )
                .join('\n'),
              1024,
            ) || 'No cases recorded yet.',
        },
        {
          name: 'Active punishments',
          value:
            active
              .map((entry) => `${entry.action}${entry.expires_at ? ` until ${relativeTimestamp(entry.expires_at, 'R')}` : ''}`)
              .join('\n') || (targetId ? 'None active.' : 'Select a member to inspect.'),
        },
        {
          name: 'Staff activity · 30d',
          value:
            truncate(staff.map((entry) => `<@${entry.moderator_id}> · **${entry.total}** cases · ${entry.bans} ban(s)`).join('\n'), 1024) ||
            'No staff cases in the last 30 days.',
        },
        {
          name: `Appeals pending · ${appeals.length}`,
          value:
            truncate(
              appeals
                .map((entry) => `\`${entry.id}\` · <@${entry.target_id}> · ${entry.action} · ${relativeTimestamp(entry.created_at, 'R')}`)
                .join('\n'),
              1024,
            ) || 'No pending appeals.',
        },
        { name: 'Log channel', value: settings.channels.modLog ? `<#${settings.channels.modLog}>` : 'Not configured', inline: true },
        { name: 'Jail', value: 'Use `/mod jail` from the panel actions', inline: true },
      ],
      footer: 'Punishments are written to the case database',
    });

    const controls = [
      row(
        button({ id: customId('mod', 'warn'), label: 'Warn', emoji: '⚠️' }),
        button({ id: customId('mod', 'mute'), label: 'Mute', emoji: '🔇' }),
        button({ id: customId('mod', 'jail'), label: 'Jail', emoji: '⛓️' }),
        button({ id: customId('mod', 'note'), label: 'Note', emoji: '📝' }),
      ),
    ];

    if (cases.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('mod', 'case'),
            placeholder: 'Inspect a case',
            options: cases.slice(0, 25).map((entry) => ({
              label: `${entry.action} · ${entry.target_id}`,
              value: entry.id,
              description: truncate(entry.reason ?? 'no reason', 100),
            })),
          }),
        ),
      );
    }

    controls.push(navRow({ backPanel: 'mod' }));
    return { embeds: [embed], components: controls };
  },
};
