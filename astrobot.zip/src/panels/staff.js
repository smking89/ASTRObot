import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { recentCases } from '../db/repositories/moderation.js';
import { listOpenTickets } from '../db/repositories/tickets.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row } from '../ui/components.js';
import { relativeTimestamp, truncate } from '../utils/format.js';

/** /staff fallback panel. */
export default {
  id: 'staff',
  async render({ ctx }) {
    const settings = getGuildSettings(ctx.guildId);
    const cases = recentCases(ctx.guildId, 5);
    const tickets = listOpenTickets(ctx.guildId, 5);

    const embed = buildEmbed({
      title: '🧑‍💼 Staff Management',
      color: COLORS.brand,
      description: 'Application intake, cross-server recruitment and moderation load at a glance.',
      fields: [
        { name: 'Applications', value: settings.staff.applicationsOpen ? '🟢 Open' : '🔴 Closed', inline: true },
        { name: 'Panel channel', value: settings.staff.panelChannelId ? `<#${settings.staff.panelChannelId}>` : 'Not set', inline: true },
        { name: 'Review channel', value: settings.staff.reviewChannelId ? `<#${settings.staff.reviewChannelId}>` : 'Not set', inline: true },
        { name: 'Recruiter roles', value: settings.staff.recruiterRoleIds.map((id) => `<@&${id}>`).join(', ') || 'None' },
        {
          name: `Recent cases (${cases.length})`,
          value:
            truncate(
              cases.map((entry) => `${entry.action} · <@${entry.target_id}> · ${relativeTimestamp(entry.created_at, 'R')}`).join('\n'),
              1024,
            ) || 'No moderation cases.',
        },
        {
          name: `Open tickets (${tickets.length})`,
          value: truncate(tickets.map((ticket) => `<@${ticket.owner_id}> · ${ticket.subject}`).join('\n'), 1024) || 'No open tickets.',
        },
      ],
      footer: 'Staff actions require the staff access tier',
    });

    const controls = [
      row(
        button({ id: customId('staff', 'apply'), label: 'Apply', emoji: '📝', style: ButtonStyle.Success, disabled: !settings.staff.applicationsOpen }),
        button({ id: customId('staff', 'publish'), label: 'Publish apply panel', emoji: '📌' }),
        button({ id: customId('staff', 'recruit'), label: 'Recruit to hub', emoji: '📡' }),
      ),
      navRow({ backPanel: 'staff' }),
    ];

    return { embeds: [embed], components: controls };
  },
};
