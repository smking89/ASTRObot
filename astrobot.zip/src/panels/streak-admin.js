import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { listBadges } from '../services/badge-service.js';
import { DEFAULT_GUILD_SETTINGS } from '../config/defaults.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, roleSelect, row, stringSelect } from '../ui/components.js';
import { truncate } from '../utils/format.js';

const DAYS = [1, 2, 3, 4, 5, 6, 7];

const describeReward = (reward) =>
  [
    Number(reward?.coins) > 0 ? `🪙 ${Number(reward.coins).toLocaleString('en-US')}` : null,
    reward?.kit ? `🎒 ${reward.kit}` : null,
    reward?.roleId ? '🎭 role' : null,
  ]
    .filter(Boolean)
    .join(' · ') || 'nothing set';

/** Staff panel: build the server's own daily login streak. */
export default {
  id: 'streak-admin',
  async render({ ctx, params }) {
    const settings = getGuildSettings(ctx.guildId);
    const config = settings.streak ?? DEFAULT_GUILD_SETTINGS.streak;
    const rewards = config.rewards ?? DEFAULT_GUILD_SETTINGS.streak.rewards;
    const day = Math.min(7, Math.max(1, Number(params.day) || 1));
    const reward = rewards[day - 1] ?? {};
    const badge = config.badgeId ? listBadges(ctx.guildId).find((entry) => entry.id === config.badgeId) : null;

    const embed = buildEmbed({
      title: '🎁 Daily rewards builder',
      color: COLORS.brand,
      description:
        'Set up your own login streak. Choose what each day pays — coins, a kit, a role — who can claim it, and the badge players earn for a full week.',
      fields: [
        {
          name: 'Status',
          value: config.enabled === false ? '🔴 Turned off' : '🟢 Running',
          inline: true,
        },
        {
          name: 'Who can claim',
          value: config.requiredRoleId
            ? `<@&${config.requiredRoleId}>${Number(config.minLevel) > 0 ? ` · level ${config.minLevel}+` : ''}`
            : Number(config.minLevel) > 0
              ? `Level ${config.minLevel}+`
              : 'Everyone',
          inline: true,
        },
        { name: 'Streak badge', value: badge ? `🏅 ${badge.label}` : 'None', inline: true },
        {
          name: 'Rewards',
          value: truncate(
            rewards.map((entry, index) => `**Day ${index + 1}** · ${describeReward(entry)}`).join('\n'),
            1024,
          ),
        },
        {
          name: `Editing day ${day}`,
          value: `${describeReward(reward)}${reward.roleId ? ` · <@&${reward.roleId}>` : ''}${
            reward.kit ? '' : ''
          }\nUse the buttons and menus below to change it. Empty kit or role means that day only pays coins.`,
        },
      ],
      footer: 'Changes apply to the next claim — no restart needed',
    });

    const badges = listBadges(ctx.guildId);
    const controls = [
      row(
        stringSelect({
          id: customId('streakcfg', 'day'),
          placeholder: 'Choose a day to edit',
          options: DAYS.map((entry) => ({
            label: `Day ${entry}`,
            value: String(entry),
            description: truncate(describeReward(rewards[entry - 1]), 100),
            default: entry === day,
          })),
        }),
      ),
      row(
        button({ id: customId('streakcfg', 'coins', String(day)), label: 'Coins', emoji: '🪙' }),
        button({ id: customId('streakcfg', 'kit', String(day)), label: 'Kit', emoji: '🎒' }),
        button({ id: customId('streakcfg', 'roleclear', String(day)), label: 'Clear role', emoji: '🎭' }),
        button({ id: customId('streakcfg', 'minlevel'), label: 'Requirement', emoji: '🔒' }),
        button({
          id: customId('streakcfg', 'toggle'),
          label: config.enabled === false ? 'Turn on' : 'Turn off',
          emoji: '⚡',
          style: config.enabled === false ? ButtonStyle.Success : ButtonStyle.Secondary,
        }),
      ),
      row(
        roleSelect({
          id: customId('streakcfg', 'dayrole', String(day)),
          placeholder: `Optional role reward for day ${day}`,
        }),
      ),
      row(
        roleSelect({
          id: customId('streakcfg', 'reqrole'),
          placeholder: config.requiredRoleId ? 'Change the role needed to claim' : 'Optional: role needed to claim',
        }),
      ),
      row(
        stringSelect({
          id: customId('streakcfg', 'badge'),
          placeholder: config.badgeId ? 'Change the streak badge' : 'Optional: badge for a 7 day streak',
          options: [
            { label: 'No badge', value: 'none', default: !config.badgeId },
            ...badges.slice(0, 24).map((entry) => ({
              label: truncate(entry.label, 100),
              value: entry.id,
              description: truncate(entry.requirement ?? 'Badge', 100),
              default: entry.id === config.badgeId,
            })),
          ],
        }),
      ),
    ];

    return { embeds: [embed], components: controls };
  },
};
