import { ButtonStyle } from 'discord.js';
import { runtime } from '../core/runtime.js';
import { listServers } from '../db/repositories/servers.js';
import { listTasks } from '../db/repositories/tasks.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { formatDuration, truncate } from '../utils/format.js';

/**
 * /server fallback panel. Subcommands cover manage/backup/template; this panel
 * gives a live overview of the RCON fleet and scheduled tasks.
 */
export default {
  id: 'server',
  async render({ ctx }) {
    const servers = listServers(ctx.guildId);
    const tasks = listTasks(ctx.guildId);
    const manager = runtime.rconManager;

    const connectionRows = servers.map((server) => {
      const connection = manager?.connections?.get?.(server.id);
      const state = connection?.connected ? '🟢 connected' : '🔴 offline';
      return `${state} · \`${server.host}:${server.port}\` · ${server.enabled ? 'enabled' : 'disabled'}`;
    });

    const embed = buildEmbed({
      title: '🗄️ Server Management',
      color: COLORS.brand,
      description:
        servers.length === 0
          ? 'No Rust servers are connected yet. Add one with `/server manage` to enable killfeed, RCON telemetry, RaidLink and scheduled commands.'
          : 'Live state of every connected console server.',
      fields: [
        {
          name: `Connected servers (${servers.length})`,
          value: truncate(servers.map((server, index) => `**${server.label}**\n${connectionRows[index]}`).join('\n\n'), 1024) || '—',
        },
        {
          name: `Scheduled tasks (${tasks.length})`,
          value:
            truncate(
              tasks
                .slice(0, 8)
                .map((task) => `\`${task.name}\` · every ${formatDuration(task.interval_seconds * 1000)} · ${task.enabled ? 'on' : 'off'}`)
                .join('\n'),
              1024,
            ) || 'No scheduled tasks.',
        },
      ],
      footer: 'RCON passwords are encrypted at rest',
    });

    const controls = [];

    if (servers.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('srv', 'select'),
            placeholder: 'Select a server',
            options: servers.slice(0, 25).map((server) => ({
              label: server.label,
              value: server.id,
              description: `${server.host}:${server.port} · ${server.enabled ? 'enabled' : 'disabled'}`,
            })),
          }),
        ),
      );
    }

    controls.push(
      row(
        button({ id: customId('srv', 'add'), label: 'Add server', emoji: '➕', style: ButtonStyle.Success }),
        button({ id: customId('srv', 'test'), label: 'Test connection', emoji: '📡' }),
        button({ id: customId('srv', 'tasks'), label: 'Scheduled tasks', emoji: '⏱️' }),
        button({ id: customId('openpanel-admin', 'announcements'), label: 'Announcements', emoji: '📣' }),
      ),
      row(
        button({ id: customId('templates', 'open'), label: 'Templates', emoji: '🧱' }),
        button({ id: customId('wipe', 'open'), label: 'Wipes', emoji: '🧨' }),
      ),
      navRow({ backPanel: 'server' }),
    );

    return { embeds: [embed], components: controls };
  },
};
