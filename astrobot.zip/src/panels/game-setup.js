import { ButtonStyle } from 'discord.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { formatCoins } from '../utils/format.js';
import { getGameConfig } from '../services/games/game-config.js';
import { GAME_CATALOG, MULTIPLAYER_CATALOG } from './play.js';

/** Admin-only quick setup for every casino game. */
export default {
  id: 'game-setup',
  async render({ ctx }) {
    const config = getGameConfig(ctx.guildId);

    const embed = buildEmbed({
      title: '⚙️ Casino Game Setup',
      color: config.enabled ? COLORS.brand : COLORS.warning,
      description:
        'Toggle games and set the shared wager range. Changes save immediately and are written to the settings audit trail.',
      fields: [
        { name: 'Casino', value: config.enabled ? '🟢 Open' : '🔴 Closed', inline: true },
        { name: 'Solo', value: config.soloEnabled ? '🟢 Enabled' : '🔴 Disabled', inline: true },
        { name: '1v1', value: config.multiplayerEnabled ? '🟢 Enabled' : '🔴 Disabled', inline: true },
        { name: 'Wager range', value: `${formatCoins(config.minWager)} – ${formatCoins(config.maxWager)}`, inline: true },
        {
          name: 'Jackpot',
          value: `Seed ${formatCoins(config.jackpot.seed)} · minimum ${formatCoins(config.jackpot.min)} · ${config.jackpot.rakePercent}% rake · milestone ${config.jackpot.milestoneThreshold > 0 ? formatCoins(config.jackpot.milestoneThreshold) : 'off'}`,
          inline: false,
        },
        {
          name: 'Game prize pools',
          value:
            Object.entries(config.prizePools)
              .filter(([, pool]) => pool.enabled && pool.prizes.length > 0)
              .map(([id, pool]) => `${id}: ${pool.prizes.map((amount) => formatCoins(amount)).join(', ')}`)
              .join('\n') || 'None enabled — optional random bonus prizes.',
          inline: false,
        },
        {
          name: 'Solo games',
          value: GAME_CATALOG.map((game) => `${config.solo[game.id] !== false ? '✅' : '⛔'} ${game.label}`).join('\n'),
          inline: true,
        },
        {
          name: '1v1 games',
          value: MULTIPLAYER_CATALOG.map((game) => `${config.multiplayer[game.id] !== false ? '✅' : '⛔'} ${game.label}`).join('\n'),
          inline: true,
        },
      ],
      footer: 'Admins only · settings are audited',
    });

    const controls = [
      row(
        stringSelect({
          id: customId('setup', 'toggle', 'solo'),
          placeholder: 'Toggle a solo game',
          options: GAME_CATALOG.map((game) => ({
            label: `${config.solo[game.id] !== false ? 'On' : 'Off'} ${game.label}`,
            value: game.id,
            description: game.blurb,
            emoji: game.emoji,
          })),
        }),
      ),
      row(
        stringSelect({
          id: customId('setup', 'toggle', 'multiplayer'),
          placeholder: 'Toggle a 1v1 game',
          options: MULTIPLAYER_CATALOG.map((game) => ({
            label: `${config.multiplayer[game.id] !== false ? 'On' : 'Off'} ${game.label}`,
            value: game.id,
            description: game.blurb,
            emoji: game.emoji,
          })),
        }),
      ),
      row(
        button({ id: customId('setup', 'all', 'on'), label: 'Enable all', emoji: '✅', style: ButtonStyle.Success }),
        button({ id: customId('setup', 'all', 'off'), label: 'Disable all', emoji: '⛔', style: ButtonStyle.Danger }),
        button({
          id: customId('setup', 'casino', config.enabled ? 'close' : 'open'),
          label: config.enabled ? 'Close casino' : 'Open casino',
          emoji: '🚪',
          style: config.enabled ? ButtonStyle.Danger : ButtonStyle.Success,
        }),
        button({ id: customId('setup', 'limits'), label: 'Wager limits', emoji: '💰', style: ButtonStyle.Secondary }),
        button({ id: customId('setup', 'jackpot'), label: 'Jackpot', emoji: '💎', style: ButtonStyle.Secondary }),
      ),
      navRow({
        backPanel: 'play',
        showRefresh: true,
        showClose: true,
        extra: [button({ id: customId('setup', 'prize-pools'), label: 'Prize pools', emoji: '🎁' })],
      }),
    ];

    return { embeds: [embed], components: controls };
  },
};

