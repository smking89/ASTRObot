import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row } from '../ui/components.js';
import { truncate } from '../utils/format.js';

/** Admin surface for posting a persistent button/select role menu. */
export default {
  id: 'reaction-roles',
  async render({ ctx, params = {} }) {
    const settings = getGuildSettings(ctx.guildId);
    const config = settings.onboarding?.reactionRoles ?? {};
    const entries = Array.isArray(config.entries) ? config.entries : [];

    const embed = buildEmbed({
      title: '🎭 Reaction / Button Roles',
      color: COLORS.brand,
      description:
        params.notice ??
        'Post a role menu that members can use to assign or remove roles. Configure the choices in `/config` → **Onboarding Roles & Events**.',
      fields: [
        { name: 'Status', value: config.enabled ? '🟢 Enabled' : '🔴 Disabled', inline: true },
        { name: 'Panel channel', value: config.channelId ? `<#${config.channelId}>` : 'Current channel', inline: true },
        {
          name: `Role choices (${entries.length})`,
          value: truncate(entries.map((entry) => `<@&${entry.roleId}>${entry.label ? ` · ${entry.label}` : ''}`).join('\n'), 1024) || 'No choices configured.',
        },
      ],
      footer: 'Members can toggle roles from the posted menu',
    });

    return {
      embeds: [embed],
      components: [
        row(
          button({
            id: customId('reaction-roles', 'post'),
            label: 'Post role menu',
            emoji: '📌',
            style: ButtonStyle.Success,
            disabled: !config.enabled || entries.length === 0,
          }),
          button({ id: customId('cfg', 'section', 'config', 'onboarding-roles'), label: 'Configure', emoji: '⚙️' }),
        ),
        navRow({ backPanel: 'reaction-roles' }),
      ],
    };
  },
};
