import { ButtonStyle } from 'discord.js';
import { bountyBoard } from '../db/repositories/bounties.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row } from '../ui/components.js';
import { formatCoins, truncate } from '../utils/format.js';

/** /bounty panel. */
export default {
  id: 'bounty',
  async render({ ctx, params }) {
    const board = bountyBoard(ctx.guildId, 10);

    const embed = buildEmbed({
      title: '🎯 Bounty Board',
      color: COLORS.danger,
      description: params.notice ?? 'Every active bounty pays out automatically to the verified killer.',
      fields: [
        {
          name: 'Top targets',
          value:
            truncate(
              board.map((row, index) => `**#${index + 1}** <@${row.target_id}> · ${formatCoins(row.total)} · ${row.backers} backer(s)`).join('\n'),
              1024,
            ) || 'No active bounties. Place the first one.',
        },
        { name: 'Minimum', value: formatCoins(ctx.guildConfig.economy.bountyMinimum), inline: true },
        { name: 'Payout', value: 'Automatic on kill', inline: true },
      ],
      footer: 'Bounties are escrowed from your wallet when placed',
    });

    const controls = [
      row(button({ id: customId('bounty', 'place'), label: 'Place a bounty', emoji: '🎯', style: ButtonStyle.Danger })),
      navRow({ backPanel: 'bounty' }),
    ];

    return { embeds: [embed], components: controls };
  },
};
