import { staffHubPayload } from './hub.js';

/** Staff master panel: kept separate from the player panel on purpose. */
export default {
  id: 'staff-hub',
  async render() {
    return staffHubPayload();
  },
};
