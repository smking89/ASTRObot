import { ButtonStyle } from 'discord.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, row, stringSelect } from '../ui/components.js';
import { HUB_ADMIN_DESTINATIONS, HUB_PLAYER_DESTINATIONS } from '../config/panel-hub.js';

const optionsFor = (entries) =>
  entries.map((entry) => ({
    label: entry.label,
    value: entry.id,
    description: entry.description,
    emoji: entry.emoji,
  }));

/** Player master panel: every player tool, no slash commands. */
export function hubPayload() {
  return {
    embeds: [
      buildEmbed({
        title: '🎮 AstroBot Player Panel',
        color: COLORS.brand,
        description:
          'Everything you can do as a player, without typing a slash command. Pick a destination from the menu below.',
        fields: [
          {
            name: '🎮 Player tools',
            value: 'Shop · kit claim · games · daily rewards · wallet · leaderboards · battle pass · challenges · bounties · teams · LFG · referrals · support',
          },
        ],
        footer: 'AstroBot panel · hub',
      }),
    ],
    components: [
      row(
        stringSelect({
          id: customId('hub', 'player'),
          placeholder: 'Player menu — shop, kits, games, rewards…',
          options: optionsFor(HUB_PLAYER_DESTINATIONS),
        }),
      ),
      row(
        button({ id: customId('openpanel', 'claim'), label: 'Daily', emoji: '🎁', style: ButtonStyle.Success }),
        button({ id: customId('openpanel', 'shop'), label: 'Shop', emoji: '🛒' }),
        button({ id: customId('openpanel', 'play'), label: 'Play', emoji: '🎮' }),
        button({ id: customId('openpanel', 'support'), label: 'Support', emoji: '🎫' }),
      ),
    ],
  };
}

/** Staff master panel: every admin tool, separate from the player panel. */
export function staffHubPayload() {
  return {
    embeds: [
      buildEmbed({
        title: '🛡️ AstroBot Staff Panel',
        color: COLORS.gold,
        description:
          'Server operations for staff. These panels are protected: only members with a staff or admin role can open them.',
        fields: [
          {
            name: '🛡️ Staff tools',
            value: 'Announcements · giveaways · polls · portal · server · staff · moderation · configuration · shop admin · kits · templates · game setup · licenses · analytics',
          },
        ],
        footer: 'AstroBot panel · staff hub',
      }),
    ],
    components: [
      row(
        stringSelect({
          id: customId('hub', 'admin'),
          placeholder: 'Staff menu — server, config, shop admin…',
          options: optionsFor(HUB_ADMIN_DESTINATIONS),
        }),
      ),
      row(
        button({ id: customId('openpanel-admin', 'templates'), label: 'Templates', emoji: '🧱' }),
        button({ id: customId('openpanel-admin', 'announcements'), label: 'Announcements', emoji: '📣' }),
        button({ id: customId('openpanel-admin', 'config'), label: 'Config', emoji: '⚙️' }),
        button({ id: customId('openpanel-admin', 'mod'), label: 'Moderation', emoji: '🔨' }),
      ),
    ],
  };
}

/** Panel entry: the player master panel templates post. */
export default {
  id: 'hub',
  public: true,
  async render() {
    return hubPayload();
  },
};
