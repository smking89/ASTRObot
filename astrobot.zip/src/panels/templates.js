import { ButtonStyle } from 'discord.js';
import { listTemplates } from '../db/repositories/templates.js';
import { TEMPLATE_PRESETS, getPresetTemplate, presetSummary } from '../config/server-templates.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { truncate } from '../utils/format.js';
import { planHasFeature } from '../services/plan-service.js';

/** Admin panel for built-in layouts and saved server templates. */
export default {
  id: 'templates',
  async render({ ctx, params }) {
    const saved = listTemplates(ctx.guildId);
    const customTemplates = planHasFeature(ctx.guildId, 'customTemplates');
    const preset = params.selected ? getPresetTemplate(params.selected) : null;
    const selected = preset ? null : params.selected ? saved.find((entry) => entry.id === params.selected) ?? null : null;
    const chosen = preset ?? selected;
    const chosenPayload = chosen?.payload ?? null;

    const presetText =
      TEMPLATE_PRESETS.map((entry) => `**${truncate(entry.name, 60)}** · ${presetSummary(entry)}`).join('\n') ||
      'No built-in layouts.';

    const savedText = saved.length
      ? saved
          .map((template) => {
            const payload = template.payload ?? {};
            const counts = `${payload.roles?.length ?? 0} roles · ${payload.categories?.length ?? 0} categories · ${payload.channels?.length ?? 0} channels`;
            return `**${truncate(template.name, 60)}** · ${counts} · <t:${Math.floor(template.created_at / 1000)}:R>`;
          })
          .join('\n')
      : 'None yet. Save the current server layout to create one.';

    const fields = [
      { name: `Built-in layouts · ${TEMPLATE_PRESETS.length}`, value: truncate(presetText, 1024) },
      { name: `Saved templates · ${saved.length}`, value: truncate(savedText, 1024) },
      {
        name: '⚠️ Applying replaces the server',
        value:
          'Preview and confirm before applying: a confirmed apply deletes every channel, category and role the bot can remove, then rebuilds the server from the layout. @everyone, bot/integration roles and roles above AstroBot are kept. On the confirm page you choose which sections to add.',
      },
    ];
    if (chosenPayload) {
      fields.push(
        { name: 'Selected', value: `**${chosen.name}**${preset ? ' · built-in' : ''}`, inline: true },
        { name: 'Roles', value: String(chosenPayload.roles?.length ?? 0), inline: true },
        { name: 'Categories', value: String(chosenPayload.categories?.length ?? 0), inline: true },
        { name: 'Channels', value: String(chosenPayload.channels?.length ?? 0), inline: true },
      );
    }

    const embed = buildEmbed({
      title: '🧱 Server Templates',
      color: COLORS.brand,
      description:
        params.notice ??
        'Apply a built-in layout to rebuild the server structure, or save the current server as a template and re-apply it later. Applying asks you to confirm first, because it replaces the current layout.',
      fields,
      footer: 'Admin only · built-in layouts can be applied but not deleted',
    });

    const controls = [];
    const options = [
      ...TEMPLATE_PRESETS.map((entry) => ({
        label: truncate(entry.name, 100),
        value: entry.id,
        description: truncate(`Built-in · ${presetSummary(entry)}`, 100),
        default: entry.id === params.selected,
      })),
      ...saved.slice(0, 25).map((template) => {
        const payload = template.payload ?? {};
        return {
          label: truncate(template.name, 100),
          value: template.id,
          description: `${payload.roles?.length ?? 0} roles · ${payload.channels?.length ?? 0} channels`,
          default: template.id === params.selected,
        };
      }),
    ];

    if (options.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('templates', 'select'),
            placeholder: 'Choose a built-in layout or saved template',
            options: options.slice(0, 25),
          }),
        ),
      );
    }

    controls.push(
      row(
        button({ id: customId('templates', 'save'), label: 'Save current server', emoji: '💾', style: ButtonStyle.Success }),
        button({ id: customId('templates', 'new'), label: 'Build a template', emoji: '✍️', disabled: !customTemplates }),
        button({
          id: customId('templates', 'preview', params.selected ?? 'none'),
          label: 'Preview selected',
          emoji: '👁️',
          disabled: !chosen,
        }),
      ),
      row(
        button({
          id: customId('templates', 'apply', params.selected ?? 'none'),
          label: preset ? 'Preview & apply layout' : 'Preview & apply',
          emoji: '🏗️',
          style: ButtonStyle.Primary,
          disabled: !chosen,
        }),
        button({
          id: customId('templates', 'edit', selected?.id ?? 'none'),
          label: 'Edit selected',
          emoji: '✏️',
          disabled: !selected,
        }),
        button({
          id: customId('templates', 'delete', selected?.id ?? 'none'),
          label: 'Delete selected',
          emoji: '🗑️',
          style: ButtonStyle.Danger,
          disabled: !selected,
        }),
      ),
      navRow({ backPanel: 'server', showRefresh: true, showClose: true }),
    );

    return { embeds: [embed], components: controls, files: [] };
  },
};
