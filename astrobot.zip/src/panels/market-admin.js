import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row } from '../ui/components.js';
import { formatCoins, truncate } from '../utils/format.js';
import { marketCurrency, marketDashboard } from '../services/marketplace-service.js';

/** Owner/staff marketplace analytics and treasury surface. */
export default {
  id: 'market-admin',
  async render({ ctx, params = {} }) {
    const settings = getGuildSettings(ctx.guildId);
    const data = marketDashboard(ctx.guildId, settings);
    const currency = marketCurrency(settings);
    const vipCurrency = marketCurrency(settings, { vip: true });

    const embed = buildEmbed({
      title: '🏪 Marketplace Admin',
      color: COLORS.gold,
      description:
        params.notice ??
        'Player-to-player listings, treasury fees and seller analytics. Configure currencies, fees, lock timers and VIP pricing in `/config` → **Player Marketplace**.',
      fields: [
        {
          name: 'Status',
          value: settings.marketplace.enabled ? '🟢 Open' : '🔴 Closed',
          inline: true,
        },
        { name: 'Active listings', value: String(data.active), inline: true },
        { name: 'Completed sales', value: String(data.sales), inline: true },
        { name: 'Volume', value: formatCoins(data.volume, currency), inline: true },
        { name: 'Fees collected', value: formatCoins(data.fees, currency), inline: true },
        { name: 'Treasury', value: formatCoins(data.treasury, currency), inline: true },
        {
          name: 'Fees & modes',
          value: `Base fee **${settings.marketplace.feePercent ?? 0}%** · buy now ${settings.marketplace.modes?.buyNow ? '✅' : '❌'} · bid ${settings.marketplace.modes?.bid ? '✅' : '❌'} · sale ${settings.marketplace.modes?.sale ? '✅' : '❌'}`,
        },
        {
          name: 'VIP',
          value: settings.marketplace.vip?.enabled
            ? `${settings.marketplace.vip.roleId ? `<@&${settings.marketplace.vip.roleId}>` : 'No role set'} · ${vipCurrency} · ${settings.marketplace.vip.feePercent ?? 0}% fee · ${settings.marketplace.vip.discountPercent ?? 0}% discount`
            : 'Disabled',
        },
        {
          name: 'Top sellers',
          value:
            truncate(
              data.topSellers
                .map((entry, index) => `${index + 1}. <@${entry.seller_id}> · ${formatCoins(entry.volume, currency)} · ${entry.sales} sale(s)`)
                .join('\n'),
              1024,
            ) || 'No completed sales yet.',
        },
        {
          name: 'Recent sales',
          value:
            truncate(
              data.recent
                .map((sale) => `<@${sale.buyer_id}> bought **${sale.asset_label}** from <@${sale.seller_id}> · ${formatCoins(sale.amount, sale.currency)} · fee ${formatCoins(sale.fee, sale.currency)}`)
                .join('\n'),
              1024,
            ) || 'No marketplace sales yet.',
        },
      ],
      footer: `Treasury fees are held in the ${currency} economy account`,
    });

    return {
      embeds: [embed],
      components: [
        row(
          button({ id: customId('cfg', 'section', 'config', 'marketplace'), label: 'Marketplace settings', emoji: '⚙️' }),
          button({ id: customId('openpanel', 'market'), label: 'Open marketplace', emoji: '🏪' }),
          button({ id: customId('market-admin', 'refresh'), label: 'Refresh', emoji: '🔄' }),
          button({ id: customId('nav', 'close'), label: 'Close', emoji: '✖️', style: ButtonStyle.Danger }),
        ),
        navRow({ backPanel: 'market-admin', showRefresh: false }),
      ],
    };
  },
};
