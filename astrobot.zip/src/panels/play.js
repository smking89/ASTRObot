import { ButtonStyle } from 'discord.js';
import { COLORS, EMOJI } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { balances } from '../services/economy-service.js';
import { formatCoins } from '../utils/format.js';
import { getGameConfig } from '../services/games/game-config.js';
import { blackjackView } from '../ui/game-views.js';
import { listServers } from '../db/repositories/servers.js';
import { getJackpot } from '../services/jackpot-service.js';
import { CORE_MULTIPLAYER_GAMES, CORE_SOLO_GAMES } from '../config/plans.js';
import { guildPlan } from '../services/plan-service.js';

export const GAME_CATALOG = Object.freeze([
  { id: 'blackjack', label: 'Blackjack', emoji: '🃏', blurb: 'Beat the dealer. Naturals pay 3:2.' },
  { id: 'uno', label: 'UNO', emoji: '🎴', blurb: 'Race the house bot to an empty hand.' },
  { id: 'dice', label: 'Dice', emoji: '🎲', blurb: 'Under, over or exactly 7 on two dice.' },
  { id: 'slots', label: 'Treasure Slots', emoji: '🎰', blurb: 'Match three relics for up to 100x.' },
  { id: 'wheel', label: 'Spin Wheel', emoji: '🎡', blurb: 'Weighted multipliers up to 10x.' },
  { id: 'tower', label: 'Tower Climb', emoji: '🗼', blurb: 'Climb floors or cash out before you fall.' },
  { id: 'mines', label: 'Mines', emoji: '💣', blurb: 'Reveal safe tiles and cash out before a mine.' },
  { id: 'crash', label: 'Astro Crash', emoji: '🚀', blurb: 'Cash out before the rocket crashes.' },
  { id: 'plinko', label: 'Plinko', emoji: '🔻', blurb: 'Drop the ball for multipliers up to 18x.' },
  { id: 'roulette', label: 'Roulette', emoji: '🔴', blurb: 'Red, black, dozens or a straight number.' },
  { id: 'lootbox', label: 'Lootbox', emoji: '📦', blurb: 'Open a lucky box for a random reward.' },
  { id: 'defuse', label: 'The Defuse Wire', emoji: '✂️', blurb: 'Cut a wire on the bomb — clip safe, double your pot, or blow it all.' },
  { id: 'minefield', label: 'The Grid Minefield', emoji: '🧱', blurb: 'Reveal cells on a 6x6 grid — stars grow your payout, but 3 hidden traps lurk.' },
  { id: 'ticket', label: 'The Ticket Jackpot', emoji: '🎟️', blurb: 'Buy raffle tickets to win the pool — odds scale with entries.' },
  { id: 'recycler', label: 'The Recycler Roulette', emoji: '♻️', blurb: 'Recycle scrap into cash — match 2 or 3 symbols on the reels.' },
  { id: 'range', label: 'The Target Range', emoji: '🎯', blurb: 'Pick a weapon and fire at the range — each hit builds a score multiple.' },
  { id: 'scratch-radiation', label: 'Radiation Rush', emoji: '☢️', blurb: 'Scratch a 3x3 card — find three hazmat tokens before the card runs out.' },
  { id: 'scratch-voltage', label: 'High-Voltage Grid', emoji: '⚡', blurb: 'Match three overclock cores on the neon grid for up to 10x.' },
  { id: 'scratch-royal', label: 'The Royal Vault', emoji: '🏛️', blurb: 'Crack the vault for three imperial crown marks and a huge multiplier.' },
  { id: 'scratch-scrap', label: 'The Scrap Pile', emoji: '🌲', blurb: 'Dig three salvaged pickaxes out of the outpost scrap.' },
]);

export const MULTIPLAYER_CATALOG = Object.freeze([
  { id: 'dice', label: 'Dice Duel', emoji: '🎲', blurb: 'Roll highest to take the pot.' },
  { id: 'coinflip', label: 'Coin Flip', emoji: '🪙', blurb: 'Pick heads or tails against a friend.' },
]);

const ADMIN = 'admin';
const MODE_LABEL = { solo: 'Solo', multiplayer: '1v1' };

function planAllowsSolo(plan, gameId) {
  return plan.features.fullGames || CORE_SOLO_GAMES.includes(gameId);
}

function planAllowsMultiplayer(plan, gameId) {
  return plan.features.fullGames || CORE_MULTIPLAYER_GAMES.includes(gameId);
}

/** /play: choose mode → server → game. */
export default {
  id: 'play',
  async render({ ctx, params = {} }) {
    if (params.game && params.sessionId) {
      // Rendered by the game component after an action; avoids duplicating views.
      return null;
    }

    const mode = params.mode === 'multiplayer' ? 'multiplayer' : params.mode === 'solo' ? 'solo' : null;
    const servers = listServers(ctx.guildId);
    const selectedServer = params.serverId && params.serverId !== 'none' ? servers.find((entry) => entry.id === params.serverId) ?? null : null;
    const hasServer = params.serverId !== undefined && params.serverId !== null;
    const config = getGameConfig(ctx.guildId);
    const account = balances(ctx.guildId, ctx.userId);
    const isAdmin = Boolean(ctx.grants?.has?.(ADMIN));
    const jackpot = getJackpot(ctx.guildId);
    const plan = guildPlan(ctx.guildId);
    const jackpotEnabled = plan.features.jackpot;

    const baseFooter = `Wallet: ${formatCoins(account.wallet, account.currency)} · wagers ${formatCoins(config.minWager)}–${formatCoins(config.maxWager)} · Jackpot ${formatCoins(jackpot.balance)}`;
    const activePrizePools = Object.entries(config.prizePools).filter(([, pool]) => pool.enabled && pool.prizes.length > 0);
    const gameLabels = Object.fromEntries([...GAME_CATALOG, ...MULTIPLAYER_CATALOG].map((game) => [game.id, game.label]));
    const prizePoolSummary = activePrizePools.length
      ? activePrizePools.map(([id, pool]) => `**${gameLabels[id] ?? id}** · ${pool.prizes.length} prize(s)`).join(' · ')
      : 'None configured (optional) · enable one from Game Setup';

    if (!mode) {
      const soloGames = GAME_CATALOG.filter((game) => config.solo[game.id] !== false && planAllowsSolo(plan, game.id));
      const soloCount = soloGames.length;
      const multiplayerCount = MULTIPLAYER_CATALOG.filter(
        (game) => config.multiplayer[game.id] !== false && planAllowsMultiplayer(plan, game.id),
      ).length;
      const controls = [];
      if (config.enabled && soloCount > 0) {
        controls.push(
          row(
            stringSelect({
              id: customId('play', 'select-game', 'solo', 'none'),
              placeholder: 'Choose a game to play',
              options: soloGames.slice(0, 25).map((game) => ({
                label: game.label,
                value: game.id,
                description: game.blurb,
                emoji: game.emoji,
              })),
            }),
          ),
        );
      }
      controls.push(
        row(
          button({ id: customId('play', 'mode', 'multiplayer'), label: '1v1', emoji: '⚔️' }),
          jackpotEnabled ? button({ id: customId('play', 'jackpot'), label: 'Jackpot', emoji: '💎' }) : null,
          isAdmin ? button({ id: customId('setup', 'open'), label: 'Configure', emoji: '⚙️' }) : null,
          isAdmin
            ? button({ id: customId('setup', 'quick'), label: 'Quick Setup', emoji: '⚡', style: ButtonStyle.Primary })
            : null,
          isAdmin
            ? button({ id: customId('setup', 'reset'), label: 'Reset', emoji: '🔄', style: ButtonStyle.Danger })
            : null,
        ),
      );
      controls.push(navRow({ refreshArgs: ['play'] }));

      return {
        embeds: [
          buildEmbed({
            title: `${EMOJI.game} Games & Casino`,
            color: config.enabled ? COLORS.brand : COLORS.warning,
            description:
              'Choose a game from the menu to open its wager prompt. Solo games settle instantly or keep their controls in the game message. Staff can use **Configure** for game and prize-pool settings, or **Quick Setup** to enable every game with the default wager range.',
            fields: [
              {
                name: 'Game access',
                value: `${soloCount}/${GAME_CATALOG.length} solo · ${multiplayerCount}/${MULTIPLAYER_CATALOG.length} 1v1`,
                inline: true,
              },
              { name: 'Wager range', value: `${formatCoins(config.minWager)}–${formatCoins(config.maxWager)}`, inline: true },
              { name: 'Jackpot', value: formatCoins(jackpot.balance), inline: true },
              { name: 'Casino status', value: config.enabled ? '🟢 Open' : '🔴 Closed', inline: true },
              {
                name: 'Available games',
                value: soloGames.length ? soloGames.map((game) => `${game.emoji} ${game.label}`).join(' · ') : 'No solo games enabled.',
                inline: false,
              },
              { name: '🎁 Game prize pools', value: prizePoolSummary, inline: false },
            ],
            footer: baseFooter,
          }),
        ],
        components: controls.filter((entry) => entry.components.length > 0),
      };
    }

    if (!hasServer) {
      const serverOptions = servers.slice(0, 24).map((server) => ({
        label: server.label,
        value: server.id,
        description: `${server.host}:${server.port} · ${server.enabled ? 'enabled' : 'disabled'}`,
      }));
      serverOptions.push({
        label: servers.length ? 'No server / global wallet' : 'No server linked',
        value: 'none',
        description: servers.length ? 'Play without tying this session to a server' : 'Add a server later from /server manage',
      });

      return {
        embeds: [
          buildEmbed({
            title: `${EMOJI.game} Astro Casino · ${MODE_LABEL[mode]}`,
            color: config.enabled ? COLORS.brand : COLORS.warning,
            description: 'Choose the server this session belongs to, then pick a game.',
            fields: [
              { name: 'Servers available', value: String(servers.length), inline: true },
              { name: 'Server required?', value: 'No — global wallet is always available.', inline: true },
            ],
            footer: baseFooter,
          }),
        ],
        components: [
          row(
            stringSelect({
              id: customId('play', 'select-server', mode),
              placeholder: 'Choose a server',
              options: serverOptions,
            }),
          ),
          row(
            button({ id: customId('play', 'reset'), label: 'Change mode', emoji: '↩️' }),
            jackpotEnabled ? button({ id: customId('play', 'jackpot'), label: 'Jackpot', emoji: '💎' }) : null,
            isAdmin ? button({ id: customId('setup', 'open'), label: 'Game Setup', emoji: '⚙️' }) : null,
          ),
          navRow({ refreshArgs: ['play'] }),
        ].filter((entry) => entry.components.length > 0),
      };
    }

    const modeEnabled = mode === 'solo' ? config.soloEnabled : config.multiplayerEnabled;
    const games =
      mode === 'solo'
        ? GAME_CATALOG.filter((game) => config.solo[game.id] !== false && planAllowsSolo(plan, game.id))
        : MULTIPLAYER_CATALOG.filter((game) => config.multiplayer[game.id] !== false && planAllowsMultiplayer(plan, game.id));

    let description;
    if (!config.enabled) {
      description = 'The casino is closed right now. An administrator can reopen it from **Game Setup**.';
    } else if (!modeEnabled) {
      description =
        mode === 'solo'
          ? 'Solo games are disabled by an administrator. Switch to 1v1 or open Game Setup.'
          : '1v1 challenges are disabled by an administrator. Switch to Solo or open Game Setup.';
    } else if (games.length === 0) {
      description = 'No games are enabled in this mode yet. An administrator can enable them from **Game Setup**.';
    } else if (mode === 'solo') {
      description = 'Pick a game, set a wager and play with buttons. Every payout is settled instantly against your wallet.';
    } else {
      description = 'Pick a game, choose an opponent and wager. Both stakes are escrowed, and the winner takes the pot.';
    }

    const fields = games.length
      ? games.map((game) => ({ name: `${game.emoji} ${game.label}`, value: game.blurb, inline: true }))
      : [{ name: 'Games', value: 'None enabled', inline: true }];

    const controls = [];
    if (config.enabled && modeEnabled && games.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('play', 'select-game', mode, params.serverId),
            placeholder: 'Choose a game',
            options: games.map((game) => ({
              label: game.label,
              value: game.id,
              description: game.blurb,
              emoji: game.emoji,
            })),
          }),
        ),
      );
    }

    controls.push(
      row(
        button({ id: customId('play', 'change-server', mode), label: 'Change server', emoji: '🗄️' }),
        button({ id: customId('play', 'jackpot'), label: 'Jackpot', emoji: '💎' }),
        button({ id: customId('play', 'reset'), label: 'Change mode', emoji: '↩️' }),
        isAdmin ? button({ id: customId('setup', 'open'), label: 'Game Setup', emoji: '⚙️' }) : null,
      ),
      navRow({ refreshArgs: ['play'] }),
    );

    return {
      embeds: [
        buildEmbed({
          title: `${EMOJI.game} Astro Casino · ${MODE_LABEL[mode]}`,
          color: config.enabled && modeEnabled ? COLORS.brand : COLORS.warning,
          description,
          fields: [
            { name: 'Server', value: selectedServer ? selectedServer.label : 'Global wallet', inline: true },
            ...fields,
          ],
          footer: baseFooter,
        }),
      ],
      components: controls.filter((entry) => entry.components.length > 0),
    };
  },
};

export { blackjackView };
