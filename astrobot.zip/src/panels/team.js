import { ButtonStyle } from 'discord.js';
import { getTeamForUser, listMembers, memberCount, pendingInvitesFor, activeWarFor } from '../db/repositories/teams.js';
import { COLORS, EMOJI } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row } from '../ui/components.js';
import { relativeTimestamp, truncate } from '../utils/format.js';
import { clanRank } from '../services/clan-service.js';
import { listClanBadges } from '../services/badge-service.js';
import { badgeAttachment, badgeImage, iconAttachment, iconUrl } from '../ui/badge-assets.js';

/** /team fallback panel. */
export default {
  id: 'team',
  async render({ ctx }) {
    const team = ctx.team ?? getTeamForUser(ctx.guildId, ctx.userId);

    if (!team) {
      const invites = pendingInvitesFor(ctx.guildId, ctx.userId);

      const embed = buildEmbed({
        title: `${EMOJI.team} Team Management`,
        color: COLORS.brand,
        description:
          'You are not in a team yet. Teams get a synchronized clan tag on every killfeed, a private RaidLink channel and an ORP zone.',
        fields: [
          {
            name: 'Pending invites',
            value: truncate(invites.map((invite) => `<@${invite.inviter_id}> · team invite · expires ${relativeTimestamp(invite.expires_at, 'R')}`).join('\n'), 1024) || 'None',
          },
        ],
        footer: '/team create · /team invite · /team manage',
      });

      const controls = [];
      if (invites.length > 0) {
        controls.push(
          row(
            button({ id: customId('team', 'accept', invites[0].id), label: 'Accept invite', style: ButtonStyle.Success }),
            button({ id: customId('team', 'decline', invites[0].id), label: 'Decline', style: ButtonStyle.Danger }),
          ),
        );
      }
      controls.push(
        row(button({ id: customId('team', 'create'), label: 'Create team', emoji: '➕', style: ButtonStyle.Primary })),
        navRow({ backPanel: 'team' }),
      );

      return { embeds: [embed], components: controls };
    }

    const members = listMembers(team.id);
    const war = activeWarFor(team.id);
    const isLeader = team.owner_id === ctx.userId || team.member_rank === 'leader' || team.member_rank === 'officer';
    const rank = clanRank(ctx.guildId, team.member_rank);
    const clanBadge = listClanBadges(ctx.guildId).find((badge) => badge.id === team.badge) ?? null;

    // Ranks and clan badges are real images: attach them and point the embed at
    // the attachment, since Discord does not render emoji or SVG in images.
    const files = [];
    let thumbnail = null;
    if (clanBadge) {
      files.push(badgeAttachment(clanBadge));
      thumbnail = badgeImage(clanBadge);
    } else if (rank) {
      files.push(iconAttachment(rank.icon));
      thumbnail = iconUrl(rank.icon);
    }

    const embed = buildEmbed({
      title: `${EMOJI.team} ${team.name} [${team.tag}]`,
      color: team.color ?? COLORS.brand,
      thumbnail,
      fields: [
        { name: 'Rank', value: `**${rank?.label ?? 'Member'}**`, inline: true },
        { name: 'Members', value: `${memberCount(team.id)}`, inline: true },
        { name: 'War', value: war ? `vs ${war.opponent_team_id}` : 'None', inline: true },
        {
          name: 'Roster',
          value: truncate(
            members.map((member) => `${clanRank(ctx.guildId, member.rank)?.label ?? 'Member'} · <@${member.user_id}>`).join('\n'),
            1024,
          ) || '—',
        },
        {
          name: 'Clan badge',
          value: clanBadge ? `**${clanBadge.label}**` : 'Not uploaded — `/team badge upload`',
          inline: true,
        },
        {
          name: 'ORP zone',
          value: team.orp_zone ? '`registered`' : 'Not registered — use `/team orp`',
          inline: true,
        },
        { name: 'RaidLink', value: team.raid_channel_id ? `<#${team.raid_channel_id}>` : 'Not configured', inline: true },
      ],
      footer: 'Leaders: /team rank create · /team badge upload',
    });

    const controls = [
      row(
        button({ id: customId('team', 'invite'), label: 'Invite', emoji: '✉️', disabled: !isLeader }),
        button({ id: customId('team', 'config'), label: 'Configure', emoji: '⚙️', disabled: !isLeader }),
        button({ id: customId('team', 'war'), label: 'War', emoji: '⚔️', disabled: !isLeader }),
        button({ id: customId('team', 'orp'), label: 'ORP zone', emoji: '🛡️', disabled: !isLeader }),
      ),
      row(button({ id: customId('team', 'leave'), label: 'Leave team', style: ButtonStyle.Danger })),
      navRow({ backPanel: 'team' }),
    ];

    return { embeds: [embed], components: controls, files };
  },
};
