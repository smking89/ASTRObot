import { ButtonStyle } from 'discord.js';
import { openTicketsFor } from '../db/repositories/tickets.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row } from '../ui/components.js';

/** The four ticket intakes offered on the panel, plus the generic one. */
const TICKET_CATEGORIES = [
  { category: 'bug', label: 'Bug Report', emoji: '❗' },
  { category: 'appeal', label: 'Ban Appeal', emoji: '🔒' },
  { category: 'refund', label: 'Refund', emoji: '📦' },
  { category: 'tech', label: 'Tech Help', emoji: '🛠️' },
];

/**
 * The support card itself. It is posted as-is in the support channel, so the
 * same payload backs both the channel card and the ephemeral panel.
 */
export function supportPayload({ atLimit = false } = {}) {
  const embed = buildEmbed({
    title: '🎫 Support',
    color: COLORS.info,
    description: 'Need help with bans, bugs, or account issues? Tap a button below to open a private ticket.',
    fields: [
      {
        name: 'Options',
        value: [...TICKET_CATEGORIES.map((entry) => `${entry.emoji} ${entry.label}`), '🎫 OPEN TICKET', '🛑 Closed Tickets'].join('\n'),
      },
    ],
    footer: 'Only you and ASTRO staff can see your ticket.',
  });

  const controls = [
    row(
      ...TICKET_CATEGORIES.map((entry) =>
        button({
          id: customId('ticket', 'open', entry.category),
          label: entry.label,
          emoji: entry.emoji,
          disabled: atLimit,
        }),
      ),
    ),
    row(
      button({
        id: customId('ticket', 'open', 'general'),
        label: 'OPEN TICKET',
        emoji: '🎫',
        style: ButtonStyle.Success,
        disabled: atLimit,
      }),
      button({ id: customId('ticket', 'closed'), label: 'Closed Tickets', emoji: '🛑' }),
    ),
  ];

  return { embeds: [embed], components: controls };
}

/** /support panel. */
export default {
  id: 'support',
  async render({ ctx }) {
    const settings = getGuildSettings(ctx.guildId);
    const mine = openTicketsFor(ctx.guildId, ctx.userId);
    const atLimit = mine.length >= Number(settings.tickets.maxOpenPerUser ?? 1);
    const payload = supportPayload({ atLimit });

    return {
      ...payload,
      components: [...payload.components, navRow({ backPanel: 'hub' })],
    };
  },
};
