import { ButtonStyle, ChannelType } from 'discord.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, channelSelect, customId, navRow, row, stringSelect } from '../ui/components.js';
import { formatCoins, formatNumber } from '../utils/format.js';
import { currencyOf } from '../services/economy-service.js';
import {
  JACKPOT_GAME_LABELS,
  JACKPOT_GAMES,
  getJackpot,
  getJackpotHistory,
} from '../services/jackpot-service.js';
import { getGameConfig } from '../services/games/game-config.js';
import { getJackpotDrawState, JACKPOT_PLACE_LABELS } from '../services/jackpot-raffle-service.js';
import { withGameArt } from '../ui/game-art.js';
import { planHasFeature } from '../services/plan-service.js';

/** Progressive jackpot, three-place raffle and ticket controls. */
export default {
  id: 'jackpot',
  async render({ ctx, params = {} }) {
    if (!planHasFeature(ctx.guildId, 'jackpot')) {
      return {
        embeds: [
          buildEmbed({
            title: '💎 Jackpot & Raffle',
            color: COLORS.gold,
            description:
              'The progressive jackpot and ticket raffle are part of **Pro and Max**. This server is on Basic. Upgrade from `/checkout` to unlock them.',
          }),
        ],
        components: [navRow({ backPanel: 'play' })],
      };
    }
    const jackpot = getJackpot(ctx.guildId);
    const config = getGameConfig(ctx.guildId).jackpot;
    const raffle = config.raffle;
    const drawState = getJackpotDrawState(ctx.guildId, ctx.userId);
    const history = getJackpotHistory(ctx.guildId, 5);
    const latest = history[0] ?? null;
    const currency = currencyOf(ctx.guildId);
    const money = (value) => formatCoins(value, currency);
    const number = (value) => Number(value).toLocaleString('en-US');
    const isAdmin = Boolean(ctx.grants?.has?.('admin'));
    const channelPicker = Boolean(params.channelPicker && isAdmin);
    const drawConfirm = Boolean(params.drawConfirm && isAdmin);
    const selectedTier = raffle.tiers.find((tier) => tier.id === params.tier) ?? raffle.tiers[0] ?? null;
    const drawReady = raffle.enabled && drawState.participants >= 3;

    const latestWinner = latest
      ? `<@${latest.userId}> won **${money(latest.amount)}** on **${JACKPOT_GAME_LABELS[latest.game] ?? latest.game}** <t:${Math.floor(latest.createdAt / 1000)}:R>`
      : 'No jackpot winner yet. The pool is waiting.';

    const recent = history.length
      ? history
          .map(
            (entry) =>
              `• <@${entry.userId}> · **${money(entry.amount)}** · ${JACKPOT_GAME_LABELS[entry.game] ?? entry.game} · <t:${Math.floor(entry.createdAt / 1000)}:R>`,
          )
          .join('\n')
      : 'No wins recorded yet.';

    const odds = JACKPOT_GAMES.map(
      (game) => `• **${JACKPOT_GAME_LABELS[game]}** · 1 in ${number(jackpot.odds[game])}`,
    ).join('\n');
    const prizes = raffle.prizeMode === 'fixed'
      ? `🥇 ${money(raffle.prizes.first)} · 🥈 ${money(raffle.prizes.second)} · 🥉 ${money(raffle.prizes.third)}`
      : `🥇 ${raffle.poolShares.first}% · 🥈 ${raffle.poolShares.second}% · 🥉 ${raffle.poolShares.third}% of the raffle pool`;
    const latestDraw = drawState.latest
      ? drawState.latest.winners
          .map((winner) => `${JACKPOT_PLACE_LABELS[winner.place]} <@${winner.userId}> · ${money(winner.amount)}`)
          .join('\n')
      : 'No raffle draw yet.';
    const raffleStatus = !raffle.enabled
      ? '🔴 Disabled'
      : drawState.participants < 3
        ? `🟡 Waiting for players (${drawState.participants}/3)`
        : '🟢 Ready to draw';
    const notice = params.notice ? `> ${params.notice}\n\n` : '';

    const embed = buildEmbed({
      title: '💎 Jackpot & Raffle',
      color: COLORS.gold,
      description: channelPicker
        ? 'Choose the channel where jackpot milestone alerts will be posted.'
        : drawConfirm
          ? `Confirm the 3-place raffle draw. **${drawState.entries}** entries from **${drawState.participants}** players are in the pool. This cannot be undone.`
          : `${notice}Every eligible wager feeds the progressive pool. The separate three-place raffle is funded by ticket sales; each ticket tier adds configured entries.`,
      fields: [
        { name: 'Current pool', value: money(jackpot.balance), inline: true },
        { name: 'Seed / minimum', value: `${money(jackpot.seed)} / ${money(jackpot.minimum)}`, inline: true },
        { name: 'Rake', value: `${jackpot.rakePercent}% of eligible wagers`, inline: true },
        {
          name: 'Milestone alert',
          value:
            config.milestoneThreshold > 0
              ? `${money(config.milestoneThreshold)}${config.milestoneChannelId ? ` · <#${config.milestoneChannelId}>` : ' · channel not set'}`
              : 'Disabled',
          inline: true,
        },
        { name: 'Latest winner', value: latestWinner, inline: false },
        { name: 'Eligible games', value: JACKPOT_GAMES.map((game) => JACKPOT_GAME_LABELS[game]).join(' · '), inline: false },
        { name: 'Odds per eligible round', value: odds, inline: false },
        { name: 'Recent winners', value: recent, inline: false },
        { name: '🎟️ Raffle pool', value: money(drawState.balance), inline: true },
        { name: 'Raffle status', value: raffleStatus, inline: true },
        { name: 'Tickets / entries', value: `${drawState.tickets} / ${drawState.entries}`, inline: true },
        { name: 'Raffle prizes', value: prizes, inline: false },
        { name: 'Your raffle entries', value: `${drawState.userEntries}`, inline: true },
        { name: 'Latest draw', value: latestDraw, inline: false },
      ],
      footer: 'Progressive jackpot and ticket raffle are separate pools · tickets use ' + currency,
    });

    if (channelPicker) {
      return withGameArt({
        embeds: [embed],
        components: [
          row(
            channelSelect({
              id: customId('jackpot', 'channel-save'),
              placeholder: 'Choose the milestone alert channel',
              channelTypes: [ChannelType.GuildText, ChannelType.GuildAnnouncement],
            }),
          ),
          navRow({ backPanel: 'play', refreshArgs: ['jackpot'], showRefresh: true, showClose: true }),
        ],
      }, { guildId: ctx.guildId, gameId: 'ticket' });
    }

    if (drawConfirm) {
      return withGameArt({
        embeds: [embed],
        components: [
          row(
            button({ id: customId('jackpot', 'draw-confirm'), label: 'Confirm draw', emoji: '🎲', style: ButtonStyle.Danger }),
            button({ id: customId('jackpot', 'draw-cancel'), label: 'Cancel', emoji: '↩️' }),
          ),
          navRow({ backPanel: 'play', refreshArgs: ['jackpot'], showRefresh: true, showClose: true }),
        ],
      }, { guildId: ctx.guildId, gameId: 'ticket' });
    }

    const components = [];
    if (raffle.enabled && raffle.tiers.length > 0) {
      components.push(
        row(
          stringSelect({
            id: customId('jackpot', 'pick-tier'),
            placeholder: 'Choose a ticket tier',
            options: raffle.tiers.map((tier) => ({
              label: `${tier.label} — ${formatNumber(tier.cost)} ${currency}`,
              value: tier.id,
              description: `${tier.entries} raffle ${tier.entries === 1 ? 'entry' : 'entries'}`,
              default: tier.id === selectedTier?.id,
            })),
          }),
        ),
        row(
          button({
            id: customId('jackpot', 'buy', selectedTier?.id ?? 'none'),
            label: selectedTier ? `Buy ${selectedTier.label} ticket` : 'Buy ticket',
            emoji: '🎟️',
            style: ButtonStyle.Success,
            disabled: !selectedTier,
          }),
        ),
      );
    }

    if (isAdmin) {
      components.push(
        row(
          button({ id: customId('setup', 'jackpot'), label: 'Configure jackpot', emoji: '⚙️' }),
          button({ id: customId('setup', 'jackpot-raffle'), label: 'Prizes & tickets', emoji: '🎟️' }),
          button({ id: customId('jackpot', 'channel'), label: 'Alert channel', emoji: '📣' }),
          button({
            id: customId('jackpot', 'draw'),
            label: 'Draw',
            emoji: '🎲',
            style: ButtonStyle.Danger,
            disabled: !drawReady,
          }),
        ),
      );
    }

    components.push(navRow({ backPanel: 'play', refreshArgs: ['jackpot'], showRefresh: true, showClose: true }));

    return withGameArt({ embeds: [embed], components }, { guildId: ctx.guildId, gameId: 'ticket' });
  },
};