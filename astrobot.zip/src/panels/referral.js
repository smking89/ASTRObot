import { ButtonStyle } from 'discord.js';
import { getReferralForOwner, referralClaimCount, topReferrers } from '../db/repositories/referrals.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row } from '../ui/components.js';
import { formatCoins, formatNumber } from '../utils/format.js';
import { leaderboardBoard } from '../services/leaderboard-service.js';

/**
 * KOBA-style referral card, matching the card language used by the KOBA bot
 * (dark panel, green/cyan accent, author line, one big value, compact fields).
 * The leaderboard is drawn as a PNG card in the same theme.
 */
const CARD = Object.freeze({
  accent: 0x7cff4f,
  accent2: 0x43d9ff,
});

export default {
  id: 'referral',
  async render({ ctx }) {
    const code = getReferralForOwner(ctx.guildId, ctx.userId);
    const settings = getGuildSettings(ctx.guildId);
    const bonus = Number(settings.economy.referralBonus) || 0;
    const claims = referralClaimCount(ctx.guildId, ctx.userId);
    const leaders = topReferrers(ctx.guildId, 100);

    const rank = leaders.findIndex((entry) => String(entry.owner_id) === String(ctx.userId)) + 1;
    const earned = (Number(code?.uses) || 0) * bonus;
    const name = ctx.member?.displayName ?? ctx.member?.user?.username ?? 'Your referral card';

    const board = await leaderboardBoard({
      guild: ctx.guild ?? null,
      guildId: ctx.guildId,
      metric: 'referrals',
      limit: 10,
      theme: 'brand',
      title: 'Referral leaders',
      eyebrow: 'ASTROBOT',
    });

    const embed = buildEmbed({
      title: code ? 'REFERRAL CODE' : 'REFERRALS',
      color: code ? CARD.accent : CARD.accent2,
      description: code
        ? `\`\`\`\n${code.code}\n\`\`\`\nShare it with new players — you earn **${formatCoins(bonus)}** each time it is redeemed.`
        : 'Create a referral code to start earning rewards for inviting players. Your code is yours to share — new players redeem it once.',
      fields: [
        { name: 'Redemptions', value: formatNumber(code?.uses ?? 0), inline: true },
        { name: 'Coins earned', value: formatCoins(earned), inline: true },
        { name: 'Your rank', value: rank > 0 ? `▲ #${rank}` : 'Unranked', inline: true },
        { name: 'Rewarded joins', value: formatNumber(claims), inline: true },
        { name: 'Invite reward', value: formatCoins(bonus), inline: true },
        { name: 'Redeemer reward', value: formatCoins(Math.floor(bonus / 2)), inline: true },
      ],
      footer: 'Rewards are paid to your wallet · referrals panel',
    });

    embed.setColor(code ? CARD.accent : CARD.accent2);
    embed.setAuthor({ name });
    embed.setFooter({ text: `Rewards are paid to your wallet · ${settings.economy.currency ?? 'coins'}` });
    embed.setImage('attachment://leaderboard.png');

    const controls = [
      row(
        button({ id: customId('ref', 'create'), label: code ? 'New code' : 'Create code', style: ButtonStyle.Success, emoji: '🎟️' }),
        button({ id: customId('ref', 'redeem'), label: 'Redeem a code', emoji: '📥' }),
        button({ id: customId('ref', 'leaderboard'), label: 'Full leaderboard', emoji: '🏆' }),
      ),
      navRow({ backPanel: 'referral' }),
    ];

    return { embeds: [embed], files: [board.attachment], components: controls };
  },
};
