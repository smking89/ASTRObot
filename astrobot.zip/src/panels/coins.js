import { ButtonStyle } from 'discord.js';
import { balances } from '../services/economy-service.js';
import { getAccount, recentTransactions, rankFor } from '../db/repositories/players.js';
import { personalRank } from '../ui/rank-icons.js';
import { iconAttachment, iconUrl } from '../ui/badge-assets.js';
import { COLORS, EMOJI } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row } from '../ui/components.js';
import { formatCoins, formatNumber, formatSigned, relativeTimestamp, truncate } from '../utils/format.js';

/** /coins fallback panel. */
export default {
  id: 'coins',
  async render({ ctx, params }) {
    const account = balances(ctx.guildId, ctx.userId);
    const history = recentTransactions(ctx.guildId, ctx.userId, 5);
    const rank = rankFor(ctx.guildId, ctx.userId, 'wallet');
    const personal = personalRank(getAccount(ctx.guildId, ctx.userId)?.level ?? 1);

    const embed = buildEmbed({
      title: `${EMOJI.coin} ${params.title ?? 'Your Currency'}`,
      color: COLORS.gold,
      thumbnail: iconUrl(personal.icon),
      fields: [
        { name: '👛 Wallet', value: formatCoins(account.wallet, account.currency), inline: true },
        { name: '🏦 Safe bank', value: formatCoins(account.bank, account.currency), inline: true },
        { name: '📊 Wallet rank', value: `#${formatNumber(rank ?? 0)}`, inline: true },
        { name: '🏅 Personal rank', value: `${personal.label}`, inline: true },
        { name: 'Wallet cap', value: formatCoins(account.walletCap, account.currency), inline: true },
        { name: 'Bank cap', value: formatCoins(account.bankCap, account.currency), inline: true },
        { name: 'Total', value: formatCoins(account.total, account.currency), inline: true },
        {
          name: 'Recent activity',
          value:
            truncate(
              history
                .map((row) => `${formatSigned(row.amount, account.currency)} · ${row.kind} · ${relativeTimestamp(row.created_at, 'R')}`)
                .join('\n'),
              1024,
            ) || 'No transactions yet.',
        },
      ],
      description: 'Cash in your wallet is lost on death. Bank balances are protected.',
      footer: 'Bank storage survives wipes unless /shop-mint burns it',
    });

    const controls = [
      row(
        button({ id: customId('eco', 'deposit'), label: 'Deposit', emoji: '🏦', style: ButtonStyle.Primary }),
        button({ id: customId('eco', 'withdraw'), label: 'Withdraw', emoji: '👛' }),
        button({ id: customId('eco', 'send'), label: 'Send coins', emoji: '✉️' }),
      ),
      row(button({ id: customId('eco', 'daily'), label: 'Daily bonus', emoji: '🎁', style: ButtonStyle.Success })),
      navRow({ backPanel: 'coins' }),
    ];

    return { embeds: [embed], components: controls, files: [iconAttachment(personal.icon)] };
  },
};
