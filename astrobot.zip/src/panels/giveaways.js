import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { listGiveaways } from '../db/repositories/onboarding.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { relativeTimestamp, truncate } from '../utils/format.js';

/** Giveaway manager. */
export default {
  id: 'giveaways',
  async render({ ctx, params = {} }) {
    const settings = getGuildSettings(ctx.guildId);
    const config = settings.onboarding?.giveaways ?? {};
    const giveaways = listGiveaways(ctx.guildId, 20);
    const active = giveaways.filter((entry) => entry.status === 'active');
    const selected = giveaways.find((entry) => entry.id === params.selected) ?? active[0] ?? null;

    const embed = buildEmbed({
      title: '🎁 Giveaways',
      color: COLORS.gold,
      description:
        params.notice ??
        (config.enabled
          ? `Create a giveaway with a prize and automatic winner draw. Entries are collected with a button. Default channel: ${config.channelId ? `<#${config.channelId}>` : 'this channel'}.`
          : 'Giveaways are disabled in `/config` → **Onboarding Roles & Events**.'),
      fields: [
        {
          name: `Active (${active.length})`,
          value:
            truncate(
              active
                .map((entry) => `**${entry.prize}** · ends ${relativeTimestamp(entry.ends_at, 'R')} · ${entry.winners} winner(s)`)
                .join('\n'),
              1024,
            ) || 'No active giveaways.',
        },
        {
          name: 'Recent',
          value:
            truncate(
              giveaways
                .filter((entry) => entry.status !== 'active')
                .slice(0, 8)
                .map((entry) => `**${entry.prize}** · ${entry.status}`)
                .join('\n'),
              1024,
            ) || 'No completed giveaways.',
        },
      ],
      footer: `Default duration: ${config.defaultHours ?? 24}h · default winners: ${config.defaultWinners ?? 1}`,
    });

    const controls = [];
    if (active.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('giveaway', 'select'),
            placeholder: 'Select an active giveaway',
            options: active.slice(0, 25).map((entry) => ({
              label: truncate(entry.prize, 100),
              value: entry.id,
              description: `Ends ${new Date(Number(entry.ends_at)).toLocaleString('en-US')}`,
              default: entry.id === selected?.id,
            })),
          }),
        ),
      );
    }
    controls.push(
      row(
        button({
          id: customId('giveaway', 'create'),
          label: 'Create giveaway',
          emoji: '➕',
          style: ButtonStyle.Success,
          disabled: !config.enabled,
        }),
        button({
          id: customId('giveaway', 'end', selected?.id ?? 'none'),
          label: 'End selected',
          emoji: '🏁',
          style: ButtonStyle.Danger,
          disabled: !selected,
        }),
        button({ id: customId('giveaway', 'refresh'), label: 'Refresh', emoji: '🔄' }),
        button({ id: customId('cfg', 'section', 'config', 'onboarding-roles'), label: 'Winner settings', emoji: '📣' }),
      ),
      navRow({ backPanel: 'giveaways' }),
    );

    return { embeds: [embed], components: controls };
  },
};
