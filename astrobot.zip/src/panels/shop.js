import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { getLink } from '../db/repositories/links.js';
import { balances } from '../services/economy-service.js';
import { applyRestock, groupByCategory, isSoldOut, restockAt, stockLabel } from '../services/shop-stock.js';
import { countPurchasesSince } from '../db/repositories/shop.js';
import { COLORS, EMOJI } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { formatCoins, inlineCode, truncate } from '../utils/format.js';

/** /shop panel. Products are managed in /shop-panel and stored in settings.shop. */
export default {
  id: 'shop',
  async render({ ctx, params }) {
    const settings = getGuildSettings(ctx.guildId);
    const account = balances(ctx.guildId, ctx.userId);
    const products = applyRestock(ctx.guildId, settings.shop.products ?? []);
    const groups = groupByCategory(products);
    const activeGroup = groups.find((group) => group.category === params.category) ?? groups[0] ?? null;
    const activeProducts = activeGroup ? activeGroup.entries.map((entry) => entry.product) : [];
    const searchQuery = String(params.query ?? '').trim();
    const searchResults = searchQuery
      ? products.filter((product) =>
          [product.name, product.shortname, product.category, product.id]
            .filter(Boolean)
            .some((value) => String(value).toLowerCase().includes(searchQuery.toLowerCase())),
        )
      : [];
    const displayedProducts = searchQuery ? searchResults : activeProducts;
    const displayLabel = searchQuery ? `Search results · ${searchQuery}` : activeGroup?.category ?? 'Products';
    const selected = products.find((entry) => String(entry.id) === String(params.selected)) ?? null;

    const selectedSoldOut = selected ? isSoldOut(selected) : false;
    const requiredRoleId = selected?.requiredRoleId ?? null;
    const hasRequiredRole = requiredRoleId
      ? Boolean((await ctx.guild?.members?.fetch?.(ctx.userId).catch(() => null))?.roles?.cache?.has?.(requiredRoleId))
      : true;
    const link = selected?.shortname ? getLink(ctx.guildId, ctx.userId) : null;

    const fields = [];

    if (searchQuery) {
      fields.push({
        name: `Search · ${searchResults.length} match${searchResults.length === 1 ? '' : 'es'}`,
        value: searchResults.length
          ? truncate(
              searchResults
                .slice(0, 12)
                .map((product) => `${product.name ?? product.id} · ${formatCoins(product.price ?? 0)}`)
                .join('\n'),
              1024,
            )
          : `No products match **${searchQuery}**. Try a shorter name, shortname or category.`,
      });
    } else if (activeGroup) {
      fields.push({
        name: `Categories · ${groups.length}`,
        value: truncate(groups.map((group) => `${group.category} · ${group.entries.length}`).join(' · '), 1024),
      });
      // Never dump the catalogue into the embed: a quick setup can list
      // hundreds of items and would flood the panel. The menu below is the
      // browser; the embed stays a compact summary.
      const prices = activeGroup.entries.map(({ product }) => Number(product.price) || 0);
      const soldOut = activeGroup.entries.filter(({ product }) => isSoldOut(product)).length;
      fields.push({
        name: `${activeGroup.category} · ${activeGroup.entries.length} items`,
        value: truncate(
          [
            `Prices ${formatCoins(Math.min(...prices))}–${formatCoins(Math.max(...prices))}`,
            soldOut > 0 ? `${soldOut} sold out` : 'All in stock',
            'Pick an item from the menu below to see its price, stock and image.',
          ].join(' · '),
          1024,
        ),
      });
    } else {
      fields.push({ name: 'Products', value: '—' });
    }

    if (selected) {
      fields.push({
        name: 'Selected item',
        value: truncate(
          `${selected.name ?? selected.id} · ${formatCoins(selected.price ?? 0)}${
            selected.stock === null || selected.stock === undefined ? '' : ` · ${stockLabel(selected)}`
          }`,
          1024,
        ),
        inline: true,
      });
    }

    if (selected?.shortname) {
      const delivery = selectedSoldOut
        ? 'Sold out — restock it from `/shop-panel`.'
        : link?.gamertag
          ? `Sends ${inlineCode(selected.shortname)} x${selected.quantity ?? 1} to **${link.gamertag}** in game.`
          : 'No gamertag linked yet — run `/link` before buying this item.';

      fields.push({ name: 'Delivery', value: delivery });
    }

    if (selected) {
      const nextRestockAt = restockAt(selected);
      const limit = Number(selected.limitPerMember) || 0;
      const windowHours = Math.max(1, Number(selected.limitWindowHours) || 24);
      const used = limit
        ? countPurchasesSince(ctx.guildId, ctx.userId, selected.id, Date.now() - windowHours * 3_600_000)
        : 0;

      fields.push({
        name: 'Restock',
        // A Discord relative timestamp ticks down client-side, so the panel is
        // live without the bot editing it on a timer.
        value:
          nextRestockAt === null
            ? 'Manual only'
            : `+${selected.restockAmount} <t:${Math.floor(nextRestockAt / 1000)}:R>`,

        inline: true,
      });
      if (limit) {
        fields.push({
          name: 'Your allowance',
          value: `${Math.max(0, limit - used)} of ${limit} left · ${windowHours}h window`,
          inline: true,
        });
      }
    }

    if (requiredRoleId) {
      fields.push({
        name: 'Requirement',
        value: hasRequiredRole ? `Requires <@&${requiredRoleId}> — you have it.` : `Requires <@&${requiredRoleId}> — you do not have it.`,
        inline: true,
      });
    }

    fields.push(
      { name: 'Your wallet', value: formatCoins(account.wallet, account.currency), inline: true },
      { name: 'Your bank', value: formatCoins(account.bank, account.currency), inline: true },
    );

    const embed = buildEmbed({
      title: `${EMOJI.shop} ${ctx.guild?.name ?? 'Server'} Shop`,
      color: COLORS.gold,
      thumbnail: selected?.image ?? displayedProducts[0]?.image ?? products[0]?.image ?? null,
      description:
        products.length === 0
          ? 'No products are configured yet. Admins can add Rust items from `/shop-panel`.'
          : params.notice ??
            (searchQuery
              ? `Search results for **${searchQuery}**. Pick an item to see its image, price and stock.`
              : 'Browse by category or search the catalog, then pick a product. Item purchases arrive in game through RCON on your linked gamertag.'),
      fields,
      footer: settings.shop.enabled ? 'Shop enabled' : 'Shop currently disabled',
    });

    const controls = [];

    if (groups.length > 1) {
      controls.push(
        row(
          stringSelect({
            id: customId('shop', 'cat'),
            placeholder: 'Browse a category',
            options: groups.slice(0, 25).map((group) => ({
              label: truncate(group.category, 100),
              value: group.category,
              description: `${group.entries.length} product${group.entries.length === 1 ? '' : 's'}`,
              default: group.category === activeGroup.category,
            })),
          }),
        ),
      );
    }

    if (displayedProducts.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('shop', 'select', searchQuery ? 'search' : activeGroup.category),
            placeholder: `Choose a product from ${displayLabel}`,
            options: displayedProducts.slice(0, 25).map((product) => ({
              label: truncate(product.name ?? product.id, 100),
              value: String(product.id),
              description: truncate(optionDescription(product), 100),
            })),
          }),
        ),
      );
    }

    controls.push(
      row(
        button({
          id: customId('shop', 'search'),
          label: searchQuery ? 'Search again' : 'Search catalog',
          emoji: '🔎',
        }),
        button({
          id: customId('shop', 'buy', params.selected ?? 'none'),
          label: params.selected
            ? `Buy ${products.find((entry) => String(entry.id) === params.selected)?.name ?? 'selected'}`
            : 'Select a product first',
          emoji: '🛒',
          style: ButtonStyle.Success,
          disabled: !settings.shop.enabled || !params.selected || selectedSoldOut || !hasRequiredRole,
        }),
      ),
    );

    controls.push(navRow({ backPanel: 'shop' }));
    return { embeds: [embed], components: controls };
  },
};

function describeProduct(product) {
  const quantity = product.shortname ? ` · x${product.quantity ?? 1}` : '';
  const kit = product.kit ? ` · kit ${inlineCode(product.kit)}` : '';
  const limited = product.stock === null || product.stock === undefined ? '' : ` · ${stockLabel(product)}`;
  const soldOut = isSoldOut(product) ? ' · **SOLD OUT**' : '';
  return `**${product.name ?? product.id}** · ${formatCoins(product.price ?? 0)}${quantity}${kit}${limited}${soldOut}`;
}

function optionDescription(product) {
  const base = product.shortname
    ? `${product.shortname} · x${product.quantity ?? 1} · ${product.price ?? 0}`
    : `${product.price ?? 0} coins`;
  return isSoldOut(product) ? `${base} · sold out` : base;
}
