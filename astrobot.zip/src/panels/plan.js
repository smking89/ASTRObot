import { ButtonStyle } from 'discord.js';
import { getGuild, getGuildSettings } from '../db/repositories/guilds.js';
import { EXTRA_SERVER_PRICING, PLAN_CATALOG, normalizePlanId } from '../config/plans.js';
import { guildPlan, seatSummary } from '../services/plan-service.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, linkButton, navRow, row, stringSelect } from '../ui/components.js';
import { relativeTimestamp } from '../utils/format.js';

/** Self-serve subscription seats for the server owner. */
export default {
  id: 'plan',
  async render({ ctx, params = {} }) {
    const settings = getGuildSettings(ctx.guildId);
    const config = settings.checkout ?? {};
    const guild = getGuild(ctx.guildId);
    const summary = seatSummary(ctx.userId);
    const current = guildPlan(ctx.guildId);
    const isOwner = ctx.guild?.ownerId === ctx.userId;
    const attachedToYou = guild?.plan_owner_id === ctx.userId && current.id !== 'basic';
    const canManage = isOwner || attachedToYou;
    const others = summary.seats.filter((seat) => String(seat.id) !== String(ctx.guildId));

    const membershipLine = summary.active
      ? `✅ **${summary.label}**${summary.lifetime ? ' · lifetime' : summary.expiresAt ? ` · ends ${relativeTimestamp(summary.expiresAt, 'R')}` : ''}`
      : 'No active membership. Start the 14-day Pro trial or buy Pro/Max from `/checkout`.';
    const seatLine = summary.active
      ? `**${summary.used}/${summary.seatLimit}** in use${summary.used < summary.seatLimit ? ` · ${summary.seatLimit - summary.used} available` : ' · all seats used'}`
      : 'No seats until a Pro or Max membership is active.';
    const attachedLine = summary.seats.length
      ? summary.seats
          .map((seat) => {
            const label = PLAN_CATALOG[normalizePlanId(seat.plan)]?.label ?? seat.plan;
            const here = String(seat.id) === String(ctx.guildId) ? ' · this server' : '';
            return `• **${seat.name || 'Unnamed server'}** (\`${seat.id}\`) · ${label}${here}`;
          })
          .join('\n')
      : 'No servers attached yet.';
    const currentLine = `**${current.label}**${current.trial ? ' trial' : ''}${attachedToYou ? ' · using one of your seats' : ''}`;

    const description =
      params.notice ??
      (params.transferPicker && others.length === 0
        ? 'No other server is attached to your subscription. Use a seat here first, then `/transfer` can move it.'
        : summary.active
          ? `Manage your **${summary.label}** membership and its Discord-server seats. Run \`/plan\` in each server you own.`
          : 'Pro and Max memberships carry Discord-server seats. Attach a server here, or move an existing seat with `/transfer`.');

    const fields = [
      { name: 'Your membership', value: membershipLine, inline: false },
      { name: 'Server seats', value: seatLine, inline: true },
      { name: 'This server', value: currentLine, inline: true },
      { name: 'Attached servers', value: attachedLine, inline: false },
      {
        name: 'Extra Discord servers',
        value: `**${EXTRA_SERVER_PRICING.label}** per additional server, on Pro or Max. Buy an extra seat, then attach it here.`,
        inline: false,
      },
      {
        name: 'How seats work',
        value:
          'The server owner runs `/plan` to attach a server to their own subscription. `/transfer` moves the subscription from one of your servers to this one without changing the plan or expiry.',
        inline: false,
      },
    ];

    if (!isOwner) {
      fields.push({
        name: 'Owner only',
        value: 'Only the server owner can attach or move a subscription to this server. The billing owner can still release a seat.',
        inline: false,
      });
    }

    const embed = buildEmbed({
      title: '💳 Your Astro subscription',
      color: summary.active ? COLORS.success : COLORS.gold,
      description,
      fields,
      footer: summary.active
        ? `AstroBot · ${summary.label} · ${summary.used}/${summary.seatLimit} server seats`
        : 'AstroBot · no active membership',
    });

    const rows = [];
    if (params.transferPicker && others.length > 0) {
      rows.push(
        row(
          stringSelect({
            id: customId('plan', 'transfer-select'),
            placeholder: 'Choose the server to move the subscription from',
            options: others.map((seat) => ({
              label: seat.name || `Server ${seat.id}`,
              value: String(seat.id),
              description: `Move ${PLAN_CATALOG[normalizePlanId(seat.plan)]?.label ?? seat.plan} here`,
            })),
          }),
        ),
      );
    } else {
      const actions = [];
      if (canManage && summary.active) {
        if (attachedToYou) {
          actions.push(
            button({
              id: customId('plan', 'detach'),
              label: 'Release this server',
              emoji: '🔓',
              style: ButtonStyle.Danger,
            }),
          );
        } else if (summary.used < summary.seatLimit) {
          actions.push(
            button({
              id: customId('plan', 'attach'),
              label: 'Use a seat here',
              emoji: '➕',
              style: ButtonStyle.Success,
            }),
          );
        } else {
          actions.push(button({ id: customId('plan', 'full'), label: 'All seats used', emoji: '🚫', disabled: true }));
        }

        const movable = attachedToYou ? others.length : summary.used;
        if (movable > 0) {
          actions.push(button({ id: customId('plan', 'transfer'), label: 'Move a seat here', emoji: '🔀' }));
        }
      }
      if (actions.length > 0) rows.push(row(...actions));
    }

    const addOns = [];
    if (config.seatMonthlyUrl) {
      addOns.push(linkButton({ label: `Extra server · ${EXTRA_SERVER_PRICING.monthlyLabel}`, url: config.seatMonthlyUrl, emoji: '➕' }));
    }
    if (config.seatYearlyUrl) {
      addOns.push(linkButton({ label: `Extra server · ${EXTRA_SERVER_PRICING.yearlyLabel}`, url: config.seatYearlyUrl, emoji: '📅' }));
    }
    if (addOns.length > 0) rows.push(row(...addOns));

    rows.push(navRow({ backPanel: 'hub', refreshArgs: ['plan'] }));

    return { embeds: [embed], components: rows };
  },
};
