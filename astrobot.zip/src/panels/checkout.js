import { getGuildSettings } from '../db/repositories/guilds.js';
import { getMembership, isActive } from '../db/repositories/memberships.js';
import { guildPlan, trialForGuild } from '../services/plan-service.js';
import { EXTRA_SERVER_PRICING, PLAN_CATALOG } from '../config/plans.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, linkButton, navRow, row } from '../ui/components.js';
import { ButtonStyle } from 'discord.js';
import { relativeTimestamp } from '../utils/format.js';

/** Plan checkout: Basic is free, Pro and Max are monthly or yearly. */
export default {
  id: 'checkout',
  async render({ ctx, params = {} }) {
    const settings = getGuildSettings(ctx.guildId);
    const config = settings.checkout ?? {};
    const membership = getMembership(ctx.userId);
    const memberActive = isActive(ctx.userId);
    const plan = guildPlan(ctx.guildId);
    const trial = trialForGuild(ctx.guildId);

    const open = config.enabled !== false;
    const purchaseButtons = [];
    if (open) {
      const proMonthly = config.proMonthlyUrl || config.proUrl;
      if (proMonthly) purchaseButtons.push(linkButton({ label: 'Pro monthly · $12', url: proMonthly, emoji: '⭐' }));
      if (config.proYearlyUrl) purchaseButtons.push(linkButton({ label: 'Pro yearly · $120', url: config.proYearlyUrl, emoji: '📅' }));
      if (config.maxMonthlyUrl) purchaseButtons.push(linkButton({ label: 'Max monthly · $29', url: config.maxMonthlyUrl, emoji: '🚀' }));
      if (config.maxYearlyUrl) purchaseButtons.push(linkButton({ label: 'Max yearly · $290', url: config.maxYearlyUrl, emoji: '🗓️' }));
      if (config.seatMonthlyUrl) {
        purchaseButtons.push(linkButton({ label: `Extra server · ${EXTRA_SERVER_PRICING.monthlyLabel}`, url: config.seatMonthlyUrl, emoji: '➕' }));
      }
      if (config.seatYearlyUrl) {
        purchaseButtons.push(linkButton({ label: `Extra server · ${EXTRA_SERVER_PRICING.yearlyLabel}`, url: config.seatYearlyUrl, emoji: '📅' }));
      }
      if (config.portalUrl) purchaseButtons.push(linkButton({ label: 'Giveaway portal', url: config.portalUrl, emoji: '🎁' }));
      if (config.supportUrl) purchaseButtons.push(linkButton({ label: 'Support', url: config.supportUrl, emoji: '🎫' }));
    }

    const planStatus = plan.trial && plan.expiresAt
      ? `🎁 **Pro trial** active · ends ${relativeTimestamp(plan.expiresAt, 'R')}`
      : plan.id === 'basic'
        ? '**Basic** · free forever'
        : `✅ **${plan.label}** active${plan.expiresAt ? ` · renews ${relativeTimestamp(plan.expiresAt, 'R')}` : ' · no expiry'}`;

    const fields = [
      { name: 'This server', value: planStatus, inline: false },
      { name: 'Your membership', value: memberActive ? `✅ **${String(membership?.tier ?? 'pro').toUpperCase()}**` : 'No personal membership. Server plans do not require one.', inline: true },
      { name: 'Support', value: 'Identical on every plan. No paid priority or faster-response tier.', inline: true },
      {
        name: `Basic · ${PLAN_CATALOG.basic.priceLabels.monthly}`,
        value: '1 Discord server · 1 Rust/RCON server · core bot and games · 1 giveaway · 14-day analytics · 3 tasks · 1 template',
        inline: false,
      },
      {
        name: `Pro · ${PLAN_CATALOG.pro.priceLabels.monthly} or ${PLAN_CATALOG.pro.priceLabels.yearly}`,
        value: '1 Discord server · 3 Rust/RCON servers · full games + jackpot/raffle · full telemetry · 5 giveaways · 1 branded hosted page (5k entrants) · 90-day analytics + CSV · 25 tasks',
        inline: false,
      },
      {
        name: `Max · ${PLAN_CATALOG.max.priceLabels.monthly} or ${PLAN_CATALOG.max.priceLabels.yearly}`,
        value: '5 Discord servers · 10 Rust/RCON servers · network events and telemetry · 15 giveaways · 5 hosted pages (25k entrants) · white-label · 365-day analytics · 100 tasks · custom templates',
        inline: false,
      },
      {
        name: 'Extra Discord servers',
        value: `**${EXTRA_SERVER_PRICING.label}** per additional server on Pro or Max. Buy the add-on, then run \`/plan\` in each server you own to attach or move a seat.`,
        inline: false,
      },
      {
        name: 'Annual billing',
        value: 'Yearly plans include two months free. A 14-day Pro trial is available once per guild.',
        inline: false,
      },
      {
        name: 'Delivery',
        value: 'Purchases are verified by the signed Tip4Serv webhook and applied to this guild automatically.',
        inline: false,
      },
    ];

    const embed = buildEmbed({
      title: '💳 Plans & checkout',
      color: plan.id === 'basic' ? COLORS.gold : COLORS.success,
      description:
        params.notice ??
        (open
          ? config.note ||
            'Basic is free forever. Pro adds 3 Rust servers, the full game suite, branded hosted giveaways and 90-day analytics. Max adds 5 Discord servers, 10 Rust servers, network telemetry and 365-day analytics. Extra Discord servers are $6/month or $60/year. Manage seats with /plan. Support is the same on every plan.'
          : 'Checkout is closed right now. Ask a server administrator for access.'),
      fields,
      footer: plan.expiresAt
        ? `AstroBot · ${plan.label} · ${plan.trial ? 'trial' : 'plan'} ends ${new Date(plan.expiresAt).toUTCString()}`
        : `AstroBot · ${plan.label} plan`,
    });

    const rows = [];
    if (purchaseButtons.length > 0) rows.push(row(...purchaseButtons.slice(0, 5)));
    if (purchaseButtons.length > 5) rows.push(row(...purchaseButtons.slice(5)));

    const trialAvailable = !trial && plan.id === 'basic' && open;
    if (trialAvailable) {
      rows.push(
        row(
          button({
            id: customId('checkout', 'trial'),
            label: 'Start 14-day Pro trial',
            emoji: '🎁',
            style: ButtonStyle.Success,
          }),
        ),
      );
    }

    rows.push(navRow({ backPanel: 'hub', refreshArgs: ['checkout'] }));

    return { embeds: [embed], components: rows };
  },
};
