import { HUB_ASTRO_DESTINATIONS } from '../config/panel-hub.js';
import { hubView } from '../ui/hub-view.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';

/** Astro staff hub for the official guild. */
export default {
  id: 'astro-hub',
  async render({ ctx, params = {} }) {
    if (!ctx.grants?.has?.('official') && !ctx.grants?.has?.('admin')) {
      return {
        embeds: [
          buildEmbed({
            title: '🛰️ Astro Staff Panel',
            color: COLORS.warning,
            description: 'This hub is only available to Astro staff in the official guild.',
            footer: 'AstroBot panel · Astro staff',
          }),
        ],
        components: [],
      };
    }

    return hubView({
      id: 'astro-hub',
      title: '🛰️ Astro Staff Panel',
      description:
        params.notice ??
        'Astro platform staff tools: licenses, fleet status, platform analytics, campaign giveaways, polls and official announcements.',
      destinations: HUB_ASTRO_DESTINATIONS,
      highlights: 'Licenses · fleet status · platform analytics · marketplace · campaigns · polls · announcements · templates',
      footer: 'AstroBot panel · Astro staff',
      color: COLORS.info,
      buttons: [
        { panel: 'license', label: 'Licenses', emoji: '🔑' },
        { panel: 'status', label: 'Status', emoji: '📡' },
        { panel: 'analytics', label: 'Analytics', emoji: '📊' },
        { panel: 'announcements', label: 'Announcements', emoji: '📣' },
      ],
    });
  },
};
