import { ButtonStyle } from 'discord.js';
import { getPresetTemplate } from '../config/server-templates.js';
import { getTemplate } from '../db/repositories/templates.js';
import { filterTemplateParts, planGuildTemplate, TEMPLATE_SECTIONS, decodeTemplateSections, encodeTemplateSections } from '../services/template-service.js';
import { planTemplatePanels } from '../services/panel-deploy.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { truncate } from '../utils/format.js';

/**
 * Confirmation page for a template apply.
 *
 * Applying a template replaces the layout: the confirm button is the only way
 * to run it, and it wipes channels, categories and roles first. Admins choose
 * which sections the layout should add before confirming.
 */
export default {
  id: 'template-preview',
  async render({ ctx, params }) {
    const selected = params.selected;
    const preset = selected ? getPresetTemplate(selected) : null;
    const template = preset ?? (selected ? getTemplate(ctx.guildId, selected) : null);
    if (!template) {
      return {
        embeds: [
          buildEmbed({
            title: '👁️ Template preview',
            color: COLORS.brand,
            description: selected
              ? 'That template no longer exists. Pick another layout from the templates panel.'
              : 'Pick a built-in layout or saved template first, then press **Preview selected**.',
            footer: 'Preview only · nothing has been created yet',
          }),
        ],
        components: [navRow({ backPanel: 'templates' })],
      };
    }

    const sections = params.sections ? decodeTemplateSections(params.sections) : TEMPLATE_SECTIONS.map((entry) => entry.id);
    const payload = filterTemplateParts(template.payload ?? {}, sections);
    const plan = planGuildTemplate(ctx.guild, payload);
    const panels = planTemplatePanels(payload);
    const kits = payload.kits ?? [];

    const groups = new Map();
    for (const channel of plan.channels) {
      const parent = channel.parentName ?? 'No category';
      groups.set(parent, [...(groups.get(parent) ?? []), channel.name]);
    }

    const sectionText = TEMPLATE_SECTIONS.map(
      (entry) => `${sections.includes(entry.id) ? '✅' : '⬜'} **${entry.label}** — ${entry.description}`,
    ).join('\n');

    const roles = plan.roles.map((entry) => entry.name).join(', ') || 'None';
    const categoryNames = plan.categories.map((entry) => entry.name).join(' · ') || 'None';
    const channelText =
      [...groups].map(([parent, names]) => `**${parent}**: ${names.join(', ')}`).join('\n') || 'None';
    const panelText = panels.map((entry) => `**${entry.type}** → ${entry.channelName}`).join('\n') || 'No panels selected';

    const embed = buildEmbed({
      title: `⚠️ Confirm · ${truncate(template.name, 180)}`,
      color: COLORS.danger ?? COLORS.brand,
      description:
        'Press **Confirm & replace server** to rebuild this server from the layout. This **deletes every channel, category and role** the bot can remove first, then creates the sections ticked below. @everyone, bot/integration roles and roles above AstroBot are kept. Every member’s roles are backed up first and restored automatically after the rebuild.',
      fields: [
        {
          name: 'Will delete first',
          value: 'All channels and categories · every role below AstroBot (managed roles are kept)',
        },
        {
          name: 'Will create',
          value: `${plan.roles.length} role(s) · ${plan.categories.length} category(s) · ${plan.channels.length} channel(s) · ${panels.length} panel(s) · ${kits.length} kit(s)`,
        },
        { name: 'Choose sections', value: truncate(sectionText, 1024) },
        { name: `Roles · ${plan.roles.length}`, value: truncate(roles, 1024) },
        { name: `Categories · ${plan.categories.length}`, value: truncate(categoryNames, 1024) },
        { name: `Channels · ${plan.channels.length}`, value: truncate(channelText, 1024) },
        { name: 'Panels', value: truncate(panelText, 1024) },
        {
          name: 'Kits',
          value: kits.length ? truncate(kits.map((kit) => `**${kit.name}** · ${Number(kit.price).toLocaleString()} coins`).join('\n'), 1024) : 'None',
        },
      ],
      footer: 'Nothing happens until you confirm · this replaces the current layout',
    });

    const encoded = encodeTemplateSections(sections);

    return {
      embeds: [embed],
      components: [
        row(
          stringSelect({
            id: customId('templates', 'parts', selected),
            placeholder: 'Choose which sections this layout adds',
            min: 1,
            max: TEMPLATE_SECTIONS.length,
            options: TEMPLATE_SECTIONS.map((entry) => ({
              label: entry.label,
              value: entry.id,
              description: entry.description,
              default: sections.includes(entry.id),
            })),
          }),
        ),
        row(
          button({
            id: customId('templates', 'confirm', selected, encoded),
            label: 'Confirm & replace server',
            emoji: '⚠️',
            style: ButtonStyle.Danger,
          }),
          button({ id: customId('templates', 'open'), label: 'Cancel', emoji: '✖️' }),
        ),
        navRow({ backPanel: 'templates', showClose: false }),
      ],
    };
  },
};
