import { AttachmentBuilder, ButtonStyle } from 'discord.js';
import { basename } from 'node:path';
import { CARD_BACKS } from '../services/games/cards.js';
import { cardBackPath } from '../services/blackjack-image.js';
import { getPref } from '../db/repositories/prefs.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row } from '../ui/components.js';

const BACK_LABELS = Object.freeze({
  classic: 'Classic Red',
  astro: 'Astro Blue',
  nebula: 'Nebula Green',
});

/** /card-style panel: pick a real deck back or register custom artwork. */
export default {
  id: 'card-style',
  async render({ ctx, params }) {
    const current = getPref(ctx.guildId, ctx.userId, 'cardBack', 'classic');
    const customUrl = getPref(ctx.guildId, ctx.userId, 'cardBackUrl', null);
    const deckKey = BACK_LABELS[current] ? current : 'classic';
    const backFile = cardBackPath(deckKey);
    const usingCustom = current === 'custom' && Boolean(customUrl);
    const image = usingCustom ? customUrl : `attachment://${basename(backFile)}`;
    const files = usingCustom ? [] : [new AttachmentBuilder(backFile, { name: basename(backFile) })];

    const embed = buildEmbed({
      title: '🖼️ Card Style',
      color: COLORS.brand,
      description:
        params.notice ??
        'Pick the card back used by Blackjack and UNO. Each deck ships with its own matching table artwork, and your choice is saved per server.',
      fields: [
        { name: 'Current deck', value: `\`${usingCustom ? 'custom' : BACK_LABELS[deckKey]}\``, inline: true },
        { name: 'Custom artwork', value: customUrl ? `[uploaded asset](${customUrl})` : 'Not set', inline: true },
        {
          name: 'Decks',
          value: Object.entries(BACK_LABELS)
            .map(([key, label]) => `${CARD_BACKS[key]} \`${label}\``)
            .join(' · '),
        },
      ],
      image,
      footer: 'Custom artwork must be a direct image URL',
    });

    const controls = [
      row(
        ...Object.entries(BACK_LABELS).map(([key, label]) =>
          button({
            id: customId('card', 'set', key),
            label,
            emoji: CARD_BACKS[key],
            style: current === key ? ButtonStyle.Success : ButtonStyle.Secondary,
          }),
        ),
      ),
      row(
        button({ id: customId('card', 'custom'), label: 'Upload custom art', emoji: '☁️' }),
        button({ id: customId('card', 'reset'), label: 'Reset', style: ButtonStyle.Danger }),
      ),
      navRow({ backPanel: 'card-style' }),
    ];

    return { embeds: [embed], components: controls, files };
  },
};
