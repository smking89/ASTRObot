import { ButtonStyle, ChannelType } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { listAnnouncements } from '../db/repositories/announcements.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, channelSelect, customId, navRow, row, stringSelect } from '../ui/components.js';
import { MAX_DELIVERY_ATTEMPTS, announcementTimeZone, scheduleLabel } from '../services/announcement-service.js';
import { listDeliveries } from '../db/repositories/announcement-deliveries.js';
import { relativeTimestamp, truncate } from '../utils/format.js';
import { formatTimeZone } from '../utils/timezone.js';
import { timeZoneOptions } from '../config/timezones.js';

/** Admin announcement scheduler: Discord and in-game messages on a clock. */
export default {
  id: 'announcements',
  async render({ ctx, params = {} }) {
    const settings = getGuildSettings(ctx.guildId);
    const config = settings.announcements ?? {};
    const rows = listAnnouncements(ctx.guildId, 25);
    const scheduled = rows.filter((entry) => entry.enabled);
    const selected = rows.find((entry) => entry.id === params.selected) ?? rows[0] ?? null;
    const guildZone = formatTimeZone(config.timezone);
    const selectedZone = selected ? announcementTimeZone(selected) : null;

    const history = selected ? listDeliveries(selected.id, 5) : [];
    const deliveryLine = (delivery) => {
      const when = `<t:${Math.floor(Number(delivery.created_at) / 1000)}:R>`;
      if (delivery.status === 'sent') return `✅ delivered ${when}`;
      if (delivery.status === 'failed') return `❌ gave up after ${delivery.attempts} tries ${when} · ${truncate(delivery.error ?? 'unknown error', 120)}`;
      return `⏳ retry ${delivery.attempts}/${MAX_DELIVERY_ATTEMPTS} ${when} · ${truncate(delivery.error ?? 'waiting', 120)}`;
    };

    const line = (entry) =>
      `**${truncate(entry.name, 60)}** · ${scheduleLabel(entry)} · ${
        entry.next_run_at ? relativeTimestamp(entry.next_run_at, 'R') : 'not scheduled'
      } · ${entry.channel_id ? `<#${entry.channel_id}>` : 'no channel'}${entry.in_game ? ' · 🎮 in game' : ''}`;

    const embed = buildEmbed({
      title: '📣 Announcements',
      color: COLORS.brand,
      description:
        params.notice ??
        `Schedule a message for a calendar date and clock time. Deliver it to Discord, the game console through RCON, or both. Default channel: ${
          config.channelId ? `<#${config.channelId}>` : settings.channels?.broadcasts ? `<#${settings.channels.broadcasts}>` : 'this channel'
        }.`,
      fields: [
        {
          name: `Scheduled (${scheduled.length})`,
          value: truncate(scheduled.slice(0, 8).map(line).join('\n'), 1024) || 'Nothing scheduled yet.',
        },
        {
          name: 'Paused / finished',
          value:
            truncate(
              rows
                .filter((entry) => !entry.enabled)
                .slice(0, 6)
                .map(line)
                .join('\n'),
              1024,
            ) || '—',
        },
        selected
          ? {
              name: `Selected · ${selected.name}`,
              value: truncate(
                `${scheduleLabel(selected)} · ${announcementTimeZone(selected)} · ${selected.in_game ? 'Discord + game' : 'Discord only'}\n> ${selected.message.replace(/\n/g, '\n> ')}`,
                1024,
              ),
            }
          : { name: 'Selected', value: 'Create an announcement to get started.' },
        ...(selected
          ? [
              {
                name: `Delivery history${history.length ? '' : ' · none yet'}`,
                value: truncate(history.map(deliveryLine).join('\n'), 1024) || 'Deliveries appear here after the first run.',
              },
            ]
          : []),
      ],
      footer: `Times use ${config.timezone ?? 'UTC'} · retries back off up to 5 attempts · /announcements`,
    });

    const controls = [];

    if (rows.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('announcements', 'select'),
            placeholder: 'Select an announcement',
            options: rows.slice(0, 25).map((entry) => ({
              label: truncate(entry.name, 100),
              value: entry.id,
              description: `${scheduleLabel(entry)} · ${entry.enabled ? 'active' : 'paused'}`,
              default: entry.id === selected?.id,
            })),
          }),
        ),
      );
    }

    if (selected) {
      controls.push(
        row(
          channelSelect({
            id: customId('announcements', 'channel', selected.id),
            placeholder: `Discord channel for “${truncate(selected.name, 60)}”`,
            channelTypes: [ChannelType.GuildText, ChannelType.GuildAnnouncement],
          }),
        ),
        row(
          stringSelect({
            id: customId('announcements', 'timezone', selected.id),
            placeholder: `Time zone for “${truncate(selected.name, 60)}”`,
            options: timeZoneOptions(guildZone).map((option) => ({
              ...option,
              default:
                option.value === '__guild__' ? selectedZone === guildZone : option.value === selectedZone,
            })),
          }),
        ),
      );
    }

    controls.push(
      row(
        button({ id: customId('announcements', 'create'), label: 'New announcement', emoji: '➕', style: ButtonStyle.Success }),
        button({
          id: customId('announcements', 'toggle', selected?.id ?? 'none'),
          label: selected?.enabled ? 'Pause' : 'Resume',
          emoji: selected?.enabled ? '⏸️' : '▶️',
          disabled: !selected,
        }),
        button({
          id: customId('announcements', 'send', selected?.id ?? 'none'),
          label: 'Send now',
          emoji: '📤',
          style: ButtonStyle.Primary,
          disabled: !selected,
        }),
        button({
          id: customId('announcements', 'remove', selected?.id ?? 'none'),
          label: 'Delete',
          emoji: '🗑️',
          style: ButtonStyle.Danger,
          disabled: !selected,
        }),
      ),
      navRow({ backPanel: 'staff-hub', refreshArgs: ['announcements'] }),
    );

    return { embeds: [embed], components: controls };
  },
};
