import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { listBids } from '../db/repositories/marketplace.js';
import { balances } from '../services/economy-service.js';
import {
  isVipMember,
  listMarketAssets,
  marketCurrency,
  marketPrice,
  listMarketplace,
} from '../services/marketplace-service.js';
import { COLORS, EMOJI } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { formatCoins, relativeTimestamp, truncate } from '../utils/format.js';

const MODE_LABEL = { buy_now: 'Buy now', bid: 'Auction', sale: 'On sale' };

const encodeAsset = (value) => Buffer.from(String(value)).toString('base64url');

/** Player marketplace: browse listings, sell owned assets and bid on auctions. */
export default {
  id: 'market',
  async render({ ctx, params = {} }) {
    const settings = getGuildSettings(ctx.guildId);
    const member = ctx.member ?? (await ctx.guild?.members?.fetch?.(ctx.userId).catch(() => null));
    const currency = marketCurrency(settings);
    const vip = isVipMember(member, settings);
    const listings = listMarketplace(ctx.guildId, { sellerId: params.mine ? ctx.userId : null });
    const assets = listMarketAssets(ctx.guildId, member);
    const account = balances(ctx.guildId, ctx.userId);
    const selectedAsset = assets.find((asset) => asset.key === params.asset) ?? null;
    const selectedListing = listings.find((listing) => listing.id === params.listing) ?? null;
    const bids = selectedListing ? listBids(selectedListing.id) : [];
    const ownSelected = selectedListing?.seller_id === ctx.userId;
    const isAdmin = Boolean(ctx.grants?.has?.('admin') || ctx.grants?.has?.('restricted'));
    const locked = selectedAsset?.lockedUntil ? `<t:${Math.floor(selectedAsset.lockedUntil / 1000)}:R>` : null;

    const listingLines = listings
      .slice(0, 12)
      .map((listing) => {
        const price = marketPrice(listing, member, settings);
        return `**${truncate(listing.asset_label, 60)}** · ${formatCoins(price, currency)} · ${MODE_LABEL[listing.mode] ?? listing.mode} · <@${listing.seller_id}>`;
      })
      .join('\n');

    const fields = [
      {
        name: 'Marketplace',
        value: settings.marketplace.enabled
          ? `${listings.length} active listing${listings.length === 1 ? '' : 's'} · fee **${settings.marketplace.feePercent ?? 0}%** · delivery lock **${settings.marketplace.lockMinutes ?? 0}m**`
          : 'Closed — an administrator can open it from `/config` → **Player Marketplace**.',
        inline: false,
      },
      {
        name: 'Your wallet',
        value: formatCoins(account.wallet, currency),
        inline: true,
      },
      {
        name: 'VIP access',
        value: vip ? `✅ ${marketCurrency(settings, { vip: true })}` : settings.marketplace.vip?.enabled ? '❌ VIP role required' : 'Not configured',
        inline: true,
      },
    ];

    if (listings.length > 0) {
      fields.push({ name: 'Active listings', value: truncate(listingLines, 1024) });
    } else {
      fields.push({ name: 'Active listings', value: 'No listings yet. Pick an asset below and create the first one.' });
    }

    if (selectedListing) {
      const price = marketPrice(selectedListing, member, settings);
      const details = [
        `**${selectedListing.asset_label}**`,
        `${MODE_LABEL[selectedListing.mode] ?? selectedListing.mode} · ${formatCoins(price, currency)}`,
        `Seller <@${selectedListing.seller_id}>`,
        selectedListing.mode === 'bid' && selectedListing.ends_at
          ? `Ends ${relativeTimestamp(selectedListing.ends_at, 'R')} · high bid ${selectedListing.high_bid ? formatCoins(selectedListing.high_bid, currency) : 'none'}`
          : null,
        selectedListing.vip_price ? `VIP price ${formatCoins(selectedListing.vip_price, marketCurrency(settings, { vip: true }))}` : null,
        bids.length ? `${bids.length} bid${bids.length === 1 ? '' : 's'}` : null,
      ].filter(Boolean);
      fields.push({ name: 'Selected listing', value: truncate(details.join('\n'), 1024) });
    }

    if (selectedAsset) {
      fields.push({
        name: 'Selected asset',
        value: `${selectedAsset.label} · ${selectedAsset.quantity > 1 ? `x${selectedAsset.quantity}` : 'single'}${locked ? ` · delivery lock ${locked}` : ''}`,
        inline: true,
      });
    }

    const embed = buildEmbed({
      title: `${EMOJI.shop} ${ctx.guild?.name ?? 'Server'} Marketplace`,
      color: vip ? COLORS.gold : COLORS.brand,
      description:
        params.notice ??
        'Trade items, kits and roles with other players. Team and clan members cannot trade with each other, and purchased kits/roles stay delivery-locked for the configured time.',
      fields,
      footer: 'Sellers set their own prices · fees support the server treasury',
    });

    const controls = [];
    if (listings.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('market', 'select-listing'),
            placeholder: 'Browse a listing',
            options: listings.slice(0, 25).map((listing) => ({
              label: truncate(listing.asset_label, 100),
              value: listing.id,
              description: truncate(`${MODE_LABEL[listing.mode] ?? listing.mode} · ${listing.price} · ${listing.kind}`, 100),
              default: listing.id === selectedListing?.id,
            })),
          }),
        ),
      );
    }

    if (assets.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('market', 'select-asset'),
            placeholder: 'Choose one of your assets to sell',
            options: assets.slice(0, 25).map((asset) => ({
              label: truncate(asset.label, 100),
              value: asset.key,
              description: truncate(`${asset.kind}${asset.quantity > 1 ? ` · x${asset.quantity}` : ''}`, 100),
              default: asset.key === selectedAsset?.key,
            })),
          }),
        ),
      );
    }

    controls.push(
      row(
        button({
          id: customId('market', 'sell', selectedAsset ? encodeAsset(selectedAsset.key) : 'none'),
          label: selectedAsset ? 'Sell selected' : 'Select an asset first',
          emoji: '🏷️',
          style: ButtonStyle.Success,
          disabled: !selectedAsset || !settings.marketplace.enabled,
        }),
        button({
          id: customId('market', 'buy', selectedListing?.id ?? 'none'),
          label: 'Buy now',
          emoji: '🛒',
          style: ButtonStyle.Primary,
          disabled: !selectedListing || ownSelected || selectedListing.mode === 'bid' || !settings.marketplace.enabled,
        }),
        button({
          id: customId('market', 'bid', selectedListing?.id ?? 'none'),
          label: 'Place bid',
          emoji: '🔨',
          disabled: !selectedListing || ownSelected || selectedListing.mode !== 'bid' || !settings.marketplace.enabled,
        }),
        button({
          id: customId('market', 'cancel', selectedListing?.id ?? 'none'),
          label: 'Cancel listing',
          emoji: '🗑️',
          style: ButtonStyle.Danger,
          disabled: !selectedListing || !ownSelected || !settings.marketplace.enabled,
        }),
      ),
      row(
        button({ id: customId('market', params.mine ? 'all' : 'mine'), label: params.mine ? 'Browse all' : 'My listings', emoji: '📋' }),
        button({ id: customId('market', 'refresh'), label: 'Refresh', emoji: '🔄' }),
        isAdmin
          ? button({ id: customId('market', 'admin'), label: 'Market analytics', emoji: '📊' })
          : null,
      ),
      navRow({ backPanel: 'market' }),
    );

    return { embeds: [embed], components: controls.filter((entry) => entry.components.length > 0) };
  },
};
