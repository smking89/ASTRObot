import { ButtonStyle } from 'discord.js';
import { listLicensesFor } from '../db/repositories/licenses.js';
import { licensePlanLabel, licenseServerLimit } from '../services/license-service.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row } from '../ui/components.js';
import { relativeTimestamp, truncate } from '../utils/format.js';

/** /license fallback panel. */
export default {
  id: 'license',
  async render({ ctx }) {
    const licenses = listLicensesFor(ctx.userId);

    const embed = buildEmbed({
      title: '🪪 License Management',
      color: COLORS.brand,
      description:
        licenses.length === 0
          ? 'No licenses are attached to your account. Activate a key to unlock premium server features.'
          : 'Licenses belong to your Discord account. Use `/plan` to attach one to a server you own.',
      fields: [
        {
          name: 'Your licenses',
          value:
            truncate(
              licenses
                .map(
                  (license) =>
                    `\`${license.key}\` · **${licensePlanLabel(license)}** · ${licenseServerLimit(license)} seat${licenseServerLimit(license) === 1 ? '' : 's'} · ${license.status}` +
                    (license.expires_at ? ` · expires ${relativeTimestamp(license.expires_at, 'R')}` : ' · lifetime'),
                )
                .join('\n'),
              1024,
            ) || 'None',
        },
      ],
      footer: 'Licenses follow your account, not a server · /plan attaches seats',
    });

    const controls = [
      row(
        button({ id: customId('lic', 'activate'), label: 'Activate key', emoji: '🔑', style: ButtonStyle.Success }),
        button({ id: customId('lic', 'manage'), label: 'Manage', emoji: '⚙️', disabled: licenses.length === 0 }),
        button({ id: customId('lic', 'transfer'), label: 'Transfer', emoji: '🔁', disabled: licenses.length === 0 }),
      ),
      navRow({ backPanel: 'license' }),
    ];

    return { embeds: [embed], components: controls };
  },
};
