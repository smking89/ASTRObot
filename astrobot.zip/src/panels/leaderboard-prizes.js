import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { LEADERBOARD_METRICS } from '../services/leaderboard-service.js';
import { PRIZE_PERIODS, displayPeriodFor, periodLabel, prizeTable } from '../services/leaderboard-prizes.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { truncate } from '../utils/format.js';

const MEDALS = ['🥇', '🥈', '🥉'];

const describe = (amounts) =>
  amounts.some((amount) => amount > 0)
    ? amounts.map((amount, index) => `${MEDALS[index]} ${amount.toLocaleString('en-US')}`).join(' · ')
    : 'not set';

/** Staff panel: prize chests for 1st, 2nd and 3rd on every board and period. */
export default {
  id: 'leaderboard-prizes',
  async render({ ctx, params = {} }) {
    const settings = getGuildSettings(ctx.guildId);
    const config = settings.leaderboardPrizes ?? {};
    const period = PRIZE_PERIODS.some((entry) => entry.id === params.period) ? params.period : displayPeriodFor(ctx.guildId);
    const metric = LEADERBOARD_METRICS.some((entry) => entry.id === params.metric) ? params.metric : LEADERBOARD_METRICS[0].id;
    const table = prizeTable(ctx.guildId, period, LEADERBOARD_METRICS);
    const selected = table.find((entry) => entry.metric === metric) ?? table[0];
    const shown = displayPeriodFor(ctx.guildId);

    const embed = buildEmbed({
      title: '🏆 Leaderboard prizes',
      color: COLORS.gold,
      description:
        'Set what 1st, 2nd and 3rd place win on each board. Boards show the chest for the period you choose to display.',
      fields: [
        { name: 'Chests on boards', value: config.enabled === false ? '🔴 Hidden' : '🟢 Visible', inline: true },
        { name: 'Boards advertise', value: periodLabel(shown), inline: true },
        { name: 'Editing', value: `${periodLabel(period)} · ${selected.label}\n${describe(selected.amounts)}` },
        {
          name: `${periodLabel(period)} prize table (coins)`,
          value: truncate(table.map((entry) => `**${entry.label}** — ${describe(entry.amounts)}`).join('\n'), 1024),
        },
      ],
      footer: 'Prize amounts are advertised on the picture boards · set them below',
    });

    const controls = [
      row(
        stringSelect({
          id: customId('lbprize', 'period', metric),
          placeholder: 'Prize period',
          options: PRIZE_PERIODS.map((entry) => ({ label: entry.label, value: entry.id, default: entry.id === period })),
        }),
      ),
      row(
        stringSelect({
          id: customId('lbprize', 'metric', period),
          placeholder: 'Which leaderboard?',
          options: LEADERBOARD_METRICS.slice(0, 25).map((entry) => ({
            label: entry.label,
            value: entry.id,
            default: entry.id === metric,
          })),
        }),
      ),
      row(
        button({ id: customId('lbprize', 'edit', period, metric), label: 'Set prizes', emoji: '🎁', style: ButtonStyle.Primary }),
        button({ id: customId('lbprize', 'clear', period, metric), label: 'Clear', emoji: '✖️' }),
        button({
          id: customId('lbprize', 'display', period),
          label: shown === period ? 'Shown on boards' : 'Show this period',
          emoji: '🖼️',
          disabled: shown === period,
        }),
        button({ id: customId('lbprize', 'compwin'), label: 'Competition win', emoji: '🏅' }),
      ),
      navRow({ backPanel: 'staff-hub' }),
    ];

    return { embeds: [embed], components: controls };
  },
};
