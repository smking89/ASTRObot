import { listServers } from '../db/repositories/servers.js';
import { listStatusEvents } from '../db/repositories/status.js';
import { computeUptime } from '../services/status-service.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { navRow, row } from '../ui/components.js';
import { truncate } from '../utils/format.js';

/** Public-facing server status and uptime view built from RCON events. */
export default {
  id: 'status',
  async render({ ctx }) {
    const now = Date.now();
    const servers = listServers(ctx.guildId);
    const events = listStatusEvents(ctx.guildId, now - 7 * 86_400_000);

    const rows = servers.map((server) => {
      const scoped = events.filter((event) => event.server_id === server.id);
      const uptime = computeUptime(scoped, now, 7 * 86_400_000);
      const label = uptime.current === 'online' ? '🟢' : uptime.current === 'offline' ? '🔴' : '⚪';
      return `${label} **${server.label}** · ${uptime.uptimePercent}% uptime · ${uptime.players} online · ${uptime.incidents} incident(s)`;
    });

    const totalOnline = servers.filter((server) => {
      const scoped = events.filter((event) => event.server_id === server.id);
      return computeUptime(scoped, now, 7 * 86_400_000).current === 'online';
    }).length;

    const embed = buildEmbed({
      title: '📡 Server Status & Uptime',
      color: COLORS.info,
      description:
        servers.length > 0
          ? 'Live RCON state with rolling 7-day uptime per server. Incidents count offline transitions.'
          : 'No servers connected yet. Add one with `/server manage`.',
      fields: [
        { name: 'Servers', value: `${servers.length}`, inline: true },
        { name: 'Online now', value: `${totalOnline}`, inline: true },
        { name: 'Window', value: '7 days', inline: true },
        { name: 'Per server', value: truncate(rows.join('\n'), 1024) || '—' },
      ],
      footer: 'Uptime is derived from RCON connect/disconnect events',
    });

    return {
      embeds: [embed],
      components: [row(), navRow({ backPanel: 'server' })],
    };
  },
};
