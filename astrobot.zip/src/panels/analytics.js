import { listSessions } from '../db/repositories/sessions.js';
import { staffCaseStats } from '../db/repositories/moderation.js';
import { peakHour, summarizeSessions } from '../services/analytics-service.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { navRow, row } from '../ui/components.js';
import { truncate } from '../utils/format.js';

/** Retention and activity analytics from RCON sessions. */
export default {
  id: 'analytics',
  async render({ ctx }) {
    const now = Date.now();
    const rows = listSessions(ctx.guildId, now - 28 * 86_400_000);
    const summary = summarizeSessions(rows, now, 28);
    const peak = peakHour(summary.heatmap);
    const staff = staffCaseStats(ctx.guildId, now - 30 * 86_400_000);

    const spark = summary.daily
      .slice(-14)
      .map((entry) => `${entry.day.slice(5)} ${'▁▂▃▄▅▆▇█'[Math.min(7, Math.ceil(entry.sessions / Math.max(1, Math.max(...summary.daily.map((d) => d.sessions))) * 7))]}`)
      .join(' · ');

    const hours = Math.round(summary.averageDurationSeconds / 60);

    const embed = buildEmbed({
      title: '📈 Retention & Activity',
      color: COLORS.brand,
      description:
        rows.length > 0
          ? 'Player sessions recorded from RCON joins and leaves. Use this to spot a falling population before the public count does.'
          : 'No sessions recorded yet. Sessions start filling as RCON join/leave telemetry arrives.',
      fields: [
        { name: 'Players · this week', value: `${summary.currentWeekPlayers}`, inline: true },
        { name: 'Returning', value: `${summary.returningPlayers}`, inline: true },
        { name: 'New', value: `${summary.newPlayers}`, inline: true },
        { name: 'Week-over-week retention', value: `${summary.retentionPercent}%`, inline: true },
        { name: 'Avg session', value: `${hours}m`, inline: true },
        { name: 'Sessions · 28d', value: `${summary.totalSessions}`, inline: true },
        {
          name: 'Peak hour',
          value: peak.sessions ? `${['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][peak.day]} ${String(peak.hour).padStart(2, '0')}:00 UTC · ${peak.sessions} sessions` : 'Not enough data',
        },
        { name: 'Daily sessions · 14d', value: truncate(spark || 'No sessions', 1024) },
        {
          name: 'Staff activity · 30d',
          value: truncate(staff.map((entry) => `<@${entry.moderator_id}> · ${entry.total} case(s)`).join('\n'), 1024) || 'No cases.',
        },
      ],
      footer: 'Retention compares this week with the previous week',
    });

    return {
      embeds: [embed],
      components: [
        row(),
        navRow({ backPanel: 'staff' }),
      ],
    };
  },
};
