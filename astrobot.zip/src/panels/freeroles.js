import { getGuildSettings } from '../db/repositories/guilds.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { customId, navRow, row, stringSelect } from '../ui/components.js';
import { truncate } from '../utils/format.js';

/** Self-assignable roles. */
export default {
  id: 'freeroles',
  async render({ ctx, params = {} }) {
    const settings = getGuildSettings(ctx.guildId);
    const config = settings.onboarding?.freeroles ?? {};
    const member = ctx.member ?? (await ctx.guild?.members?.fetch?.(ctx.userId).catch(() => null));
    const configured = Array.isArray(config.roleIds) ? config.roleIds : [];
    const roles = configured
      .map((id) => ctx.guild?.roles?.cache?.get?.(id))
      .filter(Boolean)
      .slice(0, 25);
    const current = roles.filter((role) => member?.roles?.cache?.has?.(role.id));

    const embed = buildEmbed({
      title: '🎭 Free Roles',
      color: COLORS.brand,
      description:
        params.notice ??
        (config.enabled
          ? `Choose the roles you want. You can hold up to **${config.maxRoles ?? 1}** free role${(config.maxRoles ?? 1) === 1 ? '' : 's'}.`
          : 'Free roles are disabled by an administrator.'),
      fields: [
        {
          name: 'Available roles',
          value: truncate(roles.map((role) => `<@&${role.id}>`).join(' · '), 1024) || 'No roles configured.',
        },
        {
          name: 'Your current free roles',
          value: current.length ? current.map((role) => `<@&${role.id}>`).join(' · ') : 'None',
        },
      ],
      footer: 'Select roles from the menu below; submitting updates your roles',
    });

    const controls = [];
    if (config.enabled && roles.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('freeroles', 'toggle'),
            placeholder: 'Select your free roles',
            min: 0,
            max: Math.min(roles.length, Math.max(1, Number(config.maxRoles) || 1)),
            options: roles.map((role) => ({
              label: truncate(role.name, 100),
              value: role.id,
              description: current.some((entry) => entry.id === role.id) ? 'Currently assigned' : 'Available',
              default: current.some((entry) => entry.id === role.id),
            })),
          }),
        ),
      );
    }
    controls.push(navRow({ backPanel: 'freeroles' }));
    return { embeds: [embed], components: controls };
  },
};
