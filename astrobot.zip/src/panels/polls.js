import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { listPolls, voteCount } from '../db/repositories/polls.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { pollAdminEmbed, pollIsOpen } from '../services/poll-service.js';
import { truncate } from '../utils/format.js';

/** Admin poll manager; basic totals by default, voter profiles on demand. */
export default {
  id: 'polls',
  async render({ ctx, params = {} }) {
    const settings = getGuildSettings(ctx.guildId);
    const config = settings.onboarding?.polls ?? {};
    const polls = listPolls(ctx.guildId, 25);
    const selected = polls.find((entry) => entry.id === params.selected) ?? polls[0] ?? null;
    const advanced = params.view === 'advanced';

    const embed = selected
      ? pollAdminEmbed(selected, { advanced, notice: params.notice })
      : buildEmbed({
          title: '📊 Polls',
          color: COLORS.brand,
          description:
            params.notice ??
            (config.enabled
              ? 'Create a durable button poll with configurable answers and duration. Votes are stored by AstroBot, so the admin panel can show totals and voter profiles.'
              : 'Polls are disabled in `/config` → **Onboarding Roles & Events**.'),
          fields: [
            {
              name: 'Recent polls',
              value:
                truncate(
                  polls
                    .slice(0, 10)
                    .map((entry) => `**${entry.question}** · ${pollIsOpen(entry) ? 'open' : 'closed'} · ${voteCount(entry.id)} vote(s)`)
                    .join('\n'),
                  1024,
                ) || 'No polls yet.',
            },
          ],
          footer: `Default duration: ${config.defaultHours ?? 24}h`,
        });

    const controls = [];
    if (polls.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('polls', 'select'),
            placeholder: 'Select a poll',
            options: polls.slice(0, 25).map((entry) => ({
              label: truncate(entry.question, 100),
              value: entry.id,
              description: `${pollIsOpen(entry) ? 'Open' : 'Closed'} · ${voteCount(entry.id)} vote(s)`,
              default: entry.id === selected?.id,
            })),
          }),
        ),
      );
    }

    controls.push(
      row(
        button({
          id: customId('polls', 'create', ctx.channelId ?? 'none'),
          label: 'Create poll',
          emoji: '➕',
          style: ButtonStyle.Success,
          disabled: !config.enabled,
        }),
        button({
          id: customId('polls', 'view', 'basic', selected?.id ?? 'none'),
          label: 'Basic',
          emoji: '📊',
          disabled: !selected || !advanced,
        }),
        button({
          id: customId('polls', 'view', 'advanced', selected?.id ?? 'none'),
          label: 'Advanced',
          emoji: '🔎',
          style: ButtonStyle.Primary,
          disabled: !selected || advanced,
        }),
        button({
          id: customId('polls', 'end', selected?.id ?? 'none'),
          label: 'End selected',
          emoji: '🏁',
          style: ButtonStyle.Danger,
          disabled: !selected || !pollIsOpen(selected),
        }),
        button({ id: customId('polls', 'refresh', selected?.id ?? 'none'), label: 'Refresh', emoji: '🔄' }),
      ),
    );

    controls.push(navRow({ backPanel: 'onboarding' }));
    return { embeds: [embed], components: controls };
  },
};
