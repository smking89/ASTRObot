import { ButtonStyle } from 'discord.js';
import { getGuildSettings } from '../db/repositories/guilds.js';
import { ensureProgress } from '../db/repositories/battlepass.js';
import { balances } from '../services/economy-service.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, linkButton, navRow, row } from '../ui/components.js';
import { formatNumber, progressBar } from '../utils/format.js';

/** /battle-pass panel: tier progress, claim and the real-money premium track. */
export default {
  id: 'battle-pass',
  async render({ ctx, params }) {
    const settings = getGuildSettings(ctx.guildId);
    const pass = ensureProgress(ctx.guildId, ctx.userId);
    const account = balances(ctx.guildId, ctx.userId);
    const claimed = new Set(JSON.parse(pass.claimed || '[]'));
    const xpPerTier = Number(settings.battlePass.xpPerTier) || 1000;
    const tier = Number(pass.tier);

    const premium = settings.battlePass.premium ?? {};
    const priceLabel = String(premium.priceLabel ?? '').trim();
    const checkoutUrl = String(premium.checkoutUrl ?? '').trim();
    const premiumProductId = String(premium.tip4servProductId ?? '').trim();
    const purchaseConfigured = Boolean(checkoutUrl || premiumProductId);
    const coinPrice = Number(premium.coinPrice) || 0;
    const coinPurchase = Boolean(premium.enableCoinPurchase) && coinPrice > 0;
    const currency = settings.economy.currency;

    const embed = buildEmbed({
      title: '🎖️ Battle Pass',
      color: pass.premium ? COLORS.gold : COLORS.brand,
      description: params.notice ?? `Earn XP in game and through casino play to unlock tiers. ${settings.battlePass.tiers} tiers per season.`,
      fields: [
        { name: 'Tier', value: `${formatNumber(tier)} / ${formatNumber(settings.battlePass.tiers)}`, inline: true },
        { name: 'Track', value: pass.premium ? '⭐ Premium' : 'Free', inline: true },
        { name: 'XP', value: `${formatNumber(pass.xp % xpPerTier)} / ${formatNumber(xpPerTier)}`, inline: true },
        {
          name: 'Premium',
          value: pass.premium ? '⭐ Active' : priceLabel ? `${priceLabel} · real money` : 'Not configured',
          inline: true,
        },
        { name: 'Progress', value: progressBar(pass.xp % xpPerTier, xpPerTier) },
        {
          name: 'Unclaimed tiers',
          value:
            Array.from({ length: Math.min(10, Math.max(0, tier - claimed.size)) }, (_, index) => claimed.size + index + 1)
              .map((value) => `Tier ${value}`)
              .join(', ') || 'Nothing to claim yet.',
        },
      ],
      footer: pass.premium
        ? 'Premium track active — every tier pays its premium reward.'
        : purchaseConfigured
          ? `Premium ${priceLabel || 'sold for real money'} · your wallet ${formatNumber(account.wallet)} ${currency}`
          : 'Premium purchase is not configured yet — staff can add a checkout URL in /config → Battle Pass.',
    });

    // Premium is a real-money product: the panel links straight to the owner's
    // store page (or explains the Tip4Serv product when no link is set).
    const premiumControls = [];
    if (pass.premium) {
      premiumControls.push(button({ id: customId('bp', 'premium'), label: 'Premium active', emoji: '⭐', disabled: true }));
    } else if (checkoutUrl) {
      premiumControls.push(
        linkButton({ label: priceLabel ? `Buy premium · ${priceLabel}` : 'Buy premium', url: checkoutUrl, emoji: '⭐' }),
      );
    } else {
      premiumControls.push(button({ id: customId('bp', 'premium'), label: 'How to buy premium', emoji: '⭐' }));
    }
    if (!pass.premium && coinPurchase) {
      premiumControls.push(
        button({
          id: customId('bp', 'premium-coins'),
          label: `Buy with ${formatNumber(coinPrice)} ${currency}`.slice(0, 80),
          emoji: '🪙',
        }),
      );
    }

    const controls = [
      row(
        button({
          id: customId('bp', 'claim'),
          label: 'Claim unlocked rewards',
          emoji: '🎁',
          style: ButtonStyle.Success,
          disabled: tier <= claimed.size,
        }),
        ...premiumControls,
      ),
      navRow({ backPanel: 'battle-pass' }),
    ];

    return { embeds: [embed], components: controls };
  },
};
