import { ButtonStyle } from 'discord.js';
import { templateDraft, TEMPLATE_CHANNEL_TYPES } from '../services/template-builder.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row, stringSelect } from '../ui/components.js';
import { truncate } from '../utils/format.js';
import { planHasFeature } from '../services/plan-service.js';

/** Owner-facing editor for authoring or revising a template inside Discord. */
export default {
  id: 'template-editor',
  async render({ ctx }) {
    if (!planHasFeature(ctx.guildId, 'customTemplates')) {
      return {
        embeds: [
          buildEmbed({
            title: '🧱 Template editor',
            color: COLORS.gold,
            description:
              'Building a template from scratch is a **Max** feature. Pro includes every built-in and saved template; upgrade to Max to author custom layouts.',
          }),
        ],
        components: [navRow({ backPanel: 'templates' })],
      };
    }

    const draft = templateDraft(ctx.guildId, ctx.userId);

    const roles = draft.roles.length
      ? draft.roles.map((role) => `**${role.name}** · #${Number(role.color).toString(16).padStart(6, '0')} · ${role.permissions}`).join('\n')
      : 'No roles yet.';
    const categories = draft.categories.length
      ? draft.categories
          .map((entry) => `**${entry.name}**${entry.overwrites?.length ? ` (${entry.overwrites.length} overwrites)` : ''}`)
          .join(' · ')
      : 'No categories yet.';
    const channels = draft.channels.length
      ? draft.channels
          .map((channel) => {
            const kind = Object.keys(TEMPLATE_CHANNEL_TYPES).find((key) => TEMPLATE_CHANNEL_TYPES[key] === channel.type) ?? 'text';
            const overwrites = channel.overwrites?.length ? ` · ${channel.overwrites.length} overwrites` : '';
            return `**${channel.name}** · ${kind}${channel.parentName ? ` · **${channel.parentName}**` : ''}${overwrites}`;
          })
          .join('\n')
      : 'No channels yet.';
    const kits = draft.kits?.length
      ? draft.kits
          .map((kit) => `**${kit.name}** · ${Number(kit.price).toLocaleString()} coins · \`${truncate(kit.rconCommand, 80)}\``)
          .join('\n')
      : 'No kits yet.';
    const staffRoles = draft.staffRoles?.length ? draft.staffRoles.map((entry) => `**${entry}**`).join(' · ') : 'No staff roles marked.';
    const target = draft.pendingCategory ? `**${draft.pendingCategory}**` : 'No category';

    const embed = buildEmbed({
      title: draft.editingId ? '🧱 Editing template' : '🧱 Template editor',
      color: COLORS.brand,
      description: draft.editingId
        ? `Revising saved template **${draft.name}**. Saving replaces the stored layout; the server itself is untouched until you apply it.`
        : draft.description ??
          'Build a layout from scratch: add roles, categories and channels, then save it. Nothing is created on the server until you apply the saved template.',
      fields: [
        { name: `Roles · ${draft.roles.length}`, value: truncate(roles, 1024) },
        { name: `Categories · ${draft.categories.length}`, value: truncate(categories, 1024) },
        { name: `Channels · ${draft.channels.length}`, value: truncate(channels, 1024) },
        { name: `Kits · ${draft.kits?.length ?? 0}`, value: truncate(kits, 1024) },
        { name: `Staff roles · ${draft.staffRoles?.length ?? 0}`, value: truncate(staffRoles, 1024) },
        {
          name: '⚠️ Before you apply',
          value:
            'Applying is additive: existing roles, categories and channels are reused, never deleted or renamed. Duplicate names are skipped. Panels are posted once in matching channels.',
        },
      ],
      footer: `New channels go to: ${target} · choose the category from the dropdown`,
    });

    const entries = [
      ...draft.roles.map((role, index) => ({ label: `Role · ${role.name}`, value: `role:${index}` })),
      ...draft.categories.map((category, index) => ({ label: `Category · ${category.name}`, value: `category:${index}` })),
      ...draft.channels.map((channel, index) => ({ label: `Channel · ${channel.name}`, value: `channel:${index}` })),
      ...(draft.kits ?? []).map((kit, index) => ({ label: `Kit · ${kit.name}`, value: `kit:${index}` })),
      ...draft.categories.flatMap((category, index) =>
        (category.overwrites ?? []).map((overwrite, position) => ({
          label: `Perm · category ${category.name} · ${overwrite.name}`,
          value: `overwrite:category:${index}:${position}`,
        })),
      ),
      ...draft.channels.flatMap((channel, index) =>
        (channel.overwrites ?? []).map((overwrite, position) => ({
          label: `Perm · ${channel.name} · ${overwrite.name}`,
          value: `overwrite:channel:${index}:${position}`,
        })),
      ),
    ];

    const controls = [
      row(
        button({ id: customId('template-editor', 'role'), label: 'Add role', emoji: '🎭', style: ButtonStyle.Primary }),
        button({ id: customId('template-editor', 'category'), label: 'Add category', emoji: '🗂️' }),
        button({ id: customId('template-editor', 'channel'), label: 'Add channel', emoji: '💬' }),
        button({ id: customId('template-editor', 'permission'), label: 'Permissions', emoji: '🔐' }),
        button({ id: customId('template-editor', 'kit'), label: 'Add kit', emoji: '🎒', style: ButtonStyle.Success }),
      ),
    ];

    if (draft.categories.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('template-editor', 'category-pick'),
            placeholder: 'Category for the next channel',
            options: [
              { label: 'No category', value: 'none', description: 'Create the channel at the top level', default: !draft.pendingCategory },
              ...draft.categories.slice(0, 24).map((category) => ({
                label: truncate(category.name, 100),
                value: truncate(category.name, 100),
                default: category.name === draft.pendingCategory,
              })),
            ],
          }),
        ),
      );
    }

    if (draft.roles.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('template-editor', 'staffrole'),
            placeholder: 'Toggle a role as staff',
            options: draft.roles.slice(0, 25).map((role) => {
              const staff = (draft.staffRoles ?? []).includes(role.name);
              return {
                label: truncate(`${staff ? '✓ Staff' : 'Staff'} · ${role.name}`, 100),
                value: truncate(role.name, 100),
                description: staff ? 'Tap to remove staff access' : 'Tap to grant staff access',
                default: staff,
              };
            }),
          }),
        ),
      );
    }

    if (entries.length > 0) {
      controls.push(
        row(
          stringSelect({
            id: customId('template-editor', 'remove'),
            placeholder: 'Remove an entry or overwrite',
            options: entries.slice(0, 25).map((entry) => ({ label: truncate(entry.label, 100), value: entry.value })),
          }),
        ),
      );
    }

    controls.push(
      row(
        button({
          id: customId('template-editor', 'save'),
          label: draft.editingId ? 'Save changes' : 'Save template',
          emoji: '💾',
          style: ButtonStyle.Success,
        }),
        button({ id: customId('template-editor', 'cancel'), label: 'Discard', emoji: '🚮', style: ButtonStyle.Danger }),
      ),
      navRow({ backPanel: 'templates' }),
    );

    return { embeds: [embed], components: controls };
  },
};
