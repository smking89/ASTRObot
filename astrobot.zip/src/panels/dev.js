import { ButtonStyle } from 'discord.js';
import { listGuilds } from '../db/repositories/guilds.js';
import { licenseCounts } from '../db/repositories/licenses.js';
import { bountyBoard } from '../db/repositories/bounties.js';
import { registry } from '../core/registry.js';
import { runtime } from '../core/runtime.js';
import { env } from '../config/env.js';
import { COLORS } from '../config/constants.js';
import { buildEmbed } from '../ui/embeds.js';
import { button, customId, navRow, row } from '../ui/components.js';
import { formatNumber, formatDuration, truncate } from '../utils/format.js';

/** /dev fallback panel: platform-wide overview and entry points. */
export default {
  id: 'dev',
  async render({ ctx, params }) {
    const pending = listGuilds({ approved: false, limit: 10 });
    const approved = listGuilds({ approved: true, limit: 10 });
    const licenses = licenseCounts();
    const bounties = bountyBoard(ctx.guildId, 5);
    const manager = runtime.rconManager;

    const connections = manager ? [...manager.connections.values()] : [];
    const online = connections.filter((connection) => connection.connected).length;

    const embed = buildEmbed({
      title: '🛠️ Developer Administration',
      color: COLORS.danger,
      description: params.notice ?? 'Platform health, guild approval, memberships and license inventory.',
      fields: [
        { name: 'Guilds', value: `${formatNumber(approved.length)} approved · ${formatNumber(pending.length)} pending`, inline: true },
        { name: 'RCON', value: `${online}/${connections.length} connected`, inline: true },
        { name: 'Uptime', value: formatDuration(Date.now() - registry.startedAt), inline: true },
        {
          name: 'Commands / components / panels',
          value: `${registry.commands.size} / ${registry.components.size} / ${registry.panels.size}`,
          inline: true,
        },
        {
          name: 'Licenses',
          value: licenses.map((row) => `${row.status}: ${row.count}`).join(' · ') || 'No licenses issued.',
        },
        {
          name: 'Pending approvals',
          value:
            truncate(
              pending
                .map((guild) => `\`${guild.id}\` · ${guild.name ?? 'unknown'}`)
                .join('\n'),
              1024,
            ) || 'None',
        },
        {
          name: `Top bounties (${ctx.guild?.name ?? 'this guild'})`,
          value: truncate(bounties.map((row) => `<@${row.target_id}> · ${formatNumber(row.total)}`).join('\n'), 1024) || 'None',
        },
      ],
      footer: `Developer allowlist: ${env.discord.developerIds.length} account(s)`,
    });

    const controls = [
      row(
        button({ id: customId('dev', 'pending'), label: 'Pending guilds', emoji: '⏳' }),
        button({ id: customId('dev', 'licenses'), label: 'Licenses', emoji: '🪪' }),
        button({ id: customId('dev', 'diagnostics'), label: 'Diagnostics', emoji: '📊' }),
        button({ id: customId('dev', 'approve'), label: 'Approve guild', emoji: '✅', style: ButtonStyle.Success }),
      ),
      navRow({ backPanel: 'dev' }),
    ];

    return { embeds: [embed], components: controls };
  },
};
