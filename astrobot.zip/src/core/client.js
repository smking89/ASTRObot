import { Client, GatewayIntentBits, Partials, Events } from 'discord.js';
import { env } from '../config/env.js';
import { setBrandLogoUrl } from '../config/branding.js';
import { setEmbedChannelLookup } from '../ui/embeds.js';
import { logger } from './logger.js';
import { attachRouter } from './router.js';
import { registerEvents } from '../events/index.js';

/**
 * Gateway intents:
 *  - Guilds / GuildMembers for permissions, boost detection and team features
 *  - GuildMessages + MessageContent for Frank's keyword FAQ listener
 *    (MessageContent is privileged: enable it in the developer portal)
 */
export function createClient() {
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildModeration,
      GatewayIntentBits.GuildVoiceStates,
    ],
    partials: [Partials.Channel, Partials.Message],
    allowedMentions: { parse: ['users'], repliedUser: false },
  });

  attachRouter(client);
  registerEvents(client);

  client.once(Events.ClientReady, (ready) => {
    // The avatar doubles as the default footer icon, so the logo only needs to
    // be uploaded once in the developer portal unless BRAND_LOGO_URL overrides it.
    // 256px keeps the footer mark crisp on high-DPI clients and gives any
    // larger brand surface (portal, docs) a usable avatar URL too.
    setBrandLogoUrl(ready.user.displayAvatarURL({ extension: 'png', size: 256 }));
    setEmbedChannelLookup(() => {
      const channels = new Map();
      for (const channel of ready.channels.cache.values()) {
        if (channel?.name) channels.set(channel.name.toLowerCase(), channel.id);
      }
      return channels;
    });

    logger.info(`Logged in as ${ready.user.tag} across ${ready.guilds.cache.size} guild(s).`);
    if (!env.discord.officialGuildId) logger.warn('OFFICIAL_GUILD_ID is not set - /leaderboards official is disabled.');
    if (!env.encryptionKey) logger.warn('BOT_ENCRYPTION_KEY is not set - RCON passwords are stored unencrypted.');
  });

  client.on(Events.Error, (error) => logger.error('Gateway error', error));
  client.on(Events.Warn, (message) => logger.warn(`Gateway warning: ${message}`));

  return client;
}
