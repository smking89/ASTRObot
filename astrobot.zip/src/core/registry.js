import { Collection } from 'discord.js';

/**
 * Process-wide registry. Written once by loadRegistry(), read by the router.
 */
export const registry = {
  /** @type {Collection<string, object>} */
  commands: new Collection(),
  /** @type {Collection<string, object>} */
  components: new Collection(),
  /** @type {Collection<string, object>} */
  panels: new Collection(),
  /** @type {Array<object>} */
  payloads: [],
  /** Active interactive games keyed by message id. */
  sessions: new Map(),
  /** Boot timestamp, used by /dev diagnostics. */
  startedAt: Date.now(),
};

export function registerLoaded({ commands, components, panels, payloads }) {
  registry.commands = commands;
  registry.components = components;
  registry.panels = panels;
  registry.payloads = payloads;
  return registry;
}

export function getCommand(name) {
  return registry.commands.get(name);
}

export function getComponent(id) {
  return registry.components.get(id);
}

export function getPanel(id) {
  return registry.panels.get(id);
}

export function createSession(messageId, data, ttlMs = 10 * 60 * 1000) {
  const session = { ...data, messageId, createdAt: Date.now(), expiresAt: Date.now() + ttlMs };
  registry.sessions.set(messageId, session);
  return session;
}

export function getSession(messageId) {
  const session = registry.sessions.get(messageId);
  if (!session) return null;
  if (session.expiresAt < Date.now()) {
    registry.sessions.delete(messageId);
    return null;
  }
  return session;
}

export function updateSession(messageId, patch) {
  const session = getSession(messageId);
  if (!session) return null;
  Object.assign(session, patch);
  return session;
}

export function endSession(messageId) {
  registry.sessions.delete(messageId);
}

export function sweepSessions() {
  const now = Date.now();
  for (const [key, session] of registry.sessions) {
    if (session.expiresAt < now) registry.sessions.delete(key);
  }
}
