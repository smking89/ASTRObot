import { MessageFlags } from 'discord.js';
import { openPanel } from './panel-kit.js';
import { assertFeatureEnabled, featureForPanel } from '../services/feature-service.js';

/**
 * Thin wrapper over an interaction. Every command, component and modal handler
 * receives one of these instead of the raw interaction, which keeps response
 * state handling, ephemerality and panel rendering consistent everywhere.
 */
export class InteractionContext {
  constructor({ interaction, client, command = null, subcommand = null, grants, guildConfig, team = null }) {
    this.interaction = interaction;
    this.client = client;
    this.command = command;
    this.subcommand = subcommand;
    this.grants = grants ?? new Set(['player']);
    this.guildConfig = guildConfig ?? null;
    this.team = team;

    /** Populated for message components and modals. */
    this.args = [];
    this.values = [];
    this.fields = null;
    this.customId = null;
  }

  get guild() {
    return this.interaction.guild;
  }

  get channel() {
    return this.interaction.channel;
  }

  get channelId() {
    return this.interaction.channelId ?? this.interaction.channel?.id ?? null;
  }

  get member() {
    return this.interaction.member;
  }

  get user() {
    return this.interaction.user;
  }

  get guildId() {
    return this.interaction.guildId;
  }

  get userId() {
    return this.interaction.user?.id;
  }

  get isComponent() {
    return this.interaction.isMessageComponent?.() ?? false;
  }

  get isModal() {
    return this.interaction.isModalSubmit?.() ?? false;
  }

  get deferred() {
    return Boolean(this.interaction.deferred);
  }

  get replied() {
    return Boolean(this.interaction.replied);
  }

  /** Reads a chat input option, or a modal field with the same name. */
  option(name, required = false) {
    if (this.isModal && this.fields) {
      // Select menus in modals carry their value outside the text-input API.
      if (typeof this.fields.getStringSelectValues === 'function') {
        try {
          const selected = this.fields.getStringSelectValues(name);
          if (Array.isArray(selected) && selected.length > 0) return selected[0];
        } catch {
          // Not a select field; fall through to the text-input reader.
        }
      }

      // Optional fields (for example Dice's "choice") do not exist on other
      // game modals; asking for one should return null rather than throw.
      const present = this.fields.fields?.has?.(name) ?? true;
      const value = present ? (this.fields.getTextInputValue?.(name) ?? null) : null;
      if (!value && required) throw new Error(`Modal field ${name} is required.`);
      return value;
    }
    return this.interaction.options?.get?.(name, required)?.value ?? null;
  }

  getSubcommandName() {
    return this.interaction.options?.getSubcommand?.(false) ?? null;
  }

  getSubcommandGroup() {
    return this.interaction.options?.getSubcommandGroup?.(false) ?? null;
  }

  /**
   * Acknowledges the interaction so slow work (RCON, wipes, HTTP) is allowed up
   * to Discord's 15 minute budget.
   */
  async defer({ ephemeral = false, thinking = true } = {}) {
    if (this.deferred || this.replied) return;
    const payload = {};
    if (ephemeral) payload.flags = MessageFlags.Ephemeral;
    if (thinking && typeof this.interaction.deferReply === 'function') payload.fetchReply = false;
    await this.interaction.deferReply(payload);
  }

  /** Response helper that transparently switches between reply and editReply. */
  async reply(payload, { ephemeral = false } = {}) {
    const body = { ...payload };
    if (ephemeral && body.flags === undefined) body.flags = MessageFlags.Ephemeral;

    if (this.deferred || this.replied) return this.interaction.editReply(body);
    return this.interaction.reply(body);
  }

  async edit(payload) {
    return this.interaction.editReply(payload);
  }

  async followUp(payload, { ephemeral = false } = {}) {
    const body = { ...payload };
    if (ephemeral && body.flags === undefined) body.flags = MessageFlags.Ephemeral;
    return this.interaction.followUp(body);
  }

  async update(payload) {
    if (typeof this.interaction.update === 'function') return this.interaction.update(payload);
    return this.reply(payload);
  }

  async deferUpdate() {
    if (typeof this.interaction.deferUpdate === 'function' && !this.deferred && !this.replied) {
      return this.interaction.deferUpdate();
    }
    return undefined;
  }

  /** Opens a registered panel, rendering it inline (edit) when possible. */
  async panel(id, params = {}) {
    assertFeatureEnabled(this.guildConfig, featureForPanel(id));
    return openPanel(this, id, params);
  }

  async modal(modal) {
    return this.interaction.showModal(modal);
  }

  /** Runs work with an automatic defer so the 3 second window is never missed. */
  async withDefer(work, options = { ephemeral: true }) {
    await this.defer(options);
    return work();
  }
}
