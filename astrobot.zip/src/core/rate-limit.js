import { CooldownError } from './errors.js';

/**
 * In-memory token bucket. One key per user + command / component so a button
 * cannot be spammed faster than the equivalent command.
 */
const buckets = new Map();

export function consume(key, { limit = 4, windowMs = 3000 } = {}) {
  const now = Date.now();
  const bucket = buckets.get(key) ?? { tokens: limit, updatedAt: now };

  const refill = ((now - bucket.updatedAt) / windowMs) * limit;
  bucket.tokens = Math.min(limit, bucket.tokens + refill);
  bucket.updatedAt = now;

  if (bucket.tokens < 1) {
    const missing = 1 - bucket.tokens;
    const seconds = Math.max(1, Math.ceil((missing / limit) * (windowMs / 1000)));
    buckets.set(key, bucket);
    throw new CooldownError(seconds);
  }

  bucket.tokens -= 1;
  buckets.set(key, bucket);
  return bucket.tokens;
}

export function resetLimit(key) {
  buckets.delete(key);
}

/** Drops buckets that have fully refilled so the map cannot grow forever. */
export function sweepLimits(maxIdleMs = 10 * 60 * 1000) {
  const now = Date.now();
  for (const [key, bucket] of buckets) {
    if (now - bucket.updatedAt > maxIdleMs) buckets.delete(key);
  }
}
