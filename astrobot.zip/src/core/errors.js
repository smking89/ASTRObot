/**
 * Typed errors. Anything thrown that is not an AstroError is treated as an
 * internal fault: the user sees the generic message and developers get the stack.
 */

export class AstroError extends Error {
  constructor(message, options = {}) {
    super(message, options.cause ? { cause: options.cause } : undefined);
    this.name = 'AstroError';
    this.code = options.code ?? 'ASTRO_ERROR';
    this.userMessage = options.userMessage ?? 'Something went wrong processing your request.';
    this.expose = options.expose ?? false;
    this.meta = options.meta ?? {};
  }
}

export class PermissionError extends AstroError {
  constructor(required, options = {}) {
    super(options.message ?? `Missing access tier: ${required}.`, {
      code: 'PERMISSION_DENIED',
      userMessage: options.userMessage ?? `You do not have permission to use this. Required access: **${required}**.`,
      ...options,
    });
    this.name = 'PermissionError';
    this.required = required;
  }
}

export class ValidationError extends AstroError {
  constructor(message, options = {}) {
    super(message, {
      code: 'VALIDATION',
      userMessage: message,
      expose: true,
      ...options,
    });
    this.name = 'ValidationError';
  }
}

export class CooldownError extends AstroError {
  constructor(seconds) {
    super(`Rate limited for ${seconds}s`, {
      code: 'COOLDOWN',
      userMessage: `Slow down — try again in **${seconds}s**.`,
      expose: true,
    });
    this.name = 'CooldownError';
    this.seconds = seconds;
  }
}

/** Generic user-facing text, deliberately free of internals. */
export const GENERIC_USER_MESSAGE = 'Something went wrong processing your request.';

export function userMessageFor(error) {
  if (error instanceof AstroError) return error.userMessage;
  return GENERIC_USER_MESSAGE;
}
