import { PermissionFlagsBits } from 'discord.js';
import { env } from '../config/env.js';

/**
 * Access tiers are an ordered ladder. A member's granted set is computed once per
 * interaction and re-computed for every message component, so a panel button can
 * never be used to exceed the permissions of its originating command.
 */

export const ACCESS = Object.freeze({
  PLAYER: 'player',
  TEAM: 'team',
  STAFF: 'staff',
  ADMIN: 'admin',
  RESTRICTED: 'restricted',
  DEVELOPER: 'developer',
  OFFICIAL: 'official',
});

const LADDER = ['player', 'team', 'staff', 'admin', 'restricted', 'developer'];

export const ACCESS_LABELS = Object.freeze({
  player: 'Player',
  team: 'Team',
  staff: 'Staff',
  admin: 'Admin',
  restricted: 'Restricted',
  developer: 'Developer',
  official: 'Official Guild',
});

/** Discord permission bits implied by each tier, checked at the router layer. */
export const TIER_PERMISSION_BITS = Object.freeze({
  staff: [PermissionFlagsBits.ModerateMembers],
  admin: [PermissionFlagsBits.ManageGuild],
});

export function isValidAccess(tier) {
  return Object.values(ACCESS).includes(tier);
}

/**
 * Builds the set of tiers a member holds.
 * @param {object} params
 * @param {import('discord.js').GuildMember|null} params.member
 * @param {object} params.guildConfig merged guild settings
 * @param {boolean} params.inTeam whether the member belongs to any registered team
 */
function memberRoleIds(member) {
  const roles = member?.roles;
  if (!roles) return new Set();
  if (typeof roles.cache?.keys === 'function') return new Set(roles.cache.keys());
  if (Array.isArray(roles)) return new Set(roles);
  return new Set();
}

/** Handles both a cached GuildMember and a raw interaction member (string bits). */
function memberHasPermission(member, bit) {
  const permissions = member?.permissions;
  if (!permissions) return false;
  if (typeof permissions.has === 'function') return permissions.has(bit);
  if (typeof permissions === 'string') {
    try {
      return (BigInt(permissions) & BigInt(bit)) === BigInt(bit);
    } catch {
      return false;
    }
  }
  return false;
}

export function resolveGrants({ member, guild = null, guildConfig, inTeam = false }) {
  const grants = new Set([ACCESS.PLAYER]);
  if (!member) return grants;

  const access = guildConfig?.access ?? {};
  const roleIds = memberRoleIds(member);
  const intersects = (configured = []) => configured.some((roleId) => roleIds.has(roleId));
  const guildId = guild?.id ?? member.guild?.id ?? null;
  const ownerId = guild?.ownerId ?? member.guild?.ownerId ?? null;

  if (ownerId && member.id === ownerId) {
    for (const tier of LADDER) grants.add(tier);
    return grants;
  }

  if (env.discord.developerIds.includes(member.id)) {
    for (const tier of LADDER) grants.add(tier);
    return grants;
  }

  if (inTeam) grants.add(ACCESS.TEAM);

  const staffBit = memberHasPermission(member, PermissionFlagsBits.ModerateMembers);
  const adminBit = memberHasPermission(member, PermissionFlagsBits.Administrator);

  if (staffBit || intersects(access.staffRoleIds)) {
    grants.add(ACCESS.TEAM);
    grants.add(ACCESS.STAFF);
  }

  if (adminBit || intersects(access.adminRoleIds)) {
    grants.add(ACCESS.TEAM);
    grants.add(ACCESS.STAFF);
    grants.add(ACCESS.ADMIN);
  }

  // "Restricted" is for specifically authorized roles. Administrators pass by
  // default because Administrator is Discord's absolute guild permission; a guild
  // can demand an explicit restricted role with access.strictRestricted = true.
  const restrictedByRole = intersects(access.restrictedRoleIds);
  if (restrictedByRole || (grants.has(ACCESS.ADMIN) && !access.strictRestricted)) {
    grants.add(ACCESS.RESTRICTED);
  }

  if (env.discord.officialGuildId && guildId === env.discord.officialGuildId) {
    grants.add(ACCESS.OFFICIAL);
  }

  return grants;
}

/** True when the member's set satisfies the required tier. */
export function hasAccess(grants, required = ACCESS.PLAYER) {
  if (!required) return true;

  if (required === ACCESS.OFFICIAL) return grants.has(ACCESS.OFFICIAL);

  const requiredRank = LADDER.indexOf(required);
  if (requiredRank === -1) return false;

  // Any grant at or above the required rank satisfies it. Official is not part of
  // the ladder, so it is handled above.
  return LADDER.some((tier) => grants.has(tier) && LADDER.indexOf(tier) >= requiredRank);
}

/** Bitfield check used for both command modules and component handlers. */
export function hasPermissionBits(member, bits) {
  const requirements = normalizeBits(bits);
  if (requirements.length === 0) return true;
  if (!member) return false;
  return requirements.every((bit) => memberHasPermission(member, bit));
}

export function normalizeBits(bits) {
  if (!bits) return [];
  const list = Array.isArray(bits) ? bits : [bits];
  return list.filter((bit) => typeof bit === 'bigint' || typeof bit === 'number');
}

export function describeAccess(required) {
  return ACCESS_LABELS[required] ?? required;
}
