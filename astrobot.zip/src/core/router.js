import { MessageFlags } from 'discord.js';
import { env } from '../config/env.js';
import { registry } from './registry.js';
import { InteractionContext } from './context.js';
import { hasAccess, hasPermissionBits, resolveGrants, describeAccess } from './permissions.js';
import { PermissionError, ValidationError, userMessageFor, AstroError } from './errors.js';
import { consume } from './rate-limit.js';
import { reportError } from './reporter.js';
import { ensureGuild, getGuild, getGuildSettings } from '../db/repositories/guilds.js';
import { getTeamForUser } from '../db/repositories/teams.js';
import { parseCustomId } from '../ui/components.js';
import { assertFeatureEnabled, featureForCommand } from '../services/feature-service.js';
import { createLogger } from './logger.js';

const log = createLogger('router');

/**
 * The single interaction entry point.
 *
 * Permission checks happen in three places by design:
 *   1. here, for the parent command and every subcommand;
 *   2. in the subcommand module itself when it needs resource-level rules
 *      (team rank, license ownership, ...);
 *   3. in message-component handlers, which recompute the member's grants.
 */
export function attachRouter(client) {
  client.on('interactionCreate', (interaction) => {
    handleInteraction(client, interaction).catch((error) => reportError(client, error, interaction));
  });
}

export async function handleInteraction(client, interaction) {
  if (interaction.isAutocomplete()) return handleAutocomplete(client, interaction);
  if (interaction.isChatInputCommand()) return handleCommand(client, interaction);
  if (interaction.isMessageComponent() || interaction.isModalSubmit()) return handleComponent(client, interaction);
  return null;
}

/** A root command with no subcommands is invoked directly, not treated as a parent. */
export function isStandaloneCommand(command) {
  return command.standalone === true || !command.subcommands?.size;
}

function guildSnapshot(interaction) {
  const guild = interaction.guild;
  if (!guild) return null;
  return getGuild(guild.id) ?? ensureGuild({ id: guild.id, name: guild.name, icon: guild.icon });
}

function buildContext({ interaction, client, command, subcommand, grants, guildConfig }) {
  return new InteractionContext({ interaction, client, command, subcommand, grants, guildConfig });
}

async function handleCommand(client, interaction) {
  const command = registry.commands.get(interaction.commandName);
  if (!command) {
    log.warn(`Received unknown command /${interaction.commandName}. Re-run npm run deploy.`);
    return;
  }

  if (!interaction.inGuild() && command.guildOnly !== false) {
    await interaction.reply({ content: 'AstroBot commands are only available inside a server.', flags: MessageFlags.Ephemeral });
    return;
  }

  if (!(await requireBotMembership(interaction))) return;

  const record = guildSnapshot(interaction);
  if (record && env.runtime.enforceGuildApproval && !record.approved && !env.discord.developerIds.includes(interaction.user.id)) {
    await interaction.reply({
      content: 'AstroBot is not approved for this server yet. An AstroBot developer must run `/dev guild approve`.',
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const guildConfig = getGuildSettings(interaction.guildId) ?? null;
  assertFeatureEnabled(guildConfig, featureForCommand(command.name));
  const team = interaction.inGuild() ? getTeamForUser(interaction.guildId, interaction.user.id) : null;
  const grants = resolveGrants({ member: interaction.member, guild: interaction.guild, guildConfig, inTeam: Boolean(team) });

  const ctx = buildContext({ interaction, client, command, grants, guildConfig });
  ctx.team = team;

  // Layer 1: parent-level access + Discord permission bitfield.
  if (!hasAccess(grants, command.access)) throw new PermissionError(describeAccess(command.access), { message: `/${command.name} requires ${command.access}.` });
  if (!hasPermissionBits(interaction.member, command.permissions)) {
    throw new PermissionError(describeAccess(command.access), { message: `/${command.name} requires a Discord permission the member lacks.` });
  }

  if (!isStandaloneCommand(command)) {
    const group = interaction.options.getSubcommandGroup(false);
    const name = interaction.options.getSubcommand(false);

    // Dual-route fallback: bare `/config` (API clients, or commands registered
    // without a panel subcommand) opens the category panel.
    if (!name) {
      if (!command.panel) throw new ValidationError('Choose one of this command\'s subcommands.');
      const panelId = typeof command.panel === 'string' ? command.panel : command.panel.id;
      await ctx.panel(panelId, typeof command.panel === 'object' ? command.panel.params ?? {} : {});
      return;
    }

    const key = group ? `${group}/${name}` : name;
    const sub = command.subcommands?.get(key);

    if (!sub) {
      log.warn(`No subcommand handler for ${key} in /${command.name}. Re-run npm run deploy.`);
      throw new ValidationError('That subcommand is not available yet. Ask an admin to redeploy commands.');
    }

    // Layer 2: individual subcommand access + bits.
    if (!hasAccess(grants, sub.access)) {
      throw new PermissionError(describeAccess(sub.access), { message: `${key} requires ${sub.access}.` });
    }
    if (!hasPermissionBits(interaction.member, sub.permissions)) {
      throw new PermissionError(describeAccess(sub.access), { message: `${key} requires a Discord permission the member lacks.` });
    }

    ctx.subcommand = sub;

    if (sub.panelOnly) {
      const panelId = sub.panel ?? command.panel;
      await ctx.panel(typeof panelId === 'string' ? panelId : panelId.id, typeof panelId === 'object' ? panelId.params ?? {} : {});
      return;
    }

    if (typeof sub.execute !== 'function') {
      throw new ValidationError('That subcommand has no handler.');
    }

    consume(`cmd:${interaction.user.id}:${command.name}:${key}`, { limit: 4, windowMs: command.cooldownMs ?? 1500 });

    if (sub.defer) await ctx.defer({ ephemeral: sub.defer === 'ephemeral' });
    await sub.execute(ctx);
    return;
  }

  if (typeof command.execute !== 'function') throw new ValidationError(`/${command.name} has no handler.`);

  consume(`cmd:${interaction.user.id}:${command.name}:root`, { limit: 4, windowMs: command.cooldownMs ?? 1500 });
  if (command.defer) await ctx.defer({ ephemeral: command.defer === 'ephemeral' });

  await command.execute(ctx);
}

async function handleComponent(client, interaction) {
  const parsed = parseCustomId(interaction.customId);
  if (!parsed) {
    await safeEphemeral(interaction, 'This panel has expired. Run the command again.');
    return;
  }

  const handler = registry.components.get(parsed.handler);
  if (!handler) {
    log.warn(`No component handler for ${parsed.handler} (${interaction.customId}).`);
    await safeEphemeral(interaction, 'This panel is no longer available. Run the command again.');
    return;
  }

  if (!interaction.inGuild() && handler.guildOnly !== false) {
    await safeEphemeral(interaction, 'This interaction is only available inside a server.');
    return;
  }

  if (!(await requireBotMembership(interaction))) return;

  const guildConfig = getGuildSettings(interaction.guildId) ?? null;
  const team = interaction.inGuild() ? getTeamForUser(interaction.guildId, interaction.user.id) : null;
  const grants = resolveGrants({ member: interaction.member, guild: interaction.guild, guildConfig, inTeam: Boolean(team) });

  const ctx = buildContext({ interaction, client, grants, guildConfig, command: null, subcommand: null });
  ctx.args = parsed.args;
  ctx.customId = interaction.customId;
  ctx.team = team;
  ctx.values =
    interaction.isStringSelectMenu?.() || interaction.isChannelSelectMenu?.() || interaction.isRoleSelectMenu?.()
      ? interaction.values
      : [];
  ctx.fields = interaction.isModalSubmit?.() ? interaction.fields : null;

  // Layer 3: component-level permissions, recomputed from the live member state.
  if (!hasAccess(grants, handler.access ?? 'player')) {
    throw new PermissionError(describeAccess(handler.access ?? 'player'), { message: `Component ${parsed.handler} denied.` });
  }
  if (!hasPermissionBits(interaction.member, handler.permissions)) {
    throw new PermissionError(describeAccess(handler.access ?? 'player'), { message: `Component ${parsed.handler} missing Discord permission.` });
  }

  consume(`comp:${interaction.user.id}:${parsed.handler}`, { limit: 8, windowMs: 3000 });
  await handler.execute(ctx);
}

async function handleAutocomplete(client, interaction) {
  const command = registry.commands.get(interaction.commandName);
  if (!command) return;

  const group = interaction.options.getSubcommandGroup(false);
  const name = interaction.options.getSubcommand(false);
  const target = command.subcommands?.get(group ? `${group}/${name}` : name) ?? command;

  if (typeof target.autocomplete !== 'function') {
    await interaction.respond([]).catch(() => null);
    return;
  }

  const guildConfig = getGuildSettings(interaction.guildId) ?? null;
  const team = interaction.inGuild() ? getTeamForUser(interaction.guildId, interaction.user.id) : null;
  const grants = resolveGrants({ member: interaction.member, guild: interaction.guild, guildConfig, inTeam: Boolean(team) });
  const ctx = buildContext({ interaction, client, command, grants, guildConfig });
  ctx.team = team;

  try {
    await target.autocomplete(ctx);
  } catch (error) {
    log.warn(`Autocomplete failed for /${interaction.commandName}: ${error.message}`);
    await interaction.respond([]).catch(() => null);
  }
}

/** Error-path responder that never throws InteractionAlreadyReplied. */
export async function respondWithError(interaction, userMessage) {
  const payload = { content: userMessage, flags: MessageFlags.Ephemeral };

  try {
    if (interaction.deferred && !interaction.replied) {
      await interaction.editReply({ content: userMessage });
      return;
    }
    if (interaction.replied) {
      await interaction.followUp(payload);
      return;
    }
    await interaction.reply(payload);
  } catch (error) {
    // 40060 = already acknowledged; nothing left to do.
    if (error?.code !== 40060) log.debug(`Could not deliver error message: ${error?.message}`);
  }
}

/**
 * An app can be installed with only the applications.commands scope, which
 * delivers interactions without adding the bot user to the guild. Guild-scoped
 * work cannot succeed in that state, so explain the actual fix instead of
 * failing with a generic error.
 */
async function requireBotMembership(interaction) {
  if (!interaction.inGuild() || interaction.guild) return true;
  await respondWithError(
    interaction,
    'AstroBot is installed without its bot user. Re-invite it with the **bot** scope (not only applications.commands), then try again.',
  );
  return false;
}

async function safeEphemeral(interaction, content) {
  await respondWithError(interaction, content);
}

export { userMessageFor, AstroError };
