import { MessageFlags } from 'discord.js';
import { env } from '../config/env.js';
import { buildEmbed } from '../ui/embeds.js';
import { COLORS } from '../config/constants.js';
import { codeBlock } from '../utils/format.js';
import { logger } from './logger.js';
import { AstroError, userMessageFor } from './errors.js';

/** Dedupe identical failures so a broken loop cannot spam the dev channel. */
const recent = new Map();
const DEDUPE_MS = 60_000;

export async function reportError(client, error, interaction = null) {
  const key = `${error?.name}:${error?.message}`;
  const last = recent.get(key) ?? 0;
  const shouldSend = Date.now() - last > DEDUPE_MS;
  recent.set(key, Date.now());

  const context = interaction
    ? `${interaction.isChatInputCommand?.() ? `/${interaction.commandName}` : interaction.customId ?? 'component'} by ${interaction.user?.tag ?? interaction.user?.id ?? 'unknown'} in ${interaction.guildId ?? 'DM'}`
    : 'background';

  // Permission, validation and cooldown failures are expected user outcomes;
  // they get their real explanation and are not reported as internal faults.
  const expected =
    error instanceof AstroError &&
    (error.expose || ['PERMISSION_DENIED', 'COOLDOWN', 'VALIDATION'].includes(error.code));

  if (expected) {
    logger.warn(`Rejected (${context}): ${error.message}`);
  } else {
    logger.error(`Unhandled error (${context}): ${error?.message}`, error);
  }

  // Always acknowledge the interaction: otherwise Discord shows "The application
  // did not respond" and the user never sees an error message.
  if (interaction) {
    try {
      const userMessage = userMessageFor(error);
      const payload = { content: userMessage, flags: MessageFlags.Ephemeral };
      if (interaction.deferred && !interaction.replied) {
        await interaction.editReply({ content: userMessage });
      } else if (interaction.replied) {
        await interaction.followUp(payload);
      } else {
        await interaction.reply(payload);
      }
    } catch (responseError) {
      if (responseError?.code !== 40060) {
        logger.warn(`Could not deliver the error response: ${responseError?.message}`);
      }
    }
  }

  if (expected) return;
  if (!shouldSend || !client?.isReady?.() || !env.discord.developerLogChannelId) return;

  try {
    const channel = await client.channels.fetch(env.discord.developerLogChannelId).catch(() => null);
    if (!channel?.isTextBased()) return;

    const embed = buildEmbed({
      title: 'Unhandled exception',
      color: COLORS.danger,
      description: codeBlock(error?.stack ?? String(error)),
      fields: [
        { name: 'Context', value: context.slice(0, 1024) },
        { name: 'Command', value: interaction?.commandName ?? interaction?.customId ?? 'n/a', inline: true },
        { name: 'Guild', value: interaction?.guildId ?? 'n/a', inline: true },
      ],
      footer: 'AstroBot error reporter',
    });

    await channel.send({ embeds: [embed] });
  } catch (reportingError) {
    logger.warn(`Could not deliver error report: ${reportingError.message}`);
  }
}

export function clearErrorHistory() {
  recent.clear();
}
