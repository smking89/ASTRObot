import { readdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Collection, SlashCommandBuilder, SlashCommandSubcommandBuilder, SlashCommandSubcommandGroupBuilder } from 'discord.js';
import { DISCORD_LIMITS } from '../config/constants.js';
import { ACCESS, isValidAccess } from './permissions.js';
import { titleCase } from '../utils/format.js';
import { createLogger } from './logger.js';

const log = createLogger('loader');

export const COMMANDS_DIR = fileURLToPath(new URL('../commands/', import.meta.url));
export const COMPONENTS_DIR = fileURLToPath(new URL('../components/', import.meta.url));
export const PANELS_DIR = fileURLToPath(new URL('../panels/', import.meta.url));

const NAME_PATTERN = /^[a-z0-9-]{1,32}$/;

async function importDefault(file) {
  const module = await import(pathToFileURL(file).href);
  const exported = module.default ?? module;
  if (!exported || typeof exported !== 'object') {
    throw new Error(`${path.relative(process.cwd(), file)} must have a default export object.`);
  }
  return exported;
}

function assertName(value, label, file) {
  if (!NAME_PATTERN.test(value ?? '')) {
    throw new Error(`${file}: ${label} "${value}" must match ${NAME_PATTERN}.`);
  }
}

function assertDescription(value, file) {
  if (typeof value !== 'string' || value.trim().length === 0) {
    throw new Error(`${file}: description is required.`);
  }
  if (value.length > DISCORD_LIMITS.commandDescriptionMax) {
    throw new Error(`${file}: description "${value}" exceeds ${DISCORD_LIMITS.commandDescriptionMax} characters.`);
  }
}

function assertAccess(value, file) {
  if (value === undefined) return ACCESS.PLAYER;
  if (!isValidAccess(value)) {
    throw new Error(`${file}: unknown access tier "${value}". Expected ${Object.values(ACCESS).join(', ')}.`);
  }
  return value;
}

async function listEntries(dir) {
  return readdir(dir, { withFileTypes: true });
}

/**
 * Loads one parent command folder.
 *
 *   commands/config/index.js          -> /config (parent metadata + panel)
 *   commands/config/shop.js           -> /config shop
 *   commands/dev/guild/approve.js     -> /dev guild approve
 *   commands/link.js                  -> /link (standalone)
 */
async function loadParent(folder) {
  const indexFile = path.join(folder, 'index.js');
  const folderName = path.basename(folder);
  const meta = await importDefault(indexFile);

  const name = meta.name ?? folderName;
  assertName(name, 'command name', indexFile);
  assertDescription(meta.description, indexFile);

  const builder = new SlashCommandBuilder()
    .setName(name)
    .setDescription(meta.description)
    .setDMPermission(false);

  meta.configure?.(builder);

  const subcommands = new Collection();
  const entries = await listEntries(folder);
  let groupCount = 0;
  let subCount = 0;

  for (const entry of entries) {
    if (entry.isFile()) {
      if (!entry.name.endsWith('.js') || entry.name === 'index.js') continue;
      const file = path.join(folder, entry.name);
      const subName = entry.name.slice(0, -3);
      const sub = await importDefault(file);
      const entryData = buildSubcommand(sub, subName, file, meta.access);

      if (subcommands.has(entryData.name)) {
        throw new Error(`${file}: duplicate subcommand "${entryData.name}" in /${name}.`);
      }

      const subBuilder = new SlashCommandSubcommandBuilder()
        .setName(entryData.name)
        .setDescription(entryData.description);
      sub.configure?.(subBuilder);

      builder.addSubcommand(subBuilder);
      subcommands.set(entryData.name, entryData);
      subCount += 1;
      continue;
    }

    if (entry.isDirectory()) {
      groupCount += 1;
      if (groupCount > DISCORD_LIMITS.subcommandGroupsPerParent) {
        throw new Error(`/${name}: more than ${DISCORD_LIMITS.subcommandGroupsPerParent} subcommand groups.`);
      }

      const groupDir = path.join(folder, entry.name);
      assertName(entry.name, 'subcommand group', groupDir);

      const groupMetaFile = path.join(groupDir, '_group.js');
      const groupMeta = await importDefault(groupMetaFile).catch(() => ({}));
      const groupDescription = groupMeta.description ?? `${titleCase(entry.name)} actions.`;

      const groupBuilder = new SlashCommandSubcommandGroupBuilder()
        .setName(entry.name)
        .setDescription(groupDescription.slice(0, DISCORD_LIMITS.commandDescriptionMax));

      const groupFiles = (await listEntries(groupDir)).filter(
        (child) => child.isFile() && child.name.endsWith('.js') && !child.name.startsWith('_'),
      );

      for (const groupFile of groupFiles) {
        const file = path.join(groupDir, groupFile.name);
        const subName = groupFile.name.slice(0, -3);
        const sub = await importDefault(file);
        const entryData = buildSubcommand(sub, subName, file, meta.access);
        const key = `${entry.name}/${entryData.name}`;

        if (subcommands.has(key)) throw new Error(`${file}: duplicate subcommand "${key}" in /${name}.`);

        const subBuilder = new SlashCommandSubcommandBuilder()
          .setName(entryData.name)
          .setDescription(entryData.description);
        sub.configure?.(subBuilder);

        groupBuilder.addSubcommand(subBuilder);
        subcommands.set(key, entryData);
        subCount += 1;
      }

      builder.addSubcommandGroup(groupBuilder);
    }
  }

  if (subCount > DISCORD_LIMITS.subcommandsPerParent) {
    throw new Error(`/${name}: more than ${DISCORD_LIMITS.subcommandsPerParent} subcommands.`);
  }

  // Discord makes a command with subcommands un-invocable on its own. Registering
  // a "panel" subcommand keeps the category panel one click away while the router
  // still honours bare invocations coming from API clients.
  if (meta.panel && subCount > 0 && meta.panelSubcommand !== false && !subcommands.has('panel')) {
    const panelKey = meta.panelId ?? (typeof meta.panel === 'string' ? meta.panel : meta.panel.id);
    const panelSub = {
      name: 'panel',
      description: `Open the ${meta.label ?? titleCase(name)} panel.`,
      access: assertAccess(meta.access, indexFile),
      panelOnly: true,
      panel: panelKey,
    };

    const subBuilder = new SlashCommandSubcommandBuilder()
      .setName(panelSub.name)
      .setDescription(panelSub.description);

    builder.addSubcommand(subBuilder);
    subcommands.set(panelSub.name, panelSub);
    subCount += 1;
  }

  if (subCount === 0 && !meta.execute && !meta.panel) {
    throw new Error(`${indexFile}: no subcommands, no panel and no execute handler.`);
  }

  return {
    name,
    description: meta.description,
    label: meta.label ?? titleCase(name),
    access: assertAccess(meta.access, indexFile),
    permissions: meta.permissions ?? null,
    guildOnly: meta.guildOnly ?? true,
    cooldownMs: meta.cooldownMs ?? 1500,
    defer: meta.defer ?? null,
    panel: meta.panel ?? null,
    execute: meta.execute ?? null,
    help: meta.help ?? null,
    standalone: false,
    subcommands: subcommands.size > 0 ? subcommands : null,
    data: builder.toJSON(),
    file: path.relative(process.cwd(), indexFile),
  };
}

function buildSubcommand(sub, fallbackName, file, parentAccess) {
  const name = sub.name ?? fallbackName;
  assertName(name, 'subcommand name', file);
  assertDescription(sub.description, file);

  return {
    ...sub,
    name,
    access: assertAccess(sub.access ?? parentAccess, file),
    permissions: sub.permissions ?? null,
    defer: sub.defer ?? null,
    file: path.relative(process.cwd(), file),
  };
}

async function loadStandalone(file) {
  const meta = await importDefault(file);
  if (!meta.data) throw new Error(`${file}: standalone commands must export a SlashCommandBuilder as "data".`);

  const data = typeof meta.data.toJSON === 'function' ? meta.data.toJSON() : meta.data;
  assertName(data.name, 'command name', file);
  assertDescription(data.description, file);

  return {
    ...meta,
    name: data.name,
    description: data.description,
    access: assertAccess(meta.access, file),
    permissions: meta.permissions ?? null,
    guildOnly: meta.guildOnly ?? true,
    cooldownMs: meta.cooldownMs ?? 1500,
    defer: meta.defer ?? null,
    standalone: true,
    subcommands: null,
    data,
    file: path.relative(process.cwd(), file),
  };
}

export async function loadCommands(dir = COMMANDS_DIR) {
  const commands = new Collection();
  const entries = await listEntries(dir);

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isFile() && entry.name.endsWith('.js')) {
      const command = await loadStandalone(fullPath);
      if (commands.has(command.name)) throw new Error(`${fullPath}: duplicate command /${command.name}.`);
      commands.set(command.name, command);
      continue;
    }

    if (entry.isDirectory()) {
      const command = await loadParent(fullPath);
      if (commands.has(command.name)) throw new Error(`${fullPath}: duplicate command /${command.name}.`);
      commands.set(command.name, command);
    }
  }

  return commands;
}

export async function loadComponents(dir = COMPONENTS_DIR) {
  const components = new Collection();
  const files = (await listEntries(dir))
    .filter((entry) => entry.isFile() && entry.name.endsWith('.js'))
    .map((entry) => path.join(dir, entry.name))
    .sort();

  for (const file of files) {
    const meta = await importDefault(file);
    const id = meta.id;
    if (!/^[a-z0-9-]{1,20}$/.test(id ?? '')) {
      throw new Error(`${file}: component id "${id}" must match /^[a-z0-9-]{1,20}$/.`);
    }
    if (components.has(id)) throw new Error(`${file}: duplicate component id "${id}".`);

    components.set(id, {
      ...meta,
      access: assertAccess(meta.access, file),
      permissions: meta.permissions ?? null,
      file: path.relative(process.cwd(), file),
    });
  }

  return components;
}

export async function loadPanels(dir = PANELS_DIR) {
  const panels = new Collection();
  const files = (await listEntries(dir))
    .filter((entry) => entry.isFile() && entry.name.endsWith('.js'))
    .map((entry) => path.join(dir, entry.name))
    .sort();

  for (const file of files) {
    const meta = await importDefault(file);
    if (typeof meta.render !== 'function') throw new Error(`${file}: panel must export a render() function.`);
    if (!meta.id) throw new Error(`${file}: panel id is required.`);
    if (panels.has(meta.id)) throw new Error(`${file}: duplicate panel id "${meta.id}".`);

    panels.set(meta.id, { ...meta, file: path.relative(process.cwd(), file) });
  }

  return panels;
}

/** Loads everything once at boot; the router only ever reads the registry. */
export async function loadRegistry() {
  const [commands, components, panels] = await Promise.all([loadCommands(), loadComponents(), loadPanels()]);

  const payloads = [...commands.values()].map((command) => command.data);
  log.info(`Loaded ${commands.size} commands (${payloads.reduce((sum, payload) => sum + (payload.options?.length ?? 0), 0)} top-level entries).`);
  log.info(`Loaded ${components.size} component handlers and ${panels.size} panels.`);

  return { commands, components, panels, payloads };
}
