/**
 * Minimal structured logger. Logs go to stdout/stderr and, when attached, to the
 * developer log channel via a sink so stack traces are visible to the dev team.
 */

const LEVELS = { trace: 10, debug: 20, info: 30, warn: 40, error: 50, silent: 100 };

let threshold = LEVELS[process.env.LOG_LEVEL?.toLowerCase()] ?? LEVELS.info;
const sinks = new Set();

export function setLogLevel(level) {
  threshold = LEVELS[String(level).toLowerCase()] ?? threshold;
}

/** Sink receives (level, scope, message, error) after the local write. */
export function attachLogSink(sink) {
  sinks.add(sink);
  return () => sinks.delete(sink);
}

function timestamp() {
  return new Date().toISOString();
}

function write(level, scope, message, error) {
  if (LEVELS[level] < threshold) return;

  const prefix = scope ? `[${timestamp()}] ${level.toUpperCase()} [${scope}]` : `[${timestamp()}] ${level.toUpperCase()}`;
  const line = `${prefix} ${message}`;
  if (level === 'error' || level === 'warn') {
    console.error(line);
    if (error?.stack) console.error(error.stack);
  } else {
    console.log(line);
    if (error?.stack) console.log(error.stack);
  }

  for (const sink of sinks) {
    try {
      sink(level, scope, message, error);
    } catch {
      // A broken sink must never break logging.
    }
  }
}

export function createLogger(scope = 'astrobot') {
  return {
    scope,
    child(childScope) {
      return createLogger(scope ? `${scope}:${childScope}` : childScope);
    },
    trace: (message, error) => write('trace', scope, message, error),
    debug: (message, error) => write('debug', scope, message, error),
    info: (message, error) => write('info', scope, message, error),
    warn: (message, error) => write('warn', scope, message, error),
    error: (message, error) => write('error', scope, message, error),
  };
}

export const logger = createLogger();
