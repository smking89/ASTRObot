import { MessageFlags } from 'discord.js';
import { getPanel } from './registry.js';
import { GENERIC_USER_MESSAGE } from './errors.js';
import { createLogger } from './logger.js';

const log = createLogger('panel');

/**
 * Panel contract
 * --------------
 * A panel file exports { id, public?, ephemeral?, render({ ctx, params }) }
 * and render() resolves to { embeds, components, content? }.
 *
 * Panels are the shared UI layer: a parent command's fallback, the target of a
 * subcommand, and the destination of a nav button all use openPanel(). This is
 * what keeps /config, /config shop and a "Shop settings" button in sync.
 */
export async function openPanel(ctx, id, params = {}) {
  const panel = getPanel(id);
  if (!panel) {
    log.error(`Unknown panel "${id}" requested by ${ctx.userId}.`);
    await ctx.reply({ content: GENERIC_USER_MESSAGE, flags: MessageFlags.Ephemeral });
    return null;
  }

  const payload = await panel.render({ ctx, params });
  if (!payload) return null;

  const ephemeral = payload.ephemeral ?? panel.ephemeral ?? !panel.public;
  const body = {
    embeds: payload.embeds ?? [],
    components: payload.components ?? [],
    allowedMentions: { parse: [] },
  };
  if (payload.content) body.content = payload.content;
  if (payload.files?.length) body.files = payload.files;
  if (ephemeral) body.flags = MessageFlags.Ephemeral;

  // Update in place when the interaction already owns a message (buttons,
  // selects and modals inside a panel), otherwise send a fresh reply.
  if (!payload.forceNew) {
    if (ctx.isComponent && typeof ctx.interaction.update === 'function') {
      if (ctx.deferred) {
        // Long-running buttons (template apply) defer first; editReply is the
        // only valid follow-up after a deferred component update.
        const deferredBody = { ...body };
        delete deferredBody.flags;
        return ctx.edit(deferredBody);
      }
      return ctx.update(body);
    }
    if (ctx.isModal && ctx.interaction.message && typeof ctx.interaction.update === 'function') {
      // A modal submit must be acknowledged before the panel message can be
      // edited; update() does both and preserves the original ephemerality.
      const updateBody = { ...body };
      delete updateBody.flags;
      return ctx.update(updateBody);
    }
  }

  if (ctx.deferred || ctx.replied) return ctx.edit(body);
  return ctx.reply(body);
}

/** Convenience for panels that only differ by their selected section. */
export function panelNavRow(backPanelId, { disabled = false } = {}) {
  // Imported lazily to avoid a cycle with ui/components.js during module init.
  return { backPanelId, disabled };
}
