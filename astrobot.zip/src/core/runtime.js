/**
 * Process-wide handles set during boot. Panels read RCON connection state
 * through here instead of importing the job graph (which would create cycles).
 */
export const runtime = {
  /** @type {import('discord.js').Client|null} */
  client: null,
  /** @type {object|null} */
  jobs: null,
  /** @type {import('../services/rcon/manager.js').RconManager|null} */
  rconManager: null,
};
