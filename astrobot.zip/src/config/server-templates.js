import { PermissionFlagsBits } from 'discord.js';
import { LIBRARY_PRESETS } from './template-library.js';

/**
 * Predefined server layouts.
 *
 * These ship with the bot so an owner can build a complete Rust community
 * structure without hand-making every role and channel. They use the same
 * payload shape as captured templates, so applyGuildTemplate() treats them
 * exactly like a saved snapshot: additive, matched by name, never destructive.
 */

const bits = (...names) => names.reduce((acc, name) => acc | PermissionFlagsBits[name], 0n).toString();

const CHANNEL_TYPE = Object.freeze({ text: 0, voice: 2, announcement: 5, forum: 15 });

const ADMIN_PERMS = bits('Administrator');
const MOD_PERMS = bits('ModerateMembers', 'KickMembers', 'ManageMessages', 'ViewAuditLog');
const STAFF_PERMS = bits('ManageMessages', 'ModerateMembers');

const OWNER_PERMS = bits(
  'ManageGuild',
  'ManageRoles',
  'ManageChannels',
  'ManageMessages',
  'KickMembers',
  'BanMembers',
  'ModerateMembers',
  'ViewAuditLog',
  'ManageWebhooks',
  'MentionEveryone',
);
const NETWORK_ADMIN_PERMS = bits(
  'ManageGuild',
  'ManageRoles',
  'ManageChannels',
  'ManageMessages',
  'KickMembers',
  'BanMembers',
  'ModerateMembers',
  'ViewAuditLog',
  'ManageWebhooks',
);
const NETWORK_MOD_PERMS = bits('ModerateMembers', 'KickMembers', 'ManageMessages', 'ViewAuditLog');
const SUPPORT_PERMS = bits(
  'ManageMessages',
  'ModerateMembers',
  'ManageThreads',
  'CreatePublicThreads',
  'CreatePrivateThreads',
  'SendMessagesInThreads',
);

// These four roles belong to the official AstroBot guild only. They are
// deliberately excluded from templates applied anywhere else.
export const OFFICIAL_STAFF_ROLES = Object.freeze([
  '👑 AstroBot Owner',
  '🛡️ AstroBot Administrator',
  '🔨 AstroBot Moderator',
  '🎫 Support Team',
]);

// Assigned server staff roles are normal template roles and may be created in
// any community server alongside the premium, kit and community roles.
const STAFF_ROLES = Object.freeze([
  ...OFFICIAL_STAFF_ROLES,
  '🗺️ Server Owner',
  '⚙️ Server Admin',
  '🛡️ Server Moderator',
]);

const VIEW_AND_TALK = bits(
  'ViewChannel',
  'SendMessages',
  'ReadMessageHistory',
  'AttachFiles',
  'EmbedLinks',
  'AddReactions',
);
const READ_ONLY = bits('ViewChannel', 'ReadMessageHistory');

/** Staff can post in announcement-style categories that are read-only for players. */
const READ_ONLY_CATEGORY_OVERWRITES = Object.freeze([
  Object.freeze({ type: 'role', name: '@everyone', allow: READ_ONLY, deny: bits('SendMessages') }),
  ...STAFF_ROLES.map((name) => Object.freeze({ type: 'role', name, allow: VIEW_AND_TALK, deny: '0' })),
]);

/** Hidden from players; visible to every staff tier. */
const STAFF_ONLY_OVERWRITES = Object.freeze([
  Object.freeze({ type: 'role', name: '@everyone', allow: '0', deny: bits('ViewChannel') }),
  ...STAFF_ROLES.map((name) => Object.freeze({ type: 'role', name, allow: VIEW_AND_TALK, deny: '0' })),
]);

const VIP_ONLY_OVERWRITES = Object.freeze([
  Object.freeze({ type: 'role', name: '@everyone', allow: '0', deny: bits('ViewChannel') }),
  ...STAFF_ROLES.map((name) => Object.freeze({ type: 'role', name, allow: VIEW_AND_TALK, deny: '0' })),
  Object.freeze({ type: 'role', name: '💎 VIP', allow: VIEW_AND_TALK, deny: '0' }),
  Object.freeze({ type: 'role', name: 'EliteKit44', allow: VIEW_AND_TALK, deny: '0' }),
]);

const PRO_ONLY_OVERWRITES = Object.freeze([
  Object.freeze({ type: 'role', name: '@everyone', allow: '0', deny: bits('ViewChannel') }),
  ...STAFF_ROLES.map((name) => Object.freeze({ type: 'role', name, allow: VIEW_AND_TALK, deny: '0' })),
  Object.freeze({ type: 'role', name: '👑 ASTRO PRO', allow: VIEW_AND_TALK, deny: '0' }),
]);

const BUSINESS_OVERWRITES = Object.freeze([
  Object.freeze({ type: 'role', name: '@everyone', allow: '0', deny: bits('ViewChannel') }),
  ...STAFF_ROLES.map((name) => Object.freeze({ type: 'role', name, allow: VIEW_AND_TALK, deny: '0' })),
  Object.freeze({ type: 'role', name: '🏢 Business', allow: VIEW_AND_TALK, deny: '0' }),
  Object.freeze({ type: 'role', name: '🎨 Creator', allow: VIEW_AND_TALK, deny: '0' }),
]);

/** @everyone cannot see the staff category. */
const STAFF_CATEGORY_OVERWRITES = Object.freeze([
  Object.freeze({ type: 'role', name: '@everyone', allow: '0', deny: bits('ViewChannel') }),
]);

const role = (name, color, permissions = '0', extra = {}) => ({
  name,
  color: typeof color === 'string' ? Number.parseInt(color.replace('#', ''), 16) : color,
  hoist: false,
  mentionable: false,
  permissions,
  ...extra,
});

const text = (name, parentName, topic = undefined) => ({
  name,
  type: CHANNEL_TYPE.text,
  parentName,
  ...(topic ? { topic } : {}),
});

const announcement = (name, parentName, topic = undefined) => ({
  name,
  type: CHANNEL_TYPE.announcement,
  parentName,
  ...(topic ? { topic } : {}),
});

const voice = (name, parentName, userLimit = 0) => ({ name, type: CHANNEL_TYPE.voice, parentName, userLimit });

const category = (name, overwrites = []) => ({ name, overwrites });

/**
 * Every built-in layout must be usable on its own.
 *
 * The essentials layer fills in the core structure a community needs — not
 * just decorative extras — and reuses an existing equivalent by name pattern
 * so a template with `📜・server-rules` does not also get a second `rules`
 * channel. It is applied to the hand-written presets and the library presets.
 */
const ESSENTIAL_ROLE_SPECS = Object.freeze([
  {
    key: 'admin',
    match: /\b(admin|administrator)s?\b/i,
    fallback: () => role('Admin', 0xe74c3c, NETWORK_ADMIN_PERMS, { hoist: true, mentionable: true }),
  },
  {
    key: 'moderator',
    match: /\b(moderator|mod)s?\b/i,
    fallback: () => role('Moderator', 0xe67e22, MOD_PERMS, { hoist: true }),
  },
  {
    key: 'staff',
    match: /\b(staff|support team|support|manager|producer)\b/i,
    fallback: () => role('Staff', 0x3498db, STAFF_PERMS, { hoist: true }),
  },
  { key: 'member', match: /\bmember\b/i, fallback: () => role('Member', 0x95a5a6) },
]);

const ESSENTIAL_STAFF_MATCH = /\b(owner|admin|administrator|moderator|mod|staff|support|manager|producer|stream team)\b/i;

const ESSENTIAL_CATEGORY_SPECS = Object.freeze([
  {
    key: 'information',
    match: /info|information|start|welcome|rules|announcement|official/i,
    fallback: () => category('Information'),
  },
  {
    key: 'community',
    match: /community|general|chat|lobby|talk/i,
    fallback: () => category('Community'),
  },
  {
    key: 'staff',
    match: /staff|moderation|management|team|operations/i,
    fallback: () => category('Staff', STAFF_CATEGORY_OVERWRITES),
  },
  {
    // Bot operations: the control panel, logs and join/leave feed.
    key: 'operations',
    match: /astrobot|control.panel|bot.operations/i,
    fallback: () => category('🤖 AstroBot Operations'),
  },
]);

const ESSENTIAL_CHANNEL_SPECS = Object.freeze([
  {
    key: 'welcome',
    parent: 'information',
    types: [CHANNEL_TYPE.text],
    match: /welcome|start.here|introductions?/i,
    build: (parent) => text('welcome', parent, 'Welcome to the server — start here.'),
  },
  {
    key: 'rules',
    parent: 'information',
    types: [CHANNEL_TYPE.text],
    match: /rules|guidelines/i,
    build: (parent) => text('rules', parent, 'Community rules. Read before posting.'),
  },
  {
    key: 'announcements',
    parent: 'information',
    types: [CHANNEL_TYPE.text, CHANNEL_TYPE.announcement],
    match: /announcement|news|updates/i,
    build: (parent) => text('announcements', parent, 'Server news, wipes and events.'),
  },
  {
    key: 'general',
    parent: 'community',
    types: [CHANNEL_TYPE.text],
    match: /\b(general|talk)\b|main.chat|community.chat/i,
    build: (parent) => text('general', parent, 'General chat.'),
  },
  {
    key: 'support',
    parent: 'community',
    types: [CHANNEL_TYPE.text],
    match: /\b(support|tickets?)\b/i,
    build: (parent) => text('🎫-create-a-ticket', parent, 'Open a private support ticket with the buttons below.'),
  },
  {
    key: 'shop',
    parent: 'community',
    types: [CHANNEL_TYPE.text],
    match: /\b(shop|store)\b/i,
    build: (parent) => text('shop', parent, 'Buy items, kits and currency with /shop.'),
  },
  {
    key: 'lfg',
    parent: 'community',
    types: [CHANNEL_TYPE.text],
    match: /\b(lfg|looking.for.group|find.a.team|team.find)\b/i,
    build: (parent) => text('🤝-looking-for-group', parent, 'Find teammates and post local or global LFG listings.'),
  },
  {
    key: 'partners',
    parent: 'community',
    types: [CHANNEL_TYPE.text, CHANNEL_TYPE.announcement],
    match: /partner|partnership|collab/i,
    build: (parent) => text('🤝-partners', parent, 'Partnership announcements and cross-server partner updates.'),
  },
  {
    key: 'staff-chat',
    parent: 'staff',
    types: [CHANNEL_TYPE.text],
    match: /staff.chat|team.chat|management.chat|mod.chat|moderator.chat|admin.chat/i,
    build: (parent) => text('staff-chat', parent, 'Staff discussion.'),
  },
  {
    key: 'staff-logs',
    parent: 'staff',
    types: [CHANNEL_TYPE.text],
    match: /staff.logs|mod.logs|moderation.logs|admin.logs|network.logs|bot.logs|audit|security.logs/i,
    build: (parent) => text('staff-logs', parent, 'Moderation and audit log.'),
  },
  {
    key: 'general-voice',
    parent: 'community',
    types: [CHANNEL_TYPE.voice],
    match: /general.(voice|vc)|community.voice/i,
    build: (parent) => voice('General VC', parent),
  },
  {
    key: 'staff-panel',
    parent: 'staff',
    types: [CHANNEL_TYPE.text],
    match: /astrobot.staff|staff.panel|admin.panel/i,
    build: (parent) => text('🛡️-astrobot-staff', parent, 'Staff control panel — every admin tool in one place.'),
  },
  {
    key: 'panel',
    parent: 'operations',
    types: [CHANNEL_TYPE.text],
    match: /astrobot.panel|control.panel|bot.panel|panel/i,
    build: (parent) => ({
      ...text('🤖-astrobot-panel', parent, 'AstroBot control panel — every action without a slash command.'),
      // Read-only for players; AstroBot posts with its own permissions.
      overwrites: [{ type: 'role', name: '@everyone', allow: READ_ONLY, deny: bits('SendMessages') }],
    }),
  },
  {
    key: 'welcome-leave',
    parent: 'operations',
    types: [CHANNEL_TYPE.text],
    match: /welcome.leave|goodbye|leave.log/i,
    build: (parent) => text('welcome-leave', parent, 'Join and leave announcements.'),
  },
]);

/** Staff tiers every layout ships with, so staff channels always resolve. */
const ESSENTIAL_STAFF_ROLE_NAMES = Object.freeze(['Server Owner', 'Server Admin', 'Server Moderator']);

const staffRoleFallback = (name) => {
  if (name === 'Server Owner') return role('Server Owner', 0xf1c40f, OWNER_PERMS, { hoist: true, mentionable: true });
  if (name === 'Server Admin') return role('Server Admin', 0xe74c3c, NETWORK_ADMIN_PERMS, { hoist: true });
  return role('Server Moderator', 0xe67e22, MOD_PERMS, { hoist: true });
};

function addEssentials(template) {
  const payload = template?.payload ?? {};
  const roles = [...(payload.roles ?? [])];
  for (const spec of ESSENTIAL_ROLE_SPECS) {
    if (!roles.some((entry) => spec.match.test(String(entry.name ?? '')))) roles.push(spec.fallback());
  }

  // Staff tiers and kit access roles belong to every layout: staff channels
  // grant them access and the shop hands kits out through them.
  const exactNames = new Set(roles.map((entry) => String(entry.name ?? '').toLowerCase()));
  for (const name of ESSENTIAL_STAFF_ROLE_NAMES) {
    if (exactNames.has(name.toLowerCase())) continue;
    roles.push(staffRoleFallback(name));
    exactNames.add(name.toLowerCase());
  }
  for (const kitRole of KIT_ROLES) {
    if (exactNames.has(kitRole.name.toLowerCase())) continue;
    roles.push({ ...kitRole });
    exactNames.add(kitRole.name.toLowerCase());
  }

  const categories = [...(payload.categories ?? [])];
  const categoryNames = new Map();
  for (const spec of ESSENTIAL_CATEGORY_SPECS) {
    let match = categories.find((entry) => spec.match.test(String(entry.name ?? '')));
    if (!match) {
      match = spec.fallback();
      categories.push(match);
    }
    if (spec.key === 'staff') {
      // Staff channels must be visible to the roles this template creates.
      const overwrites = [...(match.overwrites ?? [])];
      const covered = new Set(overwrites.map((entry) => String(entry.name ?? '').toLowerCase()));
      for (const roleEntry of roles) {
        const name = String(roleEntry.name ?? '');
        if (!name || covered.has(name.toLowerCase()) || !ESSENTIAL_STAFF_MATCH.test(name)) continue;
        overwrites.push({ type: 'role', name, allow: VIEW_AND_TALK, deny: '0' });
        covered.add(name.toLowerCase());
      }
      const index = categories.indexOf(match);
      match = { ...match, overwrites };
      if (index >= 0) categories[index] = match;
    }
    categoryNames.set(spec.key, match.name);
  }

  // The bot's own operations category belongs directly under information, not
  // at the bottom of the sidebar.
  const infoAt = categories.findIndex((entry) => String(entry.name) === categoryNames.get('information'));
  const opsAt = categories.findIndex((entry) => String(entry.name) === categoryNames.get('operations'));
  if (infoAt >= 0 && opsAt > infoAt + 1) categories.splice(infoAt + 1, 0, categories.splice(opsAt, 1)[0]);

  const channels = [...(payload.channels ?? [])];
  const channelNames = new Map();
  for (const spec of ESSENTIAL_CHANNEL_SPECS) {
    const existing = channels.find(
      (entry) => spec.types.includes(entry.type) && spec.match.test(String(entry.name ?? '')),
    );
    if (existing) {
      channelNames.set(spec.key, existing.name);
      continue;
    }
    const channel = spec.build(categoryNames.get(spec.parent));
    channels.push(channel);
    channelNames.set(spec.key, channel.name);
  }

  const panels = [...(payload.panels ?? [])];
  const panelTypes = new Set(
    panels.map((entry) => (String(entry?.type ?? '').toLowerCase() === 'tickets' ? 'support' : String(entry?.type ?? '').toLowerCase())),
  );
  for (const type of ['support', 'shop', 'hub', 'staff-hub']) {
    if (panelTypes.has(type)) continue;
    // Two master panels, two homes: players get the control-panel channel,
    // staff get the staff panel channel.
    const channelName =
      type === 'hub'
        ? channelNames.get('panel') ?? channelNames.get('general')
        : type === 'staff-hub'
          ? channelNames.get('staff-panel') ?? channelNames.get('staff-chat')
          : channelNames.get(type);
    if (!channelName) continue;
    panels.push({ type, channelName });
    panelTypes.add(type);
  }

  const staffRoles = new Set(payload.staffRoles ?? []);
  for (const entry of roles) {
    if (ESSENTIAL_STAFF_MATCH.test(String(entry.name ?? ''))) staffRoles.add(entry.name);
  }

  return {
    ...template,
    payload: { ...payload, roles, categories, channels, panels, staffRoles: [...staffRoles] },
  };
}

function preset({ id, name, description, roles, categories, channels, kits = [], staffRoles = [], panels = [] }) {
  return {
    id: `preset:${id}`,
    name,
    description,
    payload: { version: 1, capturedAt: null, guildName: null, roles, categories, channels, kits, staffRoles, panels },
  };
}

/** Kit access roles; names and hex values are the server's canonical set. */
const KIT_ROLE_COLORS = Object.freeze({
  FreeKit: '#2ECC71',
  FreeKit2: '#27AE60',
  EliteKit1: '#B22222',
  EliteKit2: '#228B22',
  EliteKit3: '#4169E1',
  EliteKit4: '#FF00FF',
  EliteKit5: '#00FF7F',
  EliteKit6: '#FFA500',
  EliteKit7: '#8B0000',
  EliteKit8: '#00FF00',
  EliteKit9: '#0000FF',
  EliteKit10: '#FF69B4',
  EliteKit11: '#A52A2A',
  EliteKit12: '#00FFFF',
  EliteKit13: '#FF4500',
  EliteKit14: '#6A5ACD',
  EliteKit15: '#FFFF00',
  EliteKit16: '#2E8B57',
  EliteKit17: '#8B008B',
  EliteKit18: '#20B2AA',
  EliteKit19: '#D2691E',
  EliteKit20: '#F08080',
  EliteKit21: '#4682B4',
  EliteKit22: '#EE82EE',
  EliteKit23: '#DC143C',
  EliteKit24: '#008080',
  EliteKit25: '#DA70D6',
  EliteKit26: '#7FFF00',
  EliteKit27: '#FF8C00',
  EliteKit28: '#9932CC',
  EliteKit29: '#3CB371',
  EliteKit30: '#6495ED',
  EliteKit31: '#FF1493',
  EliteKit32: '#CD5C5C',
  EliteKit33: '#40E0D0',
  EliteKit34: '#BA55D3',
  EliteKit35: '#ADFF2F',
  EliteKit36: '#1E90FF',
  EliteKit37: '#FF6347',
  EliteKit38: '#8A2BE2',
  EliteKit39: '#7CFC00',
  EliteKit40: '#00CED1',
  EliteKit41: '#FF7F50',
  EliteKit42: '#9370DB',
  EliteKit43: '#32CD32',
  EliteKit44: '#00BFFF',
});

const KIT_ROLES = Object.freeze(
  Object.entries(KIT_ROLE_COLORS).map(([name, color]) => role(name, color)),
);

export const KIT_ROLE_NAMES = Object.freeze(Object.keys(KIT_ROLE_COLORS));
export const STAFF_ROLE_NAMES = STAFF_ROLES;

const BASE_PRESETS = Object.freeze([
  preset({
    id: 'rust-community',
    name: 'Rust Console Community',
    description: 'Full community layout: rules, announcements, killfeed, shop, clans and staff areas.',
    roles: [
      role('Admin', 0xe74c3c, ADMIN_PERMS, { hoist: true, mentionable: true }),
      role('Moderator', 0xe67e22, MOD_PERMS, { hoist: true }),
      role('Staff', 0x3498db, STAFF_PERMS, { hoist: true }),
      role('Rust Player', 0x2ecc71),
      role('Clan Leader', 0x9b59b6),
      role('Member', 0x95a5a6),
    ],
    staffRoles: ['Admin', 'Moderator', 'Staff'],
    panels: [
      { type: 'shop', channelName: 'shop' },
    ],
    categories: [
      category('Information'),
      category('Rust Server'),
      category('Community'),
      category('Clans'),
      category('Staff', STAFF_CATEGORY_OVERWRITES),
    ],
    channels: [
      text('welcome', 'Information', 'Welcome to the server — start here.'),
      announcement('announcements', 'Information', 'Server news, wipes and events.'),
      text('rules', 'Information', 'Community rules. Read before posting.'),
      text('server-info', 'Rust Server', 'Connection details, wipe schedule and server settings.'),
      text('wipe-schedule', 'Rust Server', 'Upcoming wipes and map changes.'),
      text('killfeed', 'Rust Server', 'Live killfeed from the Rust server.'),
      text('shop', 'Rust Server', 'Buy items, kits and currency with /shop.'),
      text('general', 'Community', 'General chat.'),
      text('clips', 'Community', 'Share your best plays.'),
      text('suggestions', 'Community', 'Ideas for the server and community.'),
      text('clan-recruitment', 'Clans', 'Clans recruiting players.'),
      text('team-logs', 'Clans', 'Clan and team activity log.'),
      text('staff-chat', 'Staff', 'Staff discussion.'),
      text('staff-logs', 'Staff', 'Moderation and audit log.'),
      voice('General VC', 'Community'),
      voice('Raid VC', 'Rust Server'),
      voice('Staff VC', 'Staff'),
    ],
  }),
  preset({
    id: 'wipe-server',
    name: 'Rust Wipe Server',
    description: 'Server-first layout for a wipe community: info, wipe schedule, killfeed, shop and chat.',
    roles: [
      role('Admin', 0xe74c3c, ADMIN_PERMS, { hoist: true, mentionable: true }),
      role('Moderator', 0xe67e22, MOD_PERMS, { hoist: true }),
      role('Rust Player', 0x2ecc71),
    ],
    staffRoles: ['Admin', 'Moderator'],
    panels: [
      { type: 'shop', channelName: 'shop' },
    ],
    categories: [category('Server'), category('Community')],
    channels: [
      text('server-info', 'Server', 'Host, port, wipe schedule and rules.'),
      text('wipe-schedule', 'Server', 'Next wipe and map details.'),
      text('killfeed', 'Server', 'Live killfeed.'),
      text('shop', 'Server', 'Server shop and kits.'),
      text('general', 'Community', 'General chat.'),
      voice('General VC', 'Community'),
    ],
  }),
  preset({
    id: 'minimal',
    name: 'Minimal Starter',
    description: 'Small layout for a new server: welcome, rules, general chat and one voice channel.',
    roles: [role('Staff', 0x3498db, STAFF_PERMS, { hoist: true }), role('Member', 0x95a5a6)],
    staffRoles: ['Staff'],
    categories: [category('Information'), category('Community')],
    channels: [
      text('welcome', 'Information', 'Say hello.'),
      text('rules', 'Information', 'Community rules.'),
      text('general', 'Community', 'General chat.'),
      voice('General VC', 'Community'),
    ],
  }),
  preset({
    id: 'astrobot-network',
    name: 'AstroBot Network',
    description:
      'AstroBot network layout: official leadership (created only in the official guild), assigned server staff, premium tiers, partners, community and kit access roles.',
    roles: [
      role('👑 AstroBot Owner', '#B300FF', OWNER_PERMS, { hoist: true, mentionable: true }),
      role('🛡️ AstroBot Administrator', '#00CC66', NETWORK_ADMIN_PERMS, { hoist: true, mentionable: true }),
      role('🔨 AstroBot Moderator', '#0099FF', NETWORK_MOD_PERMS, { hoist: true }),
      role('🎫 Support Team', '#FF1493', SUPPORT_PERMS, { hoist: true }),
      role('🗺️ Server Owner', '#FF4500', bits('ManageChannels', 'ManageRoles', 'ManageMessages', 'ViewAuditLog', 'ManageWebhooks'), { hoist: true, mentionable: true }),
      role('⚙️ Server Admin', '#2ECC71', bits('ManageChannels', 'ManageMessages', 'KickMembers', 'ViewAuditLog', 'ManageWebhooks'), { hoist: true }),
      role('🛡️ Server Moderator', '#9B59B6', bits('KickMembers', 'ModerateMembers', 'ManageMessages', 'ViewAuditLog')),
      role('👑 ASTRO PRO', '#1E90FF', '0', { hoist: true }),
      role('💎 VIP', '#00FFFF'),
      role('💰 Donator', '#00FF7F'),
      role('🏢 Business', '#FF7A00'),
      role('🎨 Creator', '#FF69B4'),
      role('🎮 Verified Player', '#FFFFFF'),
      role('👤 Member', '#A52A2A'),
      role('🔇 Muted', '#2C3E50'),
      role('🤖 AstroBot', '#4682B4'),
      ...KIT_ROLES,
    ],
    staffRoles: [...STAFF_ROLES],
    panels: [{ type: 'support', channelName: '🎫-create-a-ticket' }],
    categories: [
      category('📜・info', READ_ONLY_CATEGORY_OVERWRITES),
      category('📡・global-status', READ_ONLY_CATEGORY_OVERWRITES),
      category('🗺️・rust-server'),
      category('🌐・astro-network'),
      category('⚔️・astro-rivals'),
      category('🛡️・astro-staff', STAFF_ONLY_OVERWRITES),
    ],
    channels: [
      text('👋・welcome', '📜・info', 'Automatic welcome messages and AstroBot ecosystem links.'),
      text('📜・astro-rules', '📜・info', 'Complete community rules.'),
      text('📖・how-to-play', '📜・info', 'Account linking, AstroBot commands and tutorials.'),
      text('🔗・link-account', '📜・info', 'Connect your console account to AstroBot with /link.'),
      announcement('📢・announcements', '📜・info', 'Official AstroBot network announcements.'),
      text('🗓️・wipe-schedule', '📜・info', 'Wipe schedules, ORP and raid rules.'),
      text('🌐・astro-links', '📜・info', 'Official website and dashboard links.'),
      text(
        '🌐｜⏰・global-players-queue',
        '📡・global-status',
        'Combined live player population and queue information across all connected AstroBot Rust Console servers.',
      ),
      text(
        '🌐・global-killfeed',
        '📡・global-status',
        'Combined killfeed from every connected AstroBot Rust server, validated and updated every 5 seconds.',
      ),
      text('🌐｜⏰・players-queue', '🗺️・rust-server', 'Combined live server population and player queue.'),
      text('💀・killfeed', '🗺️・rust-server', 'Server-specific PvP killfeed.'),
      text('⚠️・raid-alerts', '🗺️・rust-server', 'Server-specific RaidLink alerts.'),
      text('👋・talk', '🗺️・rust-server', 'General player chat for this server.'),
      text('🏆・leaderboard', '🗺️・rust-server', 'Server-specific player rankings.'),
      {
        ...text('💎・vip-chat', '🗺️・rust-server', 'Restricted to this server\'s VIP and EliteKit44 roles.'),
        overwrites: VIP_ONLY_OVERWRITES,
      },
      { ...text('🙋・player-feed', '🗺️・rust-server', 'Live player activity feed.'), overwrites: STAFF_ONLY_OVERWRITES },
      { ...text('📔・note-feed', '🗺️・rust-server', 'Player notes, records and ban histories.'), overwrites: STAFF_ONLY_OVERWRITES },
      { ...text('🚨・zorp-feed', '🗺️・rust-server', 'Zoned Offline Raid Protection activity feed.'), overwrites: STAFF_ONLY_OVERWRITES },
      { ...text('❗・admin-feed', '🗺️・rust-server', 'Administrative events and RCON overrides.'), overwrites: STAFF_ONLY_OVERWRITES },
      { ...text('🛡️・admin-chat', '🗺️・rust-server', 'Internal administrator communication.'), overwrites: STAFF_ONLY_OVERWRITES },
      { ...text('✨・mod-chat', '🗺️・rust-server', 'Moderator communication.'), overwrites: STAFF_ONLY_OVERWRITES },
      { ...text('👑・map-owner-commands', '🗺️・rust-server', 'Map owner commands.'), overwrites: STAFF_ONLY_OVERWRITES },
      { ...text('⚙️・map-admin-commands', '🗺️・rust-server', 'Map admin commands.'), overwrites: STAFF_ONLY_OVERWRITES },
      { ...text('🔨・map-mod-commands', '🗺️・rust-server', 'Map moderator commands.'), overwrites: STAFF_ONLY_OVERWRITES },
      text('👤・player-profiles', '🌐・astro-network', 'AstroBot player identities and master profiles.'),
      text('🔗・account-activity', '🌐・astro-network', 'Account linking confirmations and validation logs.'),
      text('📊・astro-rank', '🌐・astro-network', 'Astro Score, XP tracking and progression badges.'),
      text('⚔️・challenges', '🌐・astro-network', '1v1 wagered challenge activity.'),
      text('🎮・game-activity', '🌐・astro-network', 'Supported game activity and mini-game milestones.'),
      text('💰・SHOP', '🌐・astro-network', 'Coins, wallet and the server store.'),
      text('🎁・rewards', '🌐・astro-network', 'Playtime rewards and daily streak bonuses.'),
      text('🎟️・referrals', '🌐・astro-network', 'Referral codes and leaderboard tracking.'),
      text('🥊・rivals', '⚔️・astro-rivals', 'Global rival activity and combat pairings.'),
      text('📈・ranking-movement', '⚔️・astro-rivals', 'Player Astro Score ranking adjustments.'),
      text('🏅・competitions', '⚔️・astro-rivals', 'Competitive events and tournaments.'),
      text('🔥・wars', '⚔️・astro-rivals', 'Active inter-clan wars and team matchups.'),
      text('🎯・challenge-results', '⚔️・astro-rivals', 'Verified 1v1 challenge results.'),
      text('📣・rivals-updates', '⚔️・astro-rivals', 'Competitive announcements.'),
      { ...text('👑・astro-owner-commands', '🛡️・astro-staff', 'Network owner control overrides.'), overwrites: STAFF_ONLY_OVERWRITES },
      { ...text('🛡️・astro-admin-commands', '🛡️・astro-staff', 'Bot infrastructure and licensing tools.'), overwrites: STAFF_ONLY_OVERWRITES },
      { ...text('🔨・astro-mod-commands', '🛡️・astro-staff', 'Cross-server penalty and enforcement tools.'), overwrites: STAFF_ONLY_OVERWRITES },
      text('💬・staff-chat', '🛡️・astro-staff', 'General network staff discussions.'),
      text('📢・staff-announcements', '🛡️・astro-staff', 'Internal operational updates.'),
      text('📊・bot-logs', '🛡️・astro-staff', 'Global slash command audit history.'),
      text('🚨・system-alerts', '🛡️・astro-staff', 'RCON stability monitoring and socket status alerts.'),
      text('🔐・security-logs', '🛡️・astro-staff', 'Database security events.'),
      text('⚠️・fraud-flags', '🛡️・astro-staff', 'Suspicious referral activity and balance adjustments.'),
      text('📔・staff-notes', '🛡️・astro-staff', 'Internal staff performance records.'),
    ],
  }),
  ...LIBRARY_PRESETS,
].map(addEssentials));

/**
 * The official AstroBot layout.
 *
 * It is the network structure plus the leadership roles that only exist in the
 * official guild. Applying it anywhere else skips those four roles, exactly as
 * every other layout does.
 */
const networkPreset = BASE_PRESETS.find((entry) => entry.id === 'preset:astrobot-network');
const networkRoles = networkPreset?.payload.roles ?? [];

// The official guild gets a permanent feature guide. It is appended to the
// network layout rather than the shared preset so community servers do not
// inherit an official-only channel.
const OFFICIAL_FEATURES_CHANNEL = '✨・astro-features';
const officialChannels = [...(networkPreset?.payload.channels ?? [])];
if (!officialChannels.some((entry) => entry.name === OFFICIAL_FEATURES_CHANNEL)) {
  const after = officialChannels.findIndex((entry) => String(entry.name).includes('how-to-play'));
  officialChannels.splice(after >= 0 ? after + 1 : 0, 0, text(
    OFFICIAL_FEATURES_CHANNEL,
    '📜・info',
    'Every AstroBot feature: economy, giveaways, polls, analytics, games, teams, templates and the Astro Pro portal.',
  ));
}
const officialPanels = [...(networkPreset?.payload.panels ?? [])];
if (!officialPanels.some((entry) => entry.type === 'features')) {
  officialPanels.push({ type: 'features', channelName: OFFICIAL_FEATURES_CHANNEL });
}

const OFFICIAL_PRESET = addEssentials({
  id: 'preset:astro-official',
  name: 'AstroBot Official',
  description: 'The official AstroBot guild: leadership roles, the full network structure and every panel.',
  payload: {
    version: 1,
    capturedAt: null,
    guildName: 'AstroBot Official',
    roles: [
      ...networkRoles,
      ...[
        role('👑 AstroBot Owner', 0xf1c40f, OWNER_PERMS, { hoist: true, mentionable: true }),
        role('🛡️ AstroBot Administrator', 0xe74c3c, NETWORK_ADMIN_PERMS, { hoist: true }),
        role('🔨 AstroBot Moderator', 0xe67e22, NETWORK_MOD_PERMS, { hoist: true }),
        role('🎫 Support Team', 0x3498db, SUPPORT_PERMS, { hoist: true }),
      ].filter((entry) => !networkRoles.some((existing) => existing.name === entry.name)),
    ],
    categories: networkPreset?.payload.categories ?? [],
    channels: officialChannels,
    kits: networkPreset?.payload.kits ?? [],
    panels: officialPanels,
    staffRoles: [...new Set([...(networkPreset?.payload.staffRoles ?? []), ...OFFICIAL_STAFF_ROLES])],
  },
});

export const TEMPLATE_PRESETS = Object.freeze([OFFICIAL_PRESET, ...BASE_PRESETS]);

/**
 * Resolves a preset by its id, with or without the `preset:` prefix.
 *
 * Discord custom ids cannot contain `:`, so buttons built from `preset:name`
 * arrive back as `preset-name`. Accept both forms.
 */
export function getPresetTemplate(id) {
  const key = String(id ?? '').trim();
  const bare = key.replace(/^preset[:\-]/i, '');
  return TEMPLATE_PRESETS.find((entry) => entry.id === key || entry.id === `preset:${bare}`) ?? null;
}


export function presetSummary(template) {
  const payload = template.payload ?? {};
  return `${payload.roles?.length ?? 0} roles · ${payload.categories?.length ?? 0} categories · ${payload.channels?.length ?? 0} channels`;
}
