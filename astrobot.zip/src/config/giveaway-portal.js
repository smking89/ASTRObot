/**
 * Defaults for the subscriber giveaway portal.
 *
 * The palette intentionally stays on the BattleDrop-style cyan/magenta/lime
 * palette the desktop prototype used; only the brand and product move to Astro.
 */
export const DEFAULT_PORTAL_CONFIG = Object.freeze({
  brand: 'Astro',
  kicker: 'Live Giveaway · Winner announced on stream',
  headlineMain: "Don't Miss Your Shot At",
  headlineAccent: 'The Prize',
  subheadline:
    'Enter for your chance to win. Complete bonus tasks to earn extra entries before the timer runs out.',
  fomoBar: 'Entries close the instant the timer hits zero — no extensions, no exceptions.',
  footerText: '© {year} {brand} · All rights reserved.',
  logoUrl: '',
  logoWidth: 140,
  endTimestamp: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
  colors: {
    bg: '#07070d',
    cyan: '#00f0ff',
    magenta: '#ff2ec4',
    lime: '#c6ff3d',
    ink: '#eef0f8',
  },
  prize: {
    tag: 'Grand Prize',
    title: 'Giveaway Prize',
    value: '',
    imageUrl: '',
    items: [],
  },
  tasks: [
    { title: 'Enter with your Discord account', subtitle: 'Your base entry — required to qualify', points: 1, icon: 'discord', url: '' },
    { title: 'Follow on Twitch', subtitle: 'The live draw happens on stream', points: 5, icon: 'twitch', url: 'https://twitch.tv/' },
    { title: 'Join the Discord', subtitle: 'Members-only drops and early reveals', points: 10, icon: 'discord', url: 'https://discord.gg/' },
    { title: 'Follow on X', subtitle: 'Winner announcements post there first', points: 5, icon: 'x', url: 'https://x.com/' },
  ],
  stats: {
    entryCountStart: 0,
    winners: 1,
  },
  faqEnabled: true,
  faq: [
    {
      question: 'Do I really not have to pay anything?',
      answer: 'Correct — entry is 100% free. No purchase is ever necessary to enter or win.',
    },
    {
      question: 'How is the winner picked?',
      answer: "Every completed task adds weighted entries into a live, on-stream random draw. More entries = better odds, not a guarantee — it's still a raffle.",
    },
    {
      question: 'When do entries close?',
      answer: 'The instant the countdown above hits zero. There are no extensions and no late entries, regardless of task completion status.',
    },
    {
      question: 'How will I know if I won?',
      answer: 'Winners are announced live on stream and contacted via the email and gamertag, PSN ID or Steam username submitted at entry. Check the Discord #winners channel too.',
    },
  ],
  links: {
    discord: 'https://discord.gg/',
    website: '',
  },
  sections: {
    prize: true,
    tasks: true,
    countdown: true,
    ticker: true,
    glow: true,
  },
});

const clone = (value) => JSON.parse(JSON.stringify(value));
const isObject = (value) => value && typeof value === 'object' && !Array.isArray(value);
const limited = (value, max, fallback = '') => String(value ?? fallback).trim().slice(0, max);

const HEX = /^#[0-9a-f]{6}$/i;
const safeColor = (value, fallback) => (HEX.test(String(value ?? '')) ? String(value) : fallback);
const safeUrl = (value, fallback = '') => {
  const text = String(value ?? '').trim();
  if (!text) return fallback;
  return /^https?:\/\//i.test(text) || /^data:image\//i.test(text) ? text : fallback;
};

export function normalizePortalConfig(input) {
  const defaults = clone(DEFAULT_PORTAL_CONFIG);
  const value = isObject(input) ? input : {};
  const colors = isObject(value.colors) ? value.colors : {};
  const prize = isObject(value.prize) ? value.prize : {};
  const stats = isObject(value.stats) ? value.stats : {};
  const links = isObject(value.links) ? value.links : {};
  const sections = isObject(value.sections) ? value.sections : {};
  const timestamp = new Date(value.endTimestamp ?? defaults.endTimestamp);

  const tasks = Array.isArray(value.tasks) ? value.tasks : defaults.tasks;
  const items = Array.isArray(prize.items) ? prize.items : defaults.prize.items;
  const faq = Array.isArray(value.faq) ? value.faq : defaults.faq;

  return {
    brand: limited(value.brand, 40, defaults.brand) || defaults.brand,
    kicker: limited(value.kicker, 120, defaults.kicker),
    headlineMain: limited(value.headlineMain, 120, defaults.headlineMain),
    headlineAccent: limited(value.headlineAccent, 120, defaults.headlineAccent),
    subheadline: limited(value.subheadline, 500, defaults.subheadline),
    fomoBar: limited(value.fomoBar, 240, defaults.fomoBar),
    footerText: limited(value.footerText, 240, defaults.footerText),
    logoUrl: safeUrl(value.logoUrl, defaults.logoUrl),
    logoWidth: Math.max(60, Math.min(320, Number(value.logoWidth) || defaults.logoWidth)),
    endTimestamp: Number.isNaN(timestamp.getTime()) ? defaults.endTimestamp : timestamp.toISOString(),
    colors: {
      bg: safeColor(colors.bg, defaults.colors.bg),
      cyan: safeColor(colors.cyan, defaults.colors.cyan),
      magenta: safeColor(colors.magenta, defaults.colors.magenta),
      lime: safeColor(colors.lime, defaults.colors.lime),
      ink: safeColor(colors.ink, defaults.colors.ink),
    },
    prize: {
      tag: limited(prize.tag, 40, defaults.prize.tag),
      title: limited(prize.title, 120, defaults.prize.title),
      value: limited(prize.value, 40, defaults.prize.value),
      imageUrl: safeUrl(prize.imageUrl, defaults.prize.imageUrl),
      items: items
        .map((item) => limited(item, 180))
        .filter(Boolean)
        .slice(0, 12),
    },
    tasks: tasks
      .filter(isObject)
      .map((task) => ({
        title: limited(task.title, 80),
        subtitle: limited(task.subtitle, 120),
        points: Math.max(0, Math.min(1000, Number(task.points) || 0)),
        icon: limited(task.icon, 20, 'link'),
        url: safeUrl(task.url, ''),
      }))
      .filter((task) => task.title)
      .slice(0, 12),
    stats: {
      entryCountStart: Math.max(0, Math.min(100_000_000, Number(stats.entryCountStart) || defaults.stats.entryCountStart)),
    },
    faq: faq
      .filter(isObject)
      .map((item) => ({
        question: limited(item.question, 180),
        answer: limited(item.answer, 1200),
      }))
      .filter((item) => item.question && item.answer)
      .slice(0, 12),
    faqEnabled: value.faqEnabled !== false,
    links: {
      discord: safeUrl(links.discord, defaults.links.discord),
      website: safeUrl(links.website, defaults.links.website),
    },
    sections: {
      prize: sections.prize !== false,
      tasks: sections.tasks !== false,
      countdown: sections.countdown !== false,
      ticker: sections.ticker !== false,
      glow: sections.glow !== false,
    },
  };
}
