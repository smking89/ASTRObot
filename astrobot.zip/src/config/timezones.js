import { formatTimeZone } from '../utils/timezone.js';

/** Common IANA zones offered by Discord selects (25-option limit). */
export const COMMON_TIME_ZONES = Object.freeze([
  { label: 'UTC', value: 'UTC' },
  { label: 'Europe/London', value: 'Europe/London' },
  { label: 'Europe/Dublin', value: 'Europe/Dublin' },
  { label: 'Europe/Lisbon', value: 'Europe/Lisbon' },
  { label: 'Europe/Paris', value: 'Europe/Paris' },
  { label: 'Europe/Berlin', value: 'Europe/Berlin' },
  { label: 'Europe/Madrid', value: 'Europe/Madrid' },
  { label: 'Europe/Rome', value: 'Europe/Rome' },
  { label: 'Europe/Amsterdam', value: 'Europe/Amsterdam' },
  { label: 'Europe/Warsaw', value: 'Europe/Warsaw' },
  { label: 'Europe/Stockholm', value: 'Europe/Stockholm' },
  { label: 'Europe/Athens', value: 'Europe/Athens' },
  { label: 'Europe/Moscow', value: 'Europe/Moscow' },
  { label: 'America/New_York', value: 'America/New_York' },
  { label: 'America/Chicago', value: 'America/Chicago' },
  { label: 'America/Denver', value: 'America/Denver' },
  { label: 'America/Los_Angeles', value: 'America/Los_Angeles' },
  { label: 'America/Toronto', value: 'America/Toronto' },
  { label: 'America/Sao_Paulo', value: 'America/Sao_Paulo' },
  { label: 'Asia/Dubai', value: 'Asia/Dubai' },
  { label: 'Asia/Kolkata', value: 'Asia/Kolkata' },
  { label: 'Asia/Singapore', value: 'Asia/Singapore' },
  { label: 'Asia/Tokyo', value: 'Asia/Tokyo' },
  { label: 'Australia/Sydney', value: 'Australia/Sydney' },
]);

/** Guild default first, then the common zones, capped at Discord's 25 options. */
export function timeZoneOptions(guildZone) {
  const zone = formatTimeZone(guildZone);
  return [
    {
      label: `Guild default (${zone})`,
      value: '__guild__',
      description: "Use the server's current announcement timezone",
    },
    ...COMMON_TIME_ZONES.filter((entry) => entry.value !== zone),
  ].slice(0, 25);
}
