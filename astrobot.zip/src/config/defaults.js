import { env } from './env.js';

/**
 * Default guild settings. Every configurable panel edits a path inside this
 * object; stored values are deep-merged over these defaults, so adding a new
 * setting never breaks an existing guild.
 */
export const DEFAULT_GUILD_SETTINGS = Object.freeze({
  access: {
    staffRoleIds: [],
    adminRoleIds: [],
    restrictedRoleIds: [],
    // When true, Administrator alone no longer satisfies the restricted tier.
    strictRestricted: false,
    teamRoleIds: [],
  },

  channels: {
    killfeed: null,
    globalKillfeed: null,
    telemetry: null,
    joins: null,
    raids: null,
    modLog: null,
    staffApps: null,
    broadcasts: null,
    tickets: null,
    lfg: null,
    welcome: null,
  },

  economy: {
    currency: 'coins',
    // local = this guild only, global = every guild using the bot, partner =
    // only guilds linked through an accepted partnership.
    scope: 'local',
    partnerNetworkId: null,
    // Minted currency cannot be handed out manually. Only the sources below may
    // create it; owners configure which events and games are allowed to mint.
    minted: false,
    mintSources: {
      games: true,
      events: true,
      daily: true,
      kills: true,
      playtime: true,
      shop: true,
      other: false,
    },
    walletCap: 1_000_000,
    bankCap: 5_000_000,
    transferFeePercent: 0,
    deathPenaltyPercent: env.economy.deathPenaltyPercent,
    killRewardPlayer: 50,
    killRewardScientist: 15,
    playtimeReward: env.economy.playtimeReward,
    boosterMultiplier: env.economy.nitroBoosterMultiplier,
    dailyStreakBase: 100,
    referralBonus: 250,
    bountyMinimum: 100,
    // Global wallet + bank volume that flags the circulation matrix crimson.
    circulationAlert: 5_000_000,
    // Staff channel that receives a one-shot alert when the threshold is crossed.
    circulationAlertChannelId: null,
  },

  // Daily login streak, fully owned by the server. Each day can pay coins, a
  // kit, a role, or any mix; the badge is awarded when a player finishes day 7.
  streak: {
    enabled: true,
    requiredRoleId: null,
    minLevel: 0,
    graceHours: 48,
    badgeId: null,
    rewards: [
      { day: 1, coins: 100, kit: null, roleId: null, label: 'Coins drop' },
      { day: 2, coins: 125, kit: null, roleId: null, label: 'Bonus coins' },
      { day: 3, coins: 150, kit: null, roleId: null, label: 'Arcade pass' },
      { day: 4, coins: 175, kit: null, roleId: null, label: 'Playtime boost' },
      { day: 5, coins: 200, kit: null, roleId: null, label: 'Bounty shield' },
      { day: 6, coins: 225, kit: null, roleId: null, label: 'Lucky key' },
      { day: 7, coins: 300, kit: null, roleId: null, label: 'Weekly jackpot' },
    ],
  },

  games: {
    enabled: true,
    minWager: 1,
    maxWager: 100_000,
    soloEnabled: true,
    multiplayerEnabled: true,
    jackpot: {
      seed: 2_500,
      min: 2_500,
      rakePercent: 2,
      // Announce once whenever the pool crosses this balance. 0 disables alerts.
      milestoneThreshold: 10_000,
      milestoneChannelId: null,
      odds: { slots: 4_000, wheel: 3_000, crash: 2_500 },
      // Three-place ticket raffle. Ticket purchases fund the raffle pool.
      raffle: {
        enabled: true,
        prizeMode: 'pool',
        prizes: { first: 5_000, second: 2_500, third: 1_000 },
        poolShares: { first: 50, second: 30, third: 20 },
        tiers: [
          { id: 'bronze', label: 'Bronze', cost: 100, entries: 1 },
          { id: 'silver', label: 'Silver', cost: 250, entries: 3 },
          { id: 'gold', label: 'Gold', cost: 500, entries: 7 },
        ],
      },
    },
    // Optional random bonus pools. Disabled by default; when enabled, a win in
    // that game credits one randomly selected amount from its configured list.
    prizePools: {
      blackjack: { enabled: false, prizes: [] },
      uno: { enabled: false, prizes: [] },
      dice: { enabled: false, prizes: [] },
      slots: { enabled: false, prizes: [] },
      wheel: { enabled: false, prizes: [] },
      tower: { enabled: false, prizes: [] },
      mines: { enabled: false, prizes: [] },
      crash: { enabled: false, prizes: [] },
      plinko: { enabled: false, prizes: [] },
      roulette: { enabled: false, prizes: [] },
      lootbox: { enabled: false, prizes: [] },
      defuse: { enabled: false, prizes: [] },
      minefield: { enabled: false, prizes: [] },
      ticket: { enabled: false, prizes: [] },
      recycler: { enabled: false, prizes: [] },
      range: { enabled: false, prizes: [] },
      'scratch-radiation': { enabled: false, prizes: [] },
      'scratch-voltage': { enabled: false, prizes: [] },
      'scratch-royal': { enabled: false, prizes: [] },
      'scratch-scrap': { enabled: false, prizes: [] },
      coinflip: { enabled: false, prizes: [] },
    },
    solo: {
      blackjack: true,
      uno: true,
      dice: true,
      slots: true,
      wheel: true,
      tower: true,
      mines: true,
      crash: true,
      plinko: true,
      roulette: true,
      lootbox: true,
      defuse: true,
      minefield: true,
      ticket: true,
      recycler: true,
      range: true,
      'scratch-radiation': true,
      'scratch-voltage': true,
      'scratch-royal': true,
      'scratch-scrap': true,
    },
    multiplayer: {
      dice: true,
      coinflip: true,
    },
  },

  shop: {
    enabled: true,
    sales: [],
    products: [],
    // Staff channel warned when a limited product sells out or runs low.
    stockAlertChannelId: null,
    lowStockThreshold: 3,
    // Stock new products start with: null = unlimited, a number = that many.
    defaultStock: null,
    // Days of stock history kept before the maintenance sweep prunes it.
    stockHistoryDays: 30,
    // Warn when a timer-bound product has not moved stock in this many hours.
    stallAlertHours: 72,
    // Extra currency names offered by the quick setup builder.
    currencies: [],
    // Multipliers applied to catalog-derived base prices by the quick setup.
    priceTiers: { cheap: 0.6, mid: 1, expensive: 2 },
    // Delivers catalog items to the buyer's linked gamertag through RCON.
    itemCommand: 'inventory.giveto "{user}" "{shortname}" {quantity}',
  },

  marketplace: {
    enabled: false,
    // Blank uses economy.currency. The marketplace shares the economy wallet;
    // this label names the currency shown on listings and receipts.
    currency: '',
    feePercent: 5,
    // Delivery lock for kits and roles. 0 disables the lock.
    lockMinutes: 1,
    listingHours: 48,
    minBidIncrement: 10,
    modes: { buyNow: true, bid: true, sale: true },
    allowItems: true,
    allowKits: true,
    allowRoles: true,
    vip: {
      enabled: false,
      roleId: null,
      currency: '',
      feePercent: 2,
      discountPercent: 15,
    },
    announcementChannelId: null,
  },

  onboarding: {
    enabled: true,
    welcome: {
      enabled: true,
      channelId: null,
      title: 'Welcome to {server}!',
      message: 'Welcome {user} — you are member #{memberCount}. Read the rules and say hello!',
      dm: false,
      dmMessage: 'Welcome to {server}, {user}! Read the rules in the server to get started.',
      imageUrl: '',
      color: '#8b5cf6',
    },
    autoroles: {
      enabled: false,
      roleIds: [],
      delaySeconds: 0,
    },
    borderwall: {
      enabled: false,
      channelId: null,
      verifiedRoleId: null,
      timeoutMinutes: 10,
      kick: false,
      message: 'Press the button below to verify you are human and unlock the server.',
    },
    leaver: {
      enabled: false,
      channelId: null,
      message: '**{user}** left the server. We will keep the lights on.',
    },
    rulesOnJoin: { enabled: false, dm: false },
    analytics: { enabled: true },
    tempChannels: {
      enabled: false,
      hubChannelId: null,
      categoryId: null,
      name: "{username}'s channel",
      userLimit: 0,
    },
    freeroles: { enabled: false, channelId: null, roleIds: [], maxRoles: 1 },
    giveaways: {
      enabled: true,
      channelId: null,
      defaultHours: 24,
      defaultWinners: 1,
      // Portal entry links are issued from Discord with /giveaway-entry and are
      // recorded against the same giveaway as the Enter button.
      portalEntries: true,
      // Where the draw is announced. Blank reuses the giveaway channel.
      winnerChannelId: null,
      winnerMessage: '🎉 **{winners}** won **{prize}**!',
      announceInGame: false,
      gameWinnerMessage: '{winners} won {prize}!',
    },
    polls: { enabled: true, channelId: null, defaultHours: 24 },
    reactionRoles: { enabled: false, channelId: null, entries: [] },
    timeRoles: { enabled: false, entries: [] },
  },

  killfeed: {
    enabled: true,
    globalEnabled: true,
    // Embeds can attach the killer's real rank badge icon.
    embed: false,
    showNpc: false,
    rewardCoins: 5,
    layout:
      '💀 **{killer}** [{killer_clan}] eliminated **{victim}** [{victim_clan}] with **{weapon}** · {distance}m · Grid {grid}',
    globalLayout:
      '🌐 **{server}** · **{killer}** [{killer_clan}] eliminated **{victim}** [{victim_clan}] with **{weapon}** · {distance}m · Grid {grid}',
  },

  orp: {
    zorpEnabled: true,
    zorpDamageReduction: 75,
    zorpGraceMinutes: 10,
    srpEnabled: false,
    // Windows: [{ days: [0..6], startHour: 18, endHour: 23, timezone: 'UTC' }]
    srpWindows: [],
    raidLinkEnabled: true,
    raidLinkMinDamage: 50,
  },

  telemetry: {
    joins: true,
    leaves: true,
    browserStatus: true,
    pveEvents: true,
    adminOverrides: true,
    deaths: false,
  },

  battlePass: {
    enabled: true,
    tiers: 100,
    xpPerTier: 1000,
    // Premium is sold for real money through the owner's store page or a
    // Tip4Serv product. Coins cannot buy premium unless explicitly enabled.
    premium: {
      priceLabel: '$4.99',
      // Checkout page on the server owner's website (or Tip4Serv store page).
      checkoutUrl: '',
      // Tip4Serv product id the signed webhook maps to premium delivery.
      tip4servProductId: '',
      enableCoinPurchase: false,
      coinPrice: 0,
    },
    rewards: [],
  },

  lfg: {
    enabled: true,
    channelId: null,
    maxActivePerUser: 3,
    defaultPlayers: 4,
    // local keeps listings inside this guild; global publishes them to every
    // guild that has LFG enabled and has opted into the global scope.
    scope: 'local',
    staleHours: 24,
  },

  partnerships: {
    enabled: true,
    // Where incoming partnership requests are posted. When unset the bot DMs
    // the target guild owner instead.
    requestChannelId: null,
    // Public announcement channel used in both servers after acceptance.
    // Falls back to channels.broadcasts when unset.
    announcementChannelId: null,
    // Minimum source-guild member count before a request is allowed. 0 = off.
    minMembers: 0,
  },

  staff: {
    applicationsOpen: false,
    panelChannelId: null,
    recruiterRoleIds: [],
    reviewChannelId: null,
    questions: [
      'How old are you?',
      'What timezone are you in?',
      'How many hours per week can you contribute?',
      'What experience do you have moderating a Rust server?',
    ],
  },

  tickets: {
    enabled: true,
    categoryId: null,
    supportRoleIds: [],
    transcriptChannelId: null,
    maxOpenPerUser: 1,
  },

  moderation: {
    enabled: true,
  },

  bounties: {
    enabled: true,
  },

  leaderboards: {
    enabled: true,
  },

  challenges: {
    enabled: true,
  },

  referrals: {
    enabled: true,
  },

  frank: {
    enabled: false,
    channelIds: [],
    answers: [
      // { keywords: ['wipe', 'wiped'], response: 'Wipes happen every Thursday at 19:00 UTC.' }
    ],
  },

  clan: {
    enabled: true,
    maxMembers: 12,
    tagMaxLength: 5,
    createCost: 5000,
    colorsEnabled: true,
    warsEnabled: true,
    friendlyFireProtection: true,
  },

  announcements: {
    // Default Discord destination for scheduled announcements. Each announcement
    // can override it from the panel.
    channelId: null,
    // Wall clock used when an announcement says "20:30". Each announcement can
    // carry its own zone; this is the guild-wide default.
    timezone: 'UTC',
  },

  messages: {
    intervalSeconds: 600,
    rotating: {
      general: ['Welcome to the server!'],
      tips: ['Use /support to open a ticket.'],
    },
    // /rules posts this as an embed with the brand timestamp and footer icon.
    rules: {
      title: 'Rules',
      text: '**Be respectful.** No harassment, hate speech, or spam. **Staff decisions are final** — open a ticket in {support} if you want to appeal one.',
      footer: `© ${new Date().getFullYear()} KOBA GAMES All rights reserved.`,
      channelId: null,
      // Mentioned by {support}. Separate from channels.tickets, which is the
      // parent category used when a ticket channel is created.
      supportChannelId: null,
    },
  },

  events: {
    enabled: true,
    giftIntervalMinutes: 60,
    giftAmount: 100,
    giftChannelId: null,
  },

  misc: {
    autoKitsEnabled: true,
    playtimeCoinsEnabled: true,
    // Kits registered from /kit-panel: [{ name, price, rconCommand, roleId }]
    kits: [],
    // Custom mini-games authored in /game-forge on the dashboard.
    customGames: [],
    orpAppearance: {
      shieldColor: '#14b8a6',
      showOnMap: true,
    },
    leaderboardRefreshSeconds: 300,
  },

  // Per-board, per-period payouts shown on the picture leaderboards. Values are
  // [1st, 2nd, 3rd] coin amounts; empty means the board advertises no prize.
  leaderboardPrizes: {
    enabled: true,
    displayPeriod: 'weekly',
    periods: {
      daily: {},
      weekly: {},
      monthly: {},
      yearly: {},
    },
  },

  giveawayPortal: {
    // Astro Pro subscribers can publish a branded giveaway page. The builder
    // itself is gated by membership, a Pro role or an approved Pro guild plan.
    enabled: true,
    proRoleId: null,
    // Blank falls back to DASHBOARD_PUBLIC_URL (or localhost during setup).
    publicUrl: '',
  },

  checkout: {
    // Paid plans. Checkout happens on the owner's Tip4Serv store; the signed
    // webhook applies the plan to the purchasing guild automatically.
    // proUrl/tip4servProductId remain as the Pro monthly fallback for stores
    // configured before Max and annual billing existed.
    enabled: true,
    proUrl: '',
    serverProUrl: '',
    portalUrl: '',
    supportUrl: '',
    priceLabel: '',
    note: 'Basic is free forever. Pro adds 3 Rust servers, the full game suite, branded hosted giveaways and 90-day analytics. Max adds 5 Discord servers, 10 Rust servers, network telemetry and 365-day analytics. Extra Discord servers are $6/month or $60/year. Manage seats with /plan. Support is the same on every plan.',
    proMonthlyUrl: '',
    proYearlyUrl: '',
    maxMonthlyUrl: '',
    maxYearlyUrl: '',
    tip4servProductId: '',
    proMonthlyProductId: '',
    proYearlyProductId: '',
    maxMonthlyProductId: '',
    maxYearlyProductId: '',
    // One extra Discord server, sold as the same add-on on Pro and Max.
    seatMonthlyUrl: '',
    seatYearlyUrl: '',
    seatMonthlyProductId: '',
    seatYearlyProductId: '',
    membershipDays: 30,
  },

  ads: {
    enabled: false,
    lines: [],
    color: '#8b5cf6',
    size: 12,
    intervalSeconds: 900,
  },

  backup: {
    autoBackupHours: 24,
    lastBackupAt: null,
    lastBackupBy: null,
  },

  settlement: {
    walletTaxPercent: 0,
    wipeSeason: 1,
  },
});

/** Read-only view of the keys a panel may edit. */
export const SETTINGS_ROOT_KEYS = Object.freeze(Object.keys(DEFAULT_GUILD_SETTINGS));
