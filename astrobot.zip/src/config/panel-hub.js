/**
 * Destinations for every control-panel hub.
 *
 * The hubs exist so players, moderators, admins, server owners, Astro staff and
 * superadmins never need to remember slash commands: every panel is reachable
 * from a menu, and the hub handler re-checks the tier before opening a panel.
 */

export const HUB_PLAYER_DESTINATIONS = Object.freeze([
  { id: 'shop', label: 'Shop', emoji: '🛒', description: 'Buy kits, items and coin packs.' },
  { id: 'market', label: 'Marketplace', emoji: '🏪', description: 'Trade items, kits and roles with players.' },
  { id: 'freeroles', label: 'Free roles', emoji: '🎭', description: 'Choose self-assignable roles.' },
  { id: 'player-panel', label: 'Kit claim', emoji: '🎒', description: 'Claim free and purchased kits.' },
  { id: 'play', label: 'Games', emoji: '🎮', description: 'Solo or 1v1 casino games.' },
  { id: 'claim', label: 'Daily rewards', emoji: '🎁', description: 'Streak, crates and daily coins.' },
  { id: 'coins', label: 'Wallet', emoji: '💰', description: 'Balance, bank and transfers.' },
  { id: 'leaderboards', label: 'Leaderboards', emoji: '🏆', description: 'Top players by metric.' },
  { id: 'battle-pass', label: 'Battle pass', emoji: '🎖️', description: 'Tiers, progress and rewards.' },
  { id: 'progression', label: 'Challenges', emoji: '📈', description: 'Badges and milestones.' },
  { id: 'bounty', label: 'Bounties', emoji: '🎯', description: 'Place and claim bounties.' },
  { id: 'team', label: 'Teams', emoji: '🛡️', description: 'Create or join a clan.' },
  { id: 'lfg', label: 'Looking for group', emoji: '🤝', description: 'Find teammates for the next wipe.' },
  { id: 'referral', label: 'Referrals', emoji: '🎟️', description: 'Invite codes and rewards.' },
  { id: 'support', label: 'Support', emoji: '🎫', description: 'Open a private ticket.' },
  { id: 'checkout', label: 'Astro Pro checkout', emoji: '💳', description: 'Plans, membership status and store links.' },
]);

export const HUB_MOD_DESTINATIONS = Object.freeze([
  { id: 'mod', label: 'Moderation', emoji: '🔨', description: 'Cases, warnings, bans and appeals.' },
  { id: 'staff', label: 'Staff panel', emoji: '🛡️', description: 'Applications, reports and staff tools.' },
  { id: 'wipe', label: 'Wipes', emoji: '🧨', description: 'Wipe schedules and countdowns.' },
  { id: 'status', label: 'Server status', emoji: '📡', description: 'Live RCON fleet state and uptime.' },
]);

export const HUB_ADMIN_DESTINATIONS = Object.freeze([
  { id: 'server', label: 'Server management', emoji: '🗄️', description: 'Rust servers, status and wipes.' },
  { id: 'announcements', label: 'Announcements', emoji: '📣', description: 'Schedule Discord and in-game messages.' },
  { id: 'staff', label: 'Staff panel', emoji: '🛡️', description: 'Applications, reports and staff tools.' },
  { id: 'mod', label: 'Moderation', emoji: '🔨', description: 'Cases, warnings and bans.' },
  { id: 'config', label: 'Configuration', emoji: '⚙️', description: 'Every guild setting.' },
  { id: 'shop-admin', label: 'Shop admin', emoji: '🛒', description: 'Currencies, categories and products.' },
  { id: 'shop-manage', label: 'Shop manager', emoji: '📦', description: 'Stock, pricing and product edits.' },
  { id: 'kit-panel', label: 'Kit management', emoji: '🎒', description: 'Register and remove kits.' },
  { id: 'templates', label: 'Templates', emoji: '🧱', description: 'Apply layouts and repair the server.' },
  { id: 'game-setup', label: 'Game setup', emoji: '🎮', description: 'Casino limits and toggles.' },
  { id: 'streak-admin', label: 'Daily rewards setup', emoji: '🎁', description: 'Build your own login streak, rewards and badge.' },
  { id: 'leaderboard-prizes', label: 'Leaderboard prizes', emoji: '🏆', description: 'Set 1st, 2nd and 3rd prizes for each board.' },
  { id: 'license', label: 'Licenses', emoji: '🔑', description: 'Server licenses and plans.' },
  { id: 'analytics', label: 'Analytics', emoji: '📊', description: 'Activity and economy metrics.' },
  { id: 'market-admin', label: 'Marketplace admin', emoji: '🏪', description: 'Fees, treasury and seller analytics.' },
  { id: 'onboarding', label: 'Onboarding', emoji: '👋', description: 'Welcome, verification, roles and giveaways.' },
  { id: 'giveaways', label: 'Giveaways', emoji: '🎁', description: 'Create giveaways and draw winners.' },
  { id: 'polls', label: 'Polls', emoji: '📊', description: 'Create polls and view voter analytics.' },
  { id: 'giveaway-portal', label: 'Giveaway portal', emoji: '⭐', description: 'Customize the Astro Pro giveaway page.' },
  { id: 'wipe', label: 'Wipes', emoji: '🧨', description: 'Wipe schedules and countdowns.' },
  { id: 'status', label: 'Server status', emoji: '📡', description: 'Live RCON fleet state and uptime.' },
]);

export const HUB_OWNER_DESTINATIONS = Object.freeze([
  { id: 'server', label: 'Server management', emoji: '🗄️', description: 'Rust servers, status and wipes.' },
  { id: 'announcements', label: 'Announcements', emoji: '📣', description: 'Schedule Discord and in-game messages.' },
  { id: 'config', label: 'Configuration', emoji: '⚙️', description: 'Every guild setting.' },
  { id: 'onboarding', label: 'Onboarding', emoji: '👋', description: 'Welcome, verification, roles and giveaways.' },
  { id: 'giveaways', label: 'Giveaways', emoji: '🎁', description: 'Create giveaways and draw winners.' },
  { id: 'giveaway-portal', label: 'Giveaway portal', emoji: '⭐', description: 'Subscriber giveaway page and winner setup.' },
  { id: 'polls', label: 'Polls', emoji: '📊', description: 'Polls, automation and voter analytics.' },
  { id: 'checkout', label: 'Checkout', emoji: '💳', description: 'Astro Pro plans and store links.' },
  { id: 'staff', label: 'Staff panel', emoji: '🛡️', description: 'Applications, reports and staff tools.' },
  { id: 'mod', label: 'Moderation', emoji: '🔨', description: 'Cases, warnings and bans.' },
  { id: 'templates', label: 'Templates', emoji: '🧱', description: 'Apply layouts and repair the server.' },
  { id: 'license', label: 'Licenses', emoji: '🔑', description: 'Server licenses and plans.' },
  { id: 'analytics', label: 'Analytics', emoji: '📊', description: 'Activity and economy metrics.' },
  { id: 'market-admin', label: 'Marketplace admin', emoji: '🏪', description: 'Fees, treasury and seller analytics.' },
  { id: 'shop-admin', label: 'Shop admin', emoji: '🛒', description: 'Currencies, categories and products.' },
  { id: 'kit-panel', label: 'Kit management', emoji: '🎒', description: 'Register and remove kits.' },
  { id: 'wipe', label: 'Wipes', emoji: '🧨', description: 'Wipe schedules and countdowns.' },
  { id: 'status', label: 'Server status', emoji: '📡', description: 'Live RCON fleet state and uptime.' },
  { id: 'leaderboard-prizes', label: 'Leaderboard prizes', emoji: '🏆', description: 'Set the prize table for every board.' },
  { id: 'streak-admin', label: 'Daily rewards setup', emoji: '🎁', description: 'Streak rewards and badges.' },
  { id: 'game-setup', label: 'Game setup', emoji: '🎮', description: 'Casino limits and toggles.' },
]);

export const HUB_ASTRO_DESTINATIONS = Object.freeze([
  { id: 'license', label: 'Licenses', emoji: '🔑', description: 'Server licenses, plans and renewals.' },
  { id: 'analytics', label: 'Platform analytics', emoji: '📊', description: 'Activity and economy metrics.' },
  { id: 'status', label: 'Fleet status', emoji: '📡', description: 'Every connected RCON server.' },
  { id: 'market-admin', label: 'Marketplace admin', emoji: '🏪', description: 'Fees, treasury and seller analytics.' },
  { id: 'giveaways', label: 'Giveaways', emoji: '🎁', description: 'Campaign giveaways and draws.' },
  { id: 'giveaway-portal', label: 'Giveaway portal', emoji: '⭐', description: 'Subscriber portal configuration.' },
  { id: 'polls', label: 'Polls', emoji: '📊', description: 'Community polls and analytics.' },
  { id: 'announcements', label: 'Announcements', emoji: '📣', description: 'Platform-wide scheduled messages.' },
  { id: 'templates', label: 'Templates', emoji: '🧱', description: 'Official layout templates.' },
]);

export const HUB_SUPERADMIN_DESTINATIONS = Object.freeze([
  { id: 'dev', label: 'Developer tools', emoji: '🛠️', description: 'Guild approval, licenses and memberships.' },
  { id: 'license', label: 'Licenses', emoji: '🔑', description: 'Every server license and plan.' },
  { id: 'server', label: 'Server management', emoji: '🗄️', description: 'RCON fleet and global servers.' },
  { id: 'config', label: 'Configuration', emoji: '⚙️', description: 'Every guild setting.' },
  { id: 'templates', label: 'Templates', emoji: '🧱', description: 'Layouts and repair tools.' },
  { id: 'announcements', label: 'Announcements', emoji: '📣', description: 'Scheduled Discord and in-game messages.' },
  { id: 'analytics', label: 'Analytics', emoji: '📊', description: 'Platform activity and economy.' },
  { id: 'market-admin', label: 'Marketplace admin', emoji: '🏪', description: 'Fees, treasury and seller analytics.' },
  { id: 'status', label: 'Fleet status', emoji: '📡', description: 'Live server state and uptime.' },
  { id: 'wipe', label: 'Wipes', emoji: '🧨', description: 'Wipe schedules and countdowns.' },
  { id: 'polls', label: 'Polls', emoji: '📊', description: 'Polls and voter analytics.' },
]);

/**
 * Hub id → its destination menu and the tier that may use it. Gating per hub
 * matters because ids such as `polls`, `announcements` and `giveaway-portal`
 * appear in several menus; a single merged map would give them the strictest
 * tier and lock admins out of their own hub.
 */
export const HUB_SETS = Object.freeze({
  hub: { tier: 'player', destinations: HUB_PLAYER_DESTINATIONS },
  'mod-hub': { tier: 'staff', destinations: HUB_MOD_DESTINATIONS },
  'admin-hub': { tier: 'admin', destinations: HUB_ADMIN_DESTINATIONS },
  'owner-hub': { tier: 'admin', destinations: HUB_OWNER_DESTINATIONS },
  'astro-hub': { tier: 'official', destinations: HUB_ASTRO_DESTINATIONS },
  'superadmin-hub': { tier: 'developer', destinations: HUB_SUPERADMIN_DESTINATIONS },
});
