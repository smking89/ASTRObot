/**
 * Canonical regions available on public giveaway entry forms.
 * Stored by id so labels can change without rewriting historical entries.
 */
export const GIVEAWAY_REGIONS = Object.freeze([
  {
    id: 'north-america',
    label: 'North America',
    optionLabel: 'North America (USA & Canada)',
    detail: 'Washington · Dallas · San Jose · Ashburn',
  },
  {
    id: 'europe',
    label: 'Europe',
    optionLabel: 'Europe (UK, Germany, France, Netherlands & EU)',
    detail: 'United Kingdom · Germany · France · Netherlands · EU servers',
  },
  {
    id: 'asia',
    label: 'Asia',
    optionLabel: 'Asia (Singapore, Japan & regional nodes)',
    detail: 'Singapore · Japan · other regional nodes',
  },
  {
    id: 'oceania',
    label: 'Oceania',
    optionLabel: 'Oceania (Australia & surrounding areas)',
    detail: 'Australia · surrounding areas',
  },
  {
    id: 'africa-south-america',
    label: 'Africa & South America',
    optionLabel: 'Africa & South America (South Africa & Brazil)',
    detail: 'South Africa · Brazil · dedicated regional servers',
  },
]);

const REGION_BY_ID = new Map(GIVEAWAY_REGIONS.map((region) => [region.id, region]));

export function giveawayRegion(value) {
  return REGION_BY_ID.get(String(value ?? '').trim().toLowerCase()) ?? null;
}

export function giveawayRegionLabel(value) {
  return giveawayRegion(value)?.label ?? '';
}
