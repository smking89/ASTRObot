import { env } from './env.js';
import { getBranding } from '../db/repositories/branding.js';

/**
 * Branding for embeds, dashboard headers and public pages.
 *
 * The database is the source of truth once /white-label has been used; env
 * values remain the boot/default fallback so an existing deployment keeps its
 * footer logo even before the operator updates the new setting.
 */

let runtimeLogoUrl = '';

function validUrl(value) {
  if (typeof value !== 'string') return '';
  const trimmed = value.trim();
  return /^https?:\/\//i.test(trimmed) ? trimmed : '';
}

export function setBrandLogoUrl(url) {
  runtimeLogoUrl = validUrl(url);
  return runtimeLogoUrl;
}

export function getBrandingConfig() {
  return getBranding();
}

export function getBrandName() {
  return getBranding().name;
}

export function getBrandFaviconUrl() {
  return getBranding().faviconUrl;
}

export function getBrandWordmarkUrl() {
  return getBranding().wordmarkUrl;
}

export function getBrandLogoUrl() {
  return validUrl(getBrandWordmarkUrl()) || validUrl(env.branding.logoUrl) || runtimeLogoUrl;
}

export function getBrandColor() {
  const hex = getBranding().colors.brand;
  const value = Number.parseInt(hex.replace('#', ''), 16);
  return Number.isFinite(value) ? value : 0x8b5cf6;
}

export function getCopyright() {
  const branding = getBranding();
  const base = env.branding.copyright;
  if (branding.name !== 'AstroBot' && base.includes('AstroBot')) {
    return base.replaceAll('AstroBot', branding.name);
  }
  return base;
}

/** Footer text: an optional note followed by the copyright line. */
export function brandFooter(note = null) {
  const copyright = getCopyright();
  if (!note) return copyright;

  const brandName = getBrandName();
  const text = String(note).trim().replaceAll('AstroBot', brandName);
  if (!text) return copyright;
  if (text.includes('©')) return text;
  return `${text} · ${copyright}`;
}
