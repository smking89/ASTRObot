import 'dotenv/config';

/**
 * Reads and validates process.env once at boot.
 * Everything the process needs is exposed here so no module reads env directly.
 */

function str(name, fallback = '') {
  const value = process.env[name];
  return value === undefined || value.trim() === '' ? fallback : value.trim();
}

function int(name, fallback) {
  const value = Number.parseInt(str(name, ''), 10);
  return Number.isFinite(value) ? value : fallback;
}

function bool(name, fallback = false) {
  const value = str(name, '').toLowerCase();
  if (value === '') return fallback;
  return ['1', 'true', 'yes', 'on'].includes(value);
}

function list(name) {
  return str(name, '')
    .split(',')
    .map((entry) => entry.trim())
    .filter(Boolean);
}

export const env = Object.freeze({
  nodeEnv: str('NODE_ENV', 'development'),
  isProduction: str('NODE_ENV', 'development') === 'production',

  discord: Object.freeze({
    token: str('DISCORD_TOKEN'),
    clientId: str('DISCORD_CLIENT_ID'),
    devGuildId: str('DISCORD_DEV_GUILD_ID'),
    developerIds: list('DEVELOPER_IDS'),
    officialGuildId: str('OFFICIAL_GUILD_ID'),
    developerLogChannelId: str('DEVELOPER_LOG_CHANNEL_ID'),
  }),

  databasePath: str('DATABASE_PATH', './data/astrobot.db'),

  // Public origin for links minted by the bot (giveaway portal, docs).
  dashboard: Object.freeze({
    publicUrl: str('DASHBOARD_PUBLIC_URL', 'http://localhost:4173').replace(/\/+$/, ''),
  }),

  // Used to encrypt RCON passwords at rest (AES-256-GCM). Without it, secrets are
  // stored with a `plain:` prefix and the boot log warns loudly.
  encryptionKey: str('BOT_ENCRYPTION_KEY'),

  logging: Object.freeze({
    level: str('LOG_LEVEL', 'info'),
  }),

  runtime: Object.freeze({
    commandTimeoutMs: int('COMMAND_TIMEOUT_MS', 15 * 60 * 1000),
    enableBackgroundJobs: bool('ENABLE_BACKGROUND_JOBS', true),
    // When true, guilds must be approved with /dev guild approve before use.
    enforceGuildApproval: bool('ENFORCE_GUILD_APPROVAL', false),
  }),

  tip4serv: Object.freeze({
    apiKey: str('TIP4SERV_API_KEY'),
    webhookSecret: str('TIP4SERV_WEBHOOK_SECRET'),
    webhookPort: int('TIP4SERV_WEBHOOK_PORT', 8080),
    webhookPath: str('TIP4SERV_WEBHOOK_PATH', '/tip4serv/webhook'),
  }),

  rcon: Object.freeze({
    defaultHost: str('RCON_DEFAULT_HOST'),
    defaultPort: int('RCON_DEFAULT_PORT', 28016),
    reconnectMs: int('RCON_RECONNECT_MS', 15000),
  }),


  branding: Object.freeze({
    // Public https image used as the embed footer icon. Empty falls back to the
    // bot avatar, so uploading the logo as the application icon is enough.
    logoUrl: str('BRAND_LOGO_URL'),
    copyright: str('BRAND_COPYRIGHT', `© ${new Date().getFullYear()} AstroBot. All rights reserved.`),
  }),

  economy: Object.freeze({
    playtimeIntervalMs: int('PLAYTIME_COIN_INTERVAL_MS', 600000),
    playtimeReward: int('PLAYTIME_COIN_REWARD', 25),
    nitroBoosterMultiplier: int('NITRO_BOOSTER_MULTIPLIER', 2),
    deathPenaltyPercent: int('DEATH_PENALTY_PERCENT', 10),
  }),
});

/** Fails fast with an actionable message instead of a stack trace deep in login. */
export function assertRuntimeEnv() {
  const missing = [];
  if (!env.discord.token) missing.push('DISCORD_TOKEN');
  if (!env.discord.clientId) missing.push('DISCORD_CLIENT_ID');

  if (missing.length > 0) {
    throw new Error(
      `Missing required environment variables: ${missing.join(', ')}. ` +
        'Copy .env.example to .env and fill them in.',
    );
  }

  if (env.discord.developerIds.length === 0) {
    // /dev is intentionally unusable without an explicit allowlist.
    console.warn('[env] DEVELOPER_IDS is empty - /dev commands will be inaccessible.');
  }
}
