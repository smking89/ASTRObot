/**
 * AstroBot packaging.
 *
 * Plans are attached to a guild. Basic is free forever; Pro and Max are billed
 * monthly or yearly, and annual billing is two months cheaper than twelve
 * monthly payments. Support is identical on every plan — there is no paid
 * priority queue and no faster-response tier.
 */

export const DAY_MS = 86_400_000;
export const TRIAL_DAYS = 14;
export const ANNUAL_FREE_MONTHS = 2;

/**
 * One add-on price works on both Pro and Max: $6/month or $60/year per extra
 * Discord server. Max already includes five, so this is for Pro seats and for
 * Max networks that outgrow the included five.
 */
export const EXTRA_SERVER_PRICING = Object.freeze({
  monthly: 6,
  yearly: 60,
  monthlyLabel: '$6/mo',
  yearlyLabel: '$60/yr',
  label: '$6/month or $60/year',
});

export const PLAN_IDS = Object.freeze(['basic', 'pro', 'max']);

/** Games every plan can open. Everything else is a Pro/Max entitlement. */
export const CORE_SOLO_GAMES = Object.freeze(['blackjack', 'dice', 'wheel', 'slots', 'crash', 'mines']);
export const CORE_MULTIPLAYER_GAMES = Object.freeze(['dice']);

export const PLAN_CATALOG = Object.freeze({
  basic: Object.freeze({
    id: 'basic',
    label: 'Basic',
    tagline: 'One server getting started',
    prices: Object.freeze({ monthly: 0, yearly: 0 }),
    priceLabels: Object.freeze({ monthly: '$0', yearly: '$0' }),
    limits: Object.freeze({
      discordServers: 1,
      rconServers: 1,
      activeGiveaways: 1,
      hostedGiveawayPages: 0,
      hostedEntrants: 0,
      analyticsDays: 14,
      scheduledTasks: 3,
      // 1 saved template. null means unlimited.
      savedTemplates: 1,
    }),
    features: Object.freeze({
      coreGames: true,
      fullGames: false,
      jackpot: false,
      raffle: false,
      networkEvents: false,
      advancedTelemetry: false,
      networkTelemetry: false,
      hostedPages: false,
      customSubdomain: false,
      pageStyling: false,
      faqStyling: false,
      csvExports: false,
      networkDashboard: false,
      customTemplates: false,
      whiteLabel: false,
    }),
    branding: 'AstroBot branding',
    games: 'Core set: blackjack, dice, wheel, slots, crash, mines',
    rcon: 'Basic live stats and killfeed',
    includes: Object.freeze([
      'Core bot: economy, shop, kits, daily rewards, tickets, moderation, teams, LFG, referrals, polls and onboarding',
      'Core games: blackjack, dice, wheel, slots, crash and mines',
      'Basic live RCON stats and killfeed',
      '1 active Discord giveaway',
      '14 days of analytics',
      '3 scheduled tasks',
      '1 saved server template',
      'AstroBot branding',
    ]),
  }),

  pro: Object.freeze({
    id: 'pro',
    label: 'Pro',
    tagline: 'One growing community',
    prices: Object.freeze({ monthly: 12, yearly: 120 }),
    priceLabels: Object.freeze({ monthly: '$12/mo', yearly: '$120/yr' }),
    limits: Object.freeze({
      discordServers: 1,
      rconServers: 3,
      activeGiveaways: 5,
      hostedGiveawayPages: 1,
      hostedEntrants: 5_000,
      analyticsDays: 90,
      scheduledTasks: 25,
      savedTemplates: null,
    }),
    features: Object.freeze({
      coreGames: true,
      fullGames: true,
      jackpot: true,
      raffle: true,
      networkEvents: false,
      advancedTelemetry: true,
      networkTelemetry: false,
      hostedPages: true,
      customSubdomain: true,
      pageStyling: true,
      faqStyling: true,
      csvExports: true,
      networkDashboard: false,
      customTemplates: false,
      whiteLabel: false,
    }),
    branding: 'Your logo, colours, FAQ and page styling',
    games: 'Full suite + progressive jackpot and raffle',
    rcon: 'Full telemetry, protection and advanced filters',
    includes: Object.freeze([
      'Everything in Basic',
      '3 Rust/RCON servers',
      'Full game suite + progressive jackpot and raffle',
      'Full telemetry, protection and advanced filters',
      '5 active Discord giveaways',
      '1 branded hosted giveaway page with custom subdomain, bonus tasks, FAQ and 5,000 entrants',
      'Logo, colours, FAQ and page styling',
      '90 days of analytics + CSV exports',
      '25 scheduled tasks',
      'Every built-in and saved server template',
    ]),
  }),

  max: Object.freeze({
    id: 'max',
    label: 'Max',
    tagline: 'Networks and multi-server owners',
    prices: Object.freeze({ monthly: 29, yearly: 290 }),
    priceLabels: Object.freeze({ monthly: '$29/mo', yearly: '$290/yr' }),
    limits: Object.freeze({
      discordServers: 5,
      rconServers: 10,
      activeGiveaways: 15,
      hostedGiveawayPages: 5,
      hostedEntrants: 25_000,
      analyticsDays: 365,
      scheduledTasks: 100,
      savedTemplates: null,
    }),
    features: Object.freeze({
      coreGames: true,
      fullGames: true,
      jackpot: true,
      raffle: true,
      networkEvents: true,
      advancedTelemetry: true,
      networkTelemetry: true,
      hostedPages: true,
      customSubdomain: true,
      pageStyling: true,
      faqStyling: true,
      csvExports: true,
      networkDashboard: true,
      customTemplates: true,
      whiteLabel: true,
    }),
    branding: 'Full tenant white-label',
    games: 'Full suite + network events',
    rcon: 'Full telemetry across the network',
    includes: Object.freeze([
      'Everything in Pro',
      'Up to 5 Discord servers on one Max subscription',
      '10 Rust/RCON servers',
      'Full suite + network events',
      'Network telemetry across every linked server',
      '15 active Discord giveaways',
      'Up to 5 hosted giveaway pages with 25,000 entrants each',
      'Full tenant white-label',
      '365 days of analytics + network dashboard',
      '100 scheduled tasks',
      'Every template plus the custom template builder',
    ]),
  }),
});

/** Older rows used `free`, and licenses used `enterprise`. Keep them working. */
export function normalizePlanId(value) {
  const id = String(value ?? '').trim().toLowerCase();
  if (id === 'free' || id === 'basic') return 'basic';
  // Legacy lifetime memberships are Pro access with no expiry.
  if (id === 'pro' || id === 'lifetime') return 'pro';
  if (id === 'max' || id === 'enterprise') return 'max';
  return 'basic';
}

export function planDefinition(value) {
  return PLAN_CATALOG[normalizePlanId(value)];
}

export function isPaidPlan(value) {
  return normalizePlanId(value) !== 'basic';
}

/** null = unlimited. */
export function formatPlanLimit(limit) {
  return limit === null || limit === undefined ? 'Unlimited' : String(limit);
}

export function planPriceLine(planId) {
  const plan = planDefinition(planId);
  if (plan.id === 'basic') return '$0 forever';
  return `${plan.priceLabels.monthly} or ${plan.priceLabels.yearly}`;
}

/** Rows for the pricing comparison table and the landing page. */
export const PLAN_COMPARISON = Object.freeze([
  { label: 'Discord servers', values: ['1', '1', '5'] },
  { label: 'Rust/RCON servers', values: ['1', '3', '10'] },
  { label: 'Core bot', values: ['Included', 'Included', 'Included'] },
  { label: 'Games', values: ['Core set', 'Full suite + jackpot/raffle', 'Full suite + network events'] },
  { label: 'RCON/killfeed', values: ['Basic live stats', 'Full telemetry + filters', 'Network-wide telemetry'] },
  { label: 'Discord giveaways', values: ['1 active', '5 active', '15 active'] },
  { label: 'Hosted giveaway pages', values: ['—', '1 page · 5k entrants', '5 pages · 25k entrants'] },
  { label: 'Branding', values: ['AstroBot', 'Logo, colours & FAQ', 'Full white-label'] },
  { label: 'Analytics', values: ['14 days', '90 days + CSV', '365 days + network'] },
  { label: 'Scheduled tasks', values: ['3', '25', '100'] },
  { label: 'Server templates', values: ['1', 'All templates', 'All + custom'] },
]);
