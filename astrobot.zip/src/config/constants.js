/**
 * Shared constants. Access tiers live in core/permissions.js; only presentation
 * and protocol constants belong here.
 */

export const COMPONENT_PREFIX = 'ab';

/** Hard limits imposed by Discord, mirrored so the loader can validate early. */
export const DISCORD_LIMITS = Object.freeze({
  commandNameMax: 32,
  commandDescriptionMax: 100,
  subcommandsPerParent: 25,
  subcommandGroupsPerParent: 25,
  optionsPerCommand: 25,
  embedFieldValueMax: 1024,
  embedDescriptionMax: 4096,
  buttonLabelMax: 80,
  selectOptionsMax: 25,
});

export const COLORS = Object.freeze({
  brand: 0x8b5cf6,
  success: 0x22c55e,
  warning: 0xf59e0b,
  danger: 0xef4444,
  info: 0x38bdf8,
  neutral: 0x2b2d31,
  gold: 0xfbbf24,
  bank: 0x14b8a6,
});

export const EMOJI = Object.freeze({
  coin: '🪙',
  bank: '🏦',
  wallet: '👛',
  kill: '💀',
  shield: '🛡️',
  clock: '⏱️',
  passport: '🪪',
  team: '🤝',
  lfg: '📣',
  trophy: '🏆',
  game: '🎮',
  shop: '🛒',
  lock: '🔒',
  check: '✅',
  cross: '❌',
});

/** Panel identifiers used as interaction routing keys. */
export const PANELS = Object.freeze({
  config: 'config',
  set: 'set',
  server: 'server',
  team: 'team',
  lfg: 'lfg',
  coins: 'coins',
  referral: 'referral',
  leaderboards: 'leaderboards',
  staff: 'staff',
  mod: 'mod',
  dev: 'dev',
  license: 'license',
  play: 'play',
  claim: 'claim',
  shop: 'shop',
  battlePass: 'battle-pass',
  progression: 'progression',
  support: 'support',
  cardStyle: 'card-style',
  kitPanel: 'kit-panel',
  playerPanel: 'player-panel',
  shopMint: 'shop-mint',
  gameForge: 'game-forge',
  bounty: 'bounty',
});

export const TIME = Object.freeze({
  second: 1000,
  minute: 60_000,
  hour: 3_600_000,
  day: 86_400_000,
  week: 604_800_000,
});

export const WEEKDAYS = Object.freeze([
  'sunday',
  'monday',
  'tuesday',
  'wednesday',
  'thursday',
  'friday',
  'saturday',
]);

/** Where the bot points users for the web dashboards referenced by /game-forge. */
export const WEB_BASE_URL = process.env.WEB_BASE_URL?.trim() || 'https://astrobot.gg';

/** Passed as a bitfield to every reply that must stay private to the caller. */
export const EPHEMERAL = 1 << 6;
